"""Execute shipped difficulty/round callbacks and challenge arithmetic.

Native boundaries are deterministic; this does not substitute for KK playtests.
"""
from pathlib import Path
import re
from types import SimpleNamespace
from validate_economy import World, body, SCRIPT, rawcode

CASES = 0


def check(condition, label):
    global CASES
    assert condition, label
    CASES += 1


def world():
    w = World()
    w.events = []
    w.victories = []
    w.groups_destroyed = []
    w.current = None
    w.g.update({
        'PLAYER_NEUTRAL_PASSIVE': 15,
        'GetTriggeringTrigger': lambda: 100,
        'GetPlayersAll': lambda: tuple(range(6)),
        'GetClickedButtonBJ': lambda: 900,
        'GetTriggerUnit': lambda: w.current,
        'GetEnumUnit': lambda: w.current,
        'GetRectCenter': lambda rect: 0,
        'GetUnitState': lambda u, state: getattr(u, state),
        'SetUnitState': lambda u, state, amount: setattr(u, state, amount),
        'SetUnitLifePercentBJ': lambda u, percent: setattr(u, 'life', u.maximum * percent / 100.0),
        'UNIT_STATE_MAX_LIFE': 'maximum',
        'ConvertUnitState': lambda state: {18:'attack',20:'attack'}.get(state, state),
        'GetUnitStateSwap': lambda state, u: getattr(u, state),
        'SetPlayerHandicapBJ': lambda player, value: w.events.append(('handicap', player, value)),
        'GetEnumPlayer': lambda: w.g.get('_enum', 0),
        'Condition': lambda callback: callback,
        'ForGroupBJ': lambda group, callback: None,
        'CreateTimer': lambda: 200,
        'TimerStart': lambda *args: None,
        'GetLastCreatedTextTag': lambda: 500,
        'DestroyTextTag': lambda tag: None,
        'CreateTextTagLocBJ': lambda *args: None,
        'CustomVictoryBJ': lambda player, *args: w.victories.append(player),
        'DisableTrigger': lambda trigger: w.events.append(('disabled', trigger)),
        'ShowUnit': lambda unit, flag: w.events.append(('shop', unit, flag)),
        'DestroyGroup': lambda group: w.groups_destroyed.append(group),
        'LoadGroupHandle': lambda table, parent, key: w.tables[table].get((parent,key)),
        'CountPlayersInForceBJ': lambda force: 0,
        'ForcePickRandomPlayer': lambda force: 0,
        'GetUnitLevel': lambda u: 1,
        'DisplayTimedTextToForce': lambda *args: w.events.append(('text',args[-1])),
        'DisplayTextToForce': lambda *args: w.events.append(('text',args[-1])),
    })
    def force(players, callback):
        for player in players:
            w.g['_enum'] = player
            callback()
    w.g['ForForce'] = force
    for name in re.findall(r'^function (HopeChallenge_\w+)', SCRIPT, re.M):
        # Enemy module owns its own object/AI tests; do not execute that boundary.
        if name in ('HopeChallenge_SetRoster','HopeChallenge_EnemyCast'):
            continue
        w.load(name)
    return w


def install_callback(w, name):
    callback_body = body(name)[3]
    # These are engine/UI boundaries only. Helpers under test are loaded above.
    for called in re.findall(r'\b([A-Za-z_]\w*)\(', callback_body):
        if called not in w.g:
            w.g[called] = lambda *args: None
    for called in re.findall(r'\bfunction ([A-Za-z_]\w*)', callback_body):
        if called not in w.g:
            w.g[called] = lambda *args: None
    w.load(name)


def test_difficulty_callback():
    for mode, hp, gold, lumber in ((1,100.,150,3),(2,120.,100,2),(3,150.,50,1),(4,200.,0,1),(5,250.,0,1),(6,250.,0,1)):
        w = world()
        w.g['udg_Guaiwu_dwz'] = []
        for name in ('Trig____________________006Func002Func002A','Trig____________________006Func003Func002A','Trig____________________006Func004Func004A','Trig____________________006Func005Func004A'):
            w.load(name)
        w.g['Trig____________________006Func006A'] = lambda: w.events.append(('create hero', w.g['_enum']))
        w.tables['YDHT'][900,0x340FE72] = mode
        install_callback(w, 'Trig____________________006Actions')
        w.g['Trig____________________006Actions']()
        check(w.g['udg_Yx_Nd_Dj'] == mode, f'mode {mode}: actual dialog callback sets selected mode')
        check(w.g['udg_diren_xueliang'] == hp, f'mode {mode}: base monster health')
        check(all(w.resources[p,'gold'] == gold and w.resources[p,'lumber'] == lumber for p in range(6)), f'mode {mode}: starting resources apply once to all players')
        check(sum(event[0] == 'create hero' for event in w.events) == 6, f'mode {mode}: original hero init still runs once each')
        if mode >= 5:
            check(w.g['udg_ND_sz'] == 5, 'New mode free/paid growth rolls share difficulty penalty')
            check(w.tables['YDLOC'][300,0xFBEDEC54] == .5, 'New mode initial hero growth uses same .5 penalty')
        else:
            check(w.g['udg_ND_sz'] == 0, 'Existing modes preserve original growth behavior')
    dialog = body('Trig____________________003Actions')[3]
    check('炼狱（5轮）' in dialog and '无限挑战（无限轮）' in dialog, 'Both modes appear in existing synchronized difficulty dialog')
    check(dialog.count('call DialogAddButtonBJ(') == 6, 'Exactly six difficulty choices')
    original = (Path(__file__).parent/'war3map.j').read_text()
    check(body('Trig__________________________037Actions')[3] == body('Trig__________________________037Actions', original)[3], 'Timeout/default difficulty path unchanged')


def test_round_callback():
    for mode, terminal in ((0,3),(1,3),(2,3),(3,4),(4,4),(5,5),(6,None)):
        w = world()
        w.g['udg_Yx_Nd_Dj'] = mode
        w.g['udg_Guaiwu_sl'] = 9
        w.g['gg_unit_n019_0032'] = 'second_A'
        w.g['gg_unit_n01C_0003'] = 'second_B'
        install_callback(w, 'Trig_X_____________004Actions')
        for finished in range(1, 21 if mode == 6 else terminal + 1):
            w.g['Trig_X_____________004Actions']()
            check(w.g['udg_quanshu'] == finished, f'mode {mode}: round counter advances to {finished}')
            expected = 6 if terminal is not None and finished >= terminal else 0
            check(len(w.victories) == expected, f'mode {mode}: no premature victory after {finished} rounds')
            check(w.g['udg_boci'] == 1, f'mode {mode}: new round restarts at room 1')
            if mode >= 5:
                check(w.g['udg_Guaiwu_sl'] <= 12, f'mode {mode}: capped base count preserves 13 spawn positions')
        shops = [event for event in w.events if event[0] == 'shop']
        check(shops == [('shop','second_A',True),('shop','second_B',True)], f'mode {mode}: second promotion buildings open exactly at round 3')
        if mode == 6:
            check(not any(event[0] == 'disabled' for event in w.events), 'Infinite challenge never disables the round transition')
    w = world()
    w.g['udg_Yx_Nd_Dj'] = 6
    for completed in (4,5,6,10,20,100,21475,1000000,2000000000):
        w.g['udg_quanshu'] = completed
        check(not w.g['HopeChallenge_Won'](), 'Infinite has no scripted maximum round or victory boundary')


def test_scaling_and_cleanup():
    w = world()
    for mode in range(7):
        w.g['udg_Yx_Nd_Dj'] = mode
        for completed in (0,1,4,10,20,100,21475,1000000):
            u = SimpleNamespace(maximum=1000., life=50., attack=40.)
            w.g['udg_quanshu'] = completed
            w.tables['YDHT'][id(u),0x3449D65E] = .1*completed
            w.g['HopeChallenge_ScaleEnemy'](u)
            if mode < 5:
                check(u.maximum == 1000. and u.attack == 40. and u.life == 50., 'New mode scaler does not alter older modes')
            else:
                expected_hp = min(1e7,1000.*(1.+.3*completed)+100.*completed)
                expected_atk = min(1e6,40.*(1.+.12*completed))
                check(abs(u.maximum-expected_hp)<1e-5 and abs(u.attack-expected_atk)<1e-5, 'Enemy scaling is linear in completed rounds and numerically bounded')
                check(u.life == u.maximum and 0. <= w.tables['YDHT'][id(u),0x3449D65E] <= .65, 'New enemies spawn full with magic resistance capped below immunity')
                before = (u.maximum,u.attack)
                w.g['HopeChallenge_ScaleEnemy'](u)
                check((u.maximum,u.attack)==before, 'Repeated entry cannot compound scaling')
                # Fresh handle deliberately retains reference to prevent Python id reuse.
            w.tables['YDHT'].clear()
        w.g['udg_quanshu'] = 4
        points = w.g['HopeChallenge_BossPoints']()
        check(points == (10 if mode>=5 else 5+mode), 'New modes share difficulty-equivalent boss points, old rewards unchanged')
        w.g['udg_quanshu'] = 1000000
        if mode>=5:
            check(w.g['HopeChallenge_BossPoints']()==25, 'Endless boss reward cannot grow without bound')
    for mode in (4,5,6):
        w.g['udg_Yx_Nd_Dj'] = mode
        node=SimpleNamespace()
        links=object()
        w.tables['YDHT'][id(node),0xB5EB8DB8]=links
        before=len(w.groups_destroyed)
        w.g['HopeChallenge_ReleaseNode'](node)
        check(len(w.groups_destroyed)==before+(mode>=5), 'Route link groups released before removing nodes in extended runs')
    spawn = body('Trig_G_____________004Actions')[3]
    check(spawn.index('HopeChallenge_ScaleEnemy')<spawn.index('$3FBE7059'), 'Intent attack snapshot is taken after new challenge scaling')
    cleanup = body('Trig_X_____________004Func001A')[3]
    check(cleanup.index('HopeChallenge_ReleaseNode')<cleanup.index('call RemoveUnit('), 'Route group cleanup occurs before unit removal')
    check(body('CreateUnitsForPlayer11')[3].count('set u=CreateUnit(')==13, 'The real map contains exactly 13 spawn markers')


def test_turn_identity():
    w=world()
    for mode in range(7):
        w.g['udg_Yx_Nd_Dj']=mode
        w.g['udg_quanshu']=123
        w.g['udg_boci']=9
        w.g['udg_huihe_s']=15
        w.g['HopeChallenge_TurnSerial']=90
        before=w.g['HopeChallenge_TurnToken']()
        w.g['HopeChallenge_NextTurn']()
        after=w.g['HopeChallenge_TurnToken']()
        if mode<5:
            check(before==after==12309015, 'Old modes preserve previous per-round token')
        else:
            check((before,after)==(90,91), 'New mode token advances with actual turn independent of room arithmetic')
            w.g['udg_quanshu']=1000000
            w.g['udg_huihe_s']=100000
            check(w.g['HopeChallenge_TurnToken']()==91, 'Large round/turn displays cannot overflow or alias ability token')
    w.g['HopeChallenge_TurnSerial']=2000000000
    for key in ('HopeMeditation_LastCast','HopeHidden_LastHeal','HopeHidden_LastDrain','HopeJob_LastCast'):
        for i in range(1,7):
            w.g[key][i]=1
    w.g['HopeChallenge_NextTurn']()
    check(w.g['HopeChallenge_TurnSerial']==1, 'Serial itself resets safely before integer overflow')
    check(all(w.g[key][i]==-1 for key in ('HopeMeditation_LastCast','HopeHidden_LastHeal','HopeHidden_LastDrain','HopeJob_LastCast') for i in range(1,7)), 'Serial reset clears all dependent skill locks for six players')
    for name in ('HopeMeditation_Apply','HopeHidden_Cast','HopeJob_Cast'):
        check('HopeChallenge_TurnToken()' in body(name)[3], name+' uses unified token')
    check(body('Trig______________0001Actions')[3].count('call HopeChallenge_NextTurn()')==1, 'Real combat turn callback advances serial exactly once')


if __name__=='__main__':
    test_difficulty_callback()
    test_round_callback()
    test_scaling_and_cleanup()
    test_turn_identity()
    print(f'Challenge modes: {CASES} assertions passed (actual shipped JASS callbacks; no KK runtime).')
