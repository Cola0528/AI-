"""v12: public fate-event ledger and inventory-safe grants."""
import re,textwrap
from modern_choices_patch import block,replace
from hidden_objects import read_slk,raw_value,update_section

PASSIVE_ITEMS=('I01A','I01I','I01J','I03A')

def edit_slk(path,changes):
    lines,rows,heads,objects=read_slk(path)
    for alias,fields in changes.items():
        y,row=objects[alias]
        for key,value in fields.items():
            assert key in heads,key
            row[heads[key]]=raw_value(value)
    # Normalize explicit coordinates to safely add formerly absent cells.
    prefix=[l for l in lines if not l.startswith('C;') and l!='E']
    prefix=[re.sub(r';X\d+',f';X{max(heads.values())}',l) if l.startswith('B;') else l for l in prefix]
    cells=[f'C;X{x};Y{y};K{v}' for y,row in sorted(rows.items()) for x,v in sorted(row.items())]
    path.write_text('\r\n'.join(prefix+cells+['E'])+'\r\n',encoding='utf-8')

INVENTORY='''function HopeInventory_Put takes unit receiver,item it returns boolean
local integer i=GetPlayerId(GetOwningPlayer(receiver))+1
local unit helper=null
if it==null or GetItemTypeId(it)==0 or receiver==null then
return false
endif
if UnitAddItem(receiver,it) then
return true
endif
// A pickup/combine callback may already have consumed the item.
if GetItemTypeId(it)==0 or IsItemOwned(it) then
return true
endif
if i>=1 and i<=6 and (receiver==udg_hero[i] or receiver==udg_Bei_bao_danwei[i]) then
set helper=udg_Bei_bao_danwei[i]
if receiver==helper then
set helper=udg_hero[i]
endif
if helper!=null and GetUnitTypeId(helper)!=0 and UnitAddItem(helper,it) then
call DisplayTimedTextToPlayer(GetOwningPlayer(receiver),0,0,4.,"背包已满：装备已转入另一背包。")
set helper=null
return true
endif
endif
if GetItemTypeId(it)!=0 and not IsItemOwned(it) then
call SetItemPosition(it,GetUnitX(receiver),GetUnitY(receiver))
call DisplayTimedTextToPlayer(GetOwningPlayer(receiver),0,0,5.,"两个背包均无空位：装备已放在领取单位脚下。")
endif
set helper=null
return false
endfunction
function HopeInventory_Give takes integer id,unit receiver returns item
local item it=CreateItem(id,GetUnitX(receiver),GetUnitY(receiver))
call HopeInventory_Put(receiver,it)
set bj_lastCreatedItem=it
set it=null
return bj_lastCreatedItem
endfunction
'''
G='''integer HopeEvent_Count=0
integer HopeEvent_Sequence=0
integer HopeEvent_Start=0
string array HopeEvent_Line
integer HopeEvent_Seen=0
integer HopeEvent_Offset=0
boolean HopeEvent_Open=false
integer HopeEvent_Panel=0
integer HopeEvent_Body=0
integer HopeEvent_Status=0
integer HopeEvent_Button=0
'''
EARLY='''function HopeEvent_Add takes string text returns nothing
local integer a=0
local integer b=0
local integer n=StringLength(text)
loop
exitwhen b>n
if b==n or SubString(text,b,b+2)=="|n" then
if b>a then
set HopeEvent_Line[ModuloInteger(HopeEvent_Count,512)]=SubString(text,a,b)
set HopeEvent_Count=HopeEvent_Count+1
endif
set b=b+2
set a=b
else
set b=b+1
endif
endloop
endfunction
function HopeEvent_Begin takes nothing returns nothing
set HopeEvent_Sequence=HopeEvent_Sequence+1
set HopeEvent_Start=HopeEvent_Count
call HopeEvent_Add("|cffd2b879问号事件 #"+I2S(HopeEvent_Sequence)+" · 全队可见|r")
endfunction
'''
UI='''function HopeEvent_Close takes nothing returns nothing
set HopeEvent_Open=false
endfunction
function HopeEvent_Show takes nothing returns nothing
set HopeEvent_Open=true
call HopeLayout_Focus(14)
endfunction
function HopeEvent_Move takes integer delta returns nothing
set HopeEvent_Offset=IMaxBJ(IMaxBJ(0,HopeEvent_Count-512),IMinBJ(IMaxBJ(HopeEvent_Start,HopeEvent_Count-13),HopeEvent_Offset+delta))
endfunction
function HopeEvent_Up takes nothing returns nothing
call HopeEvent_Move(-3)
endfunction
function HopeEvent_Down takes nothing returns nothing
call HopeEvent_Move(3)
endfunction
function HopeEvent_Enter takes nothing returns nothing
set HopeScroll_Hover=3
endfunction
function HopeEvent_Refresh takes nothing returns nothing
local string text=""
local integer j=0
if HopeEvent_Panel==0 then
return
endif
if HopeEvent_Seen!=HopeEvent_Sequence then
set HopeEvent_Seen=HopeEvent_Sequence
set HopeEvent_Offset=HopeEvent_Start
set HopeEvent_Open=true
call HopeLayout_Focus(14)
endif
set j=IMaxBJ(IMaxBJ(0,HopeEvent_Count-512),HopeEvent_Offset)
loop
exitwhen j>=HopeEvent_Count or j>=HopeEvent_Offset+13
if text!="" then
set text=text+"|n"
endif
set text=text+HopeEvent_Line[ModuloInteger(j,512)]
set j=j+1
endloop
call HopeJob_SetText(HopeEvent_Body,text)
call HopeJob_SetText(HopeEvent_Status,"各自关闭 · "+I2S(HopeEvent_Offset+1)+"-"+I2S(j)+"/"+I2S(HopeEvent_Count)+"行")
endfunction
function HopeEvent_Create takes nothing returns nothing
local integer f=0
local integer viewport=0
set HopeEvent_Panel=HopeQoL_Surface("HopeEventPanel",.244,.505,.312,.228)
set f=HopeQoL_Label("HopeEventTitle",HopeEvent_Panel,.010,-.008,.244,.019,"问号事件 · 全队记录")
set f=HopeQoL_Button("HopeEventClose",HopeEvent_Panel,.258,-.007,.044,.021,"关闭")
call HopeQoL_Bind(f,function HopeEvent_Close,false)
set viewport=HopeQoL_Button("HopeEventViewport",HopeEvent_Panel,.010,-.035,.292,.153,"")
call DzFrameSetScriptByCode(viewport,2,function HopeEvent_Enter,false)
call DzFrameSetScriptByCode(viewport,3,function HopeScroll_Leave,false)
set HopeEvent_Body=HopeQoL_Label("HopeEventBody",viewport,.005,-.004,.282,.145,"")
call DzFrameSetFont(HopeEvent_Body,"Fonts\\\\FRIZQT__.TTF",.0085,0)
set f=HopeQoL_Button("HopeEventUp",HopeEvent_Panel,.010,-.196,.036,.023,"上")
call HopeQoL_Bind(f,function HopeEvent_Up,false)
set f=HopeQoL_Button("HopeEventDown",HopeEvent_Panel,.050,-.196,.036,.023,"下")
call HopeQoL_Bind(f,function HopeEvent_Down,false)
set HopeEvent_Status=HopeQoL_Label("HopeEventStatus",HopeEvent_Panel,.092,-.201,.210,.016,"")
call DzFrameSetFont(HopeEvent_Status,"Fonts\\\\FRIZQT__.TTF",.008,0)
set HopeEvent_Button=HopeQoL_Button("HopeEventEntry",DzGetGameUI(),.160,.222,.100,.021,"问号事件")
call HopeQoL_Bind(HopeEvent_Button,function HopeEvent_Show,false)
call HopeJob_ShowFrame(HopeEvent_Panel,false)
endfunction
'''

def wrap_message(line):
    # Event literals are plain Chinese text; names/color codes are dynamic and
    # get their own line. Split only on complete Python Unicode code points.
    line=line.replace('call DisplayTextToForce(GetPlayersAll(),','call HopeEvent_Add(',1)
    line=line.replace('GetPlayerName(GetEnumPlayer()))+','GetPlayerName(GetEnumPlayer()))+"|n"+')
    line=line.replace(',$48656946)))+',',$48656946)))+"|n"+')
    line=line.replace(',$192409FE)))+',',$192409FE)))+"|n"+')
    while re.search(r'"([^"\n]*)"\+"([^"\n]*)"',line):
        line=re.sub(r'"([^"\n]*)"\+"([^"\n]*)"',lambda m:'"'+m[1]+m[2]+'"',line)
    def wrap(m):
        txt=m[1]
        if len(txt)<26 or '|c' in txt:return m[0]
        return '"'+'|n'.join('|n'.join(textwrap.wrap(part,26,break_long_words=True,break_on_hyphens=False)) for part in txt.split('|n'))+'"'
    return re.sub(r'"([^"\n]*)"',wrap,line)

def apply(src):
    src=src.replace('globals\n','globals\n'+G,1)
    anchor=re.search(r'^function \w+',src,re.M).start()
    src=src[:anchor]+INVENTORY+EARLY+src[anchor:]
    # Equipment rewards, crafted items, and lottery sword. Keep relic-holder,
    # profession token and explicit transfer operations unchanged.
    count=0
    lines=src.splitlines()
    for i,l in enumerate(lines):
        if 'call UnitAddItemByIdSwapped(' in l and ('udg_hero[' in l or 'LoadInteger(YDLOC,' in l and 'GetTriggerUnit()' in l or '$49303456,u)' in l):
            lines[i]=l.replace('UnitAddItemByIdSwapped','HopeInventory_Give');count+=1
    assert count==5,count
    src='\n'.join(lines)+'\n'
    assert src.count('call UnitAddItem(caster,it)')==1
    src=src.replace('call UnitAddItem(caster,it)','call HopeInventory_Put(caster,it)',1)
    src=src.replace('圣剑（物品；背包满时落在英雄脚下）','圣剑（英雄满包转入助手；都满才落地）')
    # Potion pickup stays a single grant, including starting/free potion grants.
    name='Trig____________________035_______uActions'
    old=block(src,name)
    new='''function Trig____________________035_______uActions takes nothing returns nothing
local player p=GetOwningPlayer(GetTriggerUnit())
local integer i=GetPlayerId(p)+1
local integer aid=0
local unit u=null
if i>=1 and i<=6 then
set u=udg_hero[i]
if u==null and IsUnitType(GetTriggerUnit(),UNIT_TYPE_HERO) then
set u=GetTriggerUnit()
endif
set udg_Yaoshui_shenyu_cs[i]=udg_Yaoshui_shenyu_cs[i]+1
set aid=LoadInteger(YDHT,i,$3FB1F9E0)
if u!=null and aid!=0 then
call YDWESetUnitAbilityDataString(u,aid,1,218,"药水剩余次数："+I2S(udg_Yaoshui_shenyu_cs[i]))
endif
call DisplayTextToPlayer(p,0,0,"药水可用次数+1 当前剩余次数："+I2S(udg_Yaoshui_shenyu_cs[i]))
endif
call RemoveItem(GetManipulatedItem())
set u=null
set p=null
endfunction'''
    src=src.replace(old,new,1)
    # Every outcome in the fate event and its team callbacks enters one common
    # deterministic ledger; no DisplayTextToForce remains in this event family.
    for name in re.findall(r'^function (Trig____________________018\w*) takes',src,re.M):
        f=block(src,name)
        f='\n'.join(wrap_message(l) if 'call DisplayTextToForce(GetPlayersAll(),' in l else l for l in f.splitlines())
        if name=='Trig____________________018Actions':
            marker='if LoadBoolean(YDHT,GetHandleId(GetOwningPlayer(GetTriggerUnit())),$1551575)==false then'
            assert marker in f
            f=f.replace(marker,marker+'\ncall HopeEvent_Begin()',1)
        if name=='Trig____________________018Func004Func023Func002A':
            f=f.replace('LoadInteger(YDLOC,GetHandleId(GetTriggeringTrigger())*LoadInteger(YDLOC,GetHandleId(GetTriggeringTrigger()),$ECE825E7),$877546F4)','GetConvertedPlayerId(GetEnumPlayer())')
        src=replace(src,name,f)
    # Remove repeated-use chat too, with a local flag consumed by Refresh.
    src=src.replace('call DisplayTextToPlayer(GetOwningPlayer(GetTriggerUnit()),0,0,"你已经选择过命运了")','if GetOwningPlayer(GetTriggerUnit())==GetLocalPlayer() then\nset HopeEvent_Open=true\ncall HopeLayout_Focus(14)\nendif')
    message='call DisplayTextToForce(GetPlayersAll(),"你们随机到了特殊小怪关卡，小怪会有数次复活机会")'
    assert message in src
    src=src.replace(message,'call HopeEvent_Begin()\ncall HopeEvent_Add("特殊小怪关卡|n小怪有数次复活机会，请留意再次出现的敌人。")')
    refresh=block(UI,'HopeEvent_Refresh').replace('HopeJob_SetText','DzFrameSetText')
    src=src.replace('function HopeLayout_Mode takes',refresh+'\nfunction HopeLayout_Mode takes',1)
    src=src.replace('function HopeV8_Init takes',UI.replace(block(UI,'HopeEvent_Refresh'),'')+'\nfunction HopeV8_Init takes',1)
    src=src.replace('call HopeDraw_Create()','call HopeDraw_Create()\ncall HopeEvent_Create()',1)
    f=block(src,'HopeLayout_Focus').replace('set HopeChoice_Hidden=true','if view!=14 then\nset HopeEvent_Open=false\nendif\nset HopeChoice_Hidden=true')
    src=replace(src,'HopeLayout_Focus',f)
    f=block(src,'HopeLayout_Mode').replace('if HopeQoL_Expanded then','if HopeEvent_Open then\nreturn 14\nendif\nif HopeQoL_Expanded then')
    src=replace(src,'HopeLayout_Mode',f)
    f=block(src,'HopeLayout_Apply').replace('local integer mode=HopeLayout_Mode()','local integer mode=0')
    f=f.replace('call HopeLayout_Show(HopeQoL_StatsButton,dock)','call HopeEvent_Refresh()\nset mode=HopeLayout_Mode()\nset dock=active and mode<10\ncall HopeLayout_Show(HopeEvent_Panel,mode==14)\ncall HopeLayout_Show(HopeEvent_Button,dock and HopeEvent_Count>0)\ncall HopeLayout_Show(HopeQoL_StatsButton,dock)')
    src=replace(src,'HopeLayout_Apply',f)
    f=block(src,'HopeScroll_Capturing').replace('if HopeScroll_Hover==1 then','if HopeScroll_Hover==3 then\nreturn HopeEvent_Open\nelseif HopeScroll_Hover==1 then')
    src=replace(src,'HopeScroll_Capturing',f)
    # Early scrolling helper cannot call later UI function: move arithmetic here.
    f=block(src,'HopeScroll_Move').replace('\nif target==1 then','\nif target==3 then\nset HopeEvent_Offset=IMaxBJ(IMaxBJ(0,HopeEvent_Count-512),IMinBJ(IMaxBJ(HopeEvent_Start,HopeEvent_Count-13),HopeEvent_Offset+delta))\nelseif target==1 then')
    src=replace(src,'HopeScroll_Move',f)
    return src

def apply_objects(root,output):
    changes={a:{'usable':0} for a in PASSIVE_ITEMS}
    changes['phea']={'abilList':'_','powerup':1,'class':'PowerUp','droppable':0,'pawnable':0}
    edit_slk(output/'Units_ItemData.slk',changes)
    p=output/'Units_itemstrings.txt';s=p.read_text()
    s=update_section(s,'phea',{'Description':'立即补充1次药水使用次数，不占背包格。','Ubertip':'购买后立即补充1次药水使用次数。|n英雄与助手满包时仍可购买；价格仍为200金币。|n不直接恢复生命，不额外触发原生药水效果。'})
    for a in PASSIVE_ITEMS:
        m=re.search(r'^\['+a+r'\]\n(.*?)(?=^\[|\Z)',s,re.M|re.S)
        desc=re.search(r'^Ubertip=(.*)$',m[1],re.M)[1].strip('"')
        s=update_section(s,a,{'Ubertip':desc+'|n被动装备，无需左键使用。'})
    p.write_text(s,encoding='utf-8')
