"""v15: seventeen deliberately different awakenings and their real bonuses."""

# Keep original class rawcodes: level, inventory, learned skills and unit-keyed
# state survive awakening. Names are set on each hero instance using KK natives.
DESIGNS = {
'H008': dict(id='AT01', mode='passive', skill='铁壁反攻', role='盾防蓄甲 · 护甲转盾击', art='BTNDefend', bonus={'str':10,'hp':100,'def':8},
 desc='使用盾防嘲讽，额外获得力量×40%/60%/80%的护甲。|n剑盾猛攻的基础伤害额外加上当前护甲×40%/60%/80%。|n鼓励先护队蓄甲，再用盾击进攻；不额外消耗行动点。'),
'H00D': dict(id='AT02', mode='passive', skill='骑势蓄锋', role='冲锋蓄势 · 接续重击', art='BTNKnight', bonus=dict(str=8,agi=8,ap=1),
 desc='每次成功使用骑兵冲锋后蓄势，下一次平砍基础伤害提高35%/55%/75%。|n蓄势不叠加，发动下一次平砍时消耗；原冲锋速度加成继续生效。|n每场战斗开始清除蓄势。'),
'N017': dict(id='AT03', mode='active', skill='圣域回响', role='群体救治 · 溢疗护甲 · 魔力支援', art='BTNHolyBolt', bonus=dict(int=12,mp=8,regen=2),
 desc='全体存活队友恢复自身生命上限20%+施法者智力。|n溢出治疗的50%转为护甲，每人最多获得施法者智力×50%护甲。|n每位队友实际恢复2点魔法，不超过上限。|n消耗2行动点、3魔法；战斗中每回合一次。'),
'N01G': dict(id='AZ36', mode='active', skill='万法归一', role='全属性战辅 · 全队护持 · 补满气', art='BTNMagicImmunity', bonus={'str':8,'agi':8,'int':8,'def':6,'hp':60},
 desc='对当前全体敌人造成三围总和×1.1的法术伤害。|n全体存活队友恢复三围总和×0.25生命，并获得三围总和×0.10护甲。|n自身气补至3层，可继续用渡厄击救助或护心诀护队。|n消耗2行动点、3魔法；战斗中每回合一次。'),
'N018': dict(id='AT05', mode='passive', skill='影舞续刃', role='连斩续航 · 行动回收', art='BTNWindWalkOn', bonus=dict(agi=12,ap=1,critd=.25),
 desc='每回合成功使用连斩累计3/2/2次时，返还1行动点；每回合只返还一次。|n3级同时恢复2点魔法，不超过上限，为连斩追加段续航。|n只统计消耗了行动点的连斩，潜袭多段不会重复触发。'),
'N01F': dict(id='AT06', mode='active', skill='破绽处决', role='单点斩杀 · 击杀回点 · 精准投掷', art='BTNWarden', bonus=dict(agi=10,ap=1,dex=3,prec=.2),
 desc='选择一名当前敌人，造成（力量+敏捷）×4的物理伤害。|n目标当前生命不高于40%时，伤害提高50%。|n本次击杀目标后返还1行动点，不超过行动点上限。|n消耗2行动点、3魔法；战斗中每回合一次。'),
'E00S': dict(id='AT07', mode='passive', skill='游击齐射', role='多目标箭雨 · 副箭追击', art='BTNArcher', bonus=dict(agi=14,ap=1,dex=2),
 desc='成功使用射箭时，向主目标以外最多1/2/2名当前敌人各追加一支副箭。|n每支副箭基础伤害=敏捷×1.2/1.2/1.6，属于物理技能伤害。|n副箭不触发更多副箭，原弩手多目标效果保留。'),
'E010': dict(id='AT08', mode='active', skill='贯城重弩', role='直线贯穿 · 主箭重创 · 站位取舍', art='BTNGlaiveThrower', bonus=dict(str=12,agi=10,final=.2),
 desc='以所选敌人为方向，射出长2000、宽240的贯穿重弩。|n主目标基础物理伤害=攻击力×4+力量×2；射线内其他敌人各受主伤害的70%。|n只打击当前敌人，每个敌人仅命中一次，不命中射线外或身后的敌人。|n消耗2行动点、3魔法；战斗中每回合一次。'),
'H004': dict(id='AT09', mode='passive', skill='持续压制', role='三段连射 · 连续命中递增', art='BTNClusterRockets', bonus=dict(agi=10,ap=1,crit=10,skill=.15),
 desc='同一回合连续对同一个当前敌人造成伤害时，从第二次起逐次增加10%/15%/20%伤害，最多叠3层。|n更换目标或进入新回合后重新累计；三段连射可逐段叠加。|n伤害未生效不叠层，额外段不生成新的攻击。'),
'H00E': dict(id='AT10', mode='active', skill='绝命狙击', role='弹匣管理 · 必中重狙 · 单体爆发', art='BTNRifleman', bonus=dict(agi=16,prec=.3,critd=.4),
 desc='消耗1发现有子弹，对一名当前敌人造成攻击力×6+敏捷×3的物理伤害。|n没有普通狙击的30%落空；不附带群伤。|n已有精确打击时消耗它并乘以精确打击倍率；爆头的必暴效果可正常作用于本次射击。|n空弹时不能施放，请用Q装填。|n消耗2行动点、3魔法；战斗中每回合一次。'),
'N016': dict(id='AT11', mode='active', skill='寒霜封界', role='区域冰封 · 削弱敌人下一击', art='BTNBlizzard', bonus=dict(int=12,mp=12,regen=2,skill=.15),
 desc='对所选敌人周围450范围内当前敌人造成智力×3的法术伤害，并施加冰封。|n每名被冰封敌人下一次对英雄造成的伤害降低40%，随后解除。|n冰封不叠加，重复施放只刷新；下一场战斗开始清除旧标记。|n消耗2行动点、3魔法；战斗中每回合一次。'),
'N01E': dict(id='AT12', mode='passive', skill='余烬引爆', role='火球蓄种 · 炎爆引燃', art='BTNIncinerate', bonus=dict(int=14,spell=.3,crit=10),
 desc='每次成功施放火球，为该目标叠加自己来源的1层火种，最多3层。|n炎爆术消耗主目标自己的全部火种，基础伤害每层额外增加智力×0.8/1.2/1.6。|n增强伤害沿用炎爆的主伤害和半伤范围规则；队友火种互不消耗。|n每场战斗开始清除旧火种。'),
'O004': dict(id='AT13', mode='active', skill='血毒沸腾', role='自身毒层引爆 · 血战恢复', art='BTNEnvenomedSpear', bonus=dict(str=12,hp=80,ap=1),
 desc='选择中了自己毒矛的当前敌人，立即结算相当于自身2次毒伤基值的伤害。|n基值=当前攻击力×30%×自身毒层数×毒矛等级×2。|n不消耗毒层，不触发额外叠毒或推进敌方回合；自身恢复生命上限10%。|n消耗2行动点、3魔法；战斗中每回合一次，无自己的毒层不能施放。'),
'O006': dict(id='AT14', mode='passive', skill='战意连环', role='多段连斩 · 连击转续航', art='BTNHealingWave', bonus=dict(str=10,agi=10,hp=80,ap=1),
 desc='每回合累计对当前敌人造成3次有效伤害，恢复自身（力量+敏捷）×20%/30%/40%的生命。|n超过缺失生命的部分转为等额护甲；可在同一回合重复触发。|n连斩追加段和乱斩各段分别累计；回复不会生成新的伤害。'),
'N01A': dict(id='AT15', mode='passive', skill='背水狂怒', role='低血强攻 · 狂暴重砍', art='BTNBerserkForTrolls', bonus=dict(str=18,crit=15,critd=.35),
 desc='重砍基础伤害额外提高：已损失生命比例×40%/60%/80%。|n血量越低重砍越强，满血时没有此项增幅。|n保留狂暴力量、重砍修炼和原伤害浮动；不主动扣除自己的生命。'),
'O005': dict(id='AT16', mode='active', skill='围猎号令', role='全队集火 · 悬赏掠夺', art='BTNRaider', bonus=dict(str=10,agi=10,ap=1,skill=.15),
 desc='标记一名当前敌人，其后受到我方英雄的3次有效伤害提高25%。|n每次消耗标记时，造成伤害的玩家获得10金币；同一次伤害只结算一次悬赏。|n标记不能叠层，重复施放刷新至3次；下一场战斗开始清除。|n消耗1行动点、3魔法；战斗中每回合一次。'),
'HZ03': dict(id='AT17', mode='passive', skill='万象三律', role='全属性轮转 · 三式贯通', art='BTNSpellBreaker', bonus=dict(str=5,agi=5,int=5,skill=.15),
 desc='同一回合成功使用三相打击Q、三相回元D、万象汲取V各至少一次后，返还1行动点并恢复三围总和×8%/12%/16%的生命。|n技能顺序不限，同一种技能不会重复计数；每回合只触发一次。|n满血无法施放回元时不计数；恢复不超过生命上限。'),
}

BONUS_NAMES = {'str':'力量','agi':'敏捷','int':'智力','hp':'生命上限','mp':'魔法上限','def':'防御动作额外护甲','regen':'每回合回蓝','ap':'行动点上限','dex':'专注上限','crit':'暴击率','critd':'暴击伤害','prec':'精确打击加成','final':'最终伤害','skill':'技能伤害','spell':'法术伤害'}
PERCENT = {'critd','prec','final','skill','spell'}


def bonus_text(d):
    return '，'.join(BONUS_NAMES[k]+' +'+(str(round(v*100))+'%' if k in PERCENT else str(v)+('%' if k=='crit' else '')) for k,v in d['bonus'].items())


def description(d):
    suffix = '|n初始1级，可在泉水转职窗口研习至3级，每次消耗1技能点；使用原有及后续升级获得的技能点。' if d['mode']=='passive' else ('' if d['id'] in ['AT03','AT16'] else '|n伤害按技能倍率结算；法术另计法伤，暴击、最终伤害和目标减伤按原战斗规则结算。')
    return d['desc']+suffix


def update_options(opts):
    for o in opts:
        if o['stage']!=3:
            continue
        d=DESIGNS[o['target']]
        o['bonus']=d['bonus'].copy()
        o['role']=d['role']
        title=d['skill']+('（可升级被动）' if d['mode']=='passive' else '（Z）')
        o['skills']='保留二转战斗技能与已学修炼。|n|n|cffd2b879'+title+'|r|n'+description(d)
        o['passive']='三转专属奖励：'+bonus_text(d)+'。|n|n'+('觉醒被动：'+d['skill']+'。|n'+description(d) if d['mode']=='passive' else '专属主动：'+d['skill']+'，按Z使用。')+'|n三转奖励只发放一次。'
