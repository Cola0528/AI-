"""Execute shipped UI constructors and resize callbacks; inspect real frame boxes.

This records Warcraft frame native calls, not a Warcraft rendering substitute.
Optional PNGs visualize the captured geometry and text for manual review.
"""
from pathlib import Path
from dataclasses import dataclass
from itertools import combinations
import math,re,sys
from validate_economy import translate
from validate_v8_ui import UIWorld
from validate_economy import body,SCRIPT

CASES=0
@dataclass
class Frame:
 name:str;parent:int;x:float;y:float;w:float;h:float;text:str='';visible:bool=True;kind:str='label';font:float=.0095;font_path:str='Fonts\\ZiTi.ttf'

def check(ok,msg):
 global CASES
 assert ok,msg
 CASES+=1

class Layout(UIWorld):
 def __init__(self):
  super().__init__();self.frames={};self.ids={};self.nextid=1000;self.engine=99999
  self.g.update({
   'DzGetGameUI':lambda:self.engine,
   'HopeQoL_Surface':lambda n,x,y,w,h:self.add(n,0,x,y,w,h,'','panel',False),
   'HopeQoL_Label':lambda n,p,x,y,w,h,t:self.add(n,p,x,y,w,h,t,'label'),
   'HopeQoL_Button':lambda n,p,x,y,w,h,t:self.add(n,p,x,y,w,h,t,'button'),
   'HopeQoL_Fill':lambda n,p,x,y,t:self.add(n,p,x,y,.120,.003,'','bar'),
   'DzFrameSetAbsolutePoint':self.absolute,'DzFrameSetPoint':self.relative,
   'DzFrameSetSize':self.size,'DzFrameClearAllPoints':lambda f:None,
   'DzFrameShow':self.show,'DzFrameSetText':self.text,'DzFrameSetFont':self.font,
   'HopeJob_SetText':self.text,'HopeJob_ShowFrame':self.show,
   'HopeQoL_Bind':lambda *a:None,'CreateTrigger':lambda:1,
   'GetExpiredTimer':lambda:1,'DestroyTimer':lambda t:None,
   'CreateTimer':lambda:1,'TimerStart':lambda *a:None,
   'DzFrameSetScriptByCode':lambda *a:None,'SubString':lambda s,a,b:s.encode('utf-8',errors='surrogateescape')[a:b].decode('utf-8',errors='surrogateescape'),'DzFrameSetTexture':lambda *a:None,'GetLocalPlayer':lambda:0,
   'EVENT_PLAYER_UNIT_SELECTED':1,'TriggerRegisterPlayerUnitEvent':lambda *a:None,
   'TriggerAddAction':lambda *a:None,'HopeConsole_Init':lambda:None,
   'DzCreateFrameByTagName':lambda typ,n,p,*a:self.add(n,p,0,0,.020,.020,'','art'),
   'HopeChoice_HasPending':lambda:False,
   'HopeChoice_LootPending':lambda:False,
   'HopeRoute_Title':lambda n:'小游戏关卡','HopeRoute_Description':lambda n:'完成本次小游戏。|n地图标识对应当前目的地。',
   'HopeGift_Name':lambda i:'木材礼包','HopeGift_Chance':lambda i:15,
   'HopeGift_Effect':lambda i:'木材 +1',
  })
  names=['HopeQoL_CreateUI','HopeArchive_CreateUI','HopeGift_CreateUI','HopeRelic_CreateUI','HopeGrowth_CreateUI','HopeJob_CreateUI','HopeModern_Create','HopeRoute_CreateExtra','HopeDraw_Create','HopeDamage_Create','HopeEvent_Create']
  helpers=['HopeLayout_Place','HopeLayout_Show','HopeLayout_Focus','HopeLayout_Mode','HopeLayout_Apply','HopeLayout_Init','HopeLayout_Choice','HopeLayout_Assignment','HopeRoute_Active','HopeRoute_Host','HopeRoute_Leader','HopeRoute_Valid','HopeRoute_RewardPending','HopeRoute_AllReady','HopeRoute_Status','HopeChoice_PendingForPlayer','HopeRoute_UpdateUI','HopeModern_Refresh','HopeSkill_Original','HopeCompact_RText','HopeCompact_RRefresh','HopeScroll_Add','HopeScroll_View','HopeScroll_Move','HopeEvent_Refresh','HopeEvent_Add','HopeEvent_Begin','HopeEvent_Move','HopeEvent_Close','HopeEvent_Show']
  for name in names+helpers:
   for ref in re.findall(r'\bfunction (\w+)',body(name)[3]):
    self.g.setdefault(ref,lambda *a:None)
   self.load(name)
  self.g['HopeQoL_CreateUI']()
  self.g['HopeGrowth_CreateUI']();self.g['HopeJob_CreateUI']();self.g['HopeModern_Create']()
  self.g['HopeRoute_CreateExtra']();self.g['HopeDraw_Create']();self.g['HopeDamage_Create']();self.g['HopeEvent_Create']()
  # Original archive/relic buttons are created in the cloud-load trigger. Run
  # its actual button-construction slice without fetching/writing cloud data.
  old=body('Trig_______SD_017Actions')[3]
  for name,field in [('HopeSave','HopeLayout_Save'),('HopeRelic','HopeLayout_Relic')]:
   assert f'HopeQoL_Button("{name}"' in old
   self.g[field]=self.add(name,0,.025,.208,.035,.024,'存档' if name=='HopeSave' else '遗物','button')
  self.g['HopeLayout_Init']()
  assignments='\n'.join(re.findall(r'''^set HopeJob_\w+\[\d+\]=(?:".*"|'[^']+'|\d+(?:\.\d*)?|true|false)$''',SCRIPT,re.M))
  exec(translate('LayoutJobData','function LayoutJobData takes nothing returns nothing\n'+assignments+'\nendfunction'),self.g)
  self.g['LayoutJobData']()
  self.g.update({'HopeJob_InRoom':lambda p:True,'HopeJob_AdvancedOpen':lambda:False,
   'HopeJob_InPanel':lambda index,i:index<8 or index==24,'HopeJob_Blocker':lambda index,p:'',
   'HopeReclass_Can':lambda i:False,'HopeJob_Round':lambda:1,'HopeJob_WoodCost':lambda i:30,
   'GetUnitName':lambda u:'冒险者','HopeJob_Entry':1,
   'HopeJob_LastType':self.g['GetUnitTypeId'](self.g['udg_hero'][1]),'HopeJob_Selected':-1})
  self.load('HopeJob_RefreshContent','HopeDamage_Value','HopeDamage_Refresh','HopeDraw_Mine','HopeDraw_Teammates','HopeDraw_BuildTeam')
  self.colors={i:i for i in range(12)}
  self.g['GetPlayerColor']=lambda p:self.colors[p]
  for idx,color in re.findall(r'set YDWEBase__yd_PlayerColor\[(\d+)\]="([^"]+)"',SCRIPT):
   self.g['YDWEBase__yd_PlayerColor'][int(idx)]=color
  self.load('YDWEGetPlayerColorString')
  self.load('HopeGrowth_Refresh','HopeGift_Refresh','HopeGift_State','HopeGift_OwnedCount','HopeGift_DrawCost',
   'HopeGift_Name','HopeGift_Chance','HopeGift_Effect','HopeArchive_Refresh','HopeArchive_Ability',
   'HopeArchive_Effect','HopeArchive_Price','HopeRelic_Refresh','HopeRelic_Name','HopeRelic_Description',
   'HopeRelic_DescriptionPages','HopeRelic_IconPath','HopeDraw_Refresh')
  self.g.update({'HopeArchive_Count':lambda p,i:3,'HopeArchive_Total':lambda p:30,
   'HopeArchive_NewCount':lambda p:10,'HopeRelic_Total':lambda p:44,
   'HopeRelic_Owned':lambda p,i:True,'HopeRelic_State':lambda p,i:'取得 1 次'})
  self.g['HopeGrowth_UIReady']=True;self.g['HopeArchive_UIReady']=True;self.g['HopeGift_UIReady']=True;self.g['HopeRelic_UIReady']=True
  for f in self.frames.values():
   if f.parent==0 and f.kind in ('panel','button'):f.visible=False
  self.shot=Path('/workspace/outputs/ui-layout-v10');self.shot.mkdir(exist_ok=True)
 def add(self,n,p,x,y,w,h,t='',kind='label',visible=True):
  self.nextid+=1;f=self.nextid
  self.frames[f]=Frame(n,0 if p==self.engine else p,x,y,w,h,t,visible,kind,.009 if kind=='button' else .0095);self.ids[n]=f;return f
 def absolute(self,f,a,x,y):
  if f in self.frames:self.frames[f].parent=0;self.frames[f].x=x;self.frames[f].y=y
 def relative(self,f,a,p,b,x,y):
  if f in self.frames:self.frames[f].parent=0 if p==self.engine else p;self.frames[f].x=x;self.frames[f].y=y
 def size(self,f,w,h):
  if f in self.frames:self.frames[f].w=w;self.frames[f].h=h
 def show(self,f,v):
  if f in self.frames:self.frames[f].visible=bool(v)
 def text(self,f,t):
  if f in self.frames:self.frames[f].text=t or ''
 def font(self,f,path,size,flags):
  if f in self.frames:self.frames[f].font=size;self.frames[f].font_path=path
 def rect(self,f):
  v=self.frames[f];x,y=v.x,v.y
  if v.parent:
   a,b,_,_=self.rect(v.parent);x+=a;y+=b
  return x,y,v.w,v.h
 def visible(self,f):
  v=self.frames[f]
  return v.visible and (v.parent==0 or self.visible(v.parent))
 def roots(self):return [i for i,f in self.frames.items() if f.parent==0 and self.visible(i) and f.kind in ('panel','button')]
 def audit(self,label):
  roots=self.roots()
  for f in roots:
   x,y,w,h=self.rect(f)
   check(x>=0 and x+w<=.8+1e-6 and y<=.585 and y-h>=.163-1e-6,(label,'screen bounds',self.frames[f]))
  def overlap(a,b):
   x,y,w,h=self.rect(a);xx,yy,ww,hh=self.rect(b)
   return min(x+w,xx+ww)-max(x,xx)>1e-5 and min(y,yy)-max(y-h,yy-hh)>1e-5
  for a,b in combinations(roots,2):check(not overlap(a,b),(label,'root overlap',self.frames[a].name,self.frames[b].name,self.rect(a),self.rect(b)))
  for f,v in self.frames.items():
   if not v.parent or not self.visible(f) or v.kind not in ('label','button','bar'):continue
   _,_,w,h=self.rect(v.parent)
   check(v.x>=-.0001 and v.x+v.w<=w+.0001 and v.y<=.0001 and -v.y+v.h<=h+.0001,(label,'child outside parent',v,self.frames[v.parent]))
  byparent={}
  for f,v in self.frames.items():
   if v.parent and self.visible(f) and v.kind in ('label','button','bar'):byparent.setdefault(v.parent,[]).append(f)
  for ids in byparent.values():
   for a,b in combinations(ids,2):check(not overlap(a,b),(label,'children overlap',self.frames[a].name,self.frames[b].name))
 def render(self,label,save=True):
  from PIL import Image,ImageDraw,ImageFont
  scale=2400;img=Image.new('RGB',(1920,1440),'#202a29');d=ImageDraw.Draw(img)
  d.rectangle((0,scale*.44,1920,1440),fill='#39342d')
  fontpath=getattr(self,'font_path','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
  def strip(t):return re.sub(r'\|c[0-9a-fA-F]{8}|\|r','',t).replace('|n','\n')
  def wrap(text,font,width):
   lines=[]
   for line in text.split('\n'):
    acc=''
    for c in line:
     if acc and d.textlength(acc+c,font=font)>width:lines.append(acc);acc=c
     else:acc+=c
    lines.append(acc)
   return lines
  for f,v in self.frames.items():
   if not self.visible(f):continue
   x,y,w,h=self.rect(f);xx=x*scale;yy=(.6-y)*scale;ww=w*scale;hh=h*scale
   if v.kind in ('panel','button','bar'):
    d.rectangle((xx,yy,xx+ww,yy+hh),fill={'panel':'#101414','button':'#222528','bar':'#60b9a0'}[v.kind],outline='#877954',width=1)
   if v.text:
    font=ImageFont.truetype(fontpath,round(v.font*scale));lines=wrap(strip(v.text),font,ww-(6 if v.kind=='button' else 0))
    lineheight=v.font*scale*1.25
    if v.kind=='button':
     ty=yy+(hh-lineheight*len(lines))/2
     for line in lines:d.text((xx+(ww-d.textlength(line,font=font))/2,ty),line,font=font,fill='#d8c185',anchor='lt');ty+=lineheight
    else:
     for n,line in enumerate(lines):
      color='#e4e5e4'
      if v.name in ('HopeDamageText','HopeEventBody','HopeDrawText'):
       rawlines=v.text.split('|n')
       found=re.search(r'\|c[0-9a-fA-F]{2}([0-9a-fA-F]{6})',rawlines[min(n,len(rawlines)-1)])
       if found:color='#'+found[1]
      d.text((xx,yy+n*lineheight),line,font=font,fill=color,anchor='lt')
    check(len(lines)*lineheight<=hh+2,(label,'text overflow',v.name,len(lines),hh,lineheight,strip(v.text)))
  d.text((400,1380),'布局审查图 · 脚本坐标模拟，不是 KK 实机截图',font=ImageFont.truetype(fontpath,22),fill='#cccccc')
  if save:img.save(self.shot/(label+'.png'))


def run():
 w=Layout();g=w.g
 for count in range(1,7):
  w.playing=set(range(count));w.human=set(range(count))
  for i in range(count):
   w.hero(i);g['HopeRoute_Ready'][i]=True
  g['udg_boci']=1;g['HopeRoute_Node']=w.node();g['HopeRoute_Depth']=1;g['HopeRoute_Chapter']=0
  g['HopeRoute_UpdateUI']();g['HopeLayout_Apply']()
  for i in range(1,7):
   if i>count:g['udg_hero'][i]=None
   else:g['HopeDamage_Total'][i]=1000.*i;g['udg_Shuchu_dm_tj'][i]=10.*i
  g['HopeDamage_Refresh']()
  w.show(g['HopeQoL_Hud'],True)
  for name,txt in [('HopeQoLLife','生命 140/140'),('HopeQoLMana','魔法 25/26'),('HopeQoLResources','行动 3/4 专注 5/3'),('HopeQoLStatus','F 启用专注|n背包 0/6 · 助手 0/6')]:w.text(w.ids[name],txt)
  w.audit('party'+str(count))
  if count in (1,6):w.render('party'+str(count))
 g['GetPlayerName']=lambda p:'WWWWWWWWWWWWWWWWWW'
 for i in range(1,7):g['udg_Shuchu_dm_tj'][i]=999999999.
 g['HopeRoute_UpdateUI']();g['HopeDamage_Refresh']();w.audit('long-names');w.render('long-names')
 g['GetPlayerName']=lambda p:'Player '+str(p)
 # Required dialog types, exact actual constructors and per-kind positioning.
 for kind,count in [('difficulty',6),('upgrade',4),('rskill',2)]:
  g['HopeChoice_PlayerPending'][0]=1;g['HopeRoute_UpdateUI']();w.show(g['HopeQoL_Hud'],False)
  g['HopeChoice_DialogCount']=1;g['HopeChoice_Dialog'][1]=201;g['HopeChoice_Owner'][1]=0;g['HopeChoice_DialogPending'][1]=True;g['HopeChoice_Hidden']=False
  g['udg_Youxi_ND_XZ']=201 if kind=='difficulty' else 202
  g['udg_Rskill_shifoutihuan'][1]=201 if kind=='rskill' else 203
  g['LoadInteger'](g['HopeModern_Data'],201,0)
  g['SaveInteger'](g['HopeModern_Data'],201,0,count)
  g['SaveStr'](g['HopeModern_Data'],201,100,{'difficulty':'选择难度','upgrade':'升级选择','rskill':'替换 R 技能'}[kind])
  captions={'difficulty':['简单','普通','困难','极难','炼狱（5轮）','无限挑战（无限轮）'],'upgrade':['[B] 每回合防御 +6','[C] 全属性 +3','[D] 最终伤害 +5%','放弃选择'],'rskill':['是','否（不退还所消耗金钱和木材）']}[kind]
  for j,t in enumerate(captions,1):g['SaveStr'](g['HopeModern_Data'],201,j,t)
  g['SaveInteger']('YDHT',201,0xD59B01E6,int.from_bytes(b'A01H','big'));g['GetAbilityName']=lambda a:'冥想'
  g['HopeModern_Refresh']();g['HopeLayout_Apply']()
  w.audit(kind);w.render(kind)
  if kind=='difficulty':check(w.frames[g['HopeModern_Panel'][1]].w*w.frames[g['HopeModern_Panel'][1]].h<.41*.45*.4,'difficulty less than40%old area')
 g['HopeChoice_DialogPending'][1]=False;g['HopeChoice_Hidden']=True
 g['HopeChoice_PlayerPending'][0]=0
 for count in (1,2,6):
  w.playing=set(range(count));g['HopeRoute_Assigning']=True
  for i in range(6):w.show(g['HopeRoute_AssignButton'][i+1],i<count)
  g['HopeLayout_Assignment']();g['HopeLayout_Apply']();w.audit('assign'+str(count));w.render('assign'+str(count))
 g['GetPlayerName']=lambda p:'WWWWWWWWWWWWWWWWWW'
 g['HopeLayout_Assignment']();w.audit('long-assignment');w.render('long-assignment')
 g['GetPlayerName']=lambda p:'Player '+str(p)
 g['HopeRoute_Assigning']=False
 w.show(g['HopeQoL_Hud'],True);g['HopeRoute_UpdateUI']()
 # Independent battle panels and the compact HUD restore control.
 g['HopeLayout_Apply']();w.show(g['HopeRoute_Panel'],False)
 w.show(g['HopeTurn_Panel'],True);w.text(g['HopeTurn_Text'],'队友已完成，等待你|n剩余 4 行动点')
 w.show(g['HopeIntent_Panel'],True);w.size(g['HopeIntent_Panel'],.224,.1968)
 w.show(g['HopeIntent_Status'],True);w.size(g['HopeIntent_Status'],.208,.1408)
 w.text(g['HopeIntent_Title'],'虚空摄政 · 下次行动');w.text(g['HopeIntent_Text'],'群体伤害与削蓝')
 w.text(g['HopeIntent_Status'],'|n'.join('持续效果 '+str(i) for i in range(11)))
 w.audit('battle');w.render('battle')
 w.show(g['HopeQoL_Hud'],False);w.show(g['HopeQoL_Restore'],True);w.audit('collapsed-hud')
 w.show(g['HopeQoL_Restore'],False);w.show(g['HopeQoL_Hud'],True);g['HopeRoute_UpdateUI']()
 flags=['HopeQoL_Expanded','HopeArchive_Expanded','HopeGift_Expanded','HopeRelic_Expanded','HopeJob_Expanded','HopeRoute_PickerOpen','HopeDraw_Open','HopeRoute_Details']
 g['HopeRoute_AvailableCount']=6;g['udg_Youxi_xzgq']=w.node()
 for i,flag in zip([1,2,3,4,5,6,7,9],flags):
  g[flag]=True;g['HopeLayout_Focus'](i);check(sum(bool(g[x]) for x in flags)==1,'focus clears other overlay requests')
  if i==5:g['HopeJob_RefreshContent']()
  if i==2:g['HopeArchive_Refresh']()
  if i==3:g['HopeGift_Refresh']()
  if i==4:g['HopeRelic_Refresh']()
  if i==6:
   for j in range(1,7):w.text(g['HopeRoute_NodeButton'][j],str(j)+'. 小游戏关卡')
  if i==7:
   g['HopeDraw_Count'][0]=1;g['HopeDraw_Page']=1
   g['SaveStr'](g['HopeDraw_History'],0,2,'十连抽 · 648金币')
   g['SaveStr'](g['HopeDraw_History'],0,3,'|n'.join(str(j)+'. 技能伤害+10% / 法术伤害+10%' for j in range(1,11)))
   g['HopeDraw_Refresh']()
  if i==9:g['HopeRoute_UpdateUI']()
  g['HopeLayout_Apply']();w.audit('optional'+str(i))
  w.render('optional'+str(i))
 for i in range(44):
  g['HopeRelic_Expanded']=True;g['HopeLayout_Focus'](4)
  g['HopeRelic_Selected']=i;g['HopeRelic_Page']=i//6
  for page in range(g['HopeRelic_DescriptionPages'](i)):
   g['HopeRelic_DetailPage']=page;g['HopeRelic_Refresh']();g['HopeLayout_Apply']()
   w.render(f'relic-{i}-{page}',False)
 g['HopeGrowth_Pending'][0]=True;g['HopeChoice_PlayerPending'][0]=1;g['HopeChoice_Hidden']=False
 g['HopeRoute_UpdateUI']()
 g['HopeGrowth_Refresh']();g['HopeLayout_Apply']();w.audit('growth');w.render('growth')
 g['HopeChoice_Hidden']=True;g['HopeLayout_Apply']();w.show(g['HopeChoice_Button'],True)
 w.audit('folded-growth');w.render('folded-growth')
 g['HopeGrowth_Pending'][0]=False;g['HopeChoice_PlayerPending'][0]=0;w.show(g['HopeChoice_Button'],False)
 # Execute actual attribute text construction, with native combat values mocked.
 stats=body('HopeQoL_RefreshContent')[3]
 stats=stats[stats.index('if HopeQoL_Expanded then'):stats.rindex('set u=null')]
 stats=stats.rsplit('endif',1)[0]
 native={'GetUnitState':lambda u,k:100.,'ConvertUnitState':lambda k:k,
  'GetHeroStr':lambda u,b:999,'GetHeroAgi':lambda u,b:999,'GetHeroInt':lambda u,b:999,
  'HopeQoL_Number':lambda n:str(round(n,1))}
 g.update(native)
 code='function LayoutStats takes nothing returns nothing\nlocal unit u=udg_hero[1]\nlocal integer p=1\nlocal real armor=0.\nlocal integer hi=0\nlocal integer lo=0\nlocal string detail=""\nlocal string reduction=""\n'+stats+'\nendfunction'
 exec(translate('LayoutStats',code),g)
 g['HopeQoL_Expanded']=True;g['HopeLayout_Focus'](1);g['LayoutStats']();g['HopeLayout_Apply']()
 w.audit('attributes');w.render('attributes')
 # All generated profession descriptions must fit, including late stages.
 g['HopeJob_Expanded']=True;g['HopeLayout_Focus'](5)
 g['HopeJob_InPanel']=lambda index,owner:index==g['HopeJob_Selected']
 for chosen in range(g['HopeJob_Count']):
  g['HopeJob_Selected']=chosen
  for page in range(3):
   g['HopeJob_Page']=page
   count=1 if page==0 else g['HopeJob_SkillCount' if page==1 else 'HopeJob_PassiveCount'][chosen]
   for detail in range(count):
    g['HopeJob_DetailPage']=detail;g['HopeJob_RefreshContent']();g['HopeLayout_Apply']()
    w.render(f'job-{chosen}-{page}-{detail}',False)
 g['HopeReclass_Can']=lambda i:True;g['HopeJob_Page']=0;g['HopeJob_Selected']=24
 g['HopeJob_RefreshContent']();g['HopeLayout_Apply']();w.render('reclass')
 print('PASS:',CASES,'layout assertions: actual constructors,1-6players,three dialog types,1/2/6 assignment,8modal modes; bounds,intersections,text fit.')

if __name__=='__main__':run()
