"""Distinct third promotions and research with real hero skill points."""
from pathlib import Path
import re
from modern_choices_patch import block, replace
from third_design import DESIGNS, description

ROOT=Path(__file__).parent
G='''hashtable HopeThird_Data=null
integer array HopeThird_Ability
boolean array HopeThird_Passive
boolean array HopeThird_Cavalry
integer array HopeThird_ComboToken
integer array HopeThird_ComboCount
boolean array HopeThird_ComboPaid
integer array HopeThird_PressureToken
integer array HopeThird_Pressure
unit array HopeThird_PressureTarget
integer array HopeThird_HitsToken
integer array HopeThird_Hits
integer array HopeThird_HiddenToken
integer array HopeThird_HiddenMask
unit array HopeThird_FireTarget
'''

RESEARCH='''function HopeThird_StudyBlock takes integer index,player owner returns string
local integer p=GetPlayerId(owner)+1
if p<1 or p>6 or index<0 or index>=HopeJob_Count then
return "无效研习。"
endif
if not HopeJob_Awakened[p] or HopeJob_AwakenOption[p]!=index or not HopeThird_Passive[index] or udg_hero[p]==null then
return "该研习不属于当前三转职业。"
endif
if not HopeJob_InRoom(owner) then
return "请回到原泉水房间研习。"
endif
if HopeRoute_RewardPending(p-1) then
return "请先完成待选奖励。"
endif
if HopeThird_Level(udg_hero[p])>=3 then
return "三转被动已满级（3级）。"
endif
if HopeThird_Level(udg_hero[p])<1 then
return "尚未获得三转被动。"
endif
if GetHeroSkillPoints(udg_hero[p])<1 then
return "技能点不足；每次研习消耗1技能点，后续升级可继续获得技能点。"
endif
return ""
endfunction
function HopeThird_Study takes integer index,player owner returns nothing
local integer p=GetPlayerId(owner)+1
local integer level=0
local string reason=HopeThird_StudyBlock(index,owner)
if reason!="" then
call DisplayTimedTextToPlayer(owner,0,0,4.,reason)
return
endif
set level=HopeThird_Level(udg_hero[p])
call UnitModifySkillPoints(udg_hero[p],-1)
if SetUnitAbilityLevel(udg_hero[p],HopeThird_Ability[index],level+1)!=level+1 then
call UnitModifySkillPoints(udg_hero[p],1)
call DisplayTimedTextToPlayer(owner,0,0,4.,"研习未完成，技能点已退还。")
return
endif
call DisplayTimedTextToPlayer(owner,0,0,4.,"三转被动提升至 "+I2S(level+1)+"/3 级；技能点 -1。")
endfunction
function HopeJob_GoldCost takes integer index returns integer
if index>=0 and index<HopeJob_Count and HopeJob_Stage[index]==3 then
return 1000
endif
return 0
endfunction
'''

UNLOCK='''function HopeThird_Unlock takes integer index,integer p returns nothing
local unit u=udg_hero[p]
local integer aid=HopeThird_Ability[index]
local integer old='AZ31'
loop
exitwhen old>'AZ36'
if old!=aid then
call UnitRemoveAbility(u,old)
endif
set old=old+1
endloop
call UnitAddAbility(u,aid)
call SetUnitAbilityLevel(u,aid,1)
call UnitMakeAbilityPermanent(u,true,aid)
set u=null
endfunction
'''


def apply(src, opts):
    src=src.replace('globals\n','globals\n'+G,1)
    src=src.replace('function HopeSkill_InitIds takes', (ROOT/'third_combat.j').read_text()+'\nfunction HopeSkill_InitIds takes',1)
    src=src.replace('call HopeMonk_Reset()','call HopeThird_Reset()\ncall HopeMonk_Reset()',1)
    # Synchronized, successful original action branches only. Failed casts do not
    # charge passive counters; helper runs immediately after the actual AP debit.
    for name in ['Trig_JN_______001Actions','Trig_JN_______002Actions','Trig_JN_____________0010Actions','Trig_JN_______004Actions','Trig_JN_______005Actions']:
        f=block(src,name)
        f,n=re.subn(r'(^set udg_xingdong_dian\[[^\n]+\]=udg_xingdong_dian\[[^\n]+\]-\d+\n)',r'\1call HopeThird_AfterAction(GetTriggerUnit(),GetSpellAbilityId(),GetSpellTargetUnit())\n',f,flags=re.M)
        assert n==1,(name,n)
        src=replace(src,name,f)
    f=block(src,'Trig_JN_______001Actions')
    old='call SaveReal(YDLOC,GetHandleId(ydl_timer),$BB4B7313,LoadReal(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$BB4B7313))'
    assert f.count(old)==1
    f=f.replace(old,old[:-1].replace('LoadReal(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$BB4B7313)','HopeThird_Base(GetTriggerUnit(),GetSpellAbilityId(),LoadReal(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$BB4B7313),true)')+')')
    src=replace(src,'Trig_JN_______001Actions',f)
    f=block(src,'Trig_JN__________0001Actions')
    matches=[l for l in f.splitlines() if l.startswith('call SaveReal(') and '$BB4B7313,' in l and 'GetHeroInt' in l]
    assert len(matches)==1
    old=matches[0]
    f=f.replace(old,old[:-1]+'+HopeThird_Embers(GetTriggerUnit(),GetSpellTargetUnit()))',1)
    src=replace(src,'Trig_JN__________0001Actions',f)
    f=block(src,'Trig____________________005Actions')
    marker='call SaveReal(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$BB4B7313,LoadReal(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$BB4B7313)*udg_Zuizhong_Dm'
    assert marker in f
    f=f.replace(marker,'call SaveReal(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$BB4B7313,HopeThird_Damage(GetEventDamageSource(),GetTriggerUnit(),LoadReal(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$BB4B7313)))\n'+marker,1)
    src=replace(src,'Trig____________________005Actions',f)

    src=src.replace('function HopeJob_Blocker takes',RESEARCH+'\nfunction HopeJob_Blocker takes',1)
    f=block(src,'HopeJob_Blocker')
    marker='if index>=0 and index<HopeJob_Count and HopeJob_Stage[index]==1'
    f=f.replace(marker,'if i>=1 and i<=6 and HopeJob_Awakened[i] and index==HopeJob_AwakenOption[i] and HopeThird_Passive[index] then\nset u=null\nreturn HopeThird_StudyBlock(index,p)\nendif\n'+marker,1)
    marker='elseif GetHeroLevel(u)<HopeJob_Level[index] then'
    f=f.replace(marker,'elseif HopeJob_Stage[index]==3 and GetPlayerState(p,PLAYER_STATE_RESOURCE_GOLD)<HopeJob_GoldCost(index) then\nset s="金币不足：三转需要1000金币，当前 "+I2S(GetPlayerState(p,PLAYER_STATE_RESOURCE_GOLD))+"。"\n'+marker,1)
    src=replace(src,'HopeJob_Blocker',f)
    f=block(src,'HopeJob_Awaken')
    old="call UnitAddAbility(u,'AZ31'+kind-1)\ncall UnitMakeAbilityPermanent(u,true,'AZ31'+kind-1)"
    assert old in f
    f=f.replace(old,'call HopeThird_Unlock(index,i)',1)
    src=replace(src,'HopeJob_Awaken',UNLOCK+'\n'+f)
    f=block(src,'HopeJob_Commit')
    marker='if index==24 then'
    f=f.replace(marker,'if HopeJob_Awakened[i] and HopeJob_AwakenOption[i]==index and HopeThird_Passive[index] then\ncall HopeThird_Study(index,p)\nset p=null\nreturn\nendif\n'+marker,1)
    marker='call SetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER,GetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER)-HopeJob_WoodCost(index))'
    f=f.replace(marker,marker+'\ncall SetPlayerState(p,PLAYER_STATE_RESOURCE_GOLD,GetPlayerState(p,PLAYER_STATE_RESOURCE_GOLD)-HopeJob_GoldCost(index))',1)
    old='call DisplayTextToPlayer(p,0,0,"|cffffd36a三转完成："+HopeJob_Name[index]+"；消耗 "+I2S(HopeJob_WoodCost(index))+" 木材。按Z使用觉醒技能。|r")'
    assert old in f
    f=f.replace(old,'''if HopeThird_Passive[index] then
call DisplayTextToPlayer(p,0,0,"|cffffd36a三转完成："+HopeJob_Name[index]+"；消耗30木材+1000金币。已获得1级专属被动，在转职窗口花技能点研习。|r")
else
call DisplayTextToPlayer(p,0,0,"|cffffd36a三转完成："+HopeJob_Name[index]+"；消耗30木材+1000金币。按Z使用专属觉醒技能。|r")
endif''')
    src=replace(src,'HopeJob_Commit',f)
    # Completed hidden path is visible for its own research even after HZ02->HZ03.
    f=block(src,'HopeJob_Visible')
    f=f.replace('return udg_hero[i]!=null and HopeJob_Source[index]', 'if HopeJob_Awakened[i] and HopeJob_AwakenOption[i]==index then\nreturn true\nendif\nreturn udg_hero[i]!=null and HopeJob_Source[index]',1)
    src=replace(src,'HopeJob_Visible',f)

    src=src.replace('function HopeJob_Cast takes',(ROOT/'third_active.j').read_text()+'\nfunction HopeJob_Cast takes',1)
    f=block(src,'HopeJob_Cast')
    actives=[d['id'] for d in DESIGNS.values() if d['mode']=='active' and d['id']!='AZ36']
    f=f.replace("if aid=='AZ36' then",'if '+' or '.join("aid=='"+a+"'" for a in actives)+' then\ncall HopeThird_Cast(u,aid,target)\nelseif aid==\'AZ36\' then',1)
    marker='set udg_xingdong_dian[i]=udg_xingdong_dian[i]-1'
    assert f.count(marker)==1
    f=f.replace(marker,marker+"\ncall HopeThird_HiddenAction(u,aid)",1)
    # No ordinary hero is granted generic AZ31-35 now; hidden's AZ35 is removed too.
    a=f.index("elseif aid>='AZ31' and aid<='AZ35' then")
    b=f.rindex('endif\nset g=null')
    f=f[:a]+f[b:]
    src=replace(src,'HopeJob_Cast',f)
    f=block(src,'HopeHidden_Cast')
    # Execute after successful D recovery / V drain recovery, not rejection paths.
    marker='call SetUnitState(u,UNIT_STATE_LIFE,GetWidgetLife(u)+amount)'
    assert f.count(marker)==2
    f=f.replace(marker,marker+'\ncall HopeThird_HiddenAction(u,aid)')
    src=replace(src,'HopeHidden_Cast',f)

    init='function HopeThird_Init takes nothing returns nothing\nset HopeThird_Data=InitHashtable()\n'
    for index,o in enumerate(opts):
        if o['stage']==3:
            d=DESIGNS[o['target']]
            init+=f"set HopeThird_Ability[{index}]='{d['id']}'\nset HopeThird_Passive[{index}]="+('true' if d['mode']=='passive' else 'false')+'\n'
    init+='endfunction\n'
    f=block(src,'HopeJob_Init').replace('call GroupEnumUnitsOfPlayer(shops,','call HopeThird_Init()\ncall GroupEnumUnitsOfPlayer(shops,',1)
    src=replace(src,'HopeJob_Init',init+'\n'+f)

    f=block(src,'HopeJob_RefreshContent')
    f=f.replace('三转第4轮 / 30木材','三转第4轮 / 30木+1000金')
    f=f.replace('" 木材；当前木材："','" 木材+1000金币；当前木材："')
    f=f.replace('"（"+I2S(HopeJob_WoodCost(chosen))+"木材）"','"（30木+1000金）"')
    f=f.replace('"暂不可转职 · 需"+I2S(HopeJob_WoodCost(chosen))+"木材"','"需30木材+1000金币"')
    f=f.replace('call HopeJob_SetText(HopeJob_Detail,detail)', '''if HopeJob_Page==0 and HopeJob_Awakened[i] and chosen==HopeJob_AwakenOption[i] then
set detail="|cffd2b879"+HopeJob_Name[chosen]+" · 已完成三转|r|n|n"+HopeJob_Role[chosen]
if HopeThird_Passive[chosen] then
set detail=detail+"|n|n|cffd2b879专属被动研习|r|n当前 "+I2S(HopeThird_Level(udg_hero[i]))+"/3级；可用技能点 "+I2S(GetHeroSkillPoints(udg_hero[i]))+"。|n|n每提升1级消耗1技能点，不再消耗木材或金币。|n原有及后续升级获得的技能点均可使用。|n请在泉水房间点击下方研习按钮。|n技能页可查看各级效果。"
else
set detail=detail+"|n|n专属觉醒技能已获得；按Z使用。|n查看技能页了解效果与行动点消耗。|n三转奖励已发放，无需再次支付转职费用。"
endif
endif
call HopeJob_SetText(HopeJob_Detail,detail)''',1)
    marker='call HopeJob_SetText(HopeJob_Footer,block)'
    f=f.replace(marker,'''if HopeJob_Awakened[i] and chosen==HopeJob_AwakenOption[i] then
if HopeThird_Passive[chosen] then
call HopeJob_SetText(HopeJob_Status,"专属被动 "+I2S(HopeThird_Level(u))+"/3级 · 技能点 "+I2S(GetHeroSkillPoints(u)))
if HopeThird_Level(u)<3 then
call HopeJob_SetText(HopeJob_Confirm[chosen],"研习至 "+I2S(HopeThird_Level(u)+1)+" 级（1技能点）")
else
call HopeJob_SetText(HopeJob_Confirm[chosen],"专属被动已满级")
endif
set block=HopeThird_StudyBlock(chosen,p)
if block=="" then
set block="每次仅消耗1技能点；后续升级获得的技能点也可研习。"
endif
else
call HopeJob_SetText(HopeJob_Confirm[chosen],"已完成三转")
set block="专属觉醒技能已获得；查看技能页了解用法。"
endif
endif
'''+marker,1)
    f=f.replace('HopeThird_Level(u)', 'HopeThird_Level(udg_hero[i])').replace('GetHeroSkillPoints(u)', 'GetHeroSkillPoints(udg_hero[i])')
    src=replace(src,'HopeJob_RefreshContent',f)
    return src
