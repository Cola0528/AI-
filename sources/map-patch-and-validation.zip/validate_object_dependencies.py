"""Validate the packed Warcraft object dependency model without using its builder.

Run from any directory. The tiny v1 fixture is deliberately invalid: its seven
custom objects derive from aliases removed from the map's reduced AbilityData.
This checks data loading contracts, not Warcraft/KK execution or UI rendering.
"""
from collections import Counter
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
import argparse
import csv
import struct


ROOT = Path(__file__).resolve().parent
V1_ABILITIES = {"AZHA", "AZ31", "AZ32", "AZ33", "AZ34", "AZ35", "AZHP"}
NEW_ABILITIES = V1_ABILITIES | {"AZH2", "AZH3", "AZHR", "AZHD"}
ACTIVE_CONFIG = {
    "AZHA": (1, "Q", "cripple"), "AZH2": (1, "Q", "cripple"),
    "AZH3": (1, "Q", "cripple"), "AZHR": (0, "D", "rejuvenation"),
    "AZHD": (1, "V", "drain"),
    **{alias: (0, "Z", "spellsteal") for alias in ["AZ31", "AZ32", "AZ33", "AZ34", "AZ35"]},
}
HIDDEN_HEROES = {"HZ01", "HZ02", "HZ03"}
CHALLENGE_ENEMIES = {"nZ01", "nZ02", "nZ03", "nZ04", "UZ01", "UZ02"}
SLK_FILES = ["AbilityData", "UnitData", "UnitBalance", "UnitUI", "UnitWeapons", "UnitAbilities"]


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def slk_fields(line):
    """Split semicolon fields while retaining quoted/escaped SLK strings."""
    fields, begin, quoted, i = [], 0, False, 0
    while i < len(line):
        if line[i] == '"':
            if quoted and i + 1 < len(line) and line[i + 1] == '"':
                i += 2
                continue
            quoted = not quoted
        elif line[i] == ";" and not quoted:
            fields.append(line[begin:i])
            begin = i + 1
        i += 1
    require(not quoted, "SLK: unterminated quoted string")
    return fields + [line[begin:]]


@dataclass(frozen=True)
class Cell:
    kind: str
    value: object


def cell_value(raw):
    if raw.startswith('"'):
        require(raw.endswith('"'), "SLK: malformed string")
        return Cell("string", raw[1:-1].replace('""', '"'))
    try:
        value = Decimal(raw)
    except InvalidOperation as error:
        raise AssertionError(f"SLK: invalid numeric cell {raw!r}") from error
    require(value.is_finite(), "SLK: non-finite numeric cell")
    return Cell("number", value)


@dataclass
class Slk:
    cells: dict
    columns: dict
    rows: dict
    bounds: tuple


def parse_slk(data, label):
    cells, x, y, bounds, ended = {}, 1, 1, None, False
    for lineno, line in enumerate(data.decode("utf-8-sig").splitlines(), 1):
        if not line:
            continue
        parts = slk_fields(line)
        if parts[0] == "E":
            ended = True
            continue
        require(not ended, f"{label}:{lineno}: data after SLK terminator")
        if parts[0] == "B":
            require(bounds is None, f"{label}: duplicate bounds")
            axes = {p[0]: int(p[1:]) for p in parts[1:] if p[0] in "XY"}
            require(set(axes) == {"X", "Y"}, f"{label}: incomplete bounds")
            bounds = axes["X"], axes["Y"]
        if parts[0] != "C":
            continue
        for part in parts[1:]:
            if part.startswith("X"):
                x = int(part[1:])
            elif part.startswith("Y"):
                y = int(part[1:])
        values = [p[1:] for p in parts[1:] if p.startswith("K")]
        require(len(values) <= 1, f"{label}:{lineno}: duplicate K field")
        if values:
            require((y, x) not in cells, f"{label}:{lineno}: duplicate cell {(y, x)}")
            cells[y, x] = cell_value(values[0])
    require(ended and bounds is not None, f"{label}: missing bounds or terminator")
    require(all(1 <= x <= bounds[0] and 1 <= y <= bounds[1] for y, x in cells),
            f"{label}: cell exceeds declared bounds {bounds}")
    columns = {x: c.value for (y, x), c in cells.items() if y == 1}
    require(columns and 1 in columns and len(columns) == len(set(columns.values())),
            f"{label}: missing/duplicate column names")
    require(all(c.kind == "string" for (y, x), c in cells.items() if y == 1),
            f"{label}: non-string column name")
    rows = {}
    by_y = {}
    for (y, x), value in cells.items():
        if y > 1:
            require(x in columns, f"{label}: column {x} lacks a header")
            by_y.setdefault(y, {})[columns[x]] = value
    for y, row in by_y.items():
        alias = row.get(columns[1])
        require(alias is not None and alias.kind == "string" and len(alias.value) == 4,
                f"{label}: row {y} lacks a four-character alias")
        require(alias.value not in rows, f"{label}: duplicate alias {alias.value}")
        rows[alias.value] = row
    return Slk(cells, columns, rows, bounds)


class BinaryReader:
    def __init__(self, data):
        self.data, self.pos = data, 0

    def take(self, count):
        require(0 <= count <= len(self.data) - self.pos, "w3a: truncated record")
        result = self.data[self.pos:self.pos + count]
        self.pos += count
        return result

    def integer(self):
        return struct.unpack("<i", self.take(4))[0]

    def string(self):
        end = self.data.find(b"\0", self.pos)
        require(end >= self.pos, "w3a: unterminated string")
        result = self.take(end - self.pos).decode("utf-8")
        self.take(1)
        return result


def parse_w3a(data):
    r, result = BinaryReader(data), []
    require(r.integer() == 2, "w3a: unexpected format version")
    for table in range(2):
        count = r.integer()
        require(0 <= count <= 100000, "w3a: invalid object count")
        for _ in range(count):
            base, custom = r.take(4), r.take(4)
            require((custom == b"\0" * 4) == (table == 0), "w3a: invalid custom ID/table")
            alias = base if table == 0 else custom
            mods, modification_count = {}, r.integer()
            require(0 <= modification_count <= 100000, "w3a: invalid modification count")
            for _ in range(modification_count):
                field, typ, level, pointer = r.take(4), r.integer(), r.integer(), r.integer()
                require(typ in range(4) and level >= 0 and pointer >= 0, "w3a: invalid field metadata")
                if typ == 3:
                    value = r.string()
                elif typ == 0:
                    value = r.integer()
                else:
                    value = struct.unpack("<f", r.take(4))[0]
                require(r.take(4) in (b"\0" * 4, base, custom), "w3a: invalid field terminator")
                key = field.decode("ascii"), level, pointer
                require(key not in mods, f"w3a: duplicate modification {key}")
                mods[key] = typ, value
            result.append({"base": base.decode("ascii"), "alias": alias.decode("ascii"),
                           "custom": table == 1, "mods": mods})
    require(r.pos == len(data), "w3a: unexpected trailing bytes")
    aliases = [o["alias"] for o in result]
    require(len(aliases) == len(set(aliases)), "w3a: duplicate object alias")
    return result


def missing_bases(objects, slk_aliases):
    """Resolve actual template aliases, never confuse them with engine code IDs."""
    known, remaining = set(slk_aliases), list(objects)
    while remaining:
        resolved = [obj for obj in remaining if obj["base"] in known]
        if not resolved:
            break
        for obj in resolved:
            known.add(obj["alias"])
            remaining.remove(obj)
    return [(obj["alias"], obj["base"]) for obj in remaining]


def parse_profile(data, label):
    sections, section = {}, None
    for lineno, line in enumerate(data.decode("utf-8-sig").splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("//"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1]
            require(section not in sections, f"{label}:{lineno}: duplicate profile section {section}")
            sections[section] = {}
        elif "=" in line and section is not None:
            key, value = line.split("=", 1)
            key = key.lower()
            require(key not in sections[section], f"{label}:{lineno}: duplicate key {section}.{key}")
            sections[section][key] = value
    return sections


def value(row, key, kind=None):
    require(key in row, f"missing SLK field {key}")
    if kind:
        require(row[key].kind == kind, f"{key}: expected {kind}, got {row[key].kind}")
    return row[key].value


def numeric(row, key, expected):
    require(value(row, key, "number") == expected, f"{key}: expected {expected}, got {row[key]}")


def validate(root=ROOT, modified=None):
    root = Path(root)
    modified = Path(modified) if modified else root / "modified"
    tables, preserved_rows = {}, 0
    for name in SLK_FILES:
        filename = f"Units_{name}.slk"
        original = parse_slk((root / filename).read_bytes(), "original/" + filename)
        current = parse_slk((modified / filename).read_bytes(), "modified/" + filename)
        for alias, row in original.rows.items():
            expected = row
            if name == "AbilityData" and alias == "A04U":
                fields = {f"DataF{rank}": Cell("string", "acidbomb") for rank in range(1, 4)}
                require(not set(fields) & set(row), "A04U: original command data changed upstream")
                expected = {**row, **fields}
            require(current.rows.get(alias) == expected, f"{filename}: old row {alias} changed unexpected type/value/fields")
        for column, heading in original.columns.items():
            require(current.columns.get(column) == heading, f"{filename}: original header moved/changed")
        expected_new = NEW_ABILITIES if name == "AbilityData" else HIDDEN_HEROES | CHALLENGE_ENEMIES
        require(set(current.rows) - set(original.rows) == expected_new,
                f"{filename}: unexpected/missing new rows")
        tables[name] = current
        preserved_rows += len(original.rows) - (1 if name == "AbilityData" else 0)

    original_ability = parse_slk((root / "Units_AbilityData.slk").read_bytes(), "original AbilityData")
    old_binary = (root / "war3map.w3a").read_bytes()
    new_binary = (modified / "war3map.w3a").read_bytes()
    require(new_binary == old_binary, "original w3a bytes changed")
    objects = parse_w3a(new_binary)
    require(not missing_bases(objects, tables["AbilityData"].rows), "new map has unresolved w3a bases")
    fixture_objects = parse_w3a((root / "fixtures/v1-invalid-abilities.w3a").read_bytes())
    regression = missing_bases(fixture_objects, original_ability.rows)
    require({alias for alias, base in regression} == V1_ABILITIES and len(regression) == 7,
            f"v1 regression should find exactly seven unresolved objects, got {regression}")
    require(Counter(base for alias, base in regression) == {"ANcl": 6, "Aamk": 1},
            "v1 regression found unexpected missing templates")

    profiles = {}
    for filename in ("Units_campaignabilityfunc.txt", "Units_campaignabilitystrings.txt"):
        path = modified / filename
        if not path.exists():
            path = root / filename
        parsed = parse_profile(path.read_bytes(), filename)
        for alias, fields in parsed.items():
            if alias not in NEW_ABILITIES:
                continue
            combined = profiles.setdefault(alias, {})
            for key, field in fields.items():
                require(key not in combined or combined[key] == field,
                        f"{alias}: conflicting profile field {key}")
                combined[key] = field
    require(set(profiles) == NEW_ABILITIES, "missing new ability profiles")
    ability_rows = tables["AbilityData"].rows
    for alias in sorted(NEW_ABILITIES):
        row, profile = ability_rows[alias], profiles[alias]
        passive = alias == "AZHP"
        require(value(row, "code", "string") == ("Aamk" if passive else "ANcl"), f"{alias}: wrong engine code")
        numeric(row, "levels", 3 if passive else 1)
        if "hero" in row:
            numeric(row, "hero", int(passive))
        else:
            require(profile.get("hero") == str(int(passive)), f"{alias}: missing/wrong hero flag")
        for key in ("name", "art", "tip", "ubertip", "buttonpos", "order"):
            require(profile.get(key, "").strip('"_ '), f"{alias}: missing profile {key}")
        require(profile["art"].strip('"').lower().endswith(".blp"), f"{alias}: invalid icon")
        numeric(row, "item", 0)
        require(value(row, "race", "string") in {"human", "orc", "undead", "nightelf", "other"},
                f"{alias}: invalid race")
        for key in ("buttonpos", "researchbuttonpos"):
            if key in profile:
                coordinates = profile[key].split(",")
                require(len(coordinates) == 2 and all(c.isdigit() for c in coordinates),
                        f"{alias}: malformed {key}")
                require(0 <= int(coordinates[0]) <= 3 and 0 <= int(coordinates[1]) <= 2,
                        f"{alias}: command button outside grid")
        if passive:
            numeric(row, "reqLevel", 1)
            numeric(row, "levelSkip", 1)
            for rank in range(1, 4):
                numeric(row, f"Cost{rank}", 0)
                for field in "ABCD":
                    numeric(row, f"Data{field}{rank}", 0)
            for key in ("researchart", "researchbuttonpos", "researchhotkey", "researchtip", "researchubertip"):
                require(profile.get(key, "").strip('"_ '), f"{alias}: missing learning profile {key}")
            require(profile["order"] == "attributemodskill", f"{alias}: wrong passive order")
            for key in ("tip", "ubertip"):
                levels = next(csv.reader([profile[key]]))
                require(len(levels) == 3 and all(levels), f"{alias}: {key} must describe three ranks")
        else:
            numeric(row, "Cost1", 0)
            numeric(row, "DataA1", 0)
            targeted, hotkey, expected_order = ACTIVE_CONFIG[alias]
            numeric(row, "DataB1", targeted)
            options = value(row, "DataC1", "number")
            require(options == int(options) and int(options) & 1, f"{alias}: hidden channel command")
            numeric(row, "DataD1", 0)
            numeric(row, "DataE1", 0)
            numeric(row, "Dur1", 0)
            numeric(row, "HeroDur1", 0)
            order = value(row, "DataF1", "string")
            require(order == expected_order,
                    f"{alias}: active skill/awakening order collision")
            require(profile["order"] in {"channel", order}, f"{alias}: conflicting native/profile order")
            require(profile.get("hotkey") == hotkey, f"{alias}: wrong hotkey")
            require(value(row, "Rng1", "number") > 0, f"{alias}: invalid cast range")
            if targeted:
                targets = set(value(row, "targs1", "string").split(","))
                require(bool(targets & {"enemies", "enemy"}), f"{alias}: enemy units not targetable")
            else:
                require(value(row, "targs1", "string") in {"", "_"},
                        f"{alias}: no-target awakening has unit target filters")

    for alias, current, later in [("AZHA", ("0.60", "0.45"), ("0.65", "0.70", "0.80")),
                                  ("AZH2", ("0.65",), ("0.60", "0.45", "0.70", "0.80")),
                                  ("AZH3", ("0.70", "0.80"), ("0.60", "0.45", "0.65"))]:
        tooltip = profiles[alias]["ubertip"]
        require(all(number in tooltip for number in current), f"{alias}: current Q formula missing")
        require(all(number not in tooltip for number in later), f"{alias}: Q tooltip contains another stage")
    resolved = set(ability_rows) | {obj["alias"] for obj in objects}
    for enemy in CHALLENGE_ENEMIES:
        row = tables["UnitAbilities"].rows[enemy]
        require(value(row, "abilList", "string") == "A00U" and "A00U" in resolved,
                f"{enemy}: missing original AI spell")
    for hero in HIDDEN_HEROES:
        row = tables["UnitAbilities"].rows[hero]
        groups = {key: [x for x in value(row, key, "string").split(",") if x and x != "_"]
                  for key in ("abilList", "heroAbilList")}
        expected_q = {"HZ01": "AZHA", "HZ02": "AZH2", "HZ03": "AZH3"}[hero]
        require(set(groups["abilList"]) & {"AZHA", "AZH2", "AZH3"} == {expected_q},
                f"{hero}: stage-specific Q missing or duplicate Q commands")
        require("AZHR" in groups["abilList"] and ("AZHD" in groups["abilList"]) == (hero != "HZ01"),
                f"{hero}: healing/drain progression wrong")
        require("AZHP" in groups["heroAbilList"],
                f"{hero}: missing active/training ability")
        commands = [profiles[a] for a in groups["abilList"] if a in profiles]
        for field in ["hotkey", "buttonpos"]:
            assigned = [p[field] for p in commands]
            require(len(assigned) == len(set(assigned)), f"{hero}: conflicting {field}")
        for group, dependencies in groups.items():
            require(len(dependencies) == len(set(dependencies)), f"{hero}: duplicate {group} entries")
            require(set(dependencies) <= resolved, f"{hero}: unresolved {group}: {set(dependencies) - resolved}")
    print(f"PASS: object dependencies; {preserved_rows} original SLK rows preserved; A04U only adds DataF1/2/3 command fix; "
          "11 direct SLK abilities and profiles valid; original w3a unchanged; "
          "hidden hero dependencies resolve; v1 regression detects 7 missing templates.")
    return {"preserved_slk_rows": preserved_rows, "v1_missing_template_errors": len(regression)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--modified", type=Path)
    args = parser.parse_args()
    validate(args.root, args.modified)
