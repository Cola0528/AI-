"""Exercise the actual continuous log, R scrolling and colored compact damage UI."""
from pathlib import Path
import re,math
from validate_layout import Layout
from validate_economy import body,SCRIPT,rawcode

N=0
def check(v,msg):
 global N
 assert v,msg
 N+=1

def run():
 w=Layout();g=w.g
 w.load('HopeDraw_SaveRecord','HopeDraw_Record','HopeDraw_Refresh','HopeScroll_Capturing',
        'HopeScroll_EnterLog','HopeScroll_EnterR','HopeScroll_Leave','HopeScroll_Wheel',
        'HopeScroll_LogUp','HopeScroll_LogDown','HopeScroll_Latest','HopeScroll_RUp','HopeScroll_RDown',
        's__hardware_OnWheel','HopeDamage_RunClick','HopeDamage_Battle')
 g['DzGetWheelDelta']=lambda:-120;g['DzIsMouseOverUI']=lambda:True
 g['GetCameraField']=lambda field:1.;g['CAMERA_FIELD_ANGLE_OF_ATTACK']=1;g['Rad2Deg']=lambda x:x
 # Several single draws and a ten-draw share the same continuous list.
 for i in range(3):g['HopeDraw_SaveRecord'](0,'木材抽奖 · 1木材','力量 +1' if i%2 else '谢谢惠顾',False)
 g['HopeDraw_Record'](0,'十连抽 · 648金币','|n'.join(str(i)+'. 全属性 +3' for i in range(1,11)))
 g['HopeDraw_Refresh']();g['HopeLayout_Apply']()
 check(g['HopeLog_Count']==17,'four records become 17 continuous rows, not four pages')
 top=w.frames[g['HopeDraw_Text']].text
 check('#4 十连抽' in top and '10. 全属性 +3' in top and '#3 木材抽奖' in top,'one viewport spans records')
 w.audit('continuous-log');w.render('continuous-log')
 g['HopeScroll_EnterLog']();g['s__hardware_ResetCam']=False
 g['s__hardware_OnWheel']();g['HopeScroll_Wheel']();g['HopeDraw_Refresh']()
 check(g['HopeLog_Offset']==3 and not g['s__hardware_ResetCam'],'wheel scrolls three lines without zooming the camera')
 check('#4 十连抽' not in w.frames[g['HopeDraw_Text']].text,'viewport actually moves')
 g['HopeScroll_LogDown']();check(g['HopeLog_Offset']==4,'bottom clamps at final visible rows')
 g['HopeScroll_LogUp']();check(g['HopeLog_Offset']==1,'up button scrolls rows')
 g['HopeScroll_Latest']();check(g['HopeLog_Offset']==0,'latest button returns to top')
 g['HopeScroll_Leave']();g['HopeScroll_Wheel']();check(g['HopeLog_Offset']==0,'wheel elsewhere leaves record position alone')
 # The rolling buffer retains the most recent64 batches, including all their rows.
 for i in range(70):g['HopeDraw_SaveRecord'](0,'木材抽奖 · 1木材','结果 '+str(i),False)
 g['HopeDraw_Refresh']()
 check(g['HopeLog_Count']==128 and g['HopeLog_Line'][0].startswith('|cffd2b879#74 '),'newest64 records cached')
 g['HopeScroll_Move'](1,99999);g['HopeDraw_Refresh']()
 check(g['HopeLog_Offset']==115 and '结果 6' in w.frames[g['HopeDraw_Text']].text,'oldest retained result reachable at bottom')
 check(all('#10 ' not in g['HopeLog_Line'][i] for i in range(g['HopeLog_Count'])),'expired records are not displayed')
 g['HopeDraw_Open']=False;g['HopeDraw_Refresh']();g['HopeScroll_EnterLog']()
 before=g['HopeLog_Offset'];g['HopeScroll_Wheel']();check(before==g['HopeLog_Offset'],'hidden log cannot consume scroll')
 # UTF-8 split uses complete lines; blank separators never waste the viewport.
 g['HopeR_Count']=0;g['HopeScroll_Add'](2,'中文第一行|n|n技能倍率×30%|n')
 check([g['HopeR_Line'][i] for i in range(g['HopeR_Count'])]==['中文第一行','技能倍率×30%'],'UTF8 boundaries preserved')
 g['HopeR_Key']=0;g['HopeR_Current']=0
 g['HopeChoice_DialogCount']=1;g['HopeChoice_Dialog'][1]=201;g['HopeChoice_Owner'][1]=0;g['HopeChoice_DialogPending'][1]=True;g['HopeChoice_Hidden']=False
 g['udg_Rskill_shifoutihuan'][1]=201;g['udg_Youxi_ND_XZ']=202
 g['SaveInteger'](g['HopeModern_Data'],201,0,2)
 g['GetAbilityName']=lambda a:'阿修罗霸凰拳' if a==rawcode('A03Y') else '当前技能'
 aliases=re.findall(r"(?:if|elseif) id=='(\w+)'",body('HopeCompact_RText')[3])
 check(len(aliases)==17,'all17 original R abilities have a wrapped description')
 for alias in aliases:
  ability=rawcode(alias);original=g['HopeSkill_Original'](ability,1);wrapped=g['HopeCompact_RText'](ability)
  strip=lambda s:re.sub(r'\|c[0-9a-fA-F]{8}|\|r|\|n','',s)
  check(strip(original)==strip(wrapped),'no skill text lost: '+alias)
  g['SaveInteger']('YDHT',201,0xD59B01E6,ability);g['HopeModern_Refresh']();g['HopeLayout_Apply']()
  w.audit('R '+alias);w.render('R-'+alias,False)
  for offset in range(max(1,g['HopeR_Count']-4)):
   g['HopeR_Offset']=offset;g['HopeModern_Refresh']();w.render('R-lines-'+alias,False)
  check('放弃不退费用' in w.frames[g['HopeR_Notice'][1]].text,'price notice persists while details scroll')
 g['HopeScroll_EnterR']();g['HopeR_Offset']=0;g['HopeScroll_Wheel']()
 check(g['HopeR_Offset']==min(3,max(0,g['HopeR_Count']-5)),'R wheel works')
 check(g['HopeChoice_DialogPending'][1] and not w.debits and not w.writes,'scrolling never accepts a choice or changes resources')
 g['HopeChoice_Hidden']=True;before=g['HopeR_Offset'];g['HopeScroll_Wheel']();check(g['HopeR_Offset']==before,'folded R does not capture wheel')
 check('HopeScroll_Capturing()' in body('s__hardware_OnWheel')[3],'camera explicitly yields to local scroll regions')
 # Rank is independent of player color, including changed colors and compact values.
 g['HopeChoice_DialogPending'][1]=False;g['HopeR_Active']=0
 for i in range(6):
  w.hero(i);w.colors[i]=5-i;g['udg_Shuchu_dm_tj'][i+1]=(i+1)*1234567.;g['HopeDamage_Total'][i+1]=(6-i)*87654321.
 g['GetPlayerName']=lambda i:'玩家'+str(i+1)
 for totals in [False,True]:
  g['HopeDamage_Run']=totals;g['HopeDamage_Refresh']();g['HopeLayout_Apply']()
  rows=w.frames[g['HopeDamage_Text']].text.split('|n')[:6]
  for rank,row in enumerate(rows,1):
   owner=g['HopeDamage_Order'][rank]-1
   check(row.startswith(g['YDWEBase__yd_PlayerColor'][w.colors[owner]]) and '玩家'+str(owner+1) in row,'row uses actual player color, not rank or slot')
  w.audit('compact-damage');w.render('colored-total' if totals else 'colored-battle')
 check(w.frames[g['HopeDamage_Panel']].w==.144,'damage panel width reduced32%')
 for amount in [0.,9999.,10000.,99999999.,100000000.,999999999999.,1e12,3.4e38]:
  check(len(g['HopeDamage_Number'](amount))<=10,'bounded large number text '+str(amount))
 print('PASS:',N,'continuous log,64-batch retention,UTF8,mouse wheel/camera,17 full R descriptions,local-only actions,player colors and compact damage assertions.')

if __name__=='__main__':run()
