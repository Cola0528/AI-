"""Local HUD readout of existing class counters; never mutate combat state."""
from modern_choices_patch import block, replace

GLOBALS = '''integer HopeProfession_Row=0
boolean HopeProfession_Expanded=false
'''

HELPERS = '''function HopeProfession_Text takes unit u,integer p returns string
local integer kind=0
local integer current=0
local integer capacity=0
if p<1 or p>6 or u==null then
return ""
endif
if HopeMini_Actor[p]!=null then
return ""
endif
set kind=GetUnitTypeId(u)
if kind=='H00E' then
set current=LoadInteger(YDHT,GetHandleId(u),$30720CCD)
set capacity=GetUnitAbilityLevel(u,'A04Q')+1
if current<=0 then
return "|cffff8585子弹 "+I2S(current)+"/"+I2S(capacity)+" · Q装填|r"
endif
return "|cffd2b879子弹 "+I2S(current)+"/"+I2S(capacity)+"|r"
elseif kind=='N01G' then
set current=HopeMonk_Qi[p]
if current>=3 then
return "|cff80ef90气 "+I2S(current)+"/3 · 已满|r"
endif
return "|cff76cdd0气 "+I2S(current)+"/3|r"
elseif kind=='N01A' and GetUnitAbilityLevel(u,'A03M')>1 then
// The live passive starts at rank 2 and awards STR on the 15th heavy chop.
set current=udg_Zhongkan_cs[p]
if current>=14 then
return "|cff80ef90重砍 "+I2S(current)+"/15 · 下次+1力|r"
endif
return "|cffd2b879重砍 "+I2S(current)+"/15|r"
endif
return ""
endfunction

function HopeProfession_Update takes unit u,integer p returns nothing
local string text=""
local boolean expanded=false
if HopeProfession_Row==0 or HopeQoL_Hud==0 then
return
endif
set text=HopeProfession_Text(u,p)
set expanded=text!=""
call DzFrameSetText(HopeProfession_Row,text)
call DzFrameShow(HopeProfession_Row,expanded)
if expanded!=HopeProfession_Expanded then
set HopeProfession_Expanded=expanded
// Grow upward: keep the bottom at .383 and the route panel gap at .008.
call DzFrameClearAllPoints(HopeQoL_Hud)
if expanded then
call DzFrameSetAbsolutePoint(HopeQoL_Hud,0,.014,.515)
call DzFrameSetSize(HopeQoL_Hud,.134,.132)
else
call DzFrameSetAbsolutePoint(HopeQoL_Hud,0,.014,.50)
call DzFrameSetSize(HopeQoL_Hud,.134,.117)
endif
endif
endfunction
'''


def apply(src):
    src = src.replace('globals\n', 'globals\n'+GLOBALS, 1)
    f = block(src, 'HopeQoL_CreateUI')
    marker = 'set HopeQoL_Restore=HopeQoL_Label('
    assert marker in f
    f = f.replace(marker, '''set HopeProfession_Row=HopeQoL_Label("HopeProfessionResource",HopeQoL_Hud,.007,-.117,.120,.012,"")
if HopeProfession_Row!=0 then
call DzFrameSetFont(HopeProfession_Row,"Fonts\\\\ZiTi.ttf",.0085,0)
call DzFrameShow(HopeProfession_Row,false)
endif
'''+marker, 1)
    src = replace(src, 'HopeQoL_CreateUI', f)
    f = block(src, 'HopeQoL_RefreshContent')
    marker = 'call HopeRoute_UpdateUI()'
    assert marker in f
    f = f.replace(marker, 'call HopeProfession_Update(u,p)\n'+marker, 1)
    return replace(src, 'HopeQoL_RefreshContent', HELPERS+'\n'+f)
