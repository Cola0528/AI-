"""Reuse the v13 status label for class counters; no extra frame or HUD resizing."""
from modern_choices_patch import block, replace

GLOBALS = ""

HELPERS = '''function HopeProfession_Text takes unit u,integer p returns string
local integer kind=0
local integer current=0
local integer capacity=0
if p<1 or p>6 or u==null then
return ""
endif
if HopeMini_Actor[p]!=null then
return ""
endif
set kind=GetUnitTypeId(u)
if kind=='H00E' then
set current=LoadInteger(YDHT,GetHandleId(u),$30720CCD)
set capacity=GetUnitAbilityLevel(u,'A04Q')+1
if current<=0 then
return "|cffff8585子弹 "+I2S(current)+"/"+I2S(capacity)+" · Q装填|r"
endif
return "|cffd2b879子弹 "+I2S(current)+"/"+I2S(capacity)+"|r"
elseif kind=='N01G' then
set current=HopeMonk_Qi[p]
if current>=3 then
return "|cff80ef90气 "+I2S(current)+"/3 · 已满|r"
endif
return "|cff76cdd0气 "+I2S(current)+"/3|r"
elseif kind=='N01A' and GetUnitAbilityLevel(u,'A03M')>1 then
// The live passive starts at rank 2 and awards STR on the 15th heavy chop.
set current=udg_Zhongkan_cs[p]
if current>=14 then
return "|cff80ef90重砍 "+I2S(current)+"/15 · 下次+1力|r"
endif
return "|cffd2b879重砍 "+I2S(current)+"/15|r"
endif
return ""
endfunction
'''


def apply(src):
    f=block(src,'HopeQoL_RefreshContent')
    marker='call DzFrameSetText(HopeQoL_Status,focus+'
    assert f.count(marker)==1
    f=f.replace(marker,'''set detail=HopeProfession_Text(u,p)
if detail!="" then
set focus=detail
endif
'''+marker,1)
    # The original life/mana/AP/focus numbers and backpack row keep their frames.
    # Only the first line of the existing two-line status text is repurposed.
    return replace(src,'HopeQoL_RefreshContent',HELPERS+'\n'+f)
