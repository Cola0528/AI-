"""Explicit departure, party-visible destination, and elected route picker."""
from modern_choices_patch import block,replace

GLOBALS='''
integer HopeRoute_ChosenLeader=-1
boolean HopeRoute_Assigning=false
integer HopeRoute_AssignPanel=0
integer array HopeRoute_AssignButton
integer HopeRoute_DepartButton=0
integer HopeRoute_Picker=0
integer HopeRoute_PickerTitle=0
integer array HopeRoute_NodeButton
unit array HopeRoute_Available
integer HopeRoute_AvailableCount=0
boolean HopeRoute_PickerOpen=false
effect HopeRoute_Marker=null
texttag HopeRoute_MarkerText=null
'''
EARLY=r'''function HopeRoute_Host takes nothing returns integer
local integer i=0
loop
exitwhen i>=6
if HopeRoute_Active(i) then
return i
endif
set i=i+1
endloop
return -1
endfunction
function HopeRoute_ClearMarker takes nothing returns nothing
if HopeRoute_Marker!=null then
call DestroyEffect(HopeRoute_Marker)
set HopeRoute_Marker=null
endif
if HopeRoute_MarkerText!=null then
call SetTextTagVisibility(HopeRoute_MarkerText,false)
endif
endfunction
function HopeRoute_Mark takes unit node returns nothing
call HopeRoute_ClearMarker()
set HopeRoute_Marker=AddSpecialEffectTarget("Abilities\\Spells\\Other\\TalkToMe\\TalkToMe.mdl",node,"overhead")
if HopeRoute_MarkerText==null then
set HopeRoute_MarkerText=CreateTextTag()
call SetTextTagPermanent(HopeRoute_MarkerText,true)
endif
call SetTextTagText(HopeRoute_MarkerText,"|cffffd060【当前选择】|r",.022)
call SetTextTagPosUnit(HopeRoute_MarkerText,node,180.)
call SetTextTagVisibility(HopeRoute_MarkerText,true)
endfunction
'''
SELECT='''function HopeRoute_Select takes player p,unit node returns boolean
local integer leader=HopeRoute_Leader()
if HopeRoute_Assigning or leader<0 or GetPlayerId(p)!=leader then
call DisplayTextToPlayer(p,0,0,"请由指定的路线选择者提出目的地；队友可在准备面板确认。")
return false
endif
if udg_ZhandouZhong or node==null or not LoadBoolean(YDHT,GetHandleId(node),$C31B86D5) or LoadInteger(YDHT,GetHandleId(node),$66256FC7)!=udg_boci then
return false
endif
if not HopeRoute_Valid() or HopeRoute_Node!=node then
set HopeRoute_Node=node
set HopeRoute_Depth=udg_boci
set HopeRoute_Chapter=udg_quanshu
call HopeRoute_ClearReady()
call HopeRoute_Mark(node)
call DisplayTextToForce(udg_WJZ,GetPlayerName(p)+" 选择了："+GetUnitName(node)+"。地图上的金色标识为目的地；全员准备后点击【出发】。")
endif
set HopeRoute_Ready[leader]=not HopeRoute_RewardPending(leader) and udg_hero[leader+1]!=null
return false
endfunction'''
ENTER=r'''function HopeRoute_Depart takes player p returns boolean
local unit node=HopeRoute_Node
if HopeRoute_Assigning or GetPlayerId(p)!=HopeRoute_Leader() or udg_ZhandouZhong or not HopeRoute_Valid() then
set node=null
return false
endif
if not HopeRoute_AllReady() then
call DisplayTextToPlayer(p,0,0,"尚不能出发：|n"+HopeRoute_Status())
set node=null
return false
endif
// Consume proposal before transition; stale/repeated clicks cannot enter twice.
set HopeRoute_Node=null
call HopeRoute_ClearMarker()
call HopeRoute_ClearReady()
call SaveBoolean(YDHT,GetHandleId(node),$C31B86D5,false)
call SetUnitVertexColorBJ(node,50.,0.,0.,0.)
call YDWETimerDestroyEffect(2.,AddSpecialEffectTarget("Abilities\\Spells\\Human\\MassTeleport\\MassTeleportCaster.mdl",node,"origin"))
set udg_Youxi_xzgq=node
call GroupAddUnitSimple(node,udg_zouguo_luxian)
set udg_boci=udg_boci+1
call ConditionalTriggerExecute(gg_trg______________011)
call ForGroupBJ(YDWEGetUnitsOfPlayerAllNull(Player(PLAYER_NEUTRAL_PASSIVE)),function Trig______________012Func001Func008A)
set node=null
return true
endfunction
function HopeRoute_DepartClick takes nothing returns nothing
call HopeRoute_Depart(DzGetTriggerUIEventPlayer())
endfunction
'''
LATE='''function HopeRoute_Assign takes player p,integer chosen returns boolean
if not HopeRoute_Assigning or GetPlayerId(p)!=HopeRoute_Host() or not HopeRoute_Active(chosen) then
return false
endif
set HopeRoute_ChosenLeader=chosen
set HopeRoute_Assigning=false
call HopeRoute_ClearReady()
call DisplayTextToForce(udg_WJZ,"本局路线由 "+GetPlayerName(Player(chosen))+" 选择；全员准备后，由该玩家点击【出发】。")
return true
endfunction
function HopeRoute_TogglePicker takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() then
set HopeRoute_PickerOpen=not HopeRoute_PickerOpen
endif
endfunction
function HopeRoute_ChooseSlot takes integer slot returns nothing
local player p=DzGetTriggerUIEventPlayer()
if slot>=1 and slot<=HopeRoute_AvailableCount then
call HopeRoute_Select(p,HopeRoute_Available[slot])
endif
set p=null
endfunction
function HopeRoute_Collect takes nothing returns nothing
local unit u=GetEnumUnit()
local integer i=HopeRoute_AvailableCount
if LoadBoolean(YDHT,GetHandleId(u),$C31B86D5) and LoadInteger(YDHT,GetHandleId(u),$66256FC7)==udg_boci and i<6 then
// Stable left-to-right ordering makes two identical room types distinguishable.
loop
exitwhen i<=0
exitwhen GetUnitX(HopeRoute_Available[i])<=GetUnitX(u)
set HopeRoute_Available[i+1]=HopeRoute_Available[i]
set i=i-1
endloop
set HopeRoute_Available[i+1]=u
set HopeRoute_AvailableCount=HopeRoute_AvailableCount+1
endif
set u=null
endfunction
function HopeRoute_RefreshPicker takes nothing returns nothing
local integer i=1
local integer owner=GetPlayerId(GetLocalPlayer())
local boolean show=false
local group g=CreateGroup()
set HopeRoute_AvailableCount=0
call GroupEnumUnitsOfPlayer(g,Player(PLAYER_NEUTRAL_PASSIVE),null)
call ForGroup(g,function HopeRoute_Collect)
call DestroyGroup(g)
set g=null
if not HopeRoute_Valid() then
call HopeRoute_ClearMarker()
endif
call HopeJob_ShowFrame(HopeRoute_AssignPanel,HopeRoute_Assigning and owner==HopeRoute_Host())
loop
exitwhen i>6
call HopeJob_ShowFrame(HopeRoute_AssignButton[i],HopeRoute_Active(i-1))
call HopeJob_SetText(HopeRoute_AssignButton[i],"玩家 "+I2S(i)+" · "+GetPlayerName(Player(i-1)))
set i=i+1
endloop
set show=not udg_ZhandouZhong and not HopeRoute_Assigning and HopeRoute_AvailableCount>0 and HopeRoute_Active(owner)
call HopeJob_ShowFrame(HopeRoute_Picker,show and HopeRoute_PickerOpen and (HopeChoice_Hidden or not HopeChoice_HasPending()))
call HopeJob_SetText(HopeRoute_PickerTitle,"可达路线（从左到右） · 第"+I2S(udg_boci)+"层")
set i=1
loop
exitwhen i>6
call HopeJob_ShowFrame(HopeRoute_NodeButton[i],i<=HopeRoute_AvailableCount)
if i<=HopeRoute_AvailableCount then
call HopeJob_SetText(HopeRoute_NodeButton[i],I2S(i)+". "+HopeRoute_Title(HopeRoute_Available[i]))
endif
set i=i+1
endloop
endfunction
'''

def apply(src):
    src=src.replace('endglobals',GLOBALS+'\nendglobals',1)
    old=block(src,'HopeRoute_Leader')
    leader='''function HopeRoute_Leader takes nothing returns integer
if HopeRoute_Active(HopeRoute_ChosenLeader) then
return HopeRoute_ChosenLeader
endif
return HopeRoute_Host()
endfunction'''
    src=src.replace(old,EARLY+leader,1)
    src=replace(src,'HopeRoute_Select',SELECT)
    src=src.replace('function Trig______________012Actions takes',ENTER+'\nfunction Trig______________012Actions takes',1)
    src=replace(src,'Trig______________012Actions','''function Trig______________012Actions takes nothing returns nothing
call HopeRoute_Select(GetTriggerPlayer(),GetTriggerUnit())
endfunction''')
    leave=block(src,'HopeRoute_Leave')
    leave=leave.replace('call HopeRoute_ClearReady()', 'call HopeRoute_ClearReady()\nif i==HopeRoute_ChosenLeader then\nset HopeRoute_ChosenLeader=HopeRoute_Host()\nendif')
    src=replace(src,'HopeRoute_Leave',leave)
    src=src.replace('编号最小的在线玩家为队长','路线选择者离开时，自动交给编号最小的在线玩家')
    src=src.replace('全员已准备：队长再次点击已提议的路线即可出发。','全员已准备：路线选择者可点击准备面板的【出发】。')
    src=src.replace('当前在线队员中编号最小者为队长。','开局由主机指定路线选择者。')
    src=src.replace('全员准备后，队长再次点击同一节点出发。','全员准备后，路线选择者点击准备面板的【出发】。')
    src=src.replace('队长选路自动准备；队友处理好奖励并准备后，队长再次点击路线出发','路线选择者选路后自动准备；队友处理好奖励并准备后，选择者点击准备面板的【出发】')
    src=src.replace('（队长）','（选路）').replace('队长点击黄色可达节点','路线选择者点击黄色可达节点或路线列表')
    # Expand readiness panel by one row, including a guarded visible departure control.
    src=src.replace('local real contentY=-.052','local real contentY=-.082')
    anchor='call DzFrameShow(HopeRoute_WaitButton,HopeRoute_Ready[i])'
    src=src.replace(anchor,anchor+'\ncall HopeJob_ShowFrame(HopeRoute_DepartButton,i==HopeRoute_Leader())\nif HopeRoute_AllReady() then\ncall HopeJob_SetText(HopeRoute_DepartButton,"全员已准备 · 出发")\nelse\ncall HopeJob_SetText(HopeRoute_DepartButton,"等待队友 · 出发")\nendif')
    # Existing update is earlier than guarded wrappers. Use frame-native under nonzero guard.
    f=block(src,'HopeRoute_UpdateUI').replace('call HopeJob_ShowFrame(', 'call DzFrameShow(').replace('call HopeJob_SetText(', 'call DzFrameSetText(')
    f=f.replace('call DzFrameShow(HopeRoute_DepartButton,i==HopeRoute_Leader())','if HopeRoute_DepartButton!=0 then\ncall DzFrameShow(HopeRoute_DepartButton,i==HopeRoute_Leader())').replace('call DzFrameSetText(HopeRoute_Text,HopeRoute_CompactStatus())','endif\ncall DzFrameSetText(HopeRoute_Text,HopeRoute_CompactStatus())')
    src=replace(src,'HopeRoute_UpdateUI',f)
    callbacks=''
    create='''function HopeRoute_CreateExtra takes nothing returns nothing
local integer f=0
set HopeRoute_DepartButton=HopeQoL_Button("HopeDepart",HopeRoute_Panel,.007,-.052,.120,.025,"出发")
call HopeQoL_Bind(HopeRoute_DepartButton,function HopeRoute_DepartClick,true)
set f=HopeQoL_Button("HopeRoutePickerOpen",DzGetGameUI(),.014,.409,.134,.025,"选择 / 查看路线")
call DzFrameSetAbsolutePoint(f,0,.014,.410)
call HopeQoL_Bind(f,function HopeRoute_TogglePicker,false)
set HopeRoute_AssignPanel=HopeQoL_Surface("HopeRouteAssign",.229,.540,.342,.340)
set f=HopeQoL_Label("HopeRouteAssignTitle",HopeRoute_AssignPanel,.014,-.012,.310,.054,"本局由谁选择路线？|n主机指定一名在线玩家。")
set HopeRoute_Picker=HopeQoL_Surface("HopeRoutePicker",.159,.500,.272,.325)
set HopeRoute_PickerTitle=HopeQoL_Label("HopeRoutePickerTitle",HopeRoute_Picker,.012,-.012,.244,.040,"")
set f=HopeQoL_Button("HopeRoutePickerClose",HopeRoute_Picker,.184,-.282,.076,.027,"收起")
call HopeQoL_Bind(f,function HopeRoute_TogglePicker,false)
'''
    for i in range(1,7):
        callbacks+=f'function HopeRoute_Assign{i} takes nothing returns nothing\ncall HopeRoute_Assign(DzGetTriggerUIEventPlayer(),{i-1})\nendfunction\n'
        callbacks+=f'function HopeRoute_Node{i} takes nothing returns nothing\ncall HopeRoute_ChooseSlot({i})\nendfunction\n'
        create+=f'set HopeRoute_AssignButton[{i}]=HopeQoL_Button("HopeAssign{i}",HopeRoute_AssignPanel,.014,{-.077-(i-1)*.040:.3f},.314,.033,"")\ncall HopeQoL_Bind(HopeRoute_AssignButton[{i}],function HopeRoute_Assign{i},true)\n'
        create+=f'set HopeRoute_NodeButton[{i}]=HopeQoL_Button("HopeNode{i}",HopeRoute_Picker,.012,{-.050-(i-1)*.037:.3f},.248,.031,"")\ncall HopeQoL_Bind(HopeRoute_NodeButton[{i}],function HopeRoute_Node{i},true)\n'
    create+='call HopeJob_ShowFrame(HopeRoute_AssignPanel,false)\ncall HopeJob_ShowFrame(HopeRoute_Picker,false)\nendfunction\n'
    src=src.replace('function main takes nothing returns nothing',LATE+callbacks+create+'\nfunction main takes nothing returns nothing',1)
    src=src.replace('队长','路线选择者').replace('全员准备后再选路','选路、准备与出发')
    return src
