from pathlib import Path
import struct,re
R=Path('/workspace/map-edit');O=R/'modified';O.mkdir(exist_ok=True)
# Add three hidden hero records by copying the existing militia's actual SLK rows.
def clone_slk(file,ids,override):
 lines=(R/('Units_'+file)).read_text(encoding='utf-8-sig').splitlines();x=y=1;rows={};heads={}
 for l in lines:
  if not l.startswith('C;'):continue
  m=re.search(r';X(\d+)',l)
  if m:x=int(m[1])
  m=re.search(r';Y(\d+)',l)
  if m:y=int(m[1])
  if ';K' in l:
   val=l.split(';K',1)[1];rows.setdefault(y,{})[x]=val
 heads={v.strip('"'):x for x,v in rows[1].items()}
 base=next(v for y,v in rows.items() if v.get(1)=='"H000"')
 maxrow=max(rows);generated=[]
 for offset,id in enumerate(ids,1):
  r=base.copy();r[1]='"'+id+'"'
  if 'name' in heads:r[heads['name']]='"custom_'+id+'"'
  if 'file' in heads and file=='UnitUI.slk':r[heads['file']]='"units\\human\\BloodElfSpellThief\\BloodElfSpellThief"'
  if 'scale' in heads and file=='UnitUI.slk':r[heads['scale']]=str(1.+.08*(offset-1))
  for key,value in override.items():
   if key in heads:r[heads[key]]='"'+value+'"'
  for x,value in sorted(r.items()):generated.append(f'C;X{x};Y{maxrow+offset};K{value}')
 lines=[l for l in lines if l!='E']
 for i,l in enumerate(lines):
  if l.startswith('B;'):lines[i]=re.sub(r';Y\d+',f';Y{maxrow+len(ids)}',l)
 (O/('Units_'+file)).write_text('\r\n'.join(lines+generated+['E'])+'\r\n',encoding='utf-8')
ids=['HZ01','HZ02','HZ03']
for f in ['UnitData.slk','UnitBalance.slk','UnitUI.slk','UnitWeapons.slk','UnitAbilities.slk']:
 clone_slk(f,ids,{'abilList':'A001,AZHA,AInv,A002','heroAbilList':'AZHP'})
s=(R/'Units_campaignunitstrings.txt').read_text(encoding='utf-8-sig')
for id,name in zip(ids,['万象行者','万象织法者','万象天枢']):
 s+=f'\n[{id}]\nArt=ReplaceableTextures\\CommandButtons\\BTNSpellBreaker.blp\nName={name}\nMissilespeed=1500,1500\nSpecialart=Objects\\Spawnmodels\\Human\\HumanLargeDeathExplode\\HumanLargeDeathExplode.mdl\nUbertip=隐藏全属性职业，三相打击由力量、敏捷、智力共同驱动。\n'
(O/'Units_campaignunitstrings.txt').write_text(s,encoding='utf-8')
# New abilities use standard channel objects with visible no-target and enemy-target commands.
# Existing object modifications are retained byte-for-byte.
b=(R/'war3map.w3a').read_bytes();assert b[-4:]==b'\x00'*4
I=lambda n:struct.pack('<i',n)
def mod(field,typ,value,level=0,data=0):
 val=I(value) if typ==0 else struct.pack('<f',value) if typ in (1,2) else value.encode()+b'\0'
 return field.encode()+I(typ)+I(level)+I(data)+val+b'\0'*4
objects=[]
for id,name,target,order,posx,desc,art in [
('AZHA','三相打击',1,'cripple',0,'消耗1行动点，0魔法。|n单体物理伤害基值：|n一转：攻击力*0.60 + 三围总和*0.45|n二转：攻击力*0.65 + 三围总和*0.65|n三转：攻击力*0.70 + 三围总和*0.80|n计算技能与最终倍率；不附加随机暴击。','BTNSpellBreaker'),
('AZ31','战意震荡',0,'spellsteal',2,'全体存活敌人受到力量*3的物理伤害。','BTNThunderClap'),
('AZ32','风暴弹幕',0,'spellsteal',2,'全体存活敌人受到敏捷*3的物理伤害。','BTNClusterRockets'),
('AZ33','奥能洪流',0,'spellsteal',2,'全体存活敌人受到智力*3的法术伤害。','BTNMonsoon'),
('AZ34','圣愈祈愿',0,'spellsteal',2,'全体存活队友恢复各自生命上限的20% + 施法者智力。','BTNHolyBolt'),
('AZ35','万象共鸣',0,'spellsteal',2,'全体存活敌人受到三围总和*1.1的法术伤害。','BTNMagicImmunity')]:
 if id!='AZHA':desc+='|n消耗2行动点、3魔法；每回合一次。|n伤害计入技能与最终倍率，法术另计法伤倍率。'
 hotkey='Q' if id=='AZHA' else 'E'
 mods=[mod('anam',3,name),mod('ansf',3,'（职业专属）'),mod('aart',3,'ReplaceableTextures\\CommandButtons\\'+art+'.blp'),mod('ahky',3,hotkey),mod('abpx',0,posx),mod('abpy',0,2 if id=='AZHA' else 1),mod('aher',0,0),mod('alev',0,1),mod('arac',3,'human'),mod('atp1',3,name+'（'+hotkey+'）',1),mod('aub1',3,desc,1),mod('amcs',0,0,1),mod('acdn',1,.1,1),mod('aran',1,99999.,1),mod('adur',1,0.,1),mod('ahdu',1,0.,1),mod('Ncl1',1,0.,1,1),mod('Ncl2',0,target,1,2),mod('Ncl3',0,1,1,3),mod('Ncl4',1,0.,1,4),mod('Ncl5',0,0,1,5),mod('Ncl6',3,order,1,6)]
 objects.append(b'ANcl'+id.encode()+I(len(mods))+b''.join(mods))
# A passive hero skill: automatic attribute data stays at zero, and the skill event grants
# permanent BASE attributes. This keeps the existing promotion checks consistent.
mods=[mod('anam',3,'三相修炼'),mod('aart',3,'ReplaceableTextures\\PassiveButtons\\PASBTNStatUp.blp'),mod('arar',3,'ReplaceableTextures\\CommandButtons\\BTNAttributeBonus.blp'),mod('aher',0,1),mod('alev',0,3),mod('arlv',0,1),mod('alsk',0,1),mod('arhk',3,'T'),mod('aret',3,'学习三相修炼'),mod('arut',3,'每学习一级，永久基础力量、敏捷、智力各+2；最多3级。|n二转、三转保留已学等级，不重复发放属性。')]
for rank in range(1,4):
 mods.extend([mod('Istr',0,0,rank,3),mod('Iagi',0,0,rank,1),mod('Iint',0,0,rank,2),mod('atp1',3,'三相修炼 - 等级 '+str(rank),rank),mod('aub1',3,'每级永久基础力量、敏捷、智力各+2。|n最多3级；已累计各+'+str(rank*2)+'。',rank)])
objects.append(b'AamkAZHP'+I(len(mods))+b''.join(mods))
(O/'war3map.w3a').write_bytes(b[:-4]+I(len(objects))+b''.join(objects))
print('Added hidden hero rows: 3 x 5 SLK tables; abilities:',len(objects))


# Preserve all old ability-string sections, replacing only meditation's stale tooltip.
s=(R/'Units_campaignabilitystrings.txt').read_text(encoding='utf-8-sig')
a=s.index('[A01H]');b=s.index('\n[',a+1)
section=s[a:b]
section=re.sub(r'^Ubertip=.*$', 'Ubertip=恢复施法前3+（智力/5）点魔法，最多补满当前魔法上限。|n本回合智力提高30%（取整），不增加魔法上限。|n消耗1行动点、0魔法；每回合一次。|n回合结束移除临时智力，保留已恢复魔法。',section,flags=re.M)
s=s[:a]+section+s[b:]
(O/'Units_campaignabilitystrings.txt').write_text(s,encoding='utf-8')
