from pathlib import Path
import re
R=Path('/workspace/map-edit');O=R/'modified';O.mkdir(exist_ok=True)
# Add three hidden hero records by copying the existing militia's actual SLK rows.
def clone_slk(file,ids,override):
 lines=(R/('Units_'+file)).read_text(encoding='utf-8-sig').splitlines();x=y=1;rows={};heads={}
 for l in lines:
  if not l.startswith('C;'):continue
  m=re.search(r';X(\d+)',l)
  if m:x=int(m[1])
  m=re.search(r';Y(\d+)',l)
  if m:y=int(m[1])
  if ';K' in l:
   val=l.split(';K',1)[1];rows.setdefault(y,{})[x]=val
 heads={v.strip('"'):x for x,v in rows[1].items()}
 base=next(v for y,v in rows.items() if v.get(1)=='"H000"')
 maxrow=max(rows);generated=[]
 for offset,id in enumerate(ids,1):
  r=base.copy();r[1]='"'+id+'"'
  if 'name' in heads:r[heads['name']]='"custom_'+id+'"'
  if 'file' in heads and file=='UnitUI.slk':r[heads['file']]='"units\\human\\BloodElfSpellThief\\BloodElfSpellThief"'
  if 'scale' in heads and file=='UnitUI.slk':r[heads['scale']]=str(1.+.08*(offset-1))
  for key,value in override.items():
   if key in heads:r[heads[key]]='"'+value+'"'
  for x,value in sorted(r.items()):generated.append(f'C;X{x};Y{maxrow+offset};K{value}')
 lines=[l for l in lines if l!='E']
 for i,l in enumerate(lines):
  if l.startswith('B;'):lines[i]=re.sub(r';Y\d+',f';Y{maxrow+len(ids)}',l)
 (O/('Units_'+file)).write_text('\r\n'.join(lines+generated+['E'])+'\r\n',encoding='utf-8')
ids=['HZ01','HZ02','HZ03']
for f in ['UnitData.slk','UnitBalance.slk','UnitUI.slk','UnitWeapons.slk','UnitAbilities.slk']:
 clone_slk(f,ids,{'abilList':'A001,AZHA,AInv,A002','heroAbilList':'AZHP'})
s=(R/'Units_campaignunitstrings.txt').read_text(encoding='utf-8-sig')
for id,name in zip(ids,['万象行者','万象织法者','万象天枢']):
 s+=f'\n[{id}]\nArt=ReplaceableTextures\\CommandButtons\\BTNSpellBreaker.blp\nName={name}\nMissilespeed=1500,1500\nSpecialart=Objects\\Spawnmodels\\Human\\HumanLargeDeathExplode\\HumanLargeDeathExplode.mdl\nUbertip=隐藏全属性职业，三相打击由力量、敏捷、智力共同驱动。\n'
(O/'Units_campaignunitstrings.txt').write_text(s,encoding='utf-8')
# This map replaces the stock ability table with an optimized SLK. Its table
# contains ANcl/Aamk engine codes but does not contain those stock object aliases.
# Therefore new skills must be complete SLK objects, not w3a objects inheriting
# from the absent aliases. Retain the original w3a modifications byte-for-byte.
(O/'war3map.w3a').write_bytes((R/'war3map.w3a').read_bytes())

def read_slk(path):
 lines=path.read_text(encoding='utf-8-sig').splitlines()
 rows={};x=y=1
 for line in lines:
  if not line.startswith('C;'):continue
  match=re.search(r';X(\d+)',line)
  if match:x=int(match[1])
  match=re.search(r';Y(\d+)',line)
  if match:y=int(match[1])
  if ';K' in line:
   assert x not in rows.setdefault(y,{}),('duplicate cell',x,y)
   rows[y][x]=line.split(';K',1)[1]
 heads={value.strip('"'):x for x,value in rows[1].items()}
 objects={row[1].strip('"'):row for y,row in rows.items() if y!=1}
 return lines,rows,heads,objects

def slk_value(value):
 if isinstance(value,str):return '"'+value.replace('"','""')+'"'
 if isinstance(value,(int,float)):return str(value)
 raise TypeError(type(value))

ability_lines,ability_rows,ability_heads,ability_objects=read_slk(R/'Units_AbilityData.slk')
original_ability_cells={y:row.copy() for y,row in ability_rows.items()}
extra_headers=[]
for name in ('hero','item','race'):
 if name not in ability_heads:
  column=max(ability_heads.values())+1
  ability_heads[name]=column
  extra_headers.append(f'C;X{column};Y1;K"{name}"')

# Add the headers before the first data row, keeping every original cell intact.
header_end=next(i for i,line in enumerate(ability_lines)
                if line.startswith('C;') and re.search(r';Y2(?:;|$)',line))
ability_lines[header_end:header_end]=extra_headers
new_ability_rows=[]
profiles=(R/'Units_campaignabilitystrings.txt').read_text(encoding='utf-8-sig')

def clone_profile(alias):
 match=re.search(r'^\['+re.escape(alias)+r'\]\s*\n(.*?)(?=^\[|\Z)',profiles,re.M|re.S)
 assert match,alias
 fields={}
 for line in match[1].splitlines():
  if '=' in line:
   key,value=line.split('=',1)
   assert key not in fields,(alias,key)
   fields[key]=value
 return fields

def add_ability(alias,base,values,profile):
 assert alias not in ability_objects,alias
 assert not re.search(r'^\['+re.escape(alias)+r'\]',profiles,re.M),alias
 row=ability_objects[base].copy()
 values={'alias':alias,**values}
 for name,value in values.items():
  assert name in ability_heads,name
  row[ability_heads[name]]=slk_value(value)
 new_ability_rows.append(row)
 return '\n['+alias+']\n'+'\n'.join(key+'='+value for key,value in profile.items())+'\n'

profile_additions=[]
for id,name,target,order,posx,desc,art in [
('AZHA','三相打击',1,'cripple',0,'消耗1行动点，0魔法。|n单体物理伤害基值：|n一转：攻击力*0.60 + 三围总和*0.45|n二转：攻击力*0.65 + 三围总和*0.65|n三转：攻击力*0.70 + 三围总和*0.80|n计算技能与最终倍率；不附加随机暴击。','BTNSpellBreaker'),
('AZ31','战意震荡',0,'spellsteal',2,'全体存活敌人受到力量*3的物理伤害。','BTNThunderClap'),
('AZ32','风暴弹幕',0,'spellsteal',2,'全体存活敌人受到敏捷*3的物理伤害。','BTNClusterRockets'),
('AZ33','奥能洪流',0,'spellsteal',2,'全体存活敌人受到智力*3的法术伤害。','BTNMonsoon'),
('AZ34','圣愈祈愿',0,'spellsteal',2,'全体存活队友恢复各自生命上限的20% + 施法者智力。','BTNHolyBolt'),
('AZ35','万象共鸣',0,'spellsteal',2,'全体存活敌人受到三围总和*1.1的法术伤害。','BTNMagicImmunity')]:
 if id!='AZHA':desc+='|n消耗2行动点、3魔法；每回合一次。|n伤害计入技能与最终倍率，法术另计法伤倍率。'
 hotkey='Q' if id=='AZHA' else 'Z'
 base='A000' if target else 'A001'
 assert ability_objects[base][ability_heads['code']]=='"ANcl"'
 values={'code':'ANcl','hero':0,'item':0,'race':'human','levels':1,
         'reqLevel':1,'levelSkip':0,'Area1':0.0,'Cast1':0.0,'Cost1':0,
         'Cool1':0.1,'Rng1':99999.0,'Dur1':0.0,'HeroDur1':0.0,
         'DataA1':0.0,'DataB1':target,'DataC1':1,'DataD1':0.0,
         'DataE1':0,'DataF1':order,'targs1':'enemies,neutral' if target else '_'}
 profile=clone_profile(base)
 profile.update({'Name':name,'EditorSuffix':'（职业专属）',
                 'Art':'ReplaceableTextures\\CommandButtons\\'+art+'.blp',
                 'Buttonpos':str(posx)+','+('2' if id=='AZHA' else '1'),
                 'Hotkey':hotkey,'Order':order,'Tip':name+'（'+hotkey+'）','Ubertip':desc})
 profile_additions.append(add_ability(id,base,values,profile))
# A passive hero skill: automatic attribute data stays at zero, and the skill event grants
# permanent BASE attributes. This keeps the existing promotion checks consistent.
assert ability_objects['A00P'][ability_heads['code']]=='"Aamk"'
values={'code':'Aamk','hero':1,'item':0,'race':'human','levels':3,'reqLevel':1,'levelSkip':1}
for rank in range(1,4):
 for name in ('DataA','DataB','DataC','DataD','Cost'):
  values[name+str(rank)]=0
 for name in ('Area','Cast','Cool','Dur','HeroDur','Rng'):
  values[name+str(rank)]=0.0
 values['targs'+str(rank)]='_'
profile=clone_profile('A00P')
profile.update({'Name':'三相修炼','Art':'ReplaceableTextures\\PassiveButtons\\PASBTNStatUp.blp',
                'ResearchArt':'ReplaceableTextures\\CommandButtons\\BTNStatUp.blp',
                'Researchhotkey':'T','Researchtip':'学习三相修炼',
                'Researchubertip':'每学习一级，永久基础力量、敏捷、智力各+2；最多3级。|n二转、三转保留已学等级，不重复发放属性。',
                'Tip':','.join('三相修炼 - 等级 '+str(rank) for rank in range(1,4)),
                'Ubertip':','.join('每级永久基础力量、敏捷、智力各+2。|n最多3级；已累计各+'+str(rank*2)+'。' for rank in range(1,4))})
profile_additions.append(add_ability('AZHP','A00P',values,profile))

last_original_row=max(ability_rows)
ability_lines=[line for line in ability_lines if line!='E']
for i,line in enumerate(ability_lines):
 if line.startswith('B;'):
  line=re.sub(r';X\d+',f';X{max(ability_heads.values())}',line)
  ability_lines[i]=re.sub(r';Y\d+',f';Y{last_original_row+len(new_ability_rows)}',line)
for offset,row in enumerate(new_ability_rows,1):
 for column,value in sorted(row.items()):
  ability_lines.append(f'C;X{column};Y{last_original_row+offset};K{value}')
(O/'Units_AbilityData.slk').write_text('\r\n'.join(ability_lines+['E'])+'\r\n',encoding='utf-8')
# Re-read the generated table to catch cell loss and accidental numeric quoting.
_,written_rows,written_heads,written_objects=read_slk(O/'Units_AbilityData.slk')
for y,row in original_ability_cells.items():
 for column,value in row.items():assert written_rows[y][column]==value,(y,column)
for rank in range(1,4):
 for name in ('DataA','DataB','DataC'):
  assert written_objects['AZHP'][written_heads[name+str(rank)]]=='0'
assert (O/'war3map.w3a').read_bytes()==(R/'war3map.w3a').read_bytes()
print('Added hidden hero rows: 3 x 5 SLK tables; native SLK abilities:',len(new_ability_rows))

# Preserve all old ability-string sections, replacing only meditation's stale tooltip.
s=profiles
a=s.index('[A01H]');b=s.index('\n[',a+1)
section=s[a:b]
section=re.sub(r'^Ubertip=.*$', 'Ubertip=恢复施法前3+（智力/5）点魔法，最多补满当前魔法上限。|n本回合智力提高30%（取整），不增加魔法上限。|n消耗1行动点、0魔法；每回合一次。|n回合结束移除临时智力，保留已恢复魔法。',section,flags=re.M)
s=s[:a]+section+s[b:]
(O/'Units_campaignabilitystrings.txt').write_text(s+''.join(profile_additions),encoding='utf-8')

from hidden_objects import apply_objects
apply_objects(R,O)

from firemage_patch import apply_objects as apply_firemage_objects
apply_firemage_objects(R,O)

from priest_patch import apply_objects as apply_priest_objects
from challenge_objects import apply_objects as apply_challenge_objects
apply_priest_objects(R,O)
apply_challenge_objects(R,O)
