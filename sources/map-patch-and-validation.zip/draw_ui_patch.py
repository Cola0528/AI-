"""Share the original reward lottery and retain bounded per-player result history."""
from modern_choices_patch import block,replace
GLOBALS='''
hashtable HopeDraw_History=null
integer array HopeDraw_Count
boolean array HopeDraw_Busy
integer HopeDraw_Panel=0
integer HopeDraw_Title=0
integer HopeDraw_Text=0
integer HopeDraw_WoodPanel=0
integer HopeDraw_WoodStatus=0
boolean HopeDraw_Open=false
boolean HopeDraw_WoodOpen=false
integer HopeDraw_Page=0
'''
EARLY='''function HopeDraw_Reward takes player p returns string
local integer i=GetPlayerId(p)+1
local unit u=udg_hero[i]
local string result=""
// Preserve every branch and probability from the original ten-draw table.
if GetRandomInt(1,10)>=6 then
if GetRandomInt(1,3)==1 then
call ModifyHeroStat(bj_HEROSTAT_STR,u,bj_MODIFYMETHOD_ADD,1)
set result="力量 +1"
elseif GetRandomInt(1,2)==1 then
call ModifyHeroStat(bj_HEROSTAT_AGI,u,bj_MODIFYMETHOD_ADD,1)
set result="敏捷 +1"
else
call ModifyHeroStat(bj_HEROSTAT_INT,u,bj_MODIFYMETHOD_ADD,1)
set result="智力 +1"
endif
elseif GetRandomInt(1,5)>=3 then
call ModifyHeroStat(bj_HEROSTAT_STR,u,bj_MODIFYMETHOD_ADD,3)
call ModifyHeroStat(bj_HEROSTAT_AGI,u,bj_MODIFYMETHOD_ADD,3)
call ModifyHeroStat(bj_HEROSTAT_INT,u,bj_MODIFYMETHOD_ADD,3)
set result="全属性 +3"
elseif GetRandomInt(1,5)>=2 then
if GetRandomInt(1,3)==1 then
set udg_Skill_Dm[i]=udg_Skill_Dm[i]+.1
set udg_Fashang_Dm[i]=udg_Fashang_Dm[i]+.1
set result="技能伤害 +10% / 法术伤害 +10%"
elseif GetRandomInt(1,2)==1 then
set udg_Baoji_Damage[i]=udg_Baoji_Damage[i]+.1
set udg_Baoji_Lv[i]=udg_Baoji_Lv[i]+5
set result="暴击率 +5% / 暴击伤害 +10%"
else
set udg_Zuizhong_Dm[i]=udg_Zuizhong_Dm[i]+.1
set result="最终伤害 +10%"
endif
else
call UnitAddItemByIdSwapped($49303456,u)
set result="圣剑（物品；背包满时落在英雄脚下）"
endif
set u=null
return result
endfunction
function HopeDraw_Record takes player p,string title,string text returns nothing
local integer i=GetPlayerId(p)
local integer page=0
set HopeDraw_Count[i]=HopeDraw_Count[i]+1
set page=ModuloInteger(HopeDraw_Count[i],64)*2
call SaveStr(HopeDraw_History,i,page,title)
call SaveStr(HopeDraw_History,i,page+1,text)
if p==GetLocalPlayer() then
set HopeDraw_Page=HopeDraw_Count[i]
set HopeDraw_Open=true
set HopeDraw_WoodOpen=false
set HopeChoice_Hidden=true
endif
endfunction
function HopeDraw_Ten takes player p returns boolean
local integer i=GetPlayerId(p)
local integer n=1
local string text=""
if i<0 or i>=6 or HopeDraw_Busy[i] or udg_hero[i+1]==null or GetUnitTypeId(udg_hero[i+1])==0 then
return false
endif
if GetPlayerState(p,PLAYER_STATE_RESOURCE_GOLD)<648 then
call DisplayTextToPlayer(p,0,0,"十连抽需要648金币，当前金币不足。")
return false
endif
set HopeDraw_Busy[i]=true
call SetPlayerState(p,PLAYER_STATE_RESOURCE_GOLD,GetPlayerState(p,PLAYER_STATE_RESOURCE_GOLD)-648)
loop
exitwhen n>10
set text=text+I2S(n)+". "+HopeDraw_Reward(p)+"|n"
set n=n+1
endloop
call HopeDraw_Record(p,"十连抽结果 · 消耗648金币",text)
set HopeDraw_Busy[i]=false
return true
endfunction
function HopeDraw_WoodAllowed takes player p returns boolean
local integer i=GetPlayerId(p)
if i<0 or i>=6 or GetPlayerSlotState(p)!=PLAYER_SLOT_STATE_PLAYING or GetPlayerController(p)!=MAP_CONTROL_USER then
return false
endif
return not udg_ZhandouZhong and GetUnitTypeId(udg_Youxi_xzgq)=='n00K' and udg_hero[i+1]!=null and GetWidgetLife(udg_hero[i+1])>.405
endfunction
function HopeDraw_Wood takes player p returns boolean
local integer i=GetPlayerId(p)
local string result="谢谢惠顾（未获得奖励）"
if not HopeDraw_WoodAllowed(p) then
call DisplayTextToPlayer(p,0,0,"请在装备商店房间、非战斗状态下抽取。")
return false
endif
if HopeDraw_Busy[i] or GetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER)<1 then
call DisplayTextToPlayer(p,0,0,"本次抽取需要1木材。")
return false
endif
set HopeDraw_Busy[i]=true
call SetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER,GetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER)-1)
if GetRandomInt(1,100)>50 then
set result=HopeDraw_Reward(p)
endif
call HopeDraw_Record(p,"木材抽取结果 · 消耗1木材",result+"|n|n木材抽取50%谢谢惠顾；未抽空时沿用十连奖池。")
set HopeDraw_Busy[i]=false
return true
endfunction
'''
LATE='''function HopeDraw_WoodClick takes nothing returns nothing
call HopeDraw_Wood(DzGetTriggerUIEventPlayer())
endfunction
function HopeDraw_ReturnWood takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() then
set HopeDraw_Open=false
set HopeDraw_WoodOpen=true
endif
endfunction
function HopeDraw_Close takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() then
set HopeDraw_Open=false
endif
endfunction
function HopeDraw_OpenHistory takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() then
set HopeDraw_Open=not HopeDraw_Open
set HopeDraw_WoodOpen=false
if HopeDraw_Page<=0 then
set HopeDraw_Page=HopeDraw_Count[GetPlayerId(GetLocalPlayer())]
endif
if HopeDraw_Open then
set HopeChoice_Hidden=true
endif
endif
endfunction
function HopeDraw_Previous takes nothing returns nothing
local integer owner=GetPlayerId(GetLocalPlayer())
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() and HopeDraw_Page>IMaxBJ(1,HopeDraw_Count[owner]-63) then
set HopeDraw_Page=HopeDraw_Page-1
endif
endfunction
function HopeDraw_Next takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() and HopeDraw_Page<HopeDraw_Count[GetPlayerId(GetLocalPlayer())] then
set HopeDraw_Page=HopeDraw_Page+1
endif
endfunction
function HopeDraw_CloseWood takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() then
set HopeDraw_WoodOpen=false
endif
endfunction
function HopeDraw_OnSelect takes nothing returns nothing
local player p=GetTriggerPlayer()
local unit u=GetTriggerUnit()
if p==GetLocalPlayer() and (GetUnitTypeId(u)=='n00P' or GetUnitTypeId(u)=='n00Q') then
set HopeDraw_WoodOpen=true
endif
set p=null
set u=null
endfunction
function HopeDraw_Refresh takes nothing returns nothing
local integer owner=GetPlayerId(GetLocalPlayer())
local integer slot=ModuloInteger(HopeDraw_Page,64)*2
local boolean show=HopeDraw_Open and not (HopeChoice_HasPending() and not HopeChoice_Hidden) and not HopeRoute_Assigning
call HopeJob_ShowFrame(HopeDraw_Panel,show)
call HopeJob_ShowFrame(HopeDraw_WoodPanel,HopeDraw_WoodOpen and not show and HopeDraw_WoodAllowed(GetLocalPlayer()))
call HopeJob_SetText(HopeDraw_WoodStatus,"当前木材："+I2S(GetPlayerState(GetLocalPlayer(),PLAYER_STATE_RESOURCE_LUMBER))+"|n三转需要30木材，请按路线安排开销。")
if show then
if HopeDraw_Count[owner]==0 then
call HopeJob_SetText(HopeDraw_Title,"本局抽取记录")
call HopeJob_SetText(HopeDraw_Text,"尚无十连抽或木材抽取记录。")
else
call HopeJob_SetText(HopeDraw_Title,LoadStr(HopeDraw_History,owner,slot))
call HopeJob_SetText(HopeDraw_Text,LoadStr(HopeDraw_History,owner,slot+1)+"|n记录 "+I2S(HopeDraw_Page)+" / "+I2S(HopeDraw_Count[owner])+"；保留最近64次。")
endif
endif
endfunction
function HopeDraw_Create takes nothing returns nothing
local integer f=0
local integer i=0
local trigger t=CreateTrigger()
set HopeDraw_Panel=HopeQoL_Surface("HopeDrawResults",.200,.550,.400,.360)
set HopeDraw_Title=HopeQoL_Label("HopeDrawTitle",HopeDraw_Panel,.014,-.012,.300,.025,"")
set HopeDraw_Text=HopeQoL_Label("HopeDrawText",HopeDraw_Panel,.014,-.052,.372,.254,"")
set f=HopeQoL_Button("HopeDrawClose",HopeDraw_Panel,.318,-.012,.067,.026,"关闭")
call HopeQoL_Bind(f,function HopeDraw_Close,false)
set f=HopeQoL_Button("HopeDrawPrevious",HopeDraw_Panel,.014,-.318,.100,.028,"上一条记录")
call HopeQoL_Bind(f,function HopeDraw_Previous,false)
set f=HopeQoL_Button("HopeDrawNext",HopeDraw_Panel,.128,-.318,.100,.028,"下一条记录")
call HopeQoL_Bind(f,function HopeDraw_Next,false)
set f=HopeQoL_Button("HopeDrawReturnWood",HopeDraw_Panel,.242,-.318,.144,.028,"返回木材抽取")
call HopeQoL_Bind(f,function HopeDraw_ReturnWood,false)
set f=HopeQoL_Button("HopeDrawHistory",DzGetGameUI(),0.,0.,.085,.026,"抽取记录")
call DzFrameSetAbsolutePoint(f,0,.014,.191)
call HopeQoL_Bind(f,function HopeDraw_OpenHistory,false)
set HopeDraw_WoodPanel=HopeQoL_Surface("HopeWoodDraw",.214,.442,.372,.252)
set f=HopeQoL_Label("HopeWoodTitle",HopeDraw_WoodPanel,.014,-.012,.280,.028,"木材随机属性 · 每次1木材")
set f=HopeQoL_Label("HopeWoodRules",HopeDraw_WoodPanel,.014,-.051,.344,.104,"50% 谢谢惠顾|n25% 单项属性+1（力敏智等概率）；15% 全属性+3|n8% 伤害/暴击奖励（3项等概率）；2% 圣剑|n沿用十连抽奖励；只影响本局，不写入存档。")
set HopeDraw_WoodStatus=HopeQoL_Label("HopeWoodStatus",HopeDraw_WoodPanel,.014,-.153,.344,.040,"")
set f=HopeQoL_Button("HopeWoodBuy",HopeDraw_WoodPanel,.014,-.205,.210,.030,"抽取一次 · 1木材")
call HopeQoL_Bind(f,function HopeDraw_WoodClick,true)
set f=HopeQoL_Button("HopeWoodClose",HopeDraw_WoodPanel,.260,-.205,.098,.030,"关闭")
call HopeQoL_Bind(f,function HopeDraw_CloseWood,false)
call HopeJob_ShowFrame(HopeDraw_Panel,false)
call HopeJob_ShowFrame(HopeDraw_WoodPanel,false)
loop
exitwhen i>=6
call TriggerRegisterPlayerUnitEvent(t,Player(i),EVENT_PLAYER_UNIT_SELECTED,null)
set i=i+1
endloop
call TriggerAddAction(t,function HopeDraw_OnSelect)
set t=null
endfunction
'''
def apply(src):
    src=src.replace('endglobals',GLOBALS+'\nendglobals',1)
    # Preserve original full odds: 50% single, 30% all, 16% special, 4% sword.
    src=src.replace('function Trig____________________023Func036Func001Func004T takes',EARLY+'\nfunction Trig____________________023Func036Func001Func004T takes',1)
    src=replace(src,'Trig____________________023Func036Func001Func004T','''function Trig____________________023Func036Func001Func004T takes nothing returns nothing
call FlushChildHashtable(YDLOC,GetHandleId(GetExpiredTimer()))
call DestroyTimer(GetExpiredTimer())
endfunction''')
    f=block(src,'Trig____________________023Actions')
    a=f.index('if GetItemTypeId(GetManipulatedItem())==$49303431 then')
    b=f.index('if GetItemTypeId(GetManipulatedItem())==$49303434 then',a)
    f=f[:a]+'''if GetItemTypeId(GetManipulatedItem())==$49303431 then
call HopeDraw_Ten(GetOwningPlayer(GetTriggerUnit()))
endif
'''+f[b:]
    src=replace(src,'Trig____________________023Actions',f)
    src=src.replace('function main takes nothing returns nothing',LATE+'\nfunction main takes nothing returns nothing',1)
    src=src.replace('call InitGlobals()','call InitGlobals()\nset HopeDraw_History=InitHashtable()',1)
    return src
