"""Six new challenge enemies as full optimized SLK records, without w3a bases."""
import re
from hidden_objects import read_slk, raw_value, clone_section, update_section

# Four troop archetypes and two bosses: all use the map's existing A00U AI cast.
ENEMIES = {
    'nZ01': dict(base='n011', name='炼狱铁卫', hp=4200, attack=180, armor=18.0, level=8,
                scale=1.65, color=(190,110,75), skill='铁壁结阵',
                desc='施法回合为所有存活敌军提供10+当前轮数×2护甲，持续到下次敌方回合开始；同类护盾不叠加。'),
    'nZ02': dict(base='n012', name='烬火咒师', hp=3200, attack=210, armor=5.0, level=8,
                scale=1.20, color=(255,100,70), skill='焚魂火雨',
                desc='施法回合对所有存活英雄造成当前攻击×0.85+当前轮数×3的魔法伤害。'),
    'nZ03': dict(base='u00H', name='裂魂猎手', hp=3100, attack=250, armor=3.0, level=8,
                scale=1.35, color=(150,110,255), skill='裂魂狙击',
                desc='施法回合攻击生命比例最低的存活英雄，造成当前攻击×1.65的物理伤害，并削减2点魔法。'),
    'nZ04': dict(base='u007', name='血泉祭司', hp=3400, attack=140, armor=6.0, level=8,
                scale=1.55, color=(200,80,130), skill='血泉复苏',
                desc='施法回合为所有存活敌军恢复各自生命上限的8%+祭司当前攻击×0.5；不超过缺失生命。'),
    'UZ01': dict(base='Ucrl', name='熔炉暴君', hp=60000, attack=275, armor=25.0, level=10,
                scale=2.10, color=(255,120,65), skill='熔炉震荡',
                desc='施法回合对所有存活英雄造成当前攻击×1.15的物理伤害，并获得额外20护甲直到下次敌方回合开始。'),
    'UZ02': dict(base='Ulic', name='虚空摄政', hp=52000, attack=255, armor=12.0, level=10,
                scale=1.70, color=(135,100,255), skill='虚空虹吸',
                desc='施法回合对所有存活英雄造成当前攻击×0.9的魔法伤害，各削减3点魔法；按实际扣血的25%回复自己，单次至多回复生命上限的6%。'),
}
NEW_ENEMIES = set(ENEMIES)


def apply_objects(root, output):
    for table in ['UnitData', 'UnitBalance', 'UnitUI', 'UnitWeapons', 'UnitAbilities']:
        path = output / f'Units_{table}.slk'
        lines, rows, heads, objects = read_slk(path)
        last = max(rows)
        new_lines = []
        for index, (alias, info) in enumerate(ENEMIES.items(), 1):
            assert alias not in objects, alias
            row = objects[info['base']][1].copy()
            row[1] = raw_value(alias)
            changes = {}
            if table == 'UnitData' and alias in ('nZ04', 'UZ01'):
                changes = {'race': 'creeps'}
            elif table == 'UnitBalance':
                changes = {'HP': info['hp'], 'def': info['armor'], 'level': info['level'], 'regenHP': 0.0, 'mana0': 20, 'manaN': 20}
                if alias == 'nZ04':
                    changes['type'] = 'mechanical'
                elif alias == 'UZ01':
                    changes['type'] = '_'
            elif table == 'UnitWeapons':
                changes = {'dmgplus1': info['attack']}
            elif table == 'UnitUI':
                changes = dict(name='custom_'+alias, scale=info['scale'],
                    red=info['color'][0], green=info['color'][1], blue=info['color'][2])
            elif table == 'UnitAbilities':
                changes = {'abilList': 'A00U', 'heroAbilList': '_', 'auto': '_'}
            for key, value in changes.items():
                assert key in heads, (table, key)
                row[heads[key]] = raw_value(value)
            for x, value in sorted(row.items()):
                new_lines.append(f'C;X{x};Y{last+index};K{value}')
        lines = [re.sub(r';Y\d+', f';Y{last+len(ENEMIES)}', l) if l.startswith('B;') else l for l in lines if l != 'E']
        path.write_text('\r\n'.join(lines+new_lines+['E'])+'\r\n', encoding='utf-8')
        _, written, _, new_objects = read_slk(path)
        assert all(written[y] == row for y, row in rows.items()), table
        assert NEW_ENEMIES <= new_objects.keys()
    profile = output / 'Units_campaignunitstrings.txt'
    text = profile.read_text(encoding='utf-8-sig')
    for alias, info in ENEMIES.items():
        text = clone_section(text, info['base'], alias)
        changes = {'Name': info['name'], 'Tip': info['name'], 'Ubertip': info['skill']+'：'+info['desc']}
        if alias.startswith('U'):
            changes['Propernames'] = info['name']
        text = update_section(text, alias, changes)
    profile.write_text(text, encoding='utf-8')
    print('Challenge enemies: four new troops + two bosses; all original unit cells retained')
