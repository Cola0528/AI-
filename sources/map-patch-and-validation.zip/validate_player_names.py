"""Run final JASS labels with byte-faithful strings and the map's actual font.

Native UI calls are recorded; PNGs are geometry/font simulations, not KK captures.
"""
from pathlib import Path
import io,re,sys,zipfile
from fontTools.ttLib import TTFont
from PIL import ImageFont
from validate_economy import World,body,SCRIPT
from validate_layout import Layout
import validate_layout

ROOT=Path(__file__).parent
COUNT=0
def check(ok,msg):
 global COUNT
 assert ok,msg
 COUNT+=1

def original_font():
 sys.path.insert(0,'/workspace/map-tools')
 from mpq import op,read,L
 original=next(Path('/workspace/attachments').rglob('*.w3x'))
 archive=op(original,0x100)
 try:data=read(archive,r'Fonts\ZiTi.ttf')
 finally:L.SFileCloseArchive(archive)
 check(data is not None,'Chinese font actually exists in original MPQ')
 dest=ROOT/'map-chinese-font.ttf';dest.write_bytes(data)
 cmap=TTFont(io.BytesIO(data)).getBestCmap()
 event_body=body('HopeEvent_Create')[3]
 check('FRIZQT' not in SCRIPT and event_body.count('ZiTi.ttf')==2,'event text and footer explicitly use bundled Chinese font')
 check(set(re.findall(r'call DzFrameSetFont\(.*?"([^"\n]+)"',SCRIPT))=={r'Fonts\\ZiTi.ttf'},'all explicit frame fonts reference the actual bundled Chinese font')
 literals=[]
 for name in re.findall(r'^function (Trig____________________018\w*) takes',SCRIPT,re.M):
  literals+=re.findall(r'"([^"\n]*)"',body(name)[3])
 chars={c for c in ''.join(literals)+'问号事件全队玩家准备√×…★' if ord(c)>127}
 missing=sorted(c for c in chars if ord(c) not in cmap)
 check(not missing,('actual bundled font covers event Chinese and state symbols',missing))
 print('Bundled font:',len(data),'bytes;',len(cmap),'glyphs;',len(chars),'required non-ASCII characters covered.')
 return dest

def names():
 w=World();g=w.g;raw=['清风徐来','流浪的剑客','星河入梦','剑心','Cola★','小猫钓鱼']
 g['GetPlayerName']=lambda p:raw[p]
 # Check each complete character with the JASS byte-based native contract.
 samples=['清风徐来','AéΩЯ中文★𠮷😀','¢߿ࠀ￿𐀀\U0010ffff']
 for s in samples:
  at=0
  for char in s:
   size=g['HopeName_Step'](s,at)
   check(size==len(char.encode()),('UTF8 step',char,size))
   check(g['SubString'](s,at,at+size)==char,'whole code point survives byte slicing')
   at+=size
 for i,s in enumerate(raw):check(g['HopeName_Label'](i,70)==s,'normal nickname preserved '+s)
 for s in samples+['W'*30,'abcdefghijklmnopqrst','中文'*20,'A中é😀'*8]:
  for budget in [22,36,50,70,100,120]:
   actual=g['HopeName_Clip'](s,budget)
   actual.encode('utf-8') # must contain no partial UTF-8 byte surrogate
   check(g['HopeName_Width'](actual)<=budget,'clip respects visual width budget')
   check(actual==s or (actual.endswith('…') and s.startswith(actual[:-1])),'clipping retains nickname prefix')
 check(g['HopeName_Clean']('|cffff0303中文|r|n玩家')=='中文 玩家','strip inline color and linebreak codes safely')
 raw[0]='|cffff0303清风徐来|r'
 check(g['HopeName_Label'](0,70)=='清风徐来','player-color decoration does not replace nickname')
 before=g['HopeName_Version'];g['HopeName_Label'](0,70)
 check(before==g['HopeName_Version'],'cached label stable between frames')
 raw[0]='长夜未央';check(g['HopeName_Label'](0,70)=='长夜未央','late platform nickname refresh invalidates cache')
 raw[:]=['流浪的冒险者甲','流浪的冒险者乙','流浪的冒险者乙','','','孤独勇者']
 labels=[g['HopeName_Label'](i,50) for i in range(6)]
 check(len(set(labels))==6,('duplicate names and common clipped prefixes distinguish players',labels))
 for i in range(3):check(labels[i].startswith('流浪') and labels[i].endswith('#'+str(i+1)),'duplicate keeps nickname plus slot suffix')
 check(labels[3]=='玩家4' and labels[4]=='玩家5','number fallback reserved for actually empty names')
 raw[0]='小猫钓鱼';raw[1]='小猫钓鱼'
 check(g['HopeName_Label'](0,70).endswith('#1'),'same visible names disambiguated')
 w.playing.remove(1)
 check(g['HopeName_Label'](0,70)=='小猫钓鱼','departed duplicate no longer forces suffix')
 check(not w.writes and not w.messages and not w.random_calls and not w.resources,'display helpers never mutate cloud/resources/gameplay')
 check('SetPlayerName(' not in SCRIPT,'native account nickname never renamed')
 for name in ['HopeRoute_UpdateUI','HopeRoute_CompactStatus','HopeLayout_Assignment','HopeDamage_Refresh','HopeIntent_PlayerLabel']:
  text=body(name)[3]
  check('HopeName_Label' in text and 'StringLength(name)>' not in text,'all affected display consumers use safe names: '+name)

class ActualFontLayout(Layout):
 def __init__(self):
  super().__init__();self.font_path=str(ROOT/'map-chinese-font.ttf')
  self.shot=Path('/workspace/outputs/ui-layout-v13');self.shot.mkdir(exist_ok=True)

def check_single_line(w,frame,tag):
 f=w.frames[frame];text=re.sub(r'\|c[0-9a-fA-F]{8}|\|r','',f.text)
 font=ImageFont.truetype(w.font_path,round(f.font*2400))
 for line in text.split('|n'):
  check(font.getlength(line)<=f.w*2400-(6 if f.kind=='button' else 0),('actual-font single line overflow',tag,text,font.getlength(line),f.w*2400))

def panels():
 w=ActualFontLayout();g=w.g
 for count in range(1,7):
  w.playing=set(range(count));w.human=set(range(count))
  for i in range(6):
   if i<count:w.hero(i)
   else:g['udg_hero'][i+1]=None
  g['udg_boci']=1;g['HopeRoute_Node']=w.node();g['HopeRoute_Depth']=1;g['HopeRoute_Chapter']=0
  for case,raw in [
   ('chinese',['清风徐来','流浪的剑客','星河入梦','剑心','Cola★','小猫钓鱼']),
   ('long',['流浪的冒险者'+str(i) for i in range(6)]),
   ('duplicate',['星河入梦']*6),
   ('wide',['W'*18]*6)]:
   g['GetPlayerName']=lambda p:raw[p]
   for ready in [False,True]:
    for i in range(6):g['HopeRoute_Ready'][i]=ready
    g['HopeRoute_UpdateUI']();g['HopeLayout_Apply']()
    for i in range(count):
     check_single_line(w,g['HopeLayout_Member'][i],(count,case,i))
     text=w.frames[g['HopeLayout_Member'][i]].text
     check(raw[i][:2] in text,'ready panel shows actual nickname, not slot alias')
     check(('√' if ready else '×') in text,'readiness mark retained')
    w.audit('party-'+str(count)+'-'+case)
    w.render('party-'+str(count)+'-'+case,save=(count==6 and case=='chinese' and ready))
   for totals in [False,True]:
    for i in range(1,count+1):
     g['udg_Shuchu_dm_tj'][i]=3.4e38/i;g['HopeDamage_Total'][i]=3.4e38/(count+1-i)
    g['HopeDamage_Run']=totals;g['HopeDamage_Refresh']();g['HopeLayout_Apply']()
    check_single_line(w,g['HopeDamage_Text'],('damage',count,case,totals))
    w.render('damage-'+str(count)+'-'+case,save=(count==6 and case=='chinese' and totals))
   if count in [1,2,6]:
    g['HopeRoute_Assigning']=True
    for i in range(6):w.show(g['HopeRoute_AssignButton'][i+1],i<count)
    g['HopeLayout_Assignment']();g['HopeLayout_Apply']()
    for i in range(count):check_single_line(w,g['HopeRoute_AssignButton'][i+1],('assignment',case,i))
    w.audit('assignment');w.render('assignment-'+str(count)+'-'+case,save=(count==6 and case=='chinese'))
    g['HopeRoute_Assigning']=False
 check(not w.writes and not w.debits,'layout actions do not change resources')
 # All 21 shipped event branches, two random extremes, six participants and
 # every scroll offset, using actual map font instead of a substitute font.
 import validate_v12
 validate_v12.Layout=ActualFontLayout
 validate_v12.event_ui();validate_v12.event_outcomes()
 check(True,'all original event branches and shared/local-close behavior pass with actual Chinese font')
 print('PASS:',COUNT,'name/font/display assertions;',validate_layout.CASES,'geometry/text checks;',validate_v12.COUNT,'event assertions; native calls mocked, not KK.')

if __name__=='__main__':
 original_font();names();panels()
