"""Keep numeric previews, current resource rows and third job descriptions aligned."""
from modern_choices_patch import block,replace
from third_design import DESIGNS,description

RESOURCE='''function HopeThird_Resource takes unit u,integer p returns string
local integer kind=GetUnitTypeId(u)
local integer token=HopeChallenge_TurnToken()
local integer level=HopeThird_Level(u)
local integer count=0
local integer limit=2
local integer mask=0
if level<=0 then
return ""
endif
if kind=='H00D' then
if HopeThird_Cavalry[p] then
return "|cff80ef90骑势就绪 · 下次平砍强化|r"
endif
return "|cffaaaaaa骑势 · 冲锋后蓄势|r"
elseif kind=='N018' then
if level==1 then
set limit=3
endif
if HopeThird_ComboToken[p]==token then
if HopeThird_ComboPaid[p] then
return "|cff80ef90连势 · 本回合已回点|r"
endif
set count=IMinBJ(limit,HopeThird_ComboCount[p])
endif
return "|cffd2b879连势 "+I2S(count)+"/"+I2S(limit)+" · 满后回点|r"
elseif kind=='H004' then
if HopeThird_PressureToken[p]==token then
set count=HopeThird_Pressure[p]
endif
return "|cffd2b879压制 "+I2S(count)+"/3 · 换目标重置|r"
elseif kind=='N01E' then
if HopeThird_FireTarget[p]!=null and GetWidgetLife(HopeThird_FireTarget[p])>.405 then
set count=LoadInteger(HopeThird_Data,GetHandleId(HopeThird_FireTarget[p]),p)
endif
return "|cfffe8a0e最近目标火种 "+I2S(count)+"/3|r"
elseif kind=='O006' then
if HopeThird_HitsToken[p]==token then
set count=HopeThird_Hits[p]
endif
return "|cff68b99a连环 "+I2S(count)+"/3 · 满后回复|r"
elseif kind=='HZ03' then
if HopeThird_HiddenToken[p]==token then
set mask=HopeThird_HiddenMask[p]
endif
if mask>=7 then
return "|cff80ef90三律 · 本回合已贯通|r"
endif
if ModuloInteger(mask,2)==1 then
set count=count+1
endif
if ModuloInteger(mask,4)>=2 then
set count=count+1
endif
if mask>=4 then
set count=count+1
endif
return "|cff76cdd0三律 "+I2S(count)+"/3 · Q D V|r"
endif
return ""
endfunction
'''


def early(f, code):
    lines=f.splitlines()
    at=1
    while at<len(lines) and (lines[at].startswith('local ') or not lines[at].strip()):
        at+=1
    lines.insert(at,code)
    return '\n'.join(lines)


def apply(src):
    actives=[d for d in DESIGNS.values() if d['mode']=='active']
    f=block(src,'HopeSkill_InitIds')
    assert 'set HopeSkill_Count=68' in f
    f=f.replace('set HopeSkill_Count=68','\n'.join(f"set HopeSkill_Ids[{68+n}]='{d['id']}'" for n,d in enumerate(actives))+'\nset HopeSkill_Count=76')
    src=replace(src,'HopeSkill_InitIds',f)
    f=block(src,'HopeSkill_Original')
    added='\n'.join(('if' if n==0 else 'elseif')+" id=='"+d['id']+"' then\nreturn \""+description(d)+'"' for n,d in enumerate(actives))+'\nendif'
    src=replace(src,'HopeSkill_Original',early(f,added))
    f=block(src,'HopeSkill_Preview')
    previews='''if id=='AT03' then
return "每人恢复：自身生命上限20% + "+HopeSkill_Number(i)+"；回蓝2|n溢疗护甲上限 "+HopeSkill_Number(i*.5)
elseif id=='AT06' then
return "普通目标 "+HopeSkill_Number((s+d)*4.*k*z)+"；低血目标 "+HopeSkill_Number((s+d)*6.*k*z)+"|n击杀后返还1行动点"
elseif id=='AT08' then
return "主目标 "+HopeSkill_Number((a*4.+s*2.)*k*z)+"；贯穿副目标 "+HopeSkill_Number((a*4.+s*2.)*.7*k*z)+"|n长2000，宽240；只命中射线内敌人"
elseif id=='AT10' then
set b=(a*6.+d*3.)*k*z
if LoadBoolean(YDHT,GetHandleId(u),$08E215BC) then
set b=b*udg_jingque_Daji_jiacheng[p]
endif
if LoadInteger(YDHT,GetHandleId(u),$EE28B8AD)>0 then
set b=b*udg_Baoji_Damage[p]
return "必暴重狙 "+HopeSkill_Number(b)+"；剩余 "+I2S(LoadInteger(YDHT,GetHandleId(u),$30720CCD))+" 发|n消耗1发；空弹需Q装填，伤害不随机落空"
endif
return "单体重狙 "+HopeSkill_Number(b)+"；剩余 "+I2S(LoadInteger(YDHT,GetHandleId(u),$30720CCD))+" 发|n消耗1发；可配合爆头，伤害不随机落空"
elseif id=='AT11' then
return "区域每目标 "+HopeSkill_Number(i*3.*k*f*z)+"；范围450|n敌人下一次对英雄伤害 -40%"
elseif id=='AT13' then
return "每层自身毒基值 "+HopeSkill_Number(a*.3*I2R(GetUnitAbilityLevel(u,'A02U'))*2.*k*z)+"|n施放时乘以目标自己的毒层；自身恢复 "+HopeSkill_Number(hp*.1)
elseif id=='AT16' then
return "全队接下来的3次命中 +25%伤害|n每次命中玩家获得10金币；1行动点、3魔法"
elseif id=='AZ36' then
return "敌人各受 "+HopeSkill_Number((s+d+i)*1.1*k*f*z)+" 法术伤害|n队友各回复 "+HopeSkill_Number((s+d+i)*.25)+"、护甲 +"+HopeSkill_Number((s+d+i)*.1)+"；气补至3"
endif'''
    f=early(f,previews)
    # Only the already dynamic previews for the three changed base attacks.
    first='return "本次伤害 "+HopeSkill_Rolled(u,p,b,90,120)'
    assert first in f
    f=f.replace(first,'return "本次伤害 "+HopeSkill_Rolled(u,p,HopeThird_Base(u,id,b,false),90,120)',1)
    f=f.replace('HopeSkill_Rolled(u,p,b,50,151)','HopeSkill_Rolled(u,p,HopeThird_Base(u,id,b,false),50,151)')
    f=f.replace('HopeSkill_Rolled(u,p,b,50,150)','HopeSkill_Rolled(u,p,HopeThird_Base(u,id,b,false),50,150)')
    f=f.replace('HopeSkill_Rolled(u,p,a+GetUnitState(u,ConvertUnitState(32)),50,150)','HopeSkill_Rolled(u,p,HopeThird_Base(u,id,a+GetUnitState(u,ConvertUnitState(32)),false),50,150)')
    f=f.replace('return "主目标 "+HopeSkill_Number(b)+"；周围每目标 "+HopeSkill_Number(b*.5)','return "无火种主目标 "+HopeSkill_Number(b)+"；周围每目标 "+HopeSkill_Number(b*.5)+"|n觉醒后额外火种伤害按目标自己的层数结算"',1)
    src=replace(src,'HopeSkill_Preview',f)
    f=block(src,'HopeProfession_Text')
    # Existing sniper/monk/heavy-chop rows take precedence.
    end='return ""\nendfunction'
    assert f.endswith(end)
    f=f[:-len(end)]+'return HopeThird_Resource(u,p)\nendfunction'
    src=replace(src,'HopeProfession_Text',RESOURCE+'\n'+f)
    return src
