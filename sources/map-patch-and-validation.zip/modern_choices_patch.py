"""Use frame choices while preserving original synchronized reward handlers."""
import re

def block(src,name):
    return re.search(r'^function '+re.escape(name)+r' takes .*?^endfunction',src,re.M|re.S)[0]
def replace(src,name,new):
    return src.replace(block(src,name),new,1)

GLOBALS='''
hashtable HopeModern_Data=null
player HopeModern_Player=null
dialog HopeModern_Dialog=null
button HopeModern_Button=null
integer array HopeModern_Panel
integer array HopeModern_Title
integer array HopeModern_Description
integer array HopeModern_Row
integer array HopeModern_LastTick
integer HopeModern_Tick=10
boolean HopeModern_Ready=false
boolean HopeModern_Dispatching=false
'''
EARLY='''function HopeModern_Message takes dialog d,string text returns nothing
call SaveStr(HopeModern_Data,GetHandleId(d),100,text)
endfunction
function HopeModern_Add takes dialog d,string text returns nothing
local integer h=GetHandleId(d)
local integer n=LoadInteger(HopeModern_Data,h,0)+1
set bj_lastCreatedButton=DialogAddButton(d,text,0)
call SaveInteger(HopeModern_Data,h,0,n)
call SaveButtonHandle(HopeModern_Data,h,200+n,bj_lastCreatedButton)
call SaveStr(HopeModern_Data,h,n,text)
endfunction
function HopeModern_Clear takes dialog d returns nothing
call FlushChildHashtable(HopeModern_Data,GetHandleId(d))
call DialogClear(d)
endfunction
function HopeModern_NativeDisplay takes player p,dialog d,boolean show returns nothing
// No native modal is displayed. Shared lifecycle remains in HopeChoice.
endfunction
function HopeModern_GetPlayer takes nothing returns player
if HopeModern_Dispatching then
return HopeModern_Player
endif
return GetTriggerPlayer()
endfunction
function HopeModern_GetDialog takes nothing returns dialog
if HopeModern_Dispatching then
return HopeModern_Dialog
endif
return GetClickedDialogBJ()
endfunction
function HopeModern_GetButton takes nothing returns button
if HopeModern_Dispatching then
return HopeModern_Button
endif
return GetClickedButtonBJ()
endfunction
'''
LATE='''function HopeModern_Choose takes integer index,integer slot returns nothing
local player p=DzGetTriggerUIEventPlayer()
local integer owner=GetPlayerId(p)
local dialog d=null
if index<1 or index>HopeChoice_DialogCount or owner<0 or owner>=6 then
set p=null
return
endif
if HopeModern_Dispatching or not HopeChoice_DialogPending[index] or HopeChoice_Owner[index]!=owner or HopeModern_Tick-HopeModern_LastTick[owner]<3 then
set p=null
return
endif
set d=HopeChoice_Dialog[index]
if slot<1 or slot>LoadInteger(HopeModern_Data,GetHandleId(d),0) then
set p=null
set d=null
return
endif
set HopeModern_LastTick[owner]=HopeModern_Tick
set HopeModern_Player=p
set HopeModern_Dialog=d
set HopeModern_Button=LoadButtonHandle(HopeModern_Data,GetHandleId(d),200+slot)
set HopeModern_Dispatching=true
if d==udg_Youxi_ND_XZ then
if udg_Yx_Nd_Dj==0 then
call Trig____________________006Actions()
call HopeChoice_DialogClear(d)
set HopeRoute_Assigning=true
endif
elseif d==udg_Wj_sj_xz[owner+1] then
call Trig____________________013________2Actions()
elseif d==udg_Rskill_shifoutihuan[owner+1] then
call Trig_R_____________018Actions()
endif
set HopeModern_Dispatching=false
set HopeModern_Player=null
set HopeModern_Dialog=null
set HopeModern_Button=null
set d=null
set p=null
endfunction
function HopeModern_Fold takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() then
set HopeChoice_Hidden=true
endif
endfunction
function HopeModern_Refresh takes nothing returns nothing
local integer i=1
local integer j=1
local integer owner=GetPlayerId(GetLocalPlayer())
local integer newest=0
local integer h=0
local integer abilityId=0
local dialog d=null
local boolean show=false
local string title=""
local string detail="选择后立即生效；收起 F6 可先查看角色资料。"
set HopeModern_Tick=HopeModern_Tick+1
if not HopeModern_Ready then
return
endif
loop
exitwhen i>HopeChoice_DialogCount
if HopeChoice_DialogPending[i] and HopeChoice_Owner[i]==owner then
set newest=i
endif
set i=i+1
endloop
set i=1
loop
exitwhen i>13
set show=i==newest and not HopeChoice_Hidden and not HopeGrowth_Pending[owner] and not HopeRoute_Assigning
call HopeJob_ShowFrame(HopeModern_Panel[i],show)
if show then
set d=HopeChoice_Dialog[i]
set h=GetHandleId(d)
set title=LoadStr(HopeModern_Data,h,100)
if d==udg_Rskill_shifoutihuan[owner+1] then
set abilityId=LoadInteger(YDHT,h,$D59B01E6)
set title="替换 R 技能："+GetAbilityName(abilityId)
set detail="当前："+GetAbilityName(udg_R_Skill[owner+1])+"|n新技能："+HopeSkill_Original(abilityId,1)+"|n放弃不退还本次购买费用。"
elseif d==udg_Youxi_ND_XZ then
set detail="简单/普通：3轮；困难/极难：4轮。|n炼狱：5轮；无限挑战：无限轮。|n选定难度后，再指定本局的路线选择者。"
else
set detail="消耗的升级点已结算；以下奖励三选一。|n放弃不返还升级点；收起 F6 保留当前选项。"
endif
call HopeJob_SetText(HopeModern_Title[i],title)
call HopeJob_SetText(HopeModern_Description[i],detail)
set j=1
loop
exitwhen j>6
call HopeJob_ShowFrame(HopeModern_Row[i*8+j],j<=LoadInteger(HopeModern_Data,h,0))
call HopeJob_SetText(HopeModern_Row[i*8+j],LoadStr(HopeModern_Data,h,j))
set j=j+1
endloop
endif
set i=i+1
endloop
set d=null
endfunction
'''

def apply(src):
    src=src.replace('endglobals',GLOBALS+'\nendglobals',1)
    # Replace existing callers before inserting helpers containing true natives.
    src=src.replace('call DialogSetMessage(', 'call HopeModern_Message(')
    src=src.replace('call DialogAddButtonBJ(', 'call HopeModern_Add(')
    src=src.replace('call DialogClear(', 'call HopeModern_Clear(')
    src=src.replace('call DialogDisplay(', 'call HopeModern_NativeDisplay(')
    # Difficulty uses the same pending lifecycle, available after functions are moved below.
    init=block(src,'Trig____________________003Actions').replace('call HopeModern_NativeDisplay(', 'call HopeChoice_DialogDisplay(')
    init=init.replace('if GetPlayerSlotState(ConvertedPlayer(bj_forLoopAIndex))==PLAYER_SLOT_STATE_PLAYING then','if GetPlayerSlotState(ConvertedPlayer(bj_forLoopAIndex))==PLAYER_SLOT_STATE_PLAYING and GetPlayerController(ConvertedPlayer(bj_forLoopAIndex))==MAP_CONTROL_USER then')
    src=replace(src,'Trig____________________003Actions',init)
    # Move display bookkeeping early; it only needs FindDialog and native wrapper.
    find=block(src,'HopeChoice_FindDialog');display=block(src,'HopeChoice_DialogDisplay')
    src=src.replace(find+'\n','',1).replace(display+'\n','',1)
    src=src.replace('function Trig____________________003Actions takes',EARLY+find+'\n'+display+'\nfunction Trig____________________003Actions takes',1)
    for name in ['HopeChoice_DialogClicked','Trig_R_____________018Actions','Trig____________________013________2Actions','Trig____________________006Actions']:
        f=block(src,name).replace('GetTriggerPlayer()','HopeModern_GetPlayer()').replace('GetClickedButtonBJ()','HopeModern_GetButton()').replace('GetClickedDialogBJ()','HopeModern_GetDialog()')
        src=replace(src,name,f)
    fallback=block(src,'Trig__________________________037Actions').replace('call HopeModern_NativeDisplay(ConvertedPlayer(bj_forLoopAIndex),udg_Youxi_ND_XZ,false)','call HopeChoice_DialogDisplay(ConvertedPlayer(bj_forLoopAIndex),udg_Youxi_ND_XZ,false)')
    fallback=fallback.replace('玩家1没有选择难度，自动选择（N1）','60秒未选难度，采用简单难度。请指定路线选择者。')
    fallback=fallback.replace('set udg_Yx_Nd_Dj=0','set udg_Yx_Nd_Dj=1\nset HopeRoute_Assigning=true').replace('bj_forLoopAIndexEnd=4','bj_forLoopAIndexEnd=6')
    src=replace(src,'Trig__________________________037Actions',fallback)
    # No invisible fold handle needed: modern fold is a local frame button.
    src=src.replace('set HopeChoice_FoldButton[i]=DialogAddButton(d,"暂时收起（F6 展开）",0)','// Fold is handled by the modern local button.')
    # Suppress old debug-only player index output.
    src=src.replace('call DisplayTextToPlayer(Player(0),0,0,I2S(LoadInteger(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$877546F4)))','')
    callbacks=''
    create='''function HopeModern_Create takes nothing returns nothing
local integer f=0
'''
    for i in range(1,14):
        create+=f'set HopeModern_Panel[{i}]=HopeQoL_Surface("HopeChoicePanel{i}",.195,.558,.410,.450)\n'
        create+=f'set HopeModern_Title[{i}]=HopeQoL_Label("HopeChoiceTitle{i}",HopeModern_Panel[{i}],.014,-.012,.305,.026,"")\n'
        create+=f'set HopeModern_Description[{i}]=HopeQoL_Label("HopeChoiceDetail{i}",HopeModern_Panel[{i}],.014,-.046,.382,.118,"")\n'
        create+=f'set f=HopeQoL_Button("HopeChoiceFold{i}",HopeModern_Panel[{i}],.324,-.010,.072,.026,"收起 F6")\ncall HopeQoL_Bind(f,function HopeModern_Fold,false)\n'
        for j in range(1,7):
            callbacks+=f'function HopeModern_Click{i}_{j} takes nothing returns nothing\ncall HopeModern_Choose({i},{j})\nendfunction\n'
            create+=f'set HopeModern_Row[{i*8+j}]=HopeQoL_Button("HopeChoiceRow{i}_{j}",HopeModern_Panel[{i}],.014,{-.174-(j-1)*.043:.3f},.382,.037,"")\ncall HopeQoL_Bind(HopeModern_Row[{i*8+j}],function HopeModern_Click{i}_{j},true)\n'
        create+=f'call HopeJob_ShowFrame(HopeModern_Panel[{i}],false)\n'
    create+='set HopeModern_Ready=true\nendfunction\n'
    src=src.replace('function main takes nothing returns nothing',LATE+callbacks+create+'\nfunction main takes nothing returns nothing',1)
    src=src.replace('call InitGlobals()','call InitGlobals()\nset HopeModern_Data=InitHashtable()',1)
    src=src.replace('set show=HopeGrowth_Pending[owner] and not HopeChoice_Hidden','set show=HopeGrowth_Pending[owner] and not HopeChoice_Hidden and not HopeRoute_Assigning')
    return src
