"""Run the shipped promotion callbacks against deterministic Warcraft natives.

This checks logic and synchronized resource ownership, not KK client execution.
The existing awaken implementation is replaced at its boundary only, so these
tests isolate the new payment without duplicating any skill/stat calculations.
"""
from __future__ import annotations

import ast
from collections import Counter
import re
from types import SimpleNamespace

from validate_economy import SCRIPT, World, body, expression, rawcode


CASES = 0


def check(condition, message):
    global CASES
    assert condition, message
    CASES += 1


class PromotionWorld(World):
    def __init__(self):
        super().__init__()
        self.player = 0
        self.pending = set()
        self.debits = []
        self.awakenings = []
        self.item_targets = {}
        # Read authoritative initialization literals from the shipped script.
        for field, index, value in re.findall(
            r"^set HopeJob_(Source|Target|Item|Stage|Level|Str|Agi|Int|Name)\[(\d+)\]=(.*)$",
            SCRIPT,
            re.M,
        ):
            self.g["HopeJob_" + field][int(index)] = ast.literal_eval(expression(value))
        for index in range(self.g["HopeJob_Count"]):
            item = self.g["HopeJob_Item"][index]
            if item:
                self.item_targets[item] = self.g["HopeJob_Target"][index]
        self.g.update({
            "DzGetTriggerUIEventPlayer": lambda: self.player,
            "GetPlayerState": lambda p, resource: self.resources[p, resource],
            "SetPlayerState": self.set_resource,
            "AdjustPlayerStateBJ": lambda amount, p, resource: self.set_resource(p, resource, self.resources[p, resource] + amount),
            "GetHeroStr": lambda u, bonuses: u.str,
            "GetHeroAgi": lambda u, bonuses: u.agi,
            "GetHeroInt": lambda u, bonuses: u.int,
            "GetUnitX": lambda u: u.x,
            "GetUnitY": lambda u: u.y,
            "IsUnitHidden": lambda u: u.hidden,
            "HopeRoute_RewardPending": lambda i: i in self.pending,
            "HopeJob_Awaken": self.awaken,
            "HopeJob_ReplaceHidden": lambda p, kind: setattr(self.g["udg_hero"][p + 1], "kind", kind),
            "HopeJob_AddStats": lambda *args: None,
            "CreateItem": lambda kind, x, y: kind,
            "UnitAddItem": lambda u, item: setattr(u, "kind", self.item_targets[item]),
            "RemoveItem": lambda item: None,
            "SelectUnitForPlayerSingle": lambda *args: None,
            "HopeJob_ShowFrame": lambda *args: None,
            "DzFrameShow": lambda *args: None,
        })
        self.g["gg_unit_n019_0032"] = SimpleNamespace(kind=rawcode("n019"), life=100.0, hidden=False)
        self.g["gg_unit_n01C_0003"] = SimpleNamespace(kind=rawcode("n01C"), life=100.0, hidden=False)
        self.g["udg_quanshu"] = 3
        self.g["udg_ZhandouZhong"] = False
        self.load("HopeJob_Round", "HopeJob_AdvancedOpen", "HopeJob_InRoom", "HopeJob_Visible", "HopeJob_WoodCost", "HopeJob_Blocker", "HopeJob_Commit")

    def set_resource(self, player, resource, amount):
        self.debits.append((player, resource, self.resources[player, resource], amount))
        self.resources[player, resource] = amount

    def awaken(self, index, player_index):
        self.awakenings.append((index, player_index, self.resources[player_index - 1, "lumber"]))
        self.g["HopeJob_Awakened"][player_index] = True
        self.g["HopeJob_AwakenOption"][player_index] = index

    def ready(self, index, lumber, player=0):
        self.player = player
        u = self.hero(player)
        u.kind = self.g["HopeJob_Source"][index]
        u.level = 99
        u.str = u.agi = u.int = 1000
        u.x, u.y = -2500.0, 2400.0
        self.resources[player, "lumber"] = lumber
        self.g["HopeJob_Awakened"][player + 1] = False
        self.g["HopeJob_AwakenOption"][player + 1] = 0
        self.pending.discard(player)
        self.debits.clear()
        self.awakenings.clear()
        self.messages.clear()
        return u

    def blocker(self, index):
        return self.g["HopeJob_Blocker"](index, self.player)

    def commit(self, index):
        self.g["HopeJob_Commit"](index)


def test_all_awakening_options(w):
    options = [i for i in range(w.g["HopeJob_Count"]) if w.g["HopeJob_Stage"][i] == 3]
    check(len(options) == 17, "All 16 ordinary awakenings and the hidden awakening must be tested")
    check(sum(w.g["HopeJob_Source"][i] == rawcode("HZ02") for i in options) == 1, "Hidden third promotion remains in the same fee policy")
    for index in range(w.g["HopeJob_Count"]):
        check(w.g["HopeJob_WoodCost"](index) == (15 if index in options else 0), "Only third promotions cost exactly 15 wood")
    for index in (-1, w.g["HopeJob_Count"], 8190):
        check(w.g["HopeJob_WoodCost"](index) == 0, "Invalid options have no payable cost")
    for index in options:
        for balance in (0, 14):
            w.ready(index, balance)
            reason = w.blocker(index)
            check(bool(reason) and "木" in reason and "15" in reason, "Insufficient wood has an explicit 15-wood rejection")
            check(not w.debits and not w.awakenings, "Eligibility inspection never charges")
            w.commit(index)
            check(w.resources[0, "lumber"] == balance and not w.debits and not w.awakenings, "Insufficient wood cannot awaken or consume resources")
        for balance in (15, 20):
            w.ready(index, balance)
            check(w.blocker(index) == "", "Every valid third promotion accepts affordable balances")
            w.commit(index)
            check(w.resources[0, "lumber"] == balance - 15, "Every third promotion deducts exactly 15 wood")
            check(w.debits == [(0, "lumber", balance, balance - 15)], "Exactly one native resource mutation occurs")
            check(w.awakenings == [(index, 1, balance - 15)], "The synchronized debit happens before awakening")
            w.commit(index)
            check(len(w.debits) == len(w.awakenings) == 1 and w.resources[0, "lumber"] == balance - 15, "Repeated confirmation cannot awaken or charge twice")
    return options


def test_revalidation_and_player_isolation(w, options):
    for index in (options[0], options[-1]):
        w.ready(index, 15)
        check(w.blocker(index) == "", "Preview starts affordable")
        # Another authorized gameplay action spent wood after the UI last refreshed.
        w.resources[0, "lumber"] = 14
        w.commit(index)
        check(w.resources[0, "lumber"] == 14 and not w.debits and not w.awakenings, "Stale affordable UI cannot bypass current synchronized balance")
    index = options[-1]
    w.ready(index, 20, player=0)
    w.ready(index, 15, player=1)
    w.player = 0
    w.commit(index)
    check((w.resources[0, "lumber"], w.resources[1, "lumber"]) == (5, 15), "Player zero never consumes player one's wood")
    w.player = 1
    w.commit(index)
    check((w.resources[0, "lumber"], w.resources[1, "lumber"]) == (5, 0), "Each synchronized sender pays their own balance")
    check(Counter(entry[0] for entry in w.debits) == {0: 1, 1: 1}, "Multiplayer commits debit exactly once per sender")
    w.commit(index)
    check(len(w.debits) == 2 and len(w.awakenings) == 2, "A repeated second-player click cannot alter either account")


def test_existing_conditions(w, options):
    for index in (options[0], options[-1]):
        for condition in ("round3", "outside", "reward", "wrong_lineage", "battle", "dead", "closed_shops"):
            u = w.ready(index, 20)
            w.g["udg_quanshu"] = 3
            w.g["udg_ZhandouZhong"] = False
            for name in ("gg_unit_n019_0032", "gg_unit_n01C_0003"):
                w.g[name].hidden = False
            if condition == "round3":
                w.g["udg_quanshu"] = 2
            elif condition == "outside":
                u.x = 0.0
            elif condition == "reward":
                w.pending.add(0)
            elif condition == "wrong_lineage":
                u.kind = rawcode("H000")
            elif condition == "battle":
                w.g["udg_ZhandouZhong"] = True
            elif condition == "dead":
                u.life = 0.0
            else:
                w.g["gg_unit_n019_0032"].hidden = True
                w.g["gg_unit_n01C_0003"].hidden = True
            check(bool(w.blocker(index)), "Existing condition still blocks: " + condition)
            w.commit(index)
            check(w.resources[0, "lumber"] == 20 and not w.debits and not w.awakenings, "Rejected condition does not charge: " + condition)
    w.g["udg_quanshu"] = 3
    w.g["udg_ZhandouZhong"] = False
    w.g["gg_unit_n019_0032"].hidden = False
    w.g["gg_unit_n01C_0003"].hidden = False


def test_first_and_second_promotions_remain_free(w):
    options = [i for i in range(w.g["HopeJob_Count"]) if w.g["HopeJob_Stage"][i] in (1, 2)]
    check(len(options) == 26, "All existing first/second options are covered")
    for index in options:
        w.ready(index, 0)
        w.next_roll = 1  # The random entry reaches the hidden first promotion.
        check(w.blocker(index) == "", "Zero wood does not block a valid first or second promotion")
        w.commit(index)
        check(w.resources[0, "lumber"] == 0 and not w.debits and not w.awakenings, "First and second promotions never use the third-promotion fee")
        expected = rawcode("HZ01") if index == 24 else w.g["HopeJob_Target"][index]
        check(w.g["udg_hero"][1].kind == expected, "Free first/second promotion still completes its original path")


def test_mutation_location_and_synchronized_callbacks():
    commit = body("HopeJob_Commit")[3]
    fee_branch = commit.split("elseif HopeJob_Stage[index]==3 then", 1)[1].split("\nelse\n", 1)[0]
    mutation = re.search(r"call (?:SetPlayerState|AdjustPlayerStateBJ)\([^\n]*PLAYER_STATE_RESOURCE_LUMBER[^\n]*\)", fee_branch)
    check(mutation is not None, "The wood debit is inside the stage-three synchronized branch")
    check(fee_branch.index(mutation[0]) < fee_branch.index("call HopeJob_Awaken(index,i)"), "Payment precedes grant in the same non-yielding callback")
    check("TriggerSleepAction" not in commit and "PolledWait" not in commit, "Payment and grant cannot yield to another click")
    check("HopeJob_Blocker(index,p)" in commit and commit.index('if blocker!="" then') < commit.index(mutation[0]), "Final callback rechecks all current conditions before charging")
    # Reading the balance while drawing a frame is harmless; all resource writes
    # must stay out of local frame callbacks and their eligibility helpers.
    forbidden = r"(?:SetPlayerState|AdjustPlayerStateBJ|HopeJob_Commit\(|HopeJob_Awaken\()"
    for name in ("HopeJob_WoodCost", "HopeJob_Blocker", "HopeJob_Visible", "HopeJob_InPanel", "HopeJob_Show", "HopeJob_Open", "HopeJob_Select", "HopeJob_Refresh"):
        check(re.search(forbidden, body(name)[3]) is None, "Browsing/eligibility cannot mutate gameplay resources: " + name)
    for index in range(43):
        check(f"call HopeQoL_Bind(HopeJob_Confirm[{index}],function HopeJob_Commit{index},true)" in SCRIPT, "Every confirmation remains synchronized")
    refresh = body("HopeJob_Refresh")[3]
    check("HopeJob_WoodCost(chosen)" in refresh and "GetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER)" in refresh, "Third-promotion UI reads the authoritative price and current balance")


if __name__ == "__main__":
    world = PromotionWorld()
    thirds = test_all_awakening_options(world)
    test_revalidation_and_player_isolation(world, thirds)
    test_existing_conditions(world, thirds)
    test_first_and_second_promotions_remain_free(world)
    test_mutation_location_and_synchronized_callbacks()
    print(f"PASS: {CASES} assertions; all 17 third promotions cost exactly 15 wood, synchronized eligibility and payment revalidate current balances, repeat clicks reject, and all first/second promotions remain free.")
