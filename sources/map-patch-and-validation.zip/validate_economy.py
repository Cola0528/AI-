"""Execute the shipped JASS economy functions against deterministic native doubles.

This is a logic regression check, not a Warcraft/KK runtime or cloud-write test.
No builder modules are imported and no older validation suites are executed.
"""
from __future__ import annotations

import ast
from collections import defaultdict
from pathlib import Path
import re
import sys
from types import SimpleNamespace


ROOT = Path(__file__).resolve().parent
SOURCE = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "war3map-patched.j"
SCRIPT = SOURCE.read_text()
CASES = 0


def check(condition, message):
    global CASES
    assert condition, message
    CASES += 1


def rawcode(value):
    return int.from_bytes(value.encode("ascii"), "big")


def expression(value):
    # Only rewrite tokens outside double-quoted JASS strings.
    chunks = re.split(r'("(?:[^"\\]|\\.)*")', value)
    for index in range(0, len(chunks), 2):
        chunk = re.sub(r"\$([0-9A-Fa-f]+)", lambda m: str(int(m[1], 16)), chunks[index])
        chunk = re.sub(r"'([A-Za-z0-9]{4})'", lambda m: str(rawcode(m[1])), chunk)
        for original, replacement in (("null", "None"), ("true", "True"), ("false", "False")):
            chunk = re.sub(r"\b" + original + r"\b", replacement, chunk)
        chunk = re.sub(r"\bfunction\s+([A-Za-z_]\w*)", r"\1", chunk)
        chunks[index] = chunk
    return "".join(chunks)


def body(name, source=None):
    match = re.search(r"^function " + re.escape(name) + r" takes (.*?) returns (\w+)\n(.*?)^endfunction", SCRIPT if source is None else source, re.M | re.S)
    assert match, "Missing shipped JASS function: " + name
    return match


class IntegerDivision(ast.NodeTransformer):
    def visit_BinOp(self, node):
        node = self.generic_visit(node)
        if isinstance(node.op, ast.Div):
            return ast.copy_location(ast.Call(ast.Name("_jass_div", ast.Load()), [node.left, node.right], []), node)
        return node


def translate(name, source=None):
    match = body(name, source)
    arguments = [] if match[1] == "nothing" else [arg.strip().split()[-1] for arg in match[1].split(",")]
    lines = [line.strip() for line in match[3].splitlines()]
    locals_ = set(arguments)
    for line in lines:
        declaration = re.match(r"local\s+\w+\s+(\w+)", line)
        if declaration:
            locals_.add(declaration[1])
    globals_ = sorted({m[1] for line in lines if (m := re.match(r"set\s+(\w+)\s*=", line))} - locals_)
    output = ["def " + name + "(" + ",".join(arguments) + "):"]
    if globals_:
        output.append("    global " + ",".join(globals_))
    level = 1
    for line in lines:
        if not line or line.startswith("//"):
            continue
        # Existing gameplay statements do not contain trailing inline comments.
        if line in ("endif", "endloop"):
            level -= 1
            continue
        if line.startswith("elseif "):
            level -= 1
            code = "elif " + expression(line[7:-5]) + ":"
        elif line == "else":
            level -= 1
            code = "else:"
        elif line.startswith("if "):
            code = "if " + expression(line[3:-5]) + ":"
        elif line == "loop":
            code = "while True:"
        elif line.startswith("exitwhen "):
            output.append("    " * level + "if " + expression(line[9:]) + ": break")
            continue
        elif line.startswith("local "):
            declaration = line.split(" ", 2)[2]
            code = expression(declaration if "=" in declaration else declaration + "=None")
        elif line.startswith("set "):
            code = expression(line[4:])
        elif line.startswith("call "):
            code = expression(line[5:])
        elif line.startswith("return "):
            code = "return " + expression(line[7:])
        elif line == "return":
            code = "return"
        else:
            raise AssertionError(name + ": unsupported statement " + line)
        output.append("    " * level + code)
        if code.endswith(":"):
            level += 1
            output.append("    " * level + "pass")
    if len(output) == 1:
        output.append("    pass")
    tree = IntegerDivision().visit(ast.parse("\n".join(output), filename=name))
    return compile(ast.fix_missing_locations(tree), name, "exec")


def jass_div(left, right):
    if isinstance(left, int) and isinstance(right, int):
        return int(left / right)
    return left / right


class World:
    """Deterministic native boundary; JASS keeps all decisions and mutations."""

    def __init__(self):
        self.g = {"_jass_div": jass_div}
        self.writes = []
        self.messages = []
        self.random_calls = []
        self.integer_random_calls = []
        self.next_roll = 1
        self.random_fraction = 0.0
        self.saved = {}
        self.platform = set()
        self.tech = {}
        self.resources = defaultdict(int)
        self.cloud_ready = set(range(6))
        self.playing = set(range(6))
        self.human = set(range(6))
        self.tables = defaultdict(dict)
        self.ui_calls = []
        defaults = {"integer": 0, "real": 0.0, "boolean": False, "string": ""}
        globals_text = SCRIPT.split("globals", 1)[1].split("endglobals", 1)[0]
        for line in globals_text.splitlines():
            m = re.match(r"(?:constant\s+)?(\w+)\s+(array\s+)?(\w+)(?:=(.*))?$", line.strip())
            if not m:
                continue
            default = defaults.get(m[1])
            if m[2]:
                self.g[m[3]] = defaultdict(lambda default=default: default)
            elif m[4] is not None:
                try:
                    self.g[m[3]] = ast.literal_eval(expression(m[4]))
                except (ValueError, SyntaxError):
                    self.g[m[3]] = default
            else:
                self.g[m[3]] = default
        self.g.update({
            "PLAYER_SLOT_STATE_PLAYING": "playing", "MAP_CONTROL_USER": "user",
            "PLAYER_STATE_RESOURCE_GOLD": "gold", "PLAYER_STATE_RESOURCE_LUMBER": "lumber",
            "Player": lambda i: i, "ConvertedPlayer": lambda i: i - 1,
            "GetPlayerId": lambda p: -1 if p is None else p,
            "GetConvertedPlayerId": lambda p: p + 1,
            "GetPlayerSlotState": lambda p: "playing" if p in self.playing else "empty",
            "GetPlayerController": lambda p: "user" if p in self.human else "computer",
            "GetOwningPlayer": lambda u: None if u is None else u.owner,
            "GetLocalPlayer": lambda: 0,
            "GetUnitTypeId": lambda u: 0 if u is None else u.kind,
            "GetHandleId": lambda u: id(u) if not isinstance(u, (int, str)) else u,
            "GetWidgetLife": lambda u: 0.0 if u is None else u.life,
            "IsUnitType": lambda u, kind: u.hero if kind == "hero" else False,
            "UNIT_TYPE_HERO": "hero", "IsUnitPaused": lambda u: u.paused,
            "GetHeroLevel": lambda u: u.level,
            "HopeCloud_CanWrite": lambda p: p in self.cloud_ready,
            "HopeCloud_Report": lambda p: self.messages.append((p, "cloud unavailable")),
            "DzAPI_Map_StoreInteger": self.store,
            "DzAPI_Map_GetStoredInteger": lambda p, key: self.saved.get((p, key), 0) if p in self.cloud_ready else 0,
            "DzAPI_Map_GetServerValue": lambda p, key: "1" if (p, key) in self.platform else "",
            "DzAPI_Map_HasMallItem": lambda p, key: (p, key) in self.platform,
            "DisplayTextToPlayer": lambda *args: self.messages.append(args),
            "DisplayTimedTextToPlayer": lambda *args: self.messages.append(args),
            "I2S": str, "R2S": str, "S2I": int, "I2R": float, "R2I": int,
            "RMinBJ": min, "RMaxBJ": max, "IMinBJ": min, "IMaxBJ": max,
            "GetRandomReal": self.random_real,
            "GetRandomInt": self.random_int,
            "HopeQoL_GradedGrowth": lambda value, hp: str(value),
            "YDWESetUnitAbilityDataString": lambda *args: self.ui_calls.append(args),
            "bj_HEROSTAT_STR": "str", "bj_HEROSTAT_AGI": "agi", "bj_HEROSTAT_INT": "int",
            "bj_MODIFYMETHOD_ADD": "add",
            "ModifyHeroStat": lambda stat, unit, mode, amount: setattr(unit, stat, getattr(unit, stat) + amount),
            "SetPlayerTechResearchedSwap": lambda tech, level, p: self.tech.__setitem__((p, tech), level),
            "SetPlayerTechResearched": lambda p, tech, level: self.tech.__setitem__((p, tech), level),
            "GetPlayerTechCount": lambda p, tech, specific: self.tech.get((p, tech), 0),
            "AdjustPlayerStateBJ": lambda amount, p, resource: self.resources.__setitem__((p, resource), self.resources[p, resource] + amount),
            "YDHT": "YDHT", "YDLOC": "YDLOC",
        })
        for kind in ("Boolean", "Integer", "Real", "UnitHandle", "Str"):
            self.g["Save" + kind] = lambda table, parent, key, value: self.tables[table].__setitem__((parent, key), value)
        for kind, default in (("Boolean", False), ("Integer", 0), ("Real", 0.0), ("UnitHandle", None), ("Str", "")):
            self.g["Load" + kind] = lambda table, parent, key, default=default: self.tables[table].get((parent, key), default)
        for kind in ("Boolean", "Integer", "Real", "String"):
            self.g["HaveSaved" + kind] = lambda table, parent, key: (parent, key) in self.tables[table]
        for helper in ("HopeChallenge_TurnToken", "HopeReclass_First", "HopeReclass_Can", "HopeLayout_Focus"):
            if "function " + helper + " takes" in SCRIPT:
                self.load(helper)

    def store(self, player, key, value):
        self.writes.append((player, key, value))
        self.saved[player, key] = value

    def random_real(self, low, high):
        self.random_calls.append((low, high))
        return low + self.random_fraction * (high - low)

    def random_int(self, low, high):
        self.integer_random_calls.append((low, high))
        assert low <= self.next_roll <= high
        return self.next_roll

    def load(self, *names):
        for name in names:
            exec(translate(name), self.g)

    def hero(self, player=0):
        unit = SimpleNamespace(owner=player, kind=rawcode("H000"), hero=True, paused=False, level=1, life=100.0, str=5, agi=5, int=5)
        self.g["udg_hero"][player + 1] = unit
        return unit


def test_shared_spending():
    w = World()
    w.load("HopePoints_Spend")
    spend = w.g["HopePoints_Spend"]
    w.g["udg_Wj_jf"][1] = 15
    w.g["udg_Wj_jf"][2] = 22
    for invalid_player, invalid_price in ((None, 5), (-1, 5), (6, 5), (0, 0), (0, -5)):
        check(not spend(invalid_player, invalid_price), "Invalid player/price rejects purchase")
    check(w.g["udg_Wj_jf"][1] == 15 and not w.writes, "Invalid requests neither change balance nor submit writes")
    w.cloud_ready.remove(0)
    check(not spend(0, 5) and not w.writes, "Unloaded cloud rejects payment without write")
    w.cloud_ready.add(0)
    for blocker in (w.playing, w.human):
        blocker.remove(0)
        check(not spend(0, 5) and not w.writes, "Inactive or computer slot cannot spend")
        blocker.add(0)
    for busy in ("HopePoints_Busy", "HopeArchive_Busy"):
        w.g[busy][0] = True
        check(not spend(0, 5) and not w.writes, "Existing economy transaction blocks reentry")
        w.g[busy][0] = False
    check(not spend(0, 16) and not w.writes, "Insufficient points does not submit write")
    for remaining in (10, 5, 0):
        check(spend(0, 5), "Repeated valid spend succeeds through exact exhaustion")
        check(w.g["udg_Wj_jf"][1] == remaining, "Every success deducts exactly five points")
        check(w.writes[-1] == (0, "boss_jf", remaining), "One authoritative balance key receives new balance")
    check(len(w.writes) == 3 and not spend(0, 5) and len(w.writes) == 3, "Exhausted points block without extra writes")
    check(w.g["udg_Wj_jf"][2] == 22 and spend(1, 7) and w.g["udg_Wj_jf"][2] == 15, "Separate players retain separate balances")
    check(not w.g["HopePoints_Busy"][0] and not w.g["HopePoints_Busy"][1], "Transaction lock is released after success")


GROWTH_FIELDS = ("udg_cz1Str_up", "udg_cz2Agi_up", "udg_cz3Int_up", "udg_cz4Hp_up", "udg_cz5Mp_up", "udg_cz6Dex_up")


def growth_world():
    w = World()
    w.load("HopePoints_Spend", "HopeGrowth_Begin", "HopeGrowth_CanAct", "HopeGrowth_Randomize", "HopeGrowth_UpdateTooltip", "HopeGrowth_Roll", "HopeGrowth_Accept")
    return w


def values(world, player):
    return tuple(world.g[field][player + 1] for field in GROWTH_FIELDS)


def test_growth():
    w = growth_world()
    first, second = w.hero(0), w.hero(1)
    for player, unit in ((0, first), (1, second)):
        w.g["HopeGrowth_Begin"](unit)
        w.g["udg_CZ_czcs"][player + 1] = 2
        for field in GROWTH_FIELDS:
            w.g[field][player + 1] = 99.0
    check(w.g["HopeChoice_PlayerPending"][0] == 1 and w.g["HopeChoice_PlayerPending"][1] == 1, "Growth registers each player's required initial choice")
    w.g["HopeGrowth_Begin"](first)
    check(w.g["HopeChoice_PlayerPending"][0] == 1, "Duplicate region entry does not duplicate pending choice")
    w.g["udg_Wj_jf"][1] = 4
    roll = w.g["HopeGrowth_Roll"]
    check(not roll(0, True) and not w.random_calls and not w.writes, "Four points cannot buy a five-point reset or consume RNG")
    check(values(w, 0) == (99.0,) * 6 and w.g["udg_CZ_czcs"][1] == 2, "Failed paid reset preserves all growth and free uses")
    w.g["udg_Wj_jf"][1] = 20
    for number in range(4):
        w.random_fraction = number / 4
        check(roll(0, True), "Paid resets remain available beyond the original free quota")
        check(w.g["udg_Wj_jf"][1] == 15 - 5 * number and w.g["udg_CZ_czcs"][1] == 2, "Paid reset consumes exactly five and preserves free quota")
        check(values(w, 1) == (99.0,) * 6, "Reset never changes another player's growth")
    draws, writes = len(w.random_calls), len(w.writes)
    check(not roll(0, True) and len(w.random_calls) == draws and len(w.writes) == writes, "No remaining points prevents additional reset or cloud write")
    w.cloud_ready.remove(0)
    check(roll(0, False) and roll(0, False), "Both original free resets remain usable without cloud")
    check(w.g["udg_CZ_czcs"][1] == 0 and len(w.writes) == writes, "Free resets only spend free quota and never write points")
    draws = len(w.random_calls)
    check(not roll(0, False) and len(w.random_calls) == draws, "Exhausted free quota does not silently buy a paid reset")
    w.cloud_ready.add(0)
    w.g["udg_Wj_jf"][1] = 5
    check(roll(0, True) and w.g["udg_Wj_jf"][1] == 0, "Exactly five points works with zero free resets")
    w.g["udg_Wj_jf"][1] = 5
    w.cloud_ready.remove(0)
    draws, writes = len(w.random_calls), len(w.writes)
    check(not roll(0, True) and len(w.random_calls) == draws and len(w.writes) == writes, "Unloaded cloud cannot perform paid reset")
    w.cloud_ready.add(0)
    # Confirmation clears only this initial choice, preserving another choice.
    w.g["HopeChoice_PlayerPending"][0] = 2
    check(w.g["HopeGrowth_Accept"](0), "Initial growth can be accepted")
    check(w.g["HopeChoice_PlayerPending"][0] == 1 and not w.g["HopeGrowth_Pending"][0], "Accept releases only the initial growth pending gate")
    check(not w.g["HopeGrowth_Accept"](0), "Duplicate confirmation is rejected")
    check(not roll(0, True) and len(w.writes) == writes and w.g["udg_Wj_jf"][1] == 5, "Late paid click after confirmation cannot charge")
    w.g["HopeGrowth_Begin"](first)
    check(not w.g["HopeGrowth_CanAct"](0), "Reentering the starting region cannot reopen confirmed growth")
    check(w.g["HopeGrowth_CanAct"](1) and w.g["HopeChoice_PlayerPending"][1] == 1, "Another player remains free to finish their own growth")
    for attribute, invalid, normal in (("kind", rawcode("H001"), rawcode("H000")), ("life", 0.0, 100.0), ("owner", 0, 1)):
        setattr(second, attribute, invalid)
        check(not roll(1, True), "Stale/dead/foreign hero cannot use growth reset")
        setattr(second, attribute, normal)
    w.g["udg_hero"][2] = SimpleNamespace(**vars(second))
    check(not roll(1, True), "An otherwise identical replacement hero cannot reuse the initial choice")


def test_original_growth_distribution():
    # Run the unmodified original draw statements using their original hashtable
    # context, and compare with the shipped replacement under identical natives.
    original = (ROOT / "war3map.j").read_text()
    old_body = body("Trig_________________________0_042Actions", original)[3]
    first = old_body.index("call SaveReal(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$FBEDEC54,")
    last = old_body.index("set udg_CZ_czcs[", first)
    reference = "function Original_Growth_Draws takes integer ydl_localvar_step returns nothing\n" + old_body[first:last] + "endfunction\n"
    for difficulty in (0, 1, 4, 6):
        for fraction in (0.0, 0.23, 0.61, 0.79, 1.0):
            new, old = growth_world(), World()
            exec(translate("Original_Growth_Draws", reference), old.g)
            old.g["GetTriggeringTrigger"] = lambda: 123
            old.tables["YDLOC"][123, 0x877546F4] = 4
            for world in (new, old):
                world.random_fraction = fraction
                world.g["udg_ND_sz"] = difficulty
                for field in GROWTH_FIELDS:
                    world.g[field][3] = -7.0
            new.g["HopeGrowth_Randomize"](4)
            old.g["Original_Growth_Draws"](1)
            check(values(new, 3) == values(old, 3), f"Growth distribution matches original at difficulty {difficulty}, random fraction {fraction}")
            check(new.random_calls == old.random_calls, "Original random draw count, ranges and reroll conditions are preserved")
            check(values(new, 2) == (-7.0,) * 6, "Randomization writes only the requested one-based player index")


def shop_world():
    w = World()
    w.load("HopePoints_Spend", "HopeGift_Name", "HopeGift_DrawCost", "HopeGift_Chance", "HopeGift_DrawIndex", "HopeGift_Key", "HopeGift_Owned", "HopeGift_OwnedCount", "HopeGift_PlatformEntitled", "HopeGift_GrantLoaded", "HopeGift_LoadPoints", "HopeGift_Draw")
    return w


def test_shop_purchases():
    from collections import Counter
    w=shop_world()
    distribution=Counter(w.g['HopeGift_DrawIndex'](roll) for roll in range(1,101))
    check(distribution=={-1:55,2:15,1:12,5:8,0:4,3:4,4:2}, 'Every one of the 100 lottery outcomes matches the published exact probability')
    check(w.g['HopeGift_DrawCost']()==5, 'Lottery costs exactly 5 points')
    for index in range(6):
        check(w.g['HopeGift_Chance'](index)==distribution[index], 'Displayed chance matches actual lottery mapping')
    for invalid in (-1,0,101):
        check(w.g['HopeGift_DrawIndex'](invalid)==-1,'Out-of-range random values cannot grant a gift')
    for roll in range(1,101):
        w=shop_world();w.next_roll=roll
        w.g['HopeGift_Checked'][0]=w.g['HopeGift_Loaded'][0]=True
        w.g['udg_Wj_jf'][1]=5
        outcome=w.g['HopeGift_DrawIndex'](roll)
        check(w.g['HopeGift_Draw'](0) and w.g['udg_Wj_jf'][1]==0, 'Each valid paid lottery spends exactly 5')
        check(w.integer_random_calls==[(1,100)], 'Each lottery performs exactly one synchronized draw')
        expected=[(0,'boss_jf',0)]
        if outcome>=0:expected.append((0,f'gift_v1_{outcome}',1))
        check(w.writes==expected,'Only new winning entitlement is submitted in addition to balance')
        check(not any(w.g['HopeGift_Applied'].values()) and not w.resources and not w.tech,'Lottery does not grant rewards in the current run')
    for ownership in ('HopeGift_Applied','HopeGift_PointOwned','HopeGift_PlatformOwned'):
        w=shop_world();w.next_roll=71
        w.g['HopeGift_Checked'][0]=w.g['HopeGift_Loaded'][0]=True
        w.g['udg_Wj_jf'][1]=10;w.g[ownership][1]=True
        check(w.g['HopeGift_Draw'](0) and w.writes==[(0,'boss_jf',5)],'Duplicate paid/platform reward charges one draw and never stacks, rerolls or writes ownership')
        check('重复' in w.g['HopeGift_LastResult'][0] and len(w.integer_random_calls)==1,'Duplicate result is explicitly reported')
        for index in range(6):w.g[ownership][index]=True
        check(not w.g['HopeGift_Draw'](0) and len(w.writes)==1 and len(w.integer_random_calls)==1,'All six owned stops spending and RNG')
    for mode in ('poor','unchecked','unloaded','cloud','busy','observer','computer'):
        w=shop_world();w.g['udg_Wj_jf'][1]=20
        w.g['HopeGift_Checked'][0]=w.g['HopeGift_Loaded'][0]=True
        if mode=='poor':w.g['udg_Wj_jf'][1]=4
        if mode=='unchecked':w.g['HopeGift_Checked'][0]=False
        if mode=='unloaded':w.g['HopeGift_Loaded'][0]=False
        if mode=='cloud':w.cloud_ready.remove(0)
        if mode=='busy':w.g['HopeGift_Busy'][0]=True
        if mode=='observer':w.playing.remove(0)
        if mode=='computer':w.human.remove(0)
        balance=w.g['udg_Wj_jf'][1]
        check(not w.g['HopeGift_Draw'](0) and not w.writes and not w.integer_random_calls and w.g['udg_Wj_jf'][1]==balance,'Rejected draw has no spending or RNG: '+mode)
    w=shop_world();w.next_roll=56
    w.g['HopeGift_Checked'][1]=w.g['HopeGift_Loaded'][1]=True
    w.g['udg_Wj_jf'][2]=5;w.g['udg_Wj_jf'][1]=99
    check(w.g['HopeGift_Draw'](1) and w.g['HopeGift_PointOwned'][8] and not w.g['HopeGift_PointOwned'][2] and w.g['udg_Wj_jf'][1]==99,'Lottery ownership, results and spending are isolated by player')


def test_shop_loading():
    w = shop_world()
    for player in (0, 1, 2):
        w.g["HopeGift_Checked"][player] = True
        for index in range(6):
            w.saved[player, f"gift_v1_{index}"] = 1
    # Player zero already has every platform entitlement; loading saved copies
    # must not duplicate any reward. Player one has only saved ownership.
    for index in range(6):
        w.g["HopeGift_Applied"][index] = True
    w.cloud_ready.remove(2)
    hero = w.hero(1)
    w.g["HopeGift_LoadPoints"]()
    check(w.g["HopeGift_Loaded"][0] and w.g["HopeGift_Loaded"][1] and not w.g["HopeGift_Loaded"][2], "Only checked players with a loaded cloud receive saved gifts")
    check(w.resources[0, "gold"] == 0 and w.resources[0, "lumber"] == 0 and w.g["udg_CZ_czcs"][1] == 0, "Platform plus saved ownership grants no duplicate benefit")
    check(w.resources[1, "gold"] == 200 and w.resources[1, "lumber"] == 2, "Saved gifts grant their six original resource effects")
    check(w.g["udg_CZ_czcs"][2] == 3 and all(w.g[field][2] == 3 for field in ("udg_STR_cs", "udg_AGI_cs", "udg_INT_cs")), "Saved reroll and attribute gifts retain original quantities")
    check((hero.str, hero.agi, hero.int) == (8, 8, 8), "Late startup load applies saved attributes to an already existing hero")
    check(all(w.g["HopeGift_Applied"][6 + index] for index in range(6)), "Loaded gifts record all applied effects")
    snapshot = (dict(w.resources), dict(w.tech), w.g["udg_CZ_czcs"][2], hero.str, hero.agi, hero.int)
    w.g["HopeGift_LoadPoints"]()
    for index in range(6):
        w.g["HopeGift_GrantLoaded"](1, index)
    check(snapshot == (dict(w.resources), dict(w.tech), w.g["udg_CZ_czcs"][2], hero.str, hero.agi, hero.int), "Repeated loader or grant call cannot issue duplicate rewards")
    check(not w.writes, "Loading entitlements never writes points or ownership back")
    check(not any(w.g["HopeGift_PointOwned"][12 + index] for index in range(6)) and w.resources[2, "gold"] == 0, "Failed-cloud player does not gain unverified saved rights")
    platform_only=shop_world();platform_only.g['HopeGift_Checked'][0]=True
    platform_only.platform.update((0,key) for key in ('maptest2020','prebook2023','JINBI','MUCAI','SHOUCHONG','CHONGSUI'))
    platform_only.g['HopeGift_LoadPoints']()
    check(platform_only.g['HopeGift_OwnedCount'](0)==6 and platform_only.resources[0,'gold']==200 and platform_only.g['udg_CZ_czcs'][1]==3,'Ready platform recheck recovers all original rights without charging')
    platform_only.g['HopeGift_LoadPoints']()
    check(platform_only.resources[0,'gold']==200 and not platform_only.writes,'Recovered platform rights are applied only once')
    # A purchase made in this game does not become effective if the loader is
    # called again: Loaded protects the original startup snapshot.
    late = shop_world()
    late.g["HopeGift_Checked"][0] = True
    late.g["HopeGift_LoadPoints"]()
    late.g["udg_Wj_jf"][1] = 5
    late.next_roll = 83
    check(late.g["HopeGift_Draw"](0), "First-game saved gift can be purchased after startup loading")
    late.g["HopeGift_LoadPoints"]()
    check(late.g["udg_CZ_czcs"][1] == 0 and not late.g["HopeGift_Applied"][5], "Repeated load cannot make a new purchase effective in the current game")


def test_callbacks_and_loading_order():
    for callback in ("HopeGrowth_FreeClick", "HopeGrowth_PaidClick", "HopeGrowth_AcceptClick"):
        check(re.search(r"call HopeQoL_Bind\([^\n]*function " + callback + r",true\)", SCRIPT) is not None, callback + " is a synchronized UI callback")
    check('call HopeQoL_Bind(HopeGift_DrawButton,function HopeGift_DrawClick,true)' in SCRIPT,'Gift lottery uses a synchronized button')
    check('HopeGift_Draw(DzGetTriggerUIEventPlayer())' in body('HopeGift_DrawClick')[3],'Lottery operates on the event player')
    for name in ("HopePoints_Spend", "HopeGrowth_Roll", "HopeGrowth_CanAct", "HopeGift_Draw", "HopeGift_GrantLoaded"):
        text = body(name)[3]
        check("GetLocalPlayer" not in text and "DzGetTriggerUIEventFrame" not in text, name + " keeps local frame state outside its transaction")
    check(body('HopeGift_Draw')[3].count('GetRandomInt(')==1,'Lottery has one RNG call in the synchronized transaction')
    archive_load = body("Trig_______SD_017Actions")[3]
    check(archive_load.index('DzAPI_Map_GetStoredInteger(ConvertedPlayer(bj_forLoopAIndex),"boss_jf")') < archive_load.index("call HopeGift_LoadPoints()"), "Saved shop ownership loads after original point balance")
    check("HopeGift_LoadPoints" not in body("Trig____________________028Actions")[3], "Early platform gift check does not prematurely lock cloud-load status")
    check("HopeGrowth_Begin(GetTriggerUnit())" in body("Trig__________________________041Actions")[3], "Original growth entry launches new shared lifecycle")
    check("GetRandomReal" not in body("Trig_________________________0_042Actions")[3], "Legacy dialog cannot remain a second reset/charge path")


if __name__ == "__main__":
    test_shared_spending()
    test_growth()
    test_original_growth_distribution()
    test_shop_purchases()
    test_shop_loading()
    test_callbacks_and_loading_order()
    print(f"PASS: {CASES} actual JASS economy assertions. Warcraft rendering and KK persistence require client validation.")
