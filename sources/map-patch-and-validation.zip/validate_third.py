"""Execute final v15 JASS, including the existing damage dispatcher.

Warcraft natives are doubles; this does not simulate the KK client or particles.
"""
from pathlib import Path
from types import SimpleNamespace as N
import ast, json, math, re
from validate_economy import World, SCRIPT, body, expression, rawcode
from third_design import DESIGNS

ROOT=Path(__file__).parent
OPTIONS=json.loads((ROOT/'patch-options.json').read_text())
INDEX={o['target']:i for i,o in enumerate(OPTIONS) if o['stage']==3}
COUNT=0


def check(ok,message):
    global COUNT
    assert ok,message
    COUNT+=1


def close(a,b,message):
    check(math.isclose(a,b,rel_tol=1e-7,abs_tol=1e-7),(message,a,b))


class Third(World):
    def __init__(self,kind='H00E',rank=1):
        super().__init__()
        self.event=None;self.hits=[];self.effects=[];self.names=[];self.timers=[];self.sender=0
        g=self.g
        for p in range(6):
            h=self.hero(p)
            h.maximum=1000.;h.mana=20.;h.maxmana=30.;h.attack=100.;h.armor=20.
            h.str=30;h.agi=40;h.int=50;h.level=30;h.points=4;h.abilities={}
            h.x=-2500.;h.y=2400.;h.name='二转'+str(p);h.proper=h.name
            g['udg_xingdong_dian'][p+1]=6;g['udg_xingdong_dianSx'][p+1]=6
            g['udg_Skill_Dm'][p+1]=1.3;g['udg_Fashang_Dm'][p+1]=1.5
            g['udg_Zuizhong_Dm'][p+1]=2.;g['udg_Baoji_Damage'][p+1]=2.5
            g['udg_jingque_Daji_jiacheng'][p+1]=1.8
        g['udg_Zuizhong_Dm'][12]=1.
        self.u=g['udg_hero'][1]
        self.enemies=[self.enemy(500,0),self.enemy(700,60),self.enemy(500,700),self.enemy(-100,0),self.enemy(2200,0)]
        self.target=self.enemies[0]
        g.update({
            'UNIT_STATE_LIFE':'life','UNIT_STATE_MAX_LIFE':'maximum','UNIT_STATE_MANA':'mana','UNIT_STATE_MAX_MANA':'maxmana',
            'ATTACK_TYPE_NORMAL':'normal','ATTACK_TYPE_CHAOS':'chaos','ATTACK_TYPE_MAGIC':'magic','DAMAGE_TYPE_NORMAL':'normal','DAMAGE_TYPE_MAGIC':'magic','WEAPON_TYPE_WHOKNOWS':0,
            'ConvertUnitState':lambda k:k,'GetUnitState':self.state,'SetUnitState':self.setstate,
            'GetHeroStr':lambda u,b:u.str,'GetHeroAgi':lambda u,b:u.agi,'GetHeroInt':lambda u,b:u.int,
            'SetHeroStr':lambda u,v,b:setattr(u,'str',v),'SetHeroAgi':lambda u,v,b:setattr(u,'agi',v),'SetHeroInt':lambda u,v,b:setattr(u,'int',v),
            'GetHeroSkillPoints':lambda u:u.points,'UnitModifySkillPoints':lambda u,n:setattr(u,'points',u.points+n),
            'GetUnitAbilityLevel':lambda u,a:u.abilities.get(a,0) if u else 0,
            'GetUnitAbilityLevelSwapped':lambda a,u:u.abilities.get(a,0) if u else 0,
            'UnitAddAbility':lambda u,a:u.abilities.setdefault(a,1),
            'UnitRemoveAbility':lambda u,a:u.abilities.pop(a,None),
            'SetUnitAbilityLevel':lambda u,a,l:(u.abilities.__setitem__(a,l),l)[1] if a in u.abilities else 0,
            'UnitMakeAbilityPermanent':lambda *a:None,
            'GetUnitName':lambda u:u.name,'GetHeroProperName':lambda u:u.proper,
            'GetUnitX':lambda u:u.x,'GetUnitY':lambda u:u.y,'SquareRoot':math.sqrt,'RAbsBJ':abs,
            'IsUnitInGroup':lambda u,g:any(v is u for v in g),'IsUnitAliveBJ':lambda u:u.life>.405,
            'IsUnitEnemy':lambda u,p:(u.owner<6)!=(p<6),'IsUnitAlly':lambda u,p:(u.owner<6)==(p<6),
            'CreateGroup':lambda:[],'GroupAddGroup':lambda s,g:g.extend(s),'FirstOfGroup':lambda g:g[0] if g else None,
            'GroupRemoveUnit':lambda g,u:g.remove(u),'DestroyGroup':lambda g:None,
            'AddSpecialEffectTarget':lambda *a:self.effects.append(a) or len(self.effects),'DestroyEffect':lambda e:None,
            'UnitDamageTarget':self.damage,'InitHashtable':lambda:'third','ModuloInteger':lambda a,b:a%b,
            'FlushParentHashtable':lambda t:self.tables[t].clear(),'FlushChildHashtable':self.flush,
            'GetTriggerUnit':lambda:self.event.target if self.event else self.u,'GetEventDamageSource':lambda:self.event.source,
            'GetEventDamage':lambda:self.event.raw,'YDWESetEventDamage':lambda value:setattr(self.event,'result',value),
            'YDWEIsEventAttackType':lambda t:self.event.attack==t,'YDWEIsEventDamageType':lambda t:self.event.dtype==t,
            'GetTriggeringTrigger':lambda:99,'GetRandomInt':lambda lo,hi:hi,'GetRandomDirectionDeg':lambda:0.,
            'CreateTimer':lambda:1000+len(self.timers),'TimerStart':lambda *a:self.timers.append(a),
            'CreateTextTagUnitBJ':lambda *a:None,'SetTextTagVelocityBJ':lambda *a:None,'SetTextTagTextBJ':lambda *a:None,
            'GetLastCreatedTextTag':lambda:777,'YDWETimerDestroyTextTag':lambda *a:None,'YDWETimerDestroyEffect':lambda *a:None,
            'YDWEGetPlayerColorString':lambda p,s:s,
            'DzGetTriggerUIEventPlayer':lambda:self.sender,'GetPlayerState':lambda p,k:self.resources[p,k],
            'SetPlayerState':lambda p,k,n:self.resources.__setitem__((p,k),n),
            'HopeRoute_RewardPending':lambda p:False,'IsUnitHidden':lambda u:False,
            'GetSpellAbilityId':lambda:self.cast_id,'GetSpellTargetUnit':lambda:self.target,
            'SelectUnitForPlayerSingle':lambda *a:None,'DzFrameShow':lambda *a:None,
        })
        for k in ['TextTagHandle','PlayerHandle']:
            g['Save'+k]=lambda t,p,k,v:self.tables[t].__setitem__((p,k),v)
            g['Load'+k]=lambda t,p,k:self.tables[t].get((p,k))
        for ref in re.findall(r'\bfunction (\w+)',body('Trig____________________005Actions')[3]):
            g[ref]=lambda *a:None
        for field,index,value in re.findall(r'^set HopeJob_(Source|Target|Stage|Name|Level|Str|Agi|Int)\[(\d+)\]=(.*)$',SCRIPT,re.M):
            g['HopeJob_'+field][int(index)]=ast.literal_eval(expression(value))
        self.load('Trig____________________005Actions','HopeStatus_PoisonKey','HopeStatus_PoisonCount','HopeStatus_PoisonSourceBase',
                  'HopeJob_AddStats','HopeJob_Awaken','HopeJob_Round','HopeJob_AdvancedOpen','HopeJob_InRoom','HopeJob_Visible','HopeJob_WoodCost','HopeJob_GoldCost','HopeJob_Blocker','HopeJob_Commit',
                  'HopeMonk_Total','HopeMonk_Ally','HopeMonk_Heal','HopeMonk_Reset','HopeMonk_Lowest','HopeMonk_Cast','HopeJob_Cast',
                  'HopeSkill_Number','HopeSkill_Rolled','HopeSkill_Preview','HopeProfession_Text')
        g['HopeJob_ShowFrame']=lambda *a:None
        # Renaming was removed at the user's request; catch any stray bridge.
        def no_rename_bridge(*args):
            raise AssertionError('Awakening must not execute a name-changing script')
        g['EXExecuteScript']=no_rename_bridge
        # ReplaceHidden's preservation is covered separately in the existing suite;
        # this native boundary makes its type change explicit for all-route tests.
        g['HopeJob_ReplaceHidden']=lambda p,typ:setattr(g['udg_hero'][p+1],'kind',typ)
        g['udg_Guaiwu_dwz']=self.enemies;g['udg_ZhandouZhong']=True
        g['gg_unit_n019_0032']=N(kind=rawcode('n019'),life=100.)
        g['gg_unit_n01C_0003']=N(kind=rawcode('n01C'),life=100.)
        g['udg_quanshu']=3
        g['HopeThird_Init']()
        self.choose(kind,rank)

    def choose(self,kind,rank=1,p=1):
        u=self.g['udg_hero'][p];u.kind=rawcode(kind)
        self.g['HopeJob_Awakened'][p]=True;self.g['HopeJob_AwakenOption'][p]=INDEX[kind]
        self.g['HopeJob_UltimateKind'][p]=6 if kind=='N01G' else 2
        self.g['HopeJob_LastCast'][p]=-1
        u.abilities[rawcode(DESIGNS[kind]['id'])]=rank
        return u

    def enemy(self,x,y):
        return N(owner=11,kind=rawcode('u000'),life=100000.,maximum=100000.,x=x,y=y,abilities={},name='测试敌人',paused=False)

    def state(self,u,k):return getattr(u,{18:'attack',20:'attack',32:'armor'}.get(k,k))
    def setstate(self,u,k,v):setattr(u,{18:'attack',20:'attack',32:'armor'}.get(k,k),v)
    def rename(self,u,key,value):setattr(u,key,value);self.names.append((u,key,value))
    def flush(self,t,p):self.tables[t]={k:v for k,v in self.tables[t].items() if k[0]!=p}

    def damage(self,u,target,amount,attack,ranged,atype,dtype,weapon):
        previous=self.event
        self.event=N(source=u,target=target,raw=amount,result=amount,attack=atype,dtype=dtype)
        self.g['Trig____________________005Actions']()
        result=self.event.result
        self.hits.append((u,target,amount,result,atype))
        target.life=max(0.,target.life-result)
        if target.life<=.405 and target in self.enemies:self.enemies.remove(target)
        self.event=previous
        return True

    def cast(self,aid=None):
        if aid is None:aid=DESIGNS[next(k for k in DESIGNS if rawcode(k)==self.u.kind)]['id']
        self.cast_id=rawcode(aid)
        self.g['HopeJob_Cast']()


def awakenings():
    for kind,d in DESIGNS.items():
        w=Third(kind);g=w.g;u=w.u;index=INDEX[kind]
        g['HopeJob_Awakened'][1]=False
        if kind=='HZ03':u.kind=rawcode('HZ02')
        g['udg_ZhandouZhong']=False
        old=(u.str,u.agi,u.int,u.maximum,u.maxmana)
        bonus_arrays={'ap':'udg_xingdong_dianSx','dex':'udg_DEX','def':'udg_Defend_fangyu','regen':'udg_huihe_huilan','crit':'udg_Baoji_Lv','critd':'udg_Baoji_Damage','prec':'udg_jingque_Daji_jiacheng','final':'udg_Zuizhong_Dm','skill':'udg_Skill_Dm','spell':'udg_Fashang_Dm'}
        old_arrays={k:g[name][1] for k,name in bonus_arrays.items()}
        native_name=g['udg_hero'][2].name
        u.abilities[rawcode('AZ32')]=1
        w.resources[0,'lumber']=30;w.resources[0,'gold']=1000
        g['HopeJob_Commit'](index)
        check(g['HopeJob_Awakened'][1] and w.resources[0,'lumber']==0 and w.resources[0,'gold']==0,'all awakenings cost both resources '+kind)
        check(u.name==u.proper=='二转0','awakening preserves original native names '+kind)
        check(g['udg_hero'][2].name==native_name and not w.names,'no hero receives a name change '+kind)
        check(u.abilities.get(rawcode(d['id']))==1 and rawcode('AZ32') not in u.abilities,'unique skill replaces generic barrage '+kind)
        for n,attr in enumerate(['str','agi','int','maximum','maxmana']):
            close(getattr(u,attr)-old[n],d['bonus'].get(['str','agi','int','hp','mp'][n],0),'exact class bonus '+kind+' '+attr)
        for k,name in bonus_arrays.items():
            close(g[name][1]-old_arrays[k],d['bonus'].get(k,0),'actual innate reward '+kind+' '+k)
        if d['mode']=='passive':
            points=u.points
            g['HopeJob_Commit'](index)
            check(u.points==points-1 and u.abilities[rawcode(d['id'])]==2,'research spends hero point, not wood/gold '+kind)
            g['HopeJob_Commit'](index)
            check(u.points==points-2 and u.abilities[rawcode(d['id'])]==3,'research rank3 '+kind)
            g['HopeJob_Commit'](index)
            check(u.points==points-2 and not w.names,'rank cap prevents extra spend or re-awakening '+kind)
        else:
            before=(u.str,u.agi,u.int,len(w.names))
            g['HopeJob_Commit'](index)
            check(before==(u.str,u.agi,u.int,len(w.names)),'repeat active awakening rejected '+kind)
        check(w.resources[0,'lumber']==0 and w.resources[0,'gold']==0,'research/repeat never charges old fee '+kind)
    w=Third('N018');g=w.g;g['udg_ZhandouZhong']=False;w.u.points=0
    g['HopeJob_Commit'](INDEX['N018'])
    check(w.u.abilities[rawcode('AT05')]==1 and w.u.points==0,'no point research rejected')
    w.u.points+=1 # engine-provided skill point on a later level
    g['HopeJob_Commit'](INDEX['N018'])
    check(w.u.abilities[rawcode('AT05')]==2 and w.u.points==0,'later level skill point remains usable')
    check(g['udg_xingdong_dianSx'][1]==6,'research never repeats AP bonus')
    w.u.points=1
    g['SetUnitAbilityLevel']=lambda *a:0
    g['HopeJob_Commit'](INDEX['N018'])
    check(w.u.points==1 and w.u.abilities[rawcode('AT05')]==2,'failed native rank change refunds skill point')


def actives():
    w=Third('H00E');g=w.g;u=w.u
    g['SaveInteger']('YDHT',id(u),0x30720CCD,2)
    u.abilities[rawcode('A04Q')]=3
    g['SaveBoolean']('YDHT',id(u),0x08E215BC,True)
    g['SaveInteger']('YDHT',id(u),0xEE28B8AD,1)
    w.cast()
    check(len(w.hits)==1 and w.hits[0][1] is w.target,'sniper is strictly single target')
    close(w.hits[0][2],(100*6+40*3)*1.3*1.8,'sniper raw amount and precision once')
    close(w.hits[0][3],(100*6+40*3)*1.3*1.8*2*2.5,'original damage dispatcher applies final/guaranteed crit once')
    check(g['LoadInteger']('YDHT',id(u),0x30720CCD)==1 and g['udg_xingdong_dian'][1]==4 and u.mana==17,'sniper spends one round and exact cost')
    check(not g['LoadBoolean']('YDHT',id(u),0x08E215BC) and g['LoadInteger']('YDHT',id(u),0xEE28B8AD)==0,'precision and headshot consumed by this shot')
    w.cast();check(len(w.hits)==1,'sniper once per turn')
    g['udg_huihe_s']+=1;w.cast();check(len(w.hits)==2,'next turn permits new shot')
    g['udg_huihe_s']+=1;u.mana=20;g['udg_xingdong_dian'][1]=6
    w.cast();check(len(w.hits)==2 and u.mana==20 and g['udg_xingdong_dian'][1]==6,'empty ammo consumes nothing')

    w=Third('E010');w.u.x=w.u.y=0.;w.cast()
    check([h[1] for h in w.hits]==w.enemies[:2],'ballista hits forward strip only, not off-line/behind/outside')
    close(w.hits[0][2],(100*4+30*2)*1.3,'primary bolt formula')
    close(w.hits[1][2],w.hits[0][2]*.7,'secondary bolt 70 percent')
    w=Third('E010');w.u.x=w.u.y=0.;w.target.x=2201.;w.cast()
    check(not w.hits and w.u.mana==20,'invalid ray range not charged')
    w=Third('N01F');w.target.life=40000.;w.cast()
    close(w.hits[0][2],(30+40)*6*1.3,'assassin <=40 percent execute')
    w=Third('N01F');w.target.life=1.;w.cast()
    check(w.g['udg_xingdong_dian'][1]==5,'assassin actual kill refunds one AP')
    w=Third('N017');g=w.g
    for p in range(1,7):g['udg_hero'][p].life=990.;g['udg_hero'][p].mana=29.
    g['udg_hero'][6].life=0.;w.u.mana=20.;w.cast()
    check(not w.hits and g['udg_hero'][2].life==1000.,'priest heals living allies without damage')
    close(g['udg_hero'][2].armor,45.,'overheal shield capped by half caster INT')
    check(g['udg_hero'][2].mana==30. and g['udg_hero'][6].life==0.,'real capped mana and dead allies skipped')
    w=Third('N016');w.cast()
    check(len(w.hits)==2,'frost affects 450 area around selected enemy')
    enemy=w.target;w.u.life=900.
    w.damage(enemy,w.u,100.,True,False,'normal','normal',0)
    close(w.hits[-1][3],60.,'frost next incoming hit reduced 40 percent')
    w.damage(enemy,w.u,100.,True,False,'normal','normal',0)
    close(w.hits[-1][3],100.,'frost consumed exactly once')
    w=Third('O004');g=w.g;w.u.abilities[rawcode('A02U')]=2
    key=g['HopeStatus_PoisonKey'](0);g['SaveInteger']('YDHT',id(w.target),key,5)
    w.cast();close(w.hits[0][2],100*.3*5*2*2*1.3,'poison active only own live layers')
    check(g['LoadInteger']('YDHT',id(w.target),key)==5,'poison layers not consumed')
    w=Third('O004');w.cast();check(not w.hits and w.u.mana==20,'no own poison refuses without cost')
    w=Third('O005');g=w.g;w.cast();check(not w.hits and g['udg_xingdong_dian'][1]==5,'hunt costs one AP and marks without damage')
    other=g['udg_hero'][2]
    for n in range(4):w.damage(other,w.target,100,True,False,'normal','normal',0)
    check([h[3] for h in w.hits]==[250.,250.,250.,200.],'hunt benefits teammate for exactly three hits')
    check(w.resources[1,'gold']==30 and w.resources[0,'gold']==0,'hunt bounty belongs to actual attacking player')
    w=Third('N01G');w.cast();check(len(w.hits)==5 and w.g['HopeMonk_Qi'][1]==3,'monk retains unique qi refill and team effects')


def passives():
    for rank in range(1,4):
        w=Third('H008',rank);g=w.g
        g['HopeThird_AfterAction'](w.u,rawcode('A00E'),None)
        close(w.u.armor,20+30*(.2+.2*rank),'shield scales with passive rank')
        base=g['HopeThird_Base'](w.u,rawcode('A03D'),100.,False)
        close(base,100+w.u.armor*(.2+.2*rank),'shield converted into sword damage')
        w=Third('H00D',rank);g=w.g
        g['HopeThird_AfterAction'](w.u,rawcode('A04I'),None)
        for consume in [False,False,True]:close(g['HopeThird_Base'](w.u,rawcode('A000'),100.,consume),100*(1.15+.2*rank),'charge boosts next Q, previews do not spend it')
        close(g['HopeThird_Base'](w.u,rawcode('A000'),100.,True),100.,'charge boost spent once')
        w=Third('N018',rank);g=w.g;g['udg_xingdong_dian'][1]=2
        threshold=3 if rank==1 else 2
        for _ in range(threshold):g['HopeThird_AfterAction'](w.u,rawcode('A00I'),w.target)
        check(g['udg_xingdong_dian'][1]==3,'combo refunds one AP at rank threshold')
        for _ in range(5):g['HopeThird_AfterAction'](w.u,rawcode('A00I'),w.target)
        check(g['udg_xingdong_dian'][1]==3,'combo refund once per turn')
        close(w.u.mana,22. if rank==3 else 20.,'rank3 combo sustain only')
        w=Third('E00S',rank);g=w.g;g['HopeThird_AfterAction'](w.u,rawcode('A00D'),w.target)
        check(len(w.hits)==min(2,rank) and all(h[1] is not w.target for h in w.hits),'side arrows bounded and exclude primary')
        close(w.hits[0][2],40*(1.6 if rank==3 else 1.2)*1.3,'arrow rank coefficient')
        w=Third('H004',rank)
        for _ in range(5):w.damage(w.u,w.target,100.,True,False,'normal','normal',0)
        for n,h in enumerate(w.hits):close(h[3],100*(1+min(3,n)*(.05+.05*rank))*2,'machinegun stack increments per hit')
        w.damage(w.u,w.enemies[1],100.,True,False,'normal','normal',0);close(w.hits[-1][3],200.,'target switch resets pressure')
        w=Third('N01E',rank);g=w.g
        for _ in range(5):g['HopeThird_AfterAction'](w.u,rawcode('A00F'),w.target)
        other=w.choose('N01E',rank,2)
        g['HopeThird_AfterAction'](other,rawcode('A00F'),w.target)
        close(g['HopeThird_Embers'](w.u,w.target),3*50*(.4+.4*rank),'fire cap and rank coefficient')
        close(g['HopeThird_Embers'](w.u,w.target),0.,'own fire seeds consumed once')
        close(g['HopeThird_Embers'](other,w.target),50*(.4+.4*rank),'teammate seed untouched')
        w=Third('O006',rank);before=w.u.life
        for _ in range(3):w.damage(w.u,w.target,100.,True,False,'normal','normal',0)
        close(w.u.life-before,70*(.1+.1*rank),'three hit life return')
        w.u.life=1000.;before=w.u.armor
        for _ in range(3):w.damage(w.u,w.target,100.,True,False,'normal','normal',0)
        close(w.u.armor-before,70*(.1+.1*rank),'overflow converted to armor')
        w=Third('N01A',rank);g=w.g
        for hp in [1000.,500.,100.]:
            w.u.life=hp;close(g['HopeThird_Base'](w.u,rawcode('A01R'),100.,False),100*(1+(1-hp/1000)*(.2+.2*rank)),'rage missing life coefficient')
        w=Third('HZ03',rank);g=w.g;g['udg_xingdong_dian'][1]=2;before=w.u.life
        for aid in ['AZHD','AZH3','AZH3','AZHR']:g['HopeThird_HiddenAction'](w.u,rawcode(aid))
        check(g['udg_xingdong_dian'][1]==3,'different hidden actions complete one cycle')
        close(w.u.life-before,120*(.04+.04*rank),'hidden allstat recovery')
        g['HopeThird_HiddenAction'](w.u,rawcode('AZHR'))
        check(g['udg_xingdong_dian'][1]==3,'hidden once per turn')
        g['udg_huihe_s']+=1
        for aid in ['AZHR','AZH3','AZHD']:g['HopeThird_HiddenAction'](w.u,rawcode(aid))
        check(g['udg_xingdong_dian'][1]==4,'next turn permits a new hidden cycle')
    w=Third('N01E');g=w.g;g['HopeThird_AfterAction'](w.u,rawcode('A00F'),w.target)
    g['SaveInteger'](g['HopeThird_Data'],id(w.target),101,1);g['SaveInteger'](g['HopeThird_Data'],id(w.target),102,3)
    g['HopeThird_Reset']()
    check(not w.tables[g['HopeThird_Data']] and g['HopeThird_FireTarget'][1] is None,'battle reset removes all target marks and stale references')


def guards():
    for kind,d in DESIGNS.items():
        if d['mode']!='active' or kind=='N01G':continue
        for case in ['dead','paused','outside','no_ap','no_mana','not_awakened','foreign_hero','wrong_skill','dead_target','ally_target']:
            w=Third(kind);g=w.g;g['SaveInteger']('YDHT',id(w.u),0x30720CCD,3)
            w.u.abilities[rawcode('A02U')]=1
            g['SaveInteger']('YDHT',id(w.target),g['HopeStatus_PoisonKey'](0),3)
            if case=='dead':w.u.life=0.
            elif case=='paused':w.u.paused=True
            elif case=='outside':g['udg_ZhandouZhong']=False
            elif case=='no_ap':g['udg_xingdong_dian'][1]=0
            elif case=='no_mana':w.u.mana=2.
            elif case=='not_awakened':g['HopeJob_Awakened'][1]=False
            elif case=='foreign_hero':g['udg_hero'][1]=None
            elif case=='wrong_skill':w.u.abilities.clear()
            elif case=='dead_target':w.target.life=0.
            elif case=='ally_target':w.target=g['udg_hero'][2]
            if kind=='N017' and case in ['dead_target','ally_target']:continue
            before=(g['udg_xingdong_dian'][1],w.u.mana,g['LoadInteger']('YDHT',id(w.u),0x30720CCD))
            w.cast()
            check(not w.hits and before==(g['udg_xingdong_dian'][1],w.u.mana,g['LoadInteger']('YDHT',id(w.u),0x30720CCD)),'active rejected atomically '+kind+' '+case)


if __name__=='__main__':
    awakenings();actives();passives();guards()
    print(f'PASS: {COUNT} v15 class, native-name, progression, damage-pipeline, resource and rejection checks.')
    print('Executed final JASS with Warcraft native doubles; no KK engine test.')
