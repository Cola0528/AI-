"""Fifth-round/infinite enemy rosters and real turn-based AI skill effects."""
import re
from challenge_objects import ENEMIES

ROSTER = r'''
function HopeChallenge_SetRoster takes nothing returns nothing
local integer cycle=ModuloInteger(udg_quanshu-4,3)
if udg_Yx_Nd_Dj<5 or udg_quanshu<4 then
return
endif
// Every accessible troop/elite slot has a defined object, on every later round.
if cycle==0 then
set udg_boci_gw_lx[0]='nZ01'
set udg_boci_gw_lx[1]='nZ02'
set udg_boci_gw_lx[2]='nZ03'
set udg_boci_gw_lx[3]='nZ04'
set udg_boci_gw_lx[4]='nZ02'
elseif cycle==1 then
set udg_boci_gw_lx[0]='nZ03'
set udg_boci_gw_lx[1]='nZ04'
set udg_boci_gw_lx[2]='nZ01'
set udg_boci_gw_lx[3]='nZ02'
set udg_boci_gw_lx[4]='nZ03'
else
set udg_boci_gw_lx[0]='nZ02'
set udg_boci_gw_lx[1]='nZ01'
set udg_boci_gw_lx[2]='nZ04'
set udg_boci_gw_lx[3]='nZ03'
set udg_boci_gw_lx[4]='nZ04'
endif
set udg_BOSS_LX[0]='UZ01'
set udg_BOSS_LX[1]='UZ02'
if ModuloInteger(udg_quanshu,2)==0 then
set udg_BOSS_LX[2]='UZ01'
set udg_BOSS_LX_______DA[1]='UZ01'
else
set udg_BOSS_LX[2]='UZ02'
set udg_BOSS_LX_______DA[1]='UZ02'
endif
__REGISTER__
call SaveBoolean(YDHT,'UZ01',$FB89B46C,true)
call SaveBoolean(YDHT,'UZ02',$FB89B46C,true)
call SaveStr(YDHT,'nZ02',$8BB4E579,"Abilities\\Weapons\\NecromancerMissile\\NecromancerMissile.mdl")
call SaveStr(YDHT,'nZ03',$8BB4E579,"Abilities\\Weapons\\SkeletalMageMissile\\SkeletalMageMissile.mdl")
call SaveStr(YDHT,'nZ04',$8BB4E579,"Abilities\\Weapons\\FarseerMissile\\FarseerMissile.mdl")
call SaveStr(YDHT,'UZ02',$8BB4E579,"Abilities\\Weapons\\LichMissile\\LichMissile.mdl")
endfunction
'''

SKILLS = r'''
function HopeChallenge_IsEnemy takes integer id returns boolean
return id=='nZ01' or id=='nZ02' or id=='nZ03' or id=='nZ04' or id=='UZ01' or id=='UZ02'
endfunction
function HopeChallenge_PrepareSkill takes unit u returns nothing
if HopeChallenge_IsEnemy(GetUnitTypeId(u)) and GetWidgetLife(u)>.405 then
call UnitResetCooldown(u)
call SetUnitManaPercentBJ(u,100.)
endif
endfunction
function HopeChallenge_HeroAlive takes unit u returns boolean
return u!=null and GetWidgetLife(u)>.405 and IsPlayerInForce(GetOwningPlayer(u),udg_WJZ_______cunhuo)
endfunction
function HopeChallenge_Heal takes unit u,real amount returns nothing
if u!=null and GetWidgetLife(u)>.405 and amount>0. then
call SetUnitState(u,UNIT_STATE_LIFE,RMinBJ(GetUnitState(u,UNIT_STATE_MAX_LIFE),GetWidgetLife(u)+amount))
endif
endfunction
function HopeChallenge_Ward takes unit u,real amount returns nothing
local real baseline=LoadReal(YDHT,GetUnitTypeId(u),$73299135)
call SetUnitState(u,ConvertUnitState(32),RMaxBJ(GetUnitState(u,ConvertUnitState(32)),baseline+amount))
endfunction
function HopeChallenge_EnemyCast takes unit u returns nothing
local integer id=GetUnitTypeId(u)
local integer i=1
local unit v=null
local unit weakest=null
local group allies=null
local real attack=GetUnitState(u,ConvertUnitState(20))
local real ratio=2.
local real before=0.
local real actual=0.
local real amount=0.
if not HopeChallenge_IsEnemy(id) or GetOwningPlayer(u)!=Player(11) or GetWidgetLife(u)<=.405 or not IsUnitInGroup(u,udg_Guaiwu_dwz) then
return
endif
// This dispatcher is called only by the existing A00U enemy skill event.
if id=='nZ01' or id=='nZ04' then
set allies=CreateGroup()
call GroupAddGroup(udg_Guaiwu_dwz,allies)
loop
set v=FirstOfGroup(allies)
exitwhen v==null
call GroupRemoveUnit(allies,v)
if GetWidgetLife(v)>.405 then
if id=='nZ01' then
call HopeChallenge_Ward(v,10.+2.*I2R(udg_quanshu+1))
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Human\\Defend\\DefendCaster.mdl",v,"origin"))
else
call HopeChallenge_Heal(v,GetUnitState(v,UNIT_STATE_MAX_LIFE)*.08+attack*.5)
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Human\\HolyBolt\\HolyBoltSpecialArt.mdl",v,"origin"))
endif
endif
endloop
call DestroyGroup(allies)
elseif id=='nZ03' then
loop
exitwhen i>6
set v=udg_hero[i]
if HopeChallenge_HeroAlive(v) and GetWidgetLife(v)/RMaxBJ(1.,GetUnitState(v,UNIT_STATE_MAX_LIFE))<ratio then
set ratio=GetWidgetLife(v)/RMaxBJ(1.,GetUnitState(v,UNIT_STATE_MAX_LIFE))
set weakest=v
endif
set i=i+1
endloop
if weakest!=null then
call UnitDamageTarget(u,weakest,attack*1.65,true,false,ATTACK_TYPE_CHAOS,DAMAGE_TYPE_NORMAL,WEAPON_TYPE_WHOKNOWS)
call SetUnitState(weakest,UNIT_STATE_MANA,RMaxBJ(0.,GetUnitState(weakest,UNIT_STATE_MANA)-2.))
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Undead\\DeathCoil\\DeathCoilSpecialArt.mdl",weakest,"origin"))
endif
else
loop
exitwhen i>6
set v=udg_hero[i]
if HopeChallenge_HeroAlive(v) then
if id=='nZ02' then
call UnitDamageTarget(u,v,attack*.85+I2R(udg_quanshu+1)*3.,false,false,ATTACK_TYPE_MAGIC,DAMAGE_TYPE_MAGIC,WEAPON_TYPE_WHOKNOWS)
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Other\\Incinerate\\FireLordDeathExplode.mdl",v,"origin"))
elseif id=='UZ01' then
call UnitDamageTarget(u,v,attack*1.15,true,false,ATTACK_TYPE_CHAOS,DAMAGE_TYPE_NORMAL,WEAPON_TYPE_WHOKNOWS)
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Undead\\Impale\\ImpaleMissTarget.mdl",v,"origin"))
elseif id=='UZ02' then
set before=RMaxBJ(0.,GetWidgetLife(v))
call UnitDamageTarget(u,v,attack*.9,false,false,ATTACK_TYPE_MAGIC,DAMAGE_TYPE_MAGIC,WEAPON_TYPE_WHOKNOWS)
set actual=actual+RMaxBJ(0.,before-RMaxBJ(0.,GetWidgetLife(v)))
call SetUnitState(v,UNIT_STATE_MANA,RMaxBJ(0.,GetUnitState(v,UNIT_STATE_MANA)-3.))
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Undead\\DeathCoil\\DeathCoilSpecialArt.mdl",v,"origin"))
endif
endif
set i=i+1
endloop
if id=='UZ01' then
call HopeChallenge_Ward(u,20.)
elseif id=='UZ02' then
set amount=RMinBJ(actual*.25,GetUnitState(u,UNIT_STATE_MAX_LIFE)*.06)
call HopeChallenge_Heal(u,amount)
endif
endif
set v=null
set weakest=null
set allies=null
endfunction
'''


def apply(src):
    register = []
    for alias, info in ENEMIES.items():
        register.append(f'call SaveStr(YDHT,\'{alias}\',$2AAC512D,"{info["skill"]}：{info["desc"]}")')
        register.append(f'call SaveReal(YDHT,\'{alias}\',$73299135,{info["armor"]})')
    roster = ROSTER.replace('__REGISTER__', '\n'.join(register))
    marker = 'function Trig_X_____________004Actions takes nothing returns nothing\n'
    assert src.count(marker) == 1
    src = src.replace(marker, roster+'\n'+marker, 1)
    pattern = r'(function Trig_X_____________004Actions takes nothing returns nothing\n.*?)(?=endfunction)'
    m = re.search(pattern, src, re.S)
    assert m
    body = m[1]
    assert body.count('set ydl_group=null\n') == 1
    body = body.replace('set ydl_group=null\n', 'call HopeChallenge_SetRoster()\nset ydl_group=null\n', 1)
    src = src[:m.start()]+body+src[m.end():]
    marker = 'function Trig______________003Func008T takes nothing returns nothing\n'
    assert src.count(marker) == 1
    src = src.replace(marker, SKILLS+'\n'+marker, 1)
    order = 'call IssueImmediateOrderById(LoadUnitHandle(YDLOC,GetHandleId(GetExpiredTimer()),$9F0C6E00),852526)\n'
    assert src.count(order) == 1
    unit = 'LoadUnitHandle(YDLOC,GetHandleId(GetExpiredTimer()),$9F0C6E00)'
    # A00U has a real-time nine-second cooldown; turns can finish faster.
    # New enemies must honor the intent even when the player acts quickly.
    ready = 'call HopeChallenge_PrepareSkill('+unit+')\n'
    src = src.replace(order, ready+order, 1)
    pattern = r'(function Trig_S_______001Actions takes nothing returns nothing\n.*?)(?=endfunction)'
    m = re.search(pattern, src, re.S)
    assert m
    body = m[1]
    first_action = 'set ydl_localvar_step=ydl_localvar_step+3\n'
    assert body.count(first_action) == 1
    # Existing event condition requires A00U. Dispatching here retains original
    # action scheduling, pre-displayed skill intent, and end-of-turn pausing.
    body = body.replace(first_action, 'if HopeChallenge_IsEnemy(GetUnitTypeId(GetTriggerUnit())) then\ncall HopeChallenge_EnemyCast(GetTriggerUnit())\nreturn\nendif\n'+first_action, 1)
    src = src[:m.start()]+body+src[m.end():]
    return src
