"""Add a saved-points lottery for the six original gift entitlements.

Original platform grants and the ten archive upgrades remain unchanged.
apply() patches JASS only; it does not write the generated map or object data.
"""

import re


CHANCES = (4, 12, 15, 4, 2, 8)
DRAW_COST = 5
EMPTY_CHANCE = 55


def _function(src: str, name: str, replacement: str) -> str:
    pattern = rf"^function {re.escape(name)} takes .*?^endfunction$"
    src, count = re.subn(pattern, lambda _: replacement.strip(), src,
                         flags=re.M | re.S)
    assert count == 1, (name, count)
    return src


def _once(src: str, before: str, after: str) -> str:
    assert src.count(before) == 1, (before[:90], src.count(before))
    return src.replace(before, after, 1)


GLOBALS = r'''
// Ownership, lottery results and transactions are synchronized game state.
boolean array HopeGift_PointOwned
boolean array HopeGift_PlatformOwned
boolean array HopeGift_Loaded
boolean array HopeGift_Busy
string array HopeGift_LastResult
// Handles are presentation only; Draw is the single synchronized UI action.
integer HopeGift_DrawButton=0
integer HopeGift_ResultText=0
'''


ECONOMY = r'''
function HopeGift_DrawCost takes nothing returns integer
return 5
endfunction

function HopeGift_Chance takes integer index returns integer
if index==0 or index==3 then
return 4
elseif index==1 then
return 12
elseif index==2 then
return 15
elseif index==4 then
return 2
elseif index==5 then
return 8
endif
return 0
endfunction

// Exactly 100 equally likely outcomes.  Ownership never changes this table.
function HopeGift_DrawIndex takes integer roll returns integer
if roll<1 or roll>100 or roll<=55 then
return -1
elseif roll<=70 then
return 2
elseif roll<=82 then
return 1
elseif roll<=90 then
return 5
elseif roll<=94 then
return 0
elseif roll<=98 then
return 3
endif
return 4
endfunction

function HopeGift_Key takes integer index returns string
if index<0 or index>=6 then
return ""
endif
return "gift_v1_"+I2S(index)
endfunction

function HopeGift_Owned takes player p,integer index returns boolean
local integer i=-1
if p==null or index<0 or index>=6 then
return false
endif
set i=GetPlayerId(p)
if i<0 or i>=6 then
return false
endif
return HopeGift_Applied[i*6+index] or HopeGift_PointOwned[i*6+index] or HopeGift_PlatformOwned[i*6+index]
endfunction

function HopeGift_OwnedCount takes player p returns integer
local integer index=0
local integer count=0
loop
exitwhen index>=6
if HopeGift_Owned(p,index) then
set count=count+1
endif
set index=index+1
endloop
return count
endfunction

// The original .1-second check may predate cloud readiness.  Recheck only
// after the normal .2-second cloud load; never overwrite original raw keys.
function HopeGift_PlatformEntitled takes player p,integer index returns boolean
local integer i=-1
if p==null or index<0 or index>=6 then
return false
endif
set i=GetPlayerId(p)
if i<0 or i>=6 then
return false
endif
if index==0 then
return DzAPI_Map_GetServerValue(p,"maptest2020")=="1"
elseif index==1 then
return DzAPI_Map_HasMallItem(p,"JINBI")
elseif index==2 then
return DzAPI_Map_HasMallItem(p,"MUCAI")
elseif index==3 then
return DzAPI_Map_GetServerValue(p,"prebook2023")=="1"
elseif index==4 then
return DzAPI_Map_HasMallItem(p,"SHOUCHONG")
endif
return DzAPI_Map_HasMallItem(p,"CHONGSUI")
endfunction

// Apply a loaded entitlement once at startup.  A prior platform grant sets
// Applied first, so owning either or both sources never doubles its benefit.
function HopeGift_GrantLoaded takes player p,integer index returns nothing
local integer i=-1
local unit u=null
if p==null or index<0 or index>=6 then
return
endif
set i=GetPlayerId(p)
if i<0 or i>=6 then
return
endif
if GetPlayerSlotState(p)!=PLAYER_SLOT_STATE_PLAYING or GetPlayerController(p)!=MAP_CONTROL_USER then
return
endif
if not HopeGift_Owned(p,index) or HopeGift_Applied[i*6+index] then
return
endif
set HopeGift_Applied[i*6+index]=true
call SetPlayerTechResearched(p,$52303030+index,1)
if index==0 or index==1 then
call AdjustPlayerStateBJ(50,p,PLAYER_STATE_RESOURCE_GOLD)
elseif index==4 then
call AdjustPlayerStateBJ(100,p,PLAYER_STATE_RESOURCE_GOLD)
elseif index==2 or index==3 then
call AdjustPlayerStateBJ(1,p,PLAYER_STATE_RESOURCE_LUMBER)
elseif index==5 then
set udg_CZ_czcs[i+1]=udg_CZ_czcs[i+1]+3
endif
if index==0 or index==3 or index==4 then
set udg_STR_cs[i+1]=udg_STR_cs[i+1]+1
set udg_AGI_cs[i+1]=udg_AGI_cs[i+1]+1
set udg_INT_cs[i+1]=udg_INT_cs[i+1]+1
// Normally no hero exists at .2 seconds.  If startup order changes, apply
// the loaded bonus to the existing hero instead of leaving it unapplied.
set u=udg_hero[i+1]
if u!=null and GetUnitTypeId(u)!=0 then
call ModifyHeroStat(bj_HEROSTAT_STR,u,bj_MODIFYMETHOD_ADD,1)
call ModifyHeroStat(bj_HEROSTAT_AGI,u,bj_MODIFYMETHOD_ADD,1)
call ModifyHeroStat(bj_HEROSTAT_INT,u,bj_MODIFYMETHOD_ADD,1)
endif
endif
set u=null
endfunction

// A failed cloud load stays read-only this run.  This function never runs
// from the earlier .1-second platform grant or from a lottery callback.
function HopeGift_LoadPoints takes nothing returns nothing
local integer i=0
local integer index=0
local player p=null
loop
exitwhen i>=6
set p=Player(i)
if not HopeGift_Loaded[i] and HopeGift_Checked[i] and HopeCloud_CanWrite(p) then
set index=0
loop
exitwhen index>=6
set HopeGift_PlatformOwned[i*6+index]=HopeGift_Applied[i*6+index] or HopeGift_PlatformEntitled(p,index)
set HopeGift_PointOwned[i*6+index]=DzAPI_Map_GetStoredInteger(p,HopeGift_Key(index))>0
call HopeGift_GrantLoaded(p,index)
set index=index+1
endloop
set HopeGift_Loaded[i]=true
endif
set i=i+1
endloop
set p=null
endfunction

// Only a fixed synchronized UI callback invokes Draw.  Validate all gameplay
// state before spending, and spend successfully before making exactly one roll.
function HopeGift_Draw takes player p returns boolean
local integer i=-1
local integer index=-1
if p==null then
return false
endif
set i=GetPlayerId(p)
if i<0 or i>=6 then
return false
endif
if GetPlayerSlotState(p)!=PLAYER_SLOT_STATE_PLAYING or GetPlayerController(p)!=MAP_CONTROL_USER then
return false
endif
if HopeGift_Busy[i] then
return false
endif
if not HopeCloud_CanWrite(p) then
call HopeCloud_Report(p)
return false
endif
if not HopeGift_Checked[i] or not HopeGift_Loaded[i] then
call DisplayTextToPlayer(p,0,0,"礼包权益尚未载入，未扣除积分。")
return false
endif
if HopeGift_OwnedCount(p)>=6 then
call DisplayTextToPlayer(p,0,0,"六项礼包已全部拥有，停止抽奖，不扣积分。")
return false
endif
set HopeGift_Busy[i]=true
if not HopePoints_Spend(p,HopeGift_DrawCost()) then
set HopeGift_Busy[i]=false
return false
endif
set index=HopeGift_DrawIndex(GetRandomInt(1,100))
if index<0 then
set HopeGift_LastResult[i]="谢谢惠顾 · 本次未中奖"
elseif HopeGift_Owned(p,index) then
set HopeGift_LastResult[i]="重复："+HopeGift_Name(index)+"|n无新增权益，不重抽"
else
// Spend submitted boss_jf first.  Never refund/retry from the API return bit:
// it is not a durable-save acknowledgement.  New ownership applies next run.
set HopeGift_PointOwned[i*6+index]=true
call DzAPI_Map_StoreInteger(p,HopeGift_Key(index),1)
set HopeGift_LastResult[i]="抽中："+HopeGift_Name(index)+"|n已提交，结算后下局生效"
endif
set HopeGift_Busy[i]=false
call DisplayTextToPlayer(p,0,0,"本次消耗5积分："+HopeGift_LastResult[i]+"。剩余积分 "+I2S(udg_Wj_jf[i+1])+"。")
return true
endfunction
'''


STATE = r'''
function HopeGift_State takes player p,integer index returns string
local integer i=-1
if p==null or index<0 or index>=6 then
return "|cffaaaaaa不可用|r"
endif
set i=GetPlayerId(p)
if i<0 or i>=6 then
return "|cffaaaaaa不可用|r"
endif
if HopeGift_Applied[i*6+index] then
if udg_hero[i+1]==null and (index==0 or index==3 or index==4) then
return "|cffd2b879已拥有 · 待角色初始化|r"
endif
return "|cff9ddbaf已拥有 · 本局已生效|r"
endif
if HopeGift_PointOwned[i*6+index] then
return "|cffd2b879已提交 · 结算后下局生效|r"
endif
if HopeGift_PlatformOwned[i*6+index] then
return "|cff9ddbaf平台已拥有|r"
endif
if not HopeGift_Checked[i] or not HopeCloud_Checked[i] then
return "|cffaaaaaa待载入|r"
endif
if not HopeCloud_Ready[i] then
return "|cffffb878云档未就绪 · 暂不可抽奖|r"
endif
if not HopeGift_Loaded[i] then
return "|cffaaaaaa礼包权益待载入|r"
endif
return "|cffaaaaaa未拥有 · 可通过抽奖获得|r"
endfunction
'''


REFRESH = r'''
function HopeGift_DrawClick takes nothing returns nothing
call HopeGift_Draw(DzGetTriggerUIEventPlayer())
endfunction

function HopeGift_Refresh takes nothing returns nothing
local player p=GetLocalPlayer()
local integer i=GetPlayerId(p)
local integer index=0
local boolean available=false
if not HopeGift_UIReady then
set p=null
return
endif
call DzFrameShow(HopeGift_Panel,HopeGift_Expanded and not (HopeChoice_HasPending() and not HopeChoice_Hidden))
if not HopeGift_Expanded or i<0 or i>=6 then
set p=null
return
endif
if HopeQoL_Expanded or HopeRoute_Details or HopeArchive_Expanded or HopeRelic_Expanded then
set HopeGift_Expanded=false
call DzFrameShow(HopeGift_Panel,false)
set p=null
return
endif
set available=HopeGift_Loaded[i] and HopeGift_Checked[i] and HopeCloud_CanWrite(p)
call DzFrameSetText(HopeGift_Heading,"|cffd2b879礼包抽奖|r  ·  积分 "+I2S(udg_Wj_jf[i+1]))
call DzFrameSetText(HopeGift_Summary,"每抽5积分 · 谢谢惠顾55%|n以下礼包概率固定，已拥有的结果仍可能抽中。")
loop
exitwhen index>=6
call DzFrameSetText(HopeGift_StateText[index],HopeGift_State(p,index))
set index=index+1
endloop
if not available then
call DzFrameSetText(HopeGift_DrawButton,"|cff999999云档未就绪|r")
elseif HopeGift_OwnedCount(p)>=6 then
call DzFrameSetText(HopeGift_DrawButton,"|cff999999已集齐 · 停止抽奖|r")
elseif udg_Wj_jf[i+1]<HopeGift_DrawCost() then
call DzFrameSetText(HopeGift_DrawButton,"|cffbb99885 积分 · 不足|r")
else
call DzFrameSetText(HopeGift_DrawButton,"|cffffd27a抽奖 · 5积分|r")
endif
if HopeGift_LastResult[i]==null or HopeGift_LastResult[i]=="" then
call DzFrameSetText(HopeGift_ResultText,"|cffaaaaaa最近结果：本局尚未抽奖|r")
else
call DzFrameSetText(HopeGift_ResultText,HopeGift_LastResult[i])
endif
set p=null
endfunction
'''


CREATE_UI = r'''
function HopeGift_CreateUI takes nothing returns nothing
local integer f=0
local integer index=0
local real x=.009
local real y=-.079
set HopeGift_Panel=HopeQoL_Surface("HopeGiftPanel",.24,.55,.34,.390)
if HopeGift_Panel==0 then
return
endif
set HopeGift_Heading=HopeQoL_Label("HopeGiftHeading",HopeGift_Panel,.009,-.008,.285,.018,"")
set f=HopeQoL_Button("HopeGiftClose",HopeGift_Panel,.300,-.007,.031,.021,"关闭")
if f==0 then
return
endif
call HopeQoL_Bind(f,function HopeGift_Close,false)
set HopeGift_Summary=HopeQoL_Label("HopeGiftSummary",HopeGift_Panel,.009,-.034,.322,.036,"")
loop
exitwhen index>=6
if index==3 then
set x=.175
set y=-.079
endif
set HopeGift_NameText[index]=HopeQoL_Label("HopeGiftName"+I2S(index),HopeGift_Panel,x,y,.155,.014,"|cffd2b879"+HopeGift_Name(index)+" · "+I2S(HopeGift_Chance(index))+"%|r")
set HopeGift_EffectText[index]=HopeQoL_Label("HopeGiftEffect"+I2S(index),HopeGift_Panel,x,y-.017,.155,.027,"|cffdedede"+HopeGift_Effect(index)+"|r")
set HopeGift_StateText[index]=HopeQoL_Label("HopeGiftState"+I2S(index),HopeGift_Panel,x,y-.046,.155,.018,"")
if HopeGift_NameText[index]==0 or HopeGift_EffectText[index]==0 or HopeGift_StateText[index]==0 then
return
endif
set y=y-.077
set index=index+1
endloop
set HopeGift_DrawButton=HopeQoL_Button("HopeGiftDraw",HopeGift_Panel,.009,-.307,.125,.026,"")
call HopeQoL_Bind(HopeGift_DrawButton,function HopeGift_DrawClick,true)
set HopeGift_ResultText=HopeQoL_Label("HopeGiftResult",HopeGift_Panel,.143,-.307,.188,.029,"")
set HopeGift_Footer=HopeQoL_Label("HopeGiftFooter",HopeGift_Panel,.009,-.342,.322,.043,"空签或重复均消耗5积分，不重抽、不叠加、不返还。|n新礼包永久解锁，提交平台结算后下局生效。|n原平台权益保留；六项全拥有时停止抽奖。")
set HopeGift_UIReady=HopeGift_Heading!=0 and HopeGift_Summary!=0 and HopeGift_Footer!=0 and HopeGift_DrawButton!=0 and HopeGift_ResultText!=0
call DzFrameShow(HopeGift_Panel,false)
endfunction
'''


def apply(src: str) -> str:
    """Patch generated v3 once; the shared HopePoints_Spend must exist first."""
    assert "function HopeGift_Draw takes" not in src, "lottery patch already applied"
    assert "function HopeGift_Purchase takes" not in src, "use the unpatched v3 input"
    src = _once(src, "boolean array HopeGift_Applied\n",
                "boolean array HopeGift_Applied\n" + GLOBALS)
    # Place economy helpers after Name/Effect and before the cloud-load trigger.
    src = _once(src, "function HopeGift_AppliedCount takes",
                ECONOMY + "\nfunction HopeGift_AppliedCount takes")
    src = _function(src, "HopeGift_State", STATE)
    src = _once(src, "call HopeArchive_CaptureAll()\n",
                "call HopeArchive_CaptureAll()\ncall HopeGift_LoadPoints()\n")
    src = _function(src, "HopeGift_Refresh", REFRESH)
    src = _function(src, "HopeGift_CreateUI", CREATE_UI)
    # Keep the lottery visibly distinct from the ten direct archive upgrades.
    src = _once(src, '"HopeGiftOpen",DzGetGameUI(),0,0,.035,.024,"礼包"',
                '"HopeGiftOpen",DzGetGameUI(),0,0,.035,.024,"抽奖"')
    src = _once(src, '"HopeArchiveLegacy",HopeArchive_Panel,.245,-.007,.050,.021,"礼包"',
                '"HopeArchiveLegacy",HopeArchive_Panel,.245,-.007,.050,.021,"抽奖"')
    src = src.replace("礼包可从上方入口查看；输入 -save 查看存档状态。",
                      "礼包抽奖可从上方入口查看；输入 -save 查看存档状态。")
    src = src.replace("小地图上方可直接查看属性、存档、遗物和礼包；",
                      "小地图上方可直接查看属性、存档、遗物和抽奖；")
    src = src.replace("也可关闭遗物和礼包。", "也可关闭遗物和礼包抽奖。")
    src = src.replace("礼包显示六项平台权益与本局生效状态，按原图开局自动发放，无需手动领取。",
                      "礼包抽奖每次5积分，55%谢谢惠顾；六种礼包概率在面板公开。重复结果不叠加、不重抽、不返还，全部拥有后停止抽奖。新礼包永久解锁，提交平台结算后下局生效。")
    src = src.replace("// Shared observations of the original one-time entitlement trigger. No grants.",
                      "// Shared observations of the original one-time platform entitlement trigger.")
    src = src.replace("// Read the results of the original entitlement checks. Never query, purchase,\n// claim, retry or grant a platform benefit from the presentation layer.",
                      "// Preserve original platform checks; saved-point draws use a synchronized callback.")
    src = src.replace("// Two columns of three read-only entitlements. Original automatic grants have\n// no claim action, so the only button here is the local close action.",
                      "// Six fixed lottery outcomes.  Browsing stays local; the Draw action synchronizes.")
    return src
