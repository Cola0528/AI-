"""Execute shipped multiplayer functions against native doubles.

Run with an optional generated-JASS path. This validates gameplay logic, not KK.
"""
from types import SimpleNamespace
from validate_economy import World, SCRIPT, body, rawcode

CASES = 0


def check(ok, message):
    global CASES
    assert ok, message
    CASES += 1


def world(players=1, mode=1, round_=0):
    w = World()
    w.playing = set(range(players))
    w.human = set(range(players))
    w.g['udg_WJZ'] = set(range(players))
    w.g['udg_Yx_Nd_Dj'] = mode
    w.g['udg_quanshu'] = round_
    w.handicap = 250. if mode >= 5 else 100.
    w.state_writes = []
    for i in range(players):
        w.hero(i)
    def set_state(u, state, value):
        w.state_writes.append((id(u), state, value))
        setattr(u, 'maximum' if state == 'max_life' else 'attack', value)
    w.g.update({
        'IsPlayerInForce': lambda p, f: p in f,
        'GetPlayerHandicapBJ': lambda p: w.handicap,
        'SetPlayerHandicapBJ': lambda p, value: setattr(w, 'handicap', value),
        'DisplayTimedTextToForce': lambda *args: w.messages.append(args),
        'UNIT_STATE_MAX_LIFE': 'max_life',
        'ConvertUnitState': lambda state: state,
        'GetUnitState': lambda u, state: u.maximum if state == 'max_life' else u.attack,
        'SetUnitState': set_state,
        'SetUnitLifePercentBJ': lambda u, percent: setattr(u, 'life', u.maximum * percent / 100.),
    })
    w.load('HopeCoop_CountPlayers', 'HopeCoop_MonsterCount', 'HopeCoop_LifeFactor',
           'HopeCoop_AttackFactor', 'HopeCoop_IsBoss', 'HopeCoop_BeginRoom',
           'HopeCoop_ScaleEnemy')
    return w


def enemy(kind='nX01', owner=11, hero=False):
    return SimpleNamespace(kind=rawcode(kind), owner=owner, hero=hero,
                           maximum=1000., life=1000., attack=100.)


def test_population():
    for n in range(1, 7):
        w = world(n)
        count = w.g['HopeCoop_CountPlayers']
        check(count() == n, 'Exactly participating human heroes counted')
        w.g['udg_hero'][n].life = 0.
        check(count() == n, 'Death does not reduce this party population')
        w.g['HopeRoute_Left'][n-1] = True
        check(count() == max(1, n-1), 'Leave event excludes player before slot update')
        w.g['HopeRoute_Left'][n-1] = False
        w.playing.remove(n-1)
        check(count() == max(1, n-1), 'Inactive slot excluded')
        w.playing.add(n-1)
        w.human.remove(n-1)
        check(count() == max(1, n-1), 'Computer controller excluded')
        w.human.add(n-1)
        w.g['udg_WJZ'].remove(n-1)
        check(count() == max(1, n-1), 'Nonparticipant excluded')
        w.g['udg_WJZ'].add(n-1)
        w.g['udg_hero'][n] = None
        check(count() == max(1, n-1), 'Missing hero excludes spectator')
    w = world(0)
    check(w.g['HopeCoop_CountPlayers']() == 1, 'Empty force has safe denominator/factor')


def test_rooms():
    expected_base = (3, 5, 6, 7, 8, 9)
    for mode in range(7):
        for n in range(1, 7):
            for rounds in (0, 3, 4, 9, 19, 999999999):
                w = world(n, mode, rounds)
                w.g['HopeCoop_BeginRoom']()
                check(w.g['udg_Guaiwu_sl'] == min(12, expected_base[n-1] + rounds), 'Original player count curve, bounded positions')
                check(w.g['udg_Guaiwu_sl'] + 1 <= 13, 'Random extra monster fits existing thirteen positions')
                check(w.handicap == (250. if mode >= 5 else 100.) + (20. if n >= 3 else 0.), 'Legacy +20 uses this room population exactly once')
                w.g['HopeCoop_BeginRoom']()
                check(w.handicap == (250. if mode >= 5 else 100.) + (20. if n >= 3 else 0.), 'Repeated room call never stacks handicap')
    w = world(6, 6, 4)
    w.g['HopeCoop_BeginRoom']()
    for i in range(1, 6):
        w.g['HopeRoute_Left'][i] = True
    check(w.g['HopeCoop_RoomPlayers'] == 6, 'Departures do not rewrite the active battle snapshot')
    w.g['HopeCoop_BeginRoom']()
    check(w.g['HopeCoop_RoomPlayers'] == 1 and w.g['udg_Guaiwu_sl'] == 7 and w.handicap == 250., 'Next room removes departed players and their legacy handicap')
    check(len(w.messages) == 2, 'Population explanation appears on first room and population change')


def test_spawn():
    for mode in range(7):
        for n in range(1, 7):
            for boss in (False, True):
                w = world(n, mode)
                w.g['HopeCoop_BeginRoom']()
                u = enemy(hero=boss)
                scale = w.g['HopeCoop_ScaleEnemy']
                scale(u)
                check(abs(u.maximum - 1000. * (1. + (0.45 if boss else 0.20) * (n-1))) < 1e-8, 'HP factors exact for each party size, role and difficulty')
                check(abs(u.attack - 100. * (1. + 0.10 * (n-1))) < 1e-8, 'Attack factor applied once')
                expected = (u.maximum, u.attack)
                u.life = 10.
                scale(u)
                check((u.maximum, u.attack, u.life) == (*expected, 10.), 'Repeated processing neither stacks buffs nor heals damage')
                if n == 1:
                    check(not w.state_writes, 'Single player is untouched at native stat boundary')
    for category in ('hero', 'flag', 'small0', 'small1', 'small2', 'large'):
        w = world(3)
        w.g['HopeCoop_BeginRoom']()
        u = enemy(hero=category == 'hero')
        if category == 'flag':
            w.g['SaveBoolean']('YDHT', u.kind, 0xFB89B46C, True)
        elif category.startswith('small'):
            w.g['udg_BOSS_LX'][int(category[-1])] = u.kind
        elif category == 'large':
            w.g['udg_BOSS_LX_______DA'][1] = u.kind
        check(w.g['HopeCoop_IsBoss'](u), 'Boss identification: ' + category)
        w.g['HopeCoop_ScaleEnemy'](u)
        check(abs(u.maximum - 1900.) < 1e-8, 'All boss registry paths use boss HP factor')
    w = world(6, 6)
    w.g['HopeCoop_BeginRoom']()
    u = enemy(hero=True)
    u.maximum, u.attack = 10000000., 1000000.
    w.g['HopeCoop_ScaleEnemy'](u)
    check(u.maximum == 10000000. and u.attack == 1000000., 'New-mode numeric guard composes with prior challenge scaling')
    for invalid in (None, enemy(owner=0), enemy()):
        if invalid is not None and invalid.owner == 11:
            invalid.kind = 0
        writes = len(w.state_writes)
        w.g['HopeCoop_ScaleEnemy'](invalid)
        check(len(w.state_writes) == writes, 'Invalid/friendly units untouched')


def test_integration():
    spawn = body('Trig_G_____________004Actions')[3]
    room = body('Trig______________011Actions')[3]
    check(spawn.count('call HopeCoop_ScaleEnemy(GetTriggerUnit())') == 1, 'Only one enemy-spawn hook')
    check(spawn.index('call HopeCoop_ScaleEnemy(GetTriggerUnit())') < spawn.index('$3FBE7059,GetUnitStateSwap'), 'AI snapshots include the adjusted attack')
    if 'call HopeChallenge_ScaleEnemy(GetTriggerUnit())' in spawn:
        check(spawn.index('call HopeChallenge_ScaleEnemy(GetTriggerUnit())') < spawn.index('call HopeCoop_ScaleEnemy(GetTriggerUnit())'), 'Round scaling precedes party scaling')
    check(room.index('call HopeCoop_BeginRoom()') < room.index('call CreateNUnitsAtLocFacingLocBJ'), 'Population snapshot occurs before any new monster')
    check('call SetPlayerHandicapBJ(Player(11),udg_diren_xueliang+20.)' not in SCRIPT, 'Legacy initialization cannot leave stale +20 after departures')
    check('HopeCoop_' not in body('Trig____________________005Actions')[3], 'No second global damage multiplier')
    check(SCRIPT.count('call HopeCoop_ScaleEnemy(') == 1, 'UI refresh and preview do not scale stats')
    for key in ('udg_Wj_jf', 'boss_jf', 'PLAYER_STATE_RESOURCE_GOLD', 'PLAYER_STATE_RESOURCE_LUMBER'):
        check(key not in body('HopeCoop_BeginRoom')[3] + body('HopeCoop_ScaleEnemy')[3], 'Coop difficulty does not inflate rewards: ' + key)


if __name__ == '__main__':
    test_population()
    test_rooms()
    test_spawn()
    test_integration()
    print(f'Coop regression PASS: {CASES} assertions (actual shipped JASS, native doubles).')
