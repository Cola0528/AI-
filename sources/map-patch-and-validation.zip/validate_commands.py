"""Check shipped awakening commands against every eligible hero's skill set.

This validates actual SLK/profile inputs, not Warcraft's UI renderer or its
native dispatcher. The negative cases reproduce the old E collision.
"""
from pathlib import Path
import json

from validate_object_dependencies import parse_slk, parse_profile, value

R = Path(__file__).resolve().parent
O = R / 'modified'
abilities = parse_slk((O / 'Units_AbilityData.slk').read_bytes(), 'abilities').rows
units = parse_slk((O / 'Units_UnitAbilities.slk').read_bytes(), 'units').rows
profiles = {}
for path in sorted(R.glob('Units_*ability*.txt')):
    current = O / path.name
    for alias, fields in parse_profile((current if current.exists() else path).read_bytes(), path.name).items():
        profiles.setdefault(alias, {}).update(fields)
new = {'AZ31', 'AZ32', 'AZ33', 'AZ34', 'AZ35', 'AZ36'}
options = json.loads((R / 'patch-options.json').read_text())


def position(profile):
    if 'buttonpos' not in profile:
        return None
    parts = (profile['buttonpos'].split(',') + ['0', '0'])[:2]
    return tuple(int(part or '0') for part in parts)


def command(alias):
    row, profile = abilities.get(alias, {}), profiles.get(alias, {})
    if row.get('code') and value(row, 'code') == 'ANcl':
        return value(row, 'DataF1') if 'DataF1' in row else profile.get('order', 'channel').lower()
    return profile.get('order', '').lower()


# These may be added by runtime hero initialization or acquired later. Different
# player variants are compared independently with the awakening, never together.
shared = {alias for alias, fields in profiles.items()
          if fields.get('name', '').startswith(('R', 'X', '专注！', '恢复药剂'))}
assert all(fields.get('hotkey', '').upper() != 'Z' for alias, fields in profiles.items() if alias not in new)
checked = 0
old_e_collisions = []
for option in options:
    if option['stage'] != 3:
        continue
    hero = option['target']
    ultimate = 'AZ35' if hero == 'HZ03' else 'AZ3' + str(option['kind'])
    existing = shared.copy()
    for field in ['abilList', 'heroAbilList']:
        existing.update(value(units[hero], field).split(','))
    existing.discard('_')
    existing.discard('')
    profile = profiles[ultimate]
    assert profile['hotkey'] == 'Z' and position(profile) == (2, 1), ultimate
    assert '（Z）' in profile['tip'], ultimate
    assert '（Z）' in option['skills'] and '（E）' not in option['skills'], option['name']
    for other in existing:
        original = profiles.get(other, {})
        assert original.get('hotkey', '').upper() != profile['hotkey'], (hero, ultimate, other, 'key')
        assert position(original) != position(profile), (hero, ultimate, other, 'button')
        assert command(other) != command(ultimate), (hero, ultimate, other, 'command')
        if original.get('hotkey') == 'E':
            old_e_collisions.append((hero, other))
        checked += 1
assert len([o for o in options if o['stage'] == 3]) == 17
assert ('N01E', 'A04U') in old_e_collisions and ('H008', 'A00K') in old_e_collisions
assert position(profiles['A00F']) == (0, 2)
assert position(profiles['A04U']) == (2, 2)
assert profiles['A00F']['hotkey'] == 'Q' and profiles['A04U']['hotkey'] == 'E'
assert command('A00F') != command('A04U')
print(f'PASS: {checked} awakening/retained-skill pairs across all 17 careers have distinct Z keys, positions and base orders; old E collisions detected in regression cases.')
