"""v12 monk: all-stat qi, deliberate single ally recovery or team defense."""
import re
from modern_choices_patch import block,replace
from hidden_objects import read_slk,raw_value,clone_section,update_section
from inventory_event_patch import edit_slk
TEXT={
'A058':'三才掌：单体物理伤害基值=攻击力×0.8+三围总和×0.9。|n命中当前敌人获得1气，最多3气；战斗开始清零。|n消耗1行动点、0魔法。三围含装备加成。|n无额外50%翻倍；技能倍率、暴击、最终伤害和减伤按原规则结算。',
'A059':'渡厄击：消耗全部气，打击一名当前敌人并救助队友。|n法术伤害基值=三围总和×(0.8+技能等级×0.4)×(1+气×0.15)。|n治疗生命比例最低的存活队友（可含自己）：三围总和×(0.25+气×0.15)，不超过缺失生命。|n0气也可使用；消耗1行动点、3魔法，每回合一次。',
'A05C':'护心诀：消耗全部气，为所有存活队友增加护甲。|n每人获得护甲=三围总和×(0.10+气×0.03)+施法者额外护甲。|n0气也可使用；消耗1行动点、2魔法，每回合一次。|n护甲沿用原图吸收伤害与回合清理规则；没有嘲讽。',
'AZ36':'万法归一：对全体当前敌人造成三围总和×1.1的法术伤害。|n全体存活队友恢复三围总和×0.25生命，并获得三围总和×0.10护甲。|n将自身气补至3层；治疗不超过各自缺失生命。|n消耗2行动点、3魔法；战斗中每回合一次。',
}
NAMES={'A058':'三才掌','A059':'渡厄击','A05C':'护心诀','AZ36':'万法归一'}
G='''integer array HopeMonk_Qi
integer array HopeMonk_LastE
integer array HopeMonk_LastW
integer array HopeMonk_LastZ
'''
HELPERS=r'''function HopeMonk_Total takes unit u returns real
return I2R(GetHeroStr(u,true)+GetHeroAgi(u,true)+GetHeroInt(u,true))
endfunction
function HopeMonk_Reset takes nothing returns nothing
local integer i=1
loop
exitwhen i>6
set HopeMonk_Qi[i]=0
set HopeMonk_LastE[i]=0
set HopeMonk_LastW[i]=0
set HopeMonk_LastZ[i]=0
set i=i+1
endloop
endfunction
function HopeMonk_Ally takes unit u,player p returns boolean
return u!=null and GetWidgetLife(u)>.405 and IsUnitAlly(u,p)
endfunction
function HopeMonk_Heal takes unit u,real amount returns nothing
call SetUnitState(u,UNIT_STATE_LIFE,RMinBJ(GetUnitState(u,UNIT_STATE_MAX_LIFE),GetWidgetLife(u)+amount))
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Human\\HolyBolt\\HolyBoltSpecialArt.mdl",u,"origin"))
endfunction
function HopeMonk_Lowest takes player p returns unit
local integer j=1
local unit best=null
local real ratio=1.
local real current=0.
loop
exitwhen j>6
if HopeMonk_Ally(udg_hero[j],p) and GetUnitState(udg_hero[j],UNIT_STATE_MAX_LIFE)>0. then
set current=GetWidgetLife(udg_hero[j])/GetUnitState(udg_hero[j],UNIT_STATE_MAX_LIFE)
if current<ratio then
set ratio=current
set best=udg_hero[j]
endif
endif
set j=j+1
endloop
return best
endfunction
function HopeMonk_Cast takes unit u,integer aid,unit target returns nothing
local player p=GetOwningPlayer(u)
local integer i=GetPlayerId(p)+1
local integer token=HopeChallenge_TurnToken()+1
local integer j=1
local integer qi=0
local integer ap=1
local real mana=0.
local real total=HopeMonk_Total(u)
local real amount=0.
local unit ally=null
local group g=null
if i<1 or i>6 or u!=udg_hero[i] or GetUnitTypeId(u)!='N01G' or GetWidgetLife(u)<=.405 or IsUnitPaused(u) or not udg_ZhandouZhong then
set p=null
return
endif
if aid=='A059' then
set mana=3.
elseif aid=='A05C' then
set mana=2.
elseif aid=='AZ36' then
set mana=3.
set ap=2
elseif aid!='A058' then
set p=null
return
endif
if (aid=='A058' or aid=='A059') and (target==null or not IsUnitInGroup(target,udg_Guaiwu_dwz) or GetWidgetLife(target)<=.405 or not IsUnitEnemy(target,p)) then
call DisplayTimedTextToPlayer(p,0,0,3.,"需要存活的当前敌人。")
set p=null
return
endif
if (aid=='A059' and (GetUnitAbilityLevel(u,aid)<1 or HopeMonk_LastE[i]==token)) or (aid=='A05C' and HopeMonk_LastW[i]==token) or (aid=='AZ36' and (not HopeJob_Awakened[i] or HopeJob_UltimateKind[i]!=6 or HopeMonk_LastZ[i]==token)) then
call DisplayTimedTextToPlayer(p,0,0,3.,"尚未获得该技能，或本回合已经使用。")
set p=null
return
endif
if udg_xingdong_dian[i]<ap or GetUnitState(u,UNIT_STATE_MANA)<mana then
call DisplayTimedTextToPlayer(p,0,0,3.,"行动点或魔法不足。")
set p=null
return
endif
set qi=HopeMonk_Qi[i]
set udg_xingdong_dian[i]=udg_xingdong_dian[i]-ap
call SetUnitState(u,UNIT_STATE_MANA,GetUnitState(u,UNIT_STATE_MANA)-mana)
if aid=='A058' then
set HopeMonk_Qi[i]=IMinBJ(3,qi+1)
set amount=(GetUnitState(u,ConvertUnitState(20))*.8+total*.9)*udg_Skill_Dm[i]
call UnitDamageTarget(u,target,amount,true,false,ATTACK_TYPE_NORMAL,DAMAGE_TYPE_NORMAL,WEAPON_TYPE_WHOKNOWS)
elseif aid=='A059' then
set HopeMonk_LastE[i]=token
set HopeMonk_Qi[i]=0
set ally=HopeMonk_Lowest(p)
if ally!=null then
call HopeMonk_Heal(ally,total*(.25+I2R(qi)*.15))
endif
set amount=total*(.8+I2R(GetUnitAbilityLevel(u,aid))*.4)*(1.+I2R(qi)*.15)*udg_Skill_Dm[i]*udg_Fashang_Dm[i]
call UnitDamageTarget(u,target,amount,false,false,ATTACK_TYPE_MAGIC,DAMAGE_TYPE_MAGIC,WEAPON_TYPE_WHOKNOWS)
elseif aid=='A05C' then
set HopeMonk_LastW[i]=token
set HopeMonk_Qi[i]=0
set amount=total*(.10+I2R(qi)*.03)+udg_Defend_fangyu[i]
loop
exitwhen j>6
set ally=udg_hero[j]
if HopeMonk_Ally(ally,p) then
call SetUnitState(ally,ConvertUnitState(32),GetUnitState(ally,ConvertUnitState(32))+amount)
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Human\\Defend\\DefendCaster.mdl",ally,"origin"))
endif
set j=j+1
endloop
else
set HopeMonk_LastZ[i]=token
set HopeMonk_Qi[i]=3
loop
exitwhen j>6
set ally=udg_hero[j]
if HopeMonk_Ally(ally,p) then
call HopeMonk_Heal(ally,total*.25)
call SetUnitState(ally,ConvertUnitState(32),GetUnitState(ally,ConvertUnitState(32))+total*.10)
endif
set j=j+1
endloop
set amount=total*1.1*udg_Skill_Dm[i]*udg_Fashang_Dm[i]
set g=CreateGroup()
call GroupAddGroup(udg_Guaiwu_dwz,g)
loop
set target=FirstOfGroup(g)
exitwhen target==null
call GroupRemoveUnit(g,target)
if GetWidgetLife(target)>.405 and IsUnitEnemy(target,p) then
call UnitDamageTarget(u,target,amount,false,false,ATTACK_TYPE_MAGIC,DAMAGE_TYPE_MAGIC,WEAPON_TYPE_WHOKNOWS)
endif
endloop
call DestroyGroup(g)
endif
set g=null
set ally=null
set p=null
endfunction
'''

def update_options(options):
    for o in options:
        if o['target']!='N01G':continue
        o['role']='全属性战斗辅助 · 攻击蓄气 · 救人或护队'
        if o['stage']==2:
            o['skills']='|n|n'.join('|cffd2b879'+NAMES[a]+'|r|n'+TEXT[a] for a in ['A058','A059','A05C'])
        else:
            o['kind']=6
            o['bonus']['agi']=8
            o['skills']='|cffd2b879万法归一（Z）|r|n'+TEXT['AZ36']+'|n保留二转三才掌、渡厄击、护心诀与修炼。'
            o['passive']='三转属性：力量、敏捷、智力各+8，生命上限+60。|n防御额外护甲+6保留。|n万法归一补满3气后，可继续选择渡厄救人或护心保护全队。'

def apply(src):
    src=src.replace('globals\n','globals\n'+G,1)
    src=src.replace('function HopeSkill_Original takes',HELPERS+'\nfunction HopeSkill_Original takes',1)
    for name,aid in [('Trig_JN_______001_______uActions','A058'),('Trig_JN______006_______uActions','A059')]:
        src=replace(src,name,f"function {name} takes nothing returns nothing\ncall HopeMonk_Cast(GetTriggerUnit(),'{aid}',GetSpellTargetUnit())\nendfunction")
    f=block(src,'Trig_JN_______002Actions')
    f=f.replace('set ydl_localvar_step=ydl_localvar_step+3',"if GetSpellAbilityId()=='A05C' then\ncall HopeMonk_Cast(GetTriggerUnit(),'A05C',null)\nreturn\nendif\nset ydl_localvar_step=ydl_localvar_step+3",1)
    src=replace(src,'Trig_JN_______002Actions',f)
    f=block(src,'HopeJob_Cast').replace("if aid=='AZHR' or aid=='AZHD' then","if aid=='AZ36' then\ncall HopeMonk_Cast(u,aid,target)\nelseif aid=='AZHR' or aid=='AZHD' then",1)
    src=replace(src,'HopeJob_Cast',f)
    f=block(src,'HopeChallenge_NextTurn').replace('set HopeJob_LastCast[i]=-1','set HopeJob_LastCast[i]=-1\nset HopeMonk_LastE[i]=0\nset HopeMonk_LastW[i]=0\nset HopeMonk_LastZ[i]=0')
    src=replace(src,'HopeChallenge_NextTurn',f)
    src=src.replace('set udg_ZhandouZhong=true','call HopeMonk_Reset()\nset udg_ZhandouZhong=true')
    # Keep custom skill summaries and dynamic tooltips aligned with handlers.
    f=block(src,'HopeSkill_Original')
    for a in ['A058','A059','A05C']:
        f,n=re.subn(r"(elseif id=='"+a+r"' then\n)return \"[^\"]*\"",lambda m:m[1]+'return "'+TEXT[a]+'"',f);assert n==1
    src=replace(src,'HopeSkill_Original',f)
    f=block(src,'HopeSkill_ManaCost')
    for a in ['A059','A05C']:
        f,n=re.subn(r"(elseif id=='"+a+r"' then\n)return [\d.]+",r'\g<1>return 0.',f);assert n==1
    src=replace(src,'HopeSkill_ManaCost',f)
    f=block(src,'HopeSkill_Preview')
    previews={
        'A058':'"伤害基值 "+HopeSkill_Number(a*.8+(s+d+i)*.9)+"；当前气 "+I2S(HopeMonk_Qi[p])+"/3"',
        'A059':'"法术基值 "+HopeSkill_Number((s+d+i)*(.8+I2R(level)*.4)*(1.+I2R(HopeMonk_Qi[p])*.15))+"；治疗 "+HopeSkill_Number((s+d+i)*(.25+I2R(HopeMonk_Qi[p])*.15))+"|n当前气 "+I2S(HopeMonk_Qi[p])+"/3；消耗1行动点、3魔法"',
        'A05C':'"全队各获护甲 "+HopeSkill_Number((s+d+i)*(.10+I2R(HopeMonk_Qi[p])*.03)+udg_Defend_fangyu[p])+"；当前气 "+I2S(HopeMonk_Qi[p])+"/3|n消耗1行动点、2魔法，每回合一次"',
    }
    # Replace whole branches (old E has multiple conditional returns).
    for a,v in previews.items():
        pat=r"elseif id=='"+a+r"' then\n.*?(?=elseif id==|\nendif\nreturn)"
        f,n=re.subn(pat,"elseif id=='"+a+"' then\nreturn "+v+'\n',f,flags=re.S);assert n==1,(a,n)
    src=replace(src,'HopeSkill_Preview',f)
    return src

def apply_objects(root,output):
    p=output/'Units_AbilityData.slk'
    changes={'A059':{**{f'Cost{k}':0 for k in range(1,4)},**{f'Cool{k}':.1 for k in range(1,4)}},'A05C':{'Cost1':0,'Cool1':.1}}
    edit_slk(p,changes)
    lines,rows,heads,objects=read_slk(p);row=objects['AZ35'][1].copy();last=max(rows)+1
    row[heads['alias']]=raw_value('AZ36');row[heads['DataF1']]=raw_value('tranquility')
    lines=[re.sub(r';Y\d+',f';Y{last}',l) if l.startswith('B;') else l for l in lines if l!='E']
    lines += [f'C;X{x};Y{last};K{v}' for x,v in sorted(row.items())]+['E']
    p.write_text('\r\n'.join(lines)+'\r\n',encoding='utf-8')
    p=output/'Units_campaignabilitystrings.txt';s=p.read_text();s=clone_section(s,'AZ35','AZ36')
    for a in TEXT:
        fields={'Name':NAMES[a],'Ubertip':TEXT[a],'Tip':NAMES[a]}
        if a=='A059':fields.update({'Researchtip':'学习渡厄击','Researchubertip':TEXT[a]})
        if a=='AZ36':fields.update({'Tip':'万法归一（Z）','Order':'tranquility','Art':'ReplaceableTextures\\CommandButtons\\BTNTranquility.blp'})
        s=update_section(s,a,fields)
    p.write_text(s,encoding='utf-8')
    p=output/'Units_itemstrings.txt';s=p.read_text();desc='转职僧侣：全属性战斗辅助。|n攻击蓄气；渡厄击救助低血队友，护心诀保护全队。|n见习牧师15级、智力30可转；保留技能伤害+30%的转职奖励。'
    s=update_section(s,'I04Z',{'Description':desc,'Ubertip':desc});p.write_text(s,encoding='utf-8')
    p=output/'Units_campaignunitstrings.txt';s=p.read_text();s=update_section(s,'N01G',{'Ubertip':'全属性战斗辅助。三才掌蓄气，渡厄击救人，护心诀保护全队。','Tip':'僧侣'});p.write_text(s,encoding='utf-8')
