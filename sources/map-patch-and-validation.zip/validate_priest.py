"""Execute priest holy damage handlers and compare untouched support/monk paths.

Only Warcraft natives/timers and the shared downstream damage boundary are
stubbed. Formula decisions come from the shipped JASS, not builder functions.
"""
import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace
from validate_economy import World, rawcode, body, SCRIPT
from validate_object_dependencies import parse_profile

ROOT=Path(__file__).resolve().parent
OUTPUT=Path(sys.argv[2]) if len(sys.argv)>2 else ROOT/'modified'
ORIGINAL=(ROOT/'war3map.j').read_text()
Q_HANDLER='Trig_JN_______005Actions'
E_HANDLER='Trig_JN_____________008______________uActions'
E_SPLASH='Trig_JN_____________008______________uFunc005Func015Func001Func002A'

class Unit(SimpleNamespace):
    def __eq__(self, other): return self is other
    def __ne__(self, other): return self is not other


def environment(rank=1, targets=None):
    w=World();u=w.hero(0)
    u.int=100;u.attack=60.;u.mana=60.;u.maxmana=100.;u.maximum=200.
    u.learned={rawcode('A04W'):rank,rawcode('A04V'):2}
    targets=targets or [Unit(owner=11,undead=False,life=9999.)]
    state={'target':targets[0],'enum':None,'spell':rawcode('A04W'),'next_timer':100,'timers':[],'damage':[]}
    def create_timer():
        state['next_timer']+=1
        return state['next_timer']
    def get_state(unit,key):
        return unit.attack if key==20 else getattr(unit,key)
    def for_group(group,callback):
        for target in group[:]:
            state['enum']=target;callback()
        state['enum']=None
    def for_force(force,callback):
        callback()
    w.g.update({
        'UNIT_TYPE_UNDEAD':'undead','UNIT_STATE_MANA':'mana','UNIT_STATE_MAX_MANA':'maxmana',
        'UNIT_STATE_LIFE':'life','UNIT_STATE_MAX_LIFE':'maximum','ATTACK_TYPE_MAGIC':1,'DAMAGE_TYPE_COLD':2,
        'GetTriggeringTrigger':lambda:41,'GetTriggerUnit':lambda:u,'GetSpellTargetUnit':lambda:state['target'],
        'GetSpellAbilityId':lambda:state['spell'],'GetEnumUnit':lambda:state['enum'],
        'GetEnumPlayer':lambda:0,'ForForce':for_force,
        'GetUnitAbilityLevel':lambda unit,aid:unit.learned.get(aid,0),
        'GetUnitAbilityLevelSwapped':lambda aid,unit:unit.learned.get(aid,0),
        'GetHeroInt':lambda unit,bonus:unit.int,'GetHeroStr':lambda unit,bonus:unit.str,
        'GetHeroAgi':lambda unit,bonus:unit.agi,'IsUnitType':lambda unit,key:unit.undead if key=='undead' else False,
        'GetUnitState':get_state,'GetUnitStateSwap':lambda key,unit:get_state(unit,key),
        'ConvertUnitState':lambda key:key,'GetUnitLoc':lambda unit:0,
        'GetUnitManaPercent':lambda unit:unit.mana/unit.maxmana*100.,
        'SetUnitManaPercentBJ':lambda unit,value:setattr(unit,'mana',max(0.,value/100.*unit.maxmana)),
        'GetUnitLifePercent':lambda unit:unit.life/unit.maximum*100.,
        'SetUnitLifePercentBJ':lambda unit,value:setattr(unit,'life',min(unit.maximum,value/100.*unit.maximum)),
        'SetUnitLifeBJ':lambda unit,value:setattr(unit,'life',min(unit.maximum,value)),
        'IsUnitAliveBJ':lambda unit:unit.life>.405,
        'DzFrameSetText':lambda *args:None,'YDWETimerDestroyEffect':lambda *args:None,
        'AddSpecialEffectTarget':lambda *args:None,'FlushChildHashtable':lambda *args:None,
        'UnitDamageTargetBJ':lambda source,target,amount,*args:state['damage'].append((target,amount)),
        'Condition':lambda callback:callback,'YDWEGetUnitsInRectMatchingNull':lambda rect,condition:targets.copy(),
        'CountUnitsInGroup':len,'GroupPickRandomUnit':lambda group:group[0],
        'GroupRemoveUnitSimple':lambda unit,group:group.remove(unit),'DestroyGroup':lambda group:None,
        'ForGroupBJ':for_group,'CreateTimer':create_timer,
        'TimerStart':lambda timer,period,repeat,callback:state['timers'].append(timer),
        'Trig_JN_______005Func005Func018T':lambda:None,
        'YDWEDistanceBetweenUnits':lambda *args:0.,'CreateTextTagUnitBJ':lambda *args:None,
        'GetLastCreatedTextTag':lambda:0,'YDWEUnitHasItemOfTypeBJNull':lambda *args:False,
        'GetRandomInt':lambda lo,hi:lo,
    })
    for kind in ('GroupHandle','LocationHandle','TextTagHandle','EffectHandle'):
        w.g['Save'+kind]=lambda table,parent,key,value:w.tables[table].__setitem__((parent,key),value)
        w.g['Load'+kind]=lambda table,parent,key:w.tables[table].get((parent,key))
    w.g['udg_xingdong_dian'][1]=4
    w.g['udg_Skill_Dm'][1]=1.5;w.g['udg_Fashang_Dm'][1]=1.2;w.g['udg_Zuizhong_Dm'][1]=2.
    w.load('HopePriest_BaseDamage','HopePriest_TargetDamage',Q_HANDLER,E_SPLASH,
           'Trig_JN_____________008______________uFunc005Func015Func001Func001003002',
           'Trig_JN_____________008______________uFunc005Func015Func002003002',E_HANDLER)
    return w,u,state

# Real Q trigger: mage shared branch unchanged and holy Q uniform 20% base cut.
for spell,undead,expected in [('A03J',False,96.),('A03J',True,120.),('A00F',False,187.2),('A00F',True,187.2)]:
    target=Unit(owner=11,undead=undead,life=9999.)
    w,u,state=environment(targets=[target]);state['spell']=rawcode(spell)
    w.g[Q_HANDLER]()
    assert len(state['timers'])==1
    recorded=w.tables['YDLOC'][state['timers'][0],int('BB4B7313',16)]
    assert abs(recorded-expected)<1e-7,(spell,undead,recorded,expected)
    assert w.g['udg_xingdong_dian'][1]==3 and u.mana==60.

# Levels 1/2/3: actual distinct primary and secondary undead targets, 1AP,
# original 20%-maximum-mana deduction, no pre-applied final damage multiplier.
for rank in (1,2,3):
    for primary_undead in (False,True):
        for primary_first in (False,True):
            primary=Unit(owner=11,undead=primary_undead,life=9999.)
            secondary=[Unit(owner=11,undead=i%2==0,life=9999.) for i in range(5)]
            targets=([primary]+secondary) if primary_first else (secondary[:2]+[primary]+secondary[2:])
            w,u,state=environment(rank,targets);state['target']=primary
            w.g[E_HANDLER]()
            damages=state['damage'];expected_count={1:1,2:2,3:4}[rank]
            assert len(damages)==expected_count,(rank,damages)
            assert damages[0][0] is primary
            assert len({id(t) for t,v in damages})==expected_count
            for target,amount in damages:
                expected=(60.*.2+100.)*.8*1.5*1.2*(1.25 if target.undead else 1.)
                assert abs(amount-expected)<1e-7,(rank,target.undead,amount,expected)
            assert w.g['udg_xingdong_dian'][1]==3
            assert abs(u.mana-40.)<1e-7
w,u,state=environment();w.g['udg_xingdong_dian'][1]=0
w.g[E_HANDLER]();assert not state['damage'] and u.mana==60.

# Tooltip references use the same base/race values and apply final once.
w,u,state=environment(3)
w.g.update({'HopeSkill_Number':lambda value:format(value,'.6g'),
            'HopeSkill_Rolled':lambda unit,p,value,lo,hi:format(value*w.g['udg_Zuizhong_Dm'][p],'.6g')})
w.load('HopeSkill_ManaCost','HopeSkill_Preview','HopeSkill_Original')
q=w.g['HopeSkill_Preview'](u,rawcode('A03J'),1)
assert q=='一般目标 192；亡灵 240',q
u.mana=70. # displayed before the engine takes the unchanged fixed 10 MP cost
for rank in (1,2,3):
    preview=w.g['HopeSkill_Preview'](u,rawcode('A04W'),rank)
    assert '主目标 322.56；亡灵 403.2' in preview,preview
    assert ('另1目标 322.56；亡灵 403.2' in preview)==(rank==2)
    assert ('最多3个次目标各 322.56；亡灵 403.2' in preview)==(rank==3)

# Healing/defense/monk behavior remains unchanged. The shared learning trigger
# has one separately verified reclass anti-farming change: potion award dedup.
functions={m[1]:m[0] for m in re.finditer(r'^function (\w+) takes.*?^endfunction',ORIGINAL,re.M|re.S)}
prefixes=('Trig_JN_____________008_______u','Trig_JN_______001_______u','Trig_JN______006_______u')
protected={name for name in functions if name.startswith(prefixes)}
# Group defense and the learned-priest passive live in other original handlers.
for name,text in functions.items():
    if '$41303154' in text or '$4130334B' in text:
        protected.add(name)
for name in protected:
    expected=functions[name]
    if name=='Trig_JN_____________012Actions':
        old_award='set udg_Yaoshui_shenyu_cs[LoadInteger(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$877546F4)]=udg_Yaoshui_shenyu_cs[LoadInteger(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$877546F4)]+1'
        replacement='call HopeReclass_PotionLearn(GetTriggerUnit())'
        assert expected.count(old_award)==1
        assert body(name)[0].count(replacement)==1
        expected=expected.replace(old_award,replacement,1)
    assert body(name)[0]==expected,('support/monk changed',name)
# Execute actual original group recovery once: 25% max HP + INT, potion only.
w,u,state=environment();u.life=100.;u.maximum=500.
w.g['udg_Yaoshui_shenyu_cs'][1]=1
w.load('Trig_JN_____________008_______uFunc005Func008A','Trig_JN_____________008_______uActions')
w.g['Trig_JN_____________008_______uActions']()
assert u.life==325. and w.g['udg_Yaoshui_shenyu_cs'][1]==0
assert w.g['udg_xingdong_dian'][1]==4 and u.mana==60.
# Shared fireball formula, projectile, and callbacks preserved outside Q branch.
old=body(Q_HANDLER,ORIGINAL)[0];current=body(Q_HANDLER)[0]
old_segment=old[old.index('if GetSpellAbilityId()==$41303046 then'):old.index('else\ncall SaveReal(YDLOC',old.index('if GetSpellAbilityId()==$41303046 then'))]
assert old_segment in current
for name,text in functions.items():
    if name.startswith('Trig_JN_______005') and name!=Q_HANDLER:
        assert body(name)[0]==text,name

# The priest and monk awakening is still the same group heal: max HP*20%
# plus caster INT, with no priest damage scaling or skill/final multipliers.
awakening=body('HopeJob_Cast')[0]
healing=awakening.split('if kind==4 then',1)[1].split('else\nif kind==1 then',1)[0]
assert 'GetUnitState(udg_hero[j],UNIT_STATE_MAX_LIFE)*.2+I2R(GetHeroInt(u,true))' in healing
assert 'HopePriest_' not in healing and 'udg_Skill_Dm' not in healing and 'udg_Zuizhong_Dm' not in healing

profiles=parse_profile((OUTPUT/'Units_campaignabilitystrings.txt').read_bytes(),'priest profiles')
original_profiles=parse_profile((ROOT/'Units_campaignabilitystrings.txt').read_bytes(),'original profiles')
for aid in ('A03J','A04W'):
    description=w.g.get('HopeSkill_Original')
    # Compile in this fresh World too; definitions remain purely shipped text.
    w.load('HopeSkill_Original')
    text=w.g['HopeSkill_Original'](rawcode(aid),1)
    assert profiles[aid]['ubertip']==text,(aid,'profile/dynamic mismatch')
    assert '×0.8' in text and '25%' in text
    assert '双倍' not in text and '300%' not in text and '200%' not in text
    if aid=='A04W':assert profiles[aid]['researchubertip']==text
for aid in ('A00N','A01T','A03K','A058','A059','A05A','A05C'):
    assert profiles[aid]==original_profiles[aid],('support/monk profile changed',aid)
# Root may build options concurrently; all shipped promotion descriptions must
# contain the same offense descriptions when validating the final artifact.
options_path=ROOT/'patch-options.json'
options=json.loads(options_path.read_text())
for option in options:
    if option['target']=='N017' and option['stage']==2:
        for aid in ('A03J','A04W'):
            assert profiles[aid]['ubertip'] in option['skills'],('promotion mismatch',aid)
    if option['target']=='N00E':
        assert profiles['A04W']['ubertip'] in option['skills']
print('PASS: priest Q/judgment real handlers, all target/rank branches, costs and display; unchanged mage, monk, healing/defense/passives; profiles and promotion text agree.')
