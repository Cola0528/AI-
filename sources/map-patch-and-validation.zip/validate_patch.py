from pathlib import Path
from collections import defaultdict
from types import SimpleNamespace as N
import re,json
R=Path('/workspace/map-edit');s=(R/'war3map-patched.j').read_text();opts=json.loads((R/'patch-options.json').read_text())
def rid(x):return int.from_bytes(x.encode(),'big')
def expr(x):
 x=re.sub(r'\$([0-9A-Fa-f]+)',lambda m:str(int(m[1],16)),x)
 x=re.sub(r"'([A-Za-z0-9]{4})'",lambda m:str(rid(m[1])),x)
 for a,b in [('null','None'),('true','True'),('false','False')]:x=re.sub(r'\b'+a+r'\b',b,x)
 return x
# Execute the actual JASS decision functions using a minimal translation, with mocked game queries.
# This tests boundary behavior, not rendering or the native Warcraft engine.
def translate(name):
 m=re.search(r'function '+name+r' takes (.*?) returns .*?\n(.*?)\nendfunction',s,re.S);assert m
 args=[] if m[1]=='nothing' else [p.strip().split()[-1] for p in m[1].split(',')]
 out=['def '+name+'('+','.join(args)+'):'];level=1
 for l in m[2].splitlines():
  l=l.strip()
  if not l or l.startswith('//'):continue
  if l=='endif':level-=1;continue
  if l.startswith('elseif '):level-=1;code='elif '+expr(l[7:-5])+':'
  elif l=='else':level-=1;code='else:'
  elif l.startswith('if '):code='if '+expr(l[3:-5])+':'
  elif l.startswith('local '):
   local=l.split(' ',2)[2];code=expr(local if '=' in local else local+'=None')
  elif l.startswith('set '):code=expr(l[4:])
  elif l.startswith('return '):code='return '+expr(l[7:])
  elif l=='return':code='return'
  elif l.startswith('call '):code=expr(l[5:])
  else:raise AssertionError(l)
  out.append('    '*level+code)
  if code.endswith(':'):level+=1
 return '\n'.join(out)
node=N(floor=4)
g={'udg_Youxi_xzgq':node,'YDHT':{},'udg_quanshu':0,'udg_ZhandouZhong':False,'HopeJob_Count':43,'udg_hero':defaultdict(lambda:None),'HopeJob_Awakened':defaultdict(bool),'HopeJob_AwakenOption':defaultdict(int),'GetPlayerId':lambda p:p,'GetHandleId':lambda u:u,'LoadInteger':lambda ht,u,key:u.floor,'GetUnitTypeId':lambda u:0 if u is None else u.kind,'GetUnitX':lambda u:u.x,'GetUnitY':lambda u:u.y,'GetWidgetLife':lambda u:u.life,'GetHeroLevel':lambda u:u.level,'GetHeroStr':lambda u,bonus:u.str+(100 if bonus else 0),'GetHeroAgi':lambda u,bonus:u.agi+(100 if bonus else 0),'GetHeroInt':lambda u,bonus:u.int+(100 if bonus else 0),'I2S':str,'HopeRoute_RewardPending':lambda i:False}
for field,key in [('Source','source'),('Stage','stage'),('Level','level'),('Str','reqStr'),('Agi','reqAgi'),('Int','reqInt')]:g['HopeJob_'+field]={i:rid(o[key]) if field=='Source' else o[key] for i,o in enumerate(opts)}
for name in ['HopeJob_Floor','HopeJob_InRoom','HopeJob_Visible','HopeJob_Blocker']:exec(translate(name),g)
cases=0
def check(ok,msg):
 global cases
 assert ok,msg;cases+=1
hero=N(kind=rid('HZ02'),x=-3024,y=2485,life=120,level=15,str=20,agi=20,int=20);g['udg_hero'][1]=hero
block=g['HopeJob_Blocker'];visible=g['HopeJob_Visible']
for floor,blocked in [(1,True),(4,True),(5,False),(6,False),(11,False)]:
 node.floor=floor;check(bool(block(26,0))==blocked,f'Hidden third at floor {floor}')
node.floor=5
for i,o in enumerate(opts):
 if o['stage']==3 and i!=26:
  hero.kind=rid(o['source']);check(block(i,0)=='',f'{o["name"]} unlocked at floor 5')
  check(not visible(25,1) and not visible(26,1),f'Hidden progress leaked to {o["name"]}')
hero.kind=rid('HZ01');check([i for i in range(43) if visible(i,1)]==[25],'Hidden second route')
hero.kind=rid('HZ02');check([i for i in range(43) if visible(i,1)]==[26],'Hidden third route')
hero.kind=rid('H000');hero.level=5
for attr in ('str','agi','int'):
 hero.str=hero.agi=hero.int=10;setattr(hero,attr,9);check('属性不足' in block(24,0),f'Random base {attr} 9 rejected despite equipment')
hero.str=hero.agi=hero.int=10;check(block(24,0)=='','Random all base 10 accepted')
hero.level=4;check('等级不足' in block(24,0),'Random level 4 blocked');hero.level=5
hero.x=0;check('泉水' in block(24,0),'Out-of-room confirmation rejected');hero.x=-3024
g['udg_ZhandouZhong']=True;check('泉水' in block(24,0),'Combat confirmation rejected');g['udg_ZhandouZhong']=False
hero.life=.4;check('泉水' in block(24,0),'Dead hero blocked');hero.life=120
hero.kind=rid('HZ02');g['HopeJob_Awakened'][1]=True;g['HopeJob_AwakenOption'][1]=26;check('已完成三转' in block(26,0),'Duplicate awakening blocked')
check(not visible(-1,1) and not visible(43,1),'Invalid option indices rejected')
# Gameplay callbacks never read client-local preview, paging or frame selection state.
for name in ['HopeJob_Commit','HopeJob_Awaken','HopeJob_Cast','HopeJob_Blocker','HopeJob_Visible']:
 body=re.search('function '+name+r' .*?\n(.*?)endfunction',s,re.S)[1]
 check(not any(x in body for x in ['HopeJob_Selected','HopeJob_Page','HopeJob_DetailPage','HopeJob_LastType']),name+' local-state isolation')
commit=re.search(r'function HopeJob_Commit takes .*?\n(.*?)endfunction',s,re.S)[1]
check('GetRandomInt(1,100)<=10' in commit,'Hidden probability is 10 percent')
check('set pick=GetRandomInt(0,7)' in commit,'8 ordinary random outcomes')
check('set HopeJob_RandomPromotion=true' in commit and 'set HopeJob_RandomPromotion=false' in commit,'Random eligibility scoped to synchronous pickup')
first=re.search(r'function Trig____________________020Actions .*?\n(.*?)endfunction',s,re.S)[1]
check('if HopeJob_RandomPromotion or (' in first,'Random can draw 12-strength orc at all attributes 10')
# Validate object dependencies independently, including the known-bad v1 fixture.
import subprocess,sys
subprocess.run([sys.executable,str(R/'validate_object_dependencies.py')],check=True)

replacement=re.search(r'function HopeJob_ReplaceHidden .*?\n(.*?)endfunction',s,re.S)[1]
check("SetUnitAbilityLevel(u,'AZHP',training)" in replacement,'Hidden advancement preserves training rank')
check('GetHeroSkillPoints(old)-GetHeroSkillPoints(u)' in replacement,'Hidden advancement preserves unspent skill points')
learn=re.search(r'function HopeJob_Learn .*?\n(.*?)endfunction',s,re.S)[1]
check('call HopeJob_AddStats(i,2,2,2)' in learn and "GetLearnedSkill()=='AZHP'" in learn,'Hidden learned passive grants permanent base three stats once per rank')
# Keep extended-native requirements identical to the original map.
original_script=(R/'war3map.j').read_text()
check(set(re.findall(r'^native .+$',s,re.M))==set(re.findall(r'^native .+$',original_script,re.M)),'No new extension-native dependency')
main=re.search(r'function main takes nothing returns nothing\n(.*?)endfunction',s,re.S)[1]
check('call HopeJob_Init()' not in main and re.search(r'TimerStart\(CreateTimer\(\),[^,]+,false,function HopeJob_Init\)',main),'Promotion initialization runs in a separate timer callback')
init=re.search(r'function HopeJob_Init takes nothing returns nothing\n(.*?)endfunction',s,re.S)[1]
check('DestroyTimer(GetExpiredTimer())' in init,'One-shot initialization timer released')

# Execute the patched meditation's actual JASS body against two native stat-change
# models. Both can alter mana indirectly; snapshots must neutralize those changes.
for native_model in ['delta','ratio']:
 def set_int(u,value,permanent):
  delta=value-u.int;oldmax=u.maximum;u.int=value;u.maximum=max(0.,u.maximum+delta)
  if native_model=='delta':u.mana=max(0.,min(u.maximum,u.mana+delta))
  else:u.mana=0. if oldmax==0 else u.mana*u.maximum/oldmax
 def set_state(u,state,value):
  setattr(u,state,value)
  if state=='maximum':u.mana=min(u.mana,u.maximum)
 def unit(level=30,mana=21.,maximum=40.):return N(kind=rid('N016'),int=level,mana=mana,maximum=maximum,life=100.,owner=0)
 h=unit()
 m={'udg_quanshu':0,'udg_boci':6,'udg_huihe_s':1,'udg_ZhandouZhong':True,'udg_hero':{1:h},'udg_xingdong_dian':{1:3},'udg_Linshi_Int':defaultdict(int),'udg_Ls_zj_Int':defaultdict(int),'HopeMeditation_Active':defaultdict(bool),'HopeMeditation_Unit':defaultdict(lambda:None),'HopeMeditation_LastCast':defaultdict(int),'GetOwningPlayer':lambda u:u.owner,'GetPlayerId':lambda p:p,'GetHeroInt':lambda u,bonus:u.int,'GetWidgetLife':lambda u:u.life,'GetUnitState':lambda u,state:getattr(u,state),'SetUnitState':set_state,'SetHeroInt':set_int,'UNIT_STATE_MANA':'mana','UNIT_STATE_MAX_MANA':'maximum','R2I':int,'I2R':float,'RMinBJ':min,'RMaxBJ':max,'DisplayTimedTextToPlayer':lambda *args:None,'I2S':str,'R2S':str}
 for name in ['HopeMeditation_Apply','HopeMeditation_Clear']:exec(translate(name),m)
 apply=m['HopeMeditation_Apply'];clear=m['HopeMeditation_Clear']
 apply(h)
 check(h.int==39 and h.maximum==40 and h.mana==30,native_model+' true recovery and no capacity gain')
 check(m['udg_xingdong_dian'][1]==2,native_model+' exactly one action point')
 apply(h);check(h.int==39 and h.mana==30 and m['udg_xingdong_dian'][1]==2,native_model+' duplicate cast rejected')
 clear(h,1);check(h.int==30 and h.maximum==40 and h.mana==30,native_model+' expiry preserves true recovery')
 m['udg_Linshi_Int'][1]=0;m['udg_Ls_zj_Int'][1]=0;m['udg_huihe_s']=2
 h.mana=39.;apply(h);check(h.mana==40 and h.maximum==40,native_model+' recovery capped at pre-cast capacity')
 clear(h,1);check(h.mana==40 and h.maximum==40,native_model+' full-mana expiry does not burn restored mana')
 m['udg_Linshi_Int'][1]=0;m['udg_Ls_zj_Int'][1]=0;m['udg_huihe_s']=3
 h.mana=0.;m['udg_xingdong_dian'][1]=0;apply(h);check(h.int==30 and h.mana==0 and h.maximum==40,native_model+' zero-action-point cast has no effect')
 m['udg_xingdong_dian'][1]=2;m['udg_ZhandouZhong']=False;apply(h);check(h.int==30 and h.mana==0 and m['udg_xingdong_dian'][1]==2,native_model+' out-of-combat cast has no effect')
check('gg_trg_RJN_______003,EVENT_PLAYER_UNIT_SPELL_EFFECT' in s,'Meditation effect-time event, not channel-time grant')
check(len(re.findall(r'call HopeMeditation_Clear\(',s))==3,'All original temporary-intelligence cleanup routes use mana-safe expiry')
check('原触发没有实际回蓝' not in s and '原实际效果不恢复魔法值' not in s,'Stale meditation descriptions removed')

print(f'PASS: {cases} gameplay and initialization assertions, plus independent object dependency regression checks. Native engine and rendering require Warcraft client validation.')
