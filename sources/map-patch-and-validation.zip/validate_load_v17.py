"""Bound v17 content/dependency changes; this does not establish KK load success."""
from pathlib import Path
import hashlib,json,re,sys
sys.path.insert(0,'/workspace/map-tools')
from mpq import op,read,L
from validate_object_dependencies import parse_profile
ROOT=Path(__file__).parent
OUT=Path('/workspace/outputs')
HASHES={
 'AI-Tower-Team-Events-Monk-v12.w3x':'9bd5160683e8d4dec44a7af6c0094217fd43866e35e2d2667be281233a166554',
 'AI-Tower-Chinese-Names-v13.w3x':'9cdf5d11c3587032a32d2a4e646cd00803dc0dc845acc249341c40dc1013e3af',
 'AI-Tower-LoadFix-v16.w3x':'4b9446cbee8045b777f1b53ee60b90a15f9bd836d08a484d4988e02992b9387c'}
def archive(version):
 name=next(n for n in HASHES if n.endswith(f'v{version}.w3x'));p=OUT/name
 assert hashlib.sha256(p.read_bytes()).hexdigest()==HASHES[name]
 return op(p,0x100)
def script(version):
 h=archive(version)
 try:return read(h,'war3map.j').decode()
 finally:L.SFileCloseArchive(h)
def natives(s):return set(re.findall(r'^(?:constant )?native .+$',s,re.M))
def functions(s):return {m[1]:m[0] for m in re.finditer(r'^function (\w+) takes.*?^endfunction',s,re.M|re.S)}
def remainder(s):
 s=re.sub(r'^function \w+ takes.*?^endfunction','',s,flags=re.M|re.S)
 return '\n'.join(line for line in s.splitlines() if line.strip())
def run():
 v12=script(12);v13=script(13);v16=script(16)
 current=(ROOT/'war3map-patched.j').read_text();old=functions(v16);new=functions(current);stable=functions(v12)
 assert natives(current)==natives(v12),'new required platform binding'
 assert not any(x in current for x in ['HopeThird_Rename','DzSetUnitName','DzSetUnitProperName'])
 for name in ['main','config','InitGlobals','HopeQoL_CreateUI']:assert new[name]==stable[name],name+' changed from working v12'
 assert 'HopeProfession_Row' not in current and 'HopeProfession_Update' not in current
 assert not new.keys()-old.keys()
 assert old.keys()-new.keys()=={'HopeProfession_Update','HopeThird_Rename'}
 changed={n for n in new if old[n]!=new[n]}
 assert changed=={'HopeName_Step','HopeQoL_CreateUI','HopeQoL_RefreshContent','HopeThird_Resource','HopeThird_Unlock'},changed
 trimmed=v16.replace('integer HopeProfession_Row=0\n','').replace('boolean HopeProfession_Expanded=false\n','')
 assert remainder(trimmed)==remainder(current),'unexpected global changes'
 bad13=[ord(c) for c in v13 if ord(c)>0xffff]
 assert len(bad13)==5 and not any(ord(c)>0xffff for c in v12+current)
 assert new['HopeName_Step'].isascii(),'special source literals returned'
 identical=[];changed_objects={};h=archive(16)
 try:
  for p in sorted((ROOT/'modified').iterdir()):
   if not p.name.startswith('Units_') and p.name!='war3map.w3a':continue
   key='Units\\'+p.name[6:] if p.name.startswith('Units_') else p.name
   before=read(h,key);after=p.read_bytes()
   if before==after:identical.append(key);continue
   assert key=='Units\\campaignabilitystrings.txt',key
   x=parse_profile(before,key);y=parse_profile(after,key);assert x.keys()==y.keys()
   delta={k:sorted(f for f in x[k] if x[k][f]!=y[k][f]) for k in x if x[k]!=y[k]}
   assert set(delta)=={'AT01','AT02','AT05','AT07','AT09','AT12','AT14','AT15','AT17'}
   assert all(v==['ubertip'] for v in delta.values())
   for k in delta:assert len(('Ubertip='+y[k]['ubertip']).encode())<=1000
   changed_objects[key]=delta
 finally:L.SFileCloseArchive(h)
 assert len(identical)==10 and len(changed_objects)==1
 report={'jass_sha256':hashlib.sha256(current.encode()).hexdigest(),
  'working_baseline':'AI-Tower-Team-Events-Monk-v12.w3x','required_natives_match_v12':True,
  'entrypoints_and_hud_constructor_match_v12':True,'all_third_renaming_removed':True,
  'non_bmp_literals_in_v13':bad13,'non_bmp_literals_in_v17':0,
  'changed_functions_from_v16':sorted(changed),'removed_functions_from_v16':sorted(old.keys()-new.keys()),
  'unchanged_v16_functions':len(new)-len(changed),'unchanged_v16_object_files':identical,
  'changed_object_fields':changed_objects,'gameplay_and_cost_functions_preserved':True,'kk_runtime_tested':False}
 print(json.dumps(report,ensure_ascii=False,indent=2))
 return report
if __name__=='__main__':run()
