"""Exercise final JASS class counters and local HUD with native doubles.

Projectile timers are recorded, not simulated. Font/geometry images are not KK
screenshots. Gameplay functions remain byte-for-byte identical to v13.
"""
from pathlib import Path
from types import SimpleNamespace as N
from copy import deepcopy
import re
from fontTools.ttLib import TTFont
from PIL import ImageFont
from validate_economy import World, rawcode, body, SCRIPT
from validate_layout import Layout
from validate_v12 import Combat
import validate_layout

ROOT = Path(__file__).parent
COUNT = 0
AMMO = 0x30720CCD


def check(ok, msg):
    global COUNT
    assert ok, msg
    COUNT += 1


def plain(s):
    return re.sub(r'\|c[0-9a-fA-F]{8}|\|r', '', s)


class Shots(World):
    def __init__(self, kind='H00E'):
        super().__init__()
        self.u = self.hero()
        self.u.kind = rawcode(kind)
        self.ranks = {}
        self.timers = []
        self.ability = rawcode('A04P' if kind == 'H00E' else 'A01R')
        g = self.g
        g.update({
            'GetTriggeringTrigger': lambda: 99,
            'GetTriggerUnit': lambda: self.u,
            'GetSpellAbilityId': lambda: self.ability,
            'GetSpellTargetUnit': lambda: self.u,
            'GetUnitAbilityLevel': lambda u, a: self.ranks.get(a, 0) if u else 0,
            'GetUnitAbilityLevelSwapped': lambda a, u: self.ranks.get(a, 0) if u else 0,
            'GetHeroStr': lambda u, bonus: u.str,
            'GetHeroAgi': lambda u, bonus: u.agi,
            'GetUnitState': lambda u, state: 20.,
            'ConvertUnitState': lambda k: k,
            'GetUnitLoc': lambda u: 100,
            'GetRandomInt': lambda lo, hi: lo,
            'YDWEUnitHasItemOfTypeBJNull': lambda *a: False,
            'YDWEGetPlayerColorString': lambda p, s: s,
            'CreateTimer': lambda: 1000 + len(self.timers),
            'TimerStart': lambda *a: self.timers.append(a),
            'GetLastCreatedTextTag': lambda: 777,
            'FlushChildHashtable': self.flush,
        })
        for kind in ['TextTagHandle', 'LocationHandle']:
            g['Save'+kind] = lambda t, p, k, v: self.tables[t].__setitem__((p, k), v)
            g['Load'+kind] = lambda t, p, k: self.tables[t].get((p, k))
        for name in ['DzFrameSetText', 'CreateTextTagUnitBJ', 'SetTextTagTextBJ',
                     'SetTextTagVelocityBJ', 'YDWETimerDestroyTextTag', 'DoNothing',
                     'Trig_JN_______003______________uFunc005Func004Func024T',
                     'Trig_JN_______001Func005Func012T']:
            g[name] = lambda *a: None
        self.load('HopeProfession_Text', 'Trig_JN_______003______________uActions',
                  'Trig____________________039Actions', 'Trig_JN_______001Actions')
        g['udg_xingdong_dian'][1] = 30

    def flush(self, table, parent):
        self.tables[table] = {k: v for k, v in self.tables[table].items() if k[0] != parent}

    def text(self):
        return plain(self.g['HopeProfession_Text'](self.u, 1))


def counters():
    w = Shots()
    w.g['Trig____________________039Actions']()
    check(w.text() == '子弹 1/1', 'actual new sniper initialization')
    for rank in range(4):
        w = Shots()
        g = w.g
        w.ranks[rawcode('A04Q')] = rank
        capacity = rank + 1
        g['SaveInteger']('YDHT', id(w.u), AMMO, capacity)
        for remaining in range(capacity-1, -1, -1):
            ap = g['udg_xingdong_dian'][1]
            g['Trig_JN_______003______________uActions']()
            check(w.text().startswith(f'子弹 {remaining}/{capacity}'), 'shot changes displayed ammo before projectile resolves')
            check(g['udg_xingdong_dian'][1] == ap-1, 'one AP per shot')
        check('Q装填' in w.text(), 'empty magazine is red and explains Q reload')
        check(g['HopeProfession_Text'](w.u, 1).startswith('|cffff8585'), 'empty state color')
        g['udg_xingdong_dian'][1] = 0
        g['Trig_JN_______003______________uActions']()
        check(w.text().startswith(f'子弹 0/{capacity}'), 'no AP does not falsely refill HUD')
        g['udg_xingdong_dian'][1] = 3
        timers = len(w.timers)
        g['Trig_JN_______003______________uActions']()
        check(w.text() == f'子弹 {capacity}/{capacity}', 'actual Q reload fills correct rank capacity')
        check(g['udg_xingdong_dian'][1] == 2 and len(w.timers) == timers, 'reload costs AP and does not fire projectile')
        g['HopeJob_Awakened'][1] = True
        check(w.text() == f'子弹 {capacity}/{capacity}', 'third advancement retains resource display')
    w = Shots()
    w.g['SaveInteger']('YDHT', id(w.u), AMMO, 1)
    w.ranks[rawcode('A04Q')] = 3
    check(w.text() == '子弹 1/4', 'passive upgrade updates capacity without inventing filled ammo')

    w = Combat()
    w.load('HopeProfession_Text')
    g = w.g
    text = lambda: plain(g['HopeProfession_Text'](w.u, 1))
    check(text() == '气 0/3', 'monk starts empty')
    for count in [1, 2, 3, 3]:
        w.cast('A058')
        check(text().startswith(f'气 {count}/3'), 'actual Q accumulates and caps qi')
    check(text().endswith('已满'), 'full qi indicator')
    w.cast('A059')
    check(text() == '气 0/3', 'E expenditure appears immediately')
    w.cast('A058')
    w.cast('A05C', False)
    check(text() == '气 0/3', 'W expenditure appears immediately')
    g['HopeJob_Awakened'][1] = True
    g['HopeJob_UltimateKind'][1] = 6
    w.cast('AZ36', False)
    check(text() == '气 3/3 · 已满', 'third Z fills actual qi')
    w.cast('AZ36', False)
    check(text() == '气 3/3 · 已满', 'rejected repeat cast retains count')
    g['HopeMonk_Reset']()
    check(text() == '气 0/3', 'battle reset clears displayed qi')

    for rank in [0, 1, 2, 3]:
        for ability in ['A01R', 'A05F']:
            w = Shots('N01A')
            w.ability = rawcode(ability)
            w.ranks[rawcode('A03M')] = rank
            w.g['udg_Zhongkan_cs'][1] = 13
            strength = w.u.str
            w.g['Trig_JN_______001Actions']()
            check(w.text() == ('重砍 14/15 · 下次+1力' if rank > 1 else ''), 'heavy chop rank gating and progress from real handler')
            w.g['Trig_JN_______001Actions']()
            check(w.text() == ('重砍 0/15' if rank > 1 else ''), '15th chop resets actual progress')
            check(w.u.str == strength+(1 if rank > 1 else 0), 'display milestone matches actual strength award')


class HUD(Layout):
    def __init__(self):
        super().__init__()
        self.font_path = str(ROOT/'map-chinese-font.ttf')
        self.shot = Path('/workspace/outputs/ui-layout-v14')
        self.shot.mkdir(exist_ok=True)
        self.owner = 0
        self.ranks = {}
        g = self.g
        self.load('HopeProfession_Text', 'HopeProfession_Update', 'HopeQoL_Number',
                  'HopeQoL_CompactNumber', 'HopeQoL_RefreshContent', 'HopeQoL_Refresh')
        for name in ['HopeQoL_RefreshLegacyAP', 'HopeTeam_UpdateAP', 'HopeIntent_RefreshAll',
                     'HopeSkill_Refresh', 'HopeChoice_Refresh', 'HopeGrowth_Refresh',
                     'HopeArchive_Refresh', 'HopeGift_Refresh', 'HopeRelic_Refresh',
                     'HopeTurn_UpdateUI', 'HopeIntent_UpdateUI']:
            g[name] = lambda: None
        g.update({'GetLocalPlayer': lambda: self.owner,
                  'GetUnitAbilityLevel': lambda u, a: self.ranks.get((id(u), a), 0),
                  'UNIT_STATE_LIFE': 'life', 'UNIT_STATE_MAX_LIFE': 'maximum',
                  'UNIT_STATE_MANA': 'mana', 'UNIT_STATE_MAX_MANA': 'maxmana',
                  'GetUnitState': lambda u, state: getattr(u, state),
                  'HopeQoL_Slots': lambda u: 6,
                  'HopeQoL_BarValue': lambda *a: None})
        self.playing = set(range(6))
        self.human = set(range(6))
        for p in range(6):
            u = self.hero(p)
            u.kind = rawcode(['H00E', 'N01G', 'N01A'][p % 3])
            u.maximum = 140.
            u.mana = 25.
            u.maxmana = 26.
            self.ranks[id(u), rawcode('A04Q')] = 3
            self.ranks[id(u), rawcode('A03M')] = 3
            g['SaveInteger']('YDHT', id(u), AMMO, p % 4)
            g['HopeMonk_Qi'][p+1] = p % 4
            g['udg_Zhongkan_cs'][p+1] = 14
            g['udg_xingdong_dian'][p+1] = 3
            g['udg_xingdong_dianSx'][p+1] = 4
            g['udg_zhuanzhuzhi_sy'][p+1] = 5.
            g['udg_DEX'][p+1] = 3.
            g['HopeRoute_Ready'][p] = True
        g['udg_boci'] = 1
        g['HopeRoute_Node'] = self.node()
        g['HopeRoute_Depth'] = 1
        g['HopeRoute_Chapter'] = 0
        g['HopeQoL_Visible'] = True
        g['HopeQoL_UIReady'] = True


def layout():
    w = HUD()
    g = w.g
    row = g['HopeProfession_Row']
    hud = g['HopeQoL_Hud']
    route = g['HopeRoute_Panel']
    font = ImageFont.truetype(w.font_path, round(.0085*2400))
    cmap = TTFont(w.font_path).getBestCmap()
    check(not w.frames[row].visible, 'new row starts hidden')
    check(w.frames[row].font_path == 'Fonts\\ZiTi.ttf', 'new text references packaged Chinese font')
    for p in range(6):
        w.owner = p
        g['HopeQoL_Refresh']()
        expected = g['HopeProfession_Text'](g['udg_hero'][p+1], p+1)
        check(w.frames[row].text == expected and w.visible(row), 'local refresh reads own hero only')
        check(abs(w.rect(hud)[1]-w.rect(hud)[3]-.383) < 1e-9, 'HUD bottom unchanged')
        check(abs(w.rect(hud)[1]-w.rect(hud)[3]-w.rect(route)[1]-.008) < 1e-9, 'ready panel gap retained')
        txt = plain(expected)
        check(font.getlength(txt) <= .120*2400, 'resource stays on one line '+txt)
        check(all(ord(c) in cmap for c in txt), 'all new characters in original map font')
        w.audit('resource-player-'+str(p))
        w.render('resource-player-'+str(p), save=p in [0, 2])
    w.owner = 1
    g['HopeMonk_Qi'][2] = 3
    g['HopeQoL_Refresh']()
    w.render('monk-full-qi')
    g['HopeQoL_Visible'] = False
    g['HopeQoL_Refresh']()
    check(not w.visible(row) and w.visible(g['HopeQoL_Restore']), 'F5 collapse also hides child')
    g['HopeQoL_Visible'] = True
    g['HopeQoL_Refresh']()
    check(w.visible(row), 'F5 restores resource')
    u = g['udg_hero'][2]
    g['HopeMini_Actor'][2] = u
    g['HopeQoL_Refresh']()
    check(not w.visible(row) and w.frames[row].text == '', 'minigame actor clears class resource')
    check(w.rect(hud)[3] == .117, 'non-class HUD returns to original size')
    g['HopeMini_Actor'][2] = None
    u.kind = rawcode('H000')
    g['HopeQoL_Refresh']()
    check(not w.visible(row), 'ordinary class never retains previous qi')
    w.audit('ordinary-hero')
    w.render('ordinary-hero')
    u.kind = rawcode('H00E')
    g['HopeQoL_Refresh']()
    check(w.visible(row) and '子弹' in w.frames[row].text, 'class change replaces old resource')
    g['HopeChoice_HasPending'] = lambda: True
    g['HopeQoL_Refresh']()
    check(not w.visible(row), 'required choice hides HUD and child together')
    g['HopeChoice_HasPending'] = lambda: False
    g['udg_hero'][2] = None
    g['HopeQoL_Refresh']()
    check(not w.visible(row) and w.frames[row].text == '', 'no hero clears resource')
    for invalid in [-1, 0, 7, 16]:
        check(g['HopeProfession_Text'](u, invalid) == '', 'invalid player safely omitted')
    for missing in ['HopeProfession_Row', 'HopeQoL_Hud']:
        previous = g[missing]
        g[missing] = 0
        g['HopeProfession_Update'](u, 2)
        g[missing] = previous
    before = deepcopy((w.tables, w.resources, w.writes, w.integer_random_calls, w.random_calls))
    state = (u.str, u.agi, u.int, dict(g['HopeMonk_Qi']), dict(g['udg_Zhongkan_cs']))
    for _ in range(20):
        g['HopeProfession_Update'](u, 2)
    check(before == (w.tables, w.resources, w.writes, w.integer_random_calls, w.random_calls), 'local display never writes hashtables, resources, cloud, or random state')
    check(state == (u.str, u.agi, u.int, dict(g['HopeMonk_Qi']), dict(g['udg_Zhongkan_cs'])), 'display never mutates any class counters or attributes')
    check('TimerStart(CreateTimer(),.2,true,function HopeQoL_Refresh)' in body('HopeQoL_Init')[3], 'existing 0.2-second refresh owns resource updates')


if __name__ == '__main__':
    counters()
    layout()
    print(f'PASS: {COUNT} class-resource checks; {validate_layout.CASES} geometry/font checks.')
    print('Native doubles and original-font layout simulation; no Warcraft/KK runtime available.')
