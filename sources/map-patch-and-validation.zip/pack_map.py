from pathlib import Path
import sys,shutil,hashlib,json,io
sys.path.insert(0,'/workspace/map-tools');sys.path.insert(0,'/workspace/map-tools/python')
from mpq import *
import mpyq
R=Path('/workspace/map-edit');original=next(Path('/workspace/attachments').rglob('*.w3x'));out=Path('/workspace/outputs/AI-Tower-Interface-Route-v8.w3x');shutil.copy2(original,out)
files={'war3map.j':R/'war3map-patched.j','war3map.w3a':R/'modified/war3map.w3a'}
for p in (R/'modified').glob('Units_*'):files['Units\\'+p.name[6:]]=p
h=op(out)
files={name:path for name,path in files.items() if read(h,name)!=path.read_bytes()}
for name,path in files.items():
 assert L.SFileAddFileEx(h,str(path).encode(),name.encode(),0x80000200,2,2),f'Cannot add {name}'
assert L.SFileCloseArchive(h)
h=op(out,0x100)
for name,p in files.items():assert read(h,name)==p.read_bytes(),name+' round-trip mismatch'
assert read(h,'war3map.w3a')==(R/'war3map.w3a').read_bytes(),'Original binary ability edits changed'
L.SFileCloseArchive(h)
a=original.read_bytes();b=out.read_bytes();off=a.find(b'MPQ\x1a');assert b[:off]==a[:off],'Outer map header changed'
ma=mpyq.MPQArchive(io.BytesIO(a[off:]),listfile=False);mb=mpyq.MPQArchive(io.BytesIO(b[off:]),listfile=False)
changed=[];preserved=0
for index,old in enumerate(ma.block_table):
 if not old.flags&0x80000000:continue
 new=mb.block_table[index]
 oldbytes=a[off+old.offset:off+old.offset+old.archived_size];newbytes=b[off+new.offset:off+new.offset+new.archived_size]
 if oldbytes==newbytes and old.flags==new.flags and old.size==new.size:preserved+=1
 else:changed.append(index)
# Identify precisely which old block indices are expected to change.
expected=set()
for name in files:
 entry=ma.get_hash_table_entry(name)
 if entry:expected.add(entry.block_table_index)
# Internal MPQ attributes may be updated to match edited contents.
for name in ['(attributes)','(listfile)']:
 entry=ma.get_hash_table_entry(name)
 if entry:expected.add(entry.block_table_index)
assert set(changed)<=expected,(changed,expected)
manifest={'original_sha256':hashlib.sha256(a).hexdigest(),'modified_sha256':hashlib.sha256(b).hexdigest(),'modified_files':list(files),'preserved_original_resource_blocks':preserved,'changed_original_blocks':changed,'bytes':len(b)}
(R/'verification-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps(manifest,ensure_ascii=False,indent=2));print('Output:',out)
