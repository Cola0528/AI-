"""Native stock de-duplication, ten-wood settlement, odds and reward quality."""
from pathlib import Path
from types import SimpleNamespace as N
from collections import Counter
import re
from validate_wood_shop import ShopWorld
from validate_object_dependencies import parse_slk
from validate_economy import rawcode,body,SCRIPT

COUNT=0
def check(ok,msg):
 global COUNT
 assert ok,msg
 COUNT+=1

class Stock(ShopWorld):
 def __init__(self):
  super().__init__();self.entries=Counter();self.removals=[]
  self.g.update({'CreateTrigger':lambda:1,'EVENT_PLAYER_UNIT_SELL_ITEM':1,'TriggerRegisterAnyUnitEventBJ':lambda *a:None,'TriggerAddAction':lambda *a:None,
   'AddItemToStock':self.add,'RemoveItemFromStock':self.remove})
  self.load('HopeWood_Init','HopeDraw_Ten');self.g['HopeWood_Init']()
 def add(self,shop,item,*args):self.entries[item]+=1;self.stock.append((shop,item,*args))
 def remove(self,shop,item):self.entries.pop(item,None);self.removals.append(item)
 def purchase(self,item,owner=0):
  cost=10 if item=='IZWT' else 1
  if self.resources[owner,'lumber']<cost:return False
  self.buyer=self.g['udg_hero'][owner+1]
  self.debit(owner,'lumber',self.resources[owner,'lumber']-cost)
  self.sold=N(kind=rawcode(item));self.g['HopeWood_Sold']();return True

def run():
 root=Path(__file__).parent
 data=parse_slk((root/'modified/Units_ItemData.slk').read_bytes(),'items').rows
 for item,cost in [('IZWD',1),('IZWT',10)]:
  row=data[item]
  check(row['goldcost'].value==0 and row['lumbercost'].value==cost,item+' native correct price')
  check(row['abilList'].value=='_' and row['powerup'].value==1 and row['perishable'].value==1,item+' no extra native item reward, no bag slot')
 profiles=(root/'modified/Units_itemstrings.txt').read_text()
 positions=[]
 for item in ['IZWD','IZWT']:
  section=re.search(r'^\['+item+r'\]\n(.*?)(?=^\[|\Z)',profiles,re.M|re.S)[1]
  positions.append(re.search(r'^Buttonpos=(.*)$',section,re.M)[1])
 check(positions==['3,0','0,1'],'single then ten distinct native button positions')
 check('IZWD' not in (root/'modified/Units_campaignunitstrings.txt').read_text(),'no static plus dynamic stock duplication')
 for repeat in [1,2,12]:
  w=Stock();w.resources[0,'lumber']=repeat*11;w.g['GetRandomInt']=lambda a,b:1
  for _ in range(repeat):
   check(w.purchase('IZWD') and w.purchase('IZWT'),'both stock entries remain purchasable')
   check(w.entries=={rawcode('IZWD'):1,rawcode('IZWT'):1},'restocking never adds duplicate native buttons')
  check(w.resources[0,'lumber']==0 and len(w.debits)==repeat*2,'native cost only, no second script debit')
 w=Stock();g=w.g;w.resources[0,'lumber']=9
 check(not w.purchase('IZWT') and not g['HopeDraw_Count'][0],'9wood cannot start ten draw')
 w.resources[0,'lumber']=10;rolls=iter([1,50,51,100,1,50,51,100,1,100]);draws=[]
 g['GetRandomInt']=lambda lo,hi:next(rolls)
 g['HopeDraw_Reward']=lambda p:draws.append(p) or g['HopeDraw_Quality']('全属性 +3')
 check(w.purchase('IZWT') and w.resources[0,'lumber']==0,'exactly10 wood succeeds')
 text=w.tables['HopeDraw_History'][0,3]
 check(len(draws)==5 and text.count('谢谢惠顾')==6,'10 independent rolls, five blanks plus explanatory text')
 check(len(re.findall(r'(?:^|\|n)\d+\. ',text))==10,'all10 outcomes stored as one batch')
 check(g['HopeDraw_Count'][0]==1 and g['HopeDraw_Open'] and not g['HopeDraw_Team'],'ten opens own full result panel')
 check(len(w.debits)==1 and not w.writes,'one native debit, no cloud points')
 before=(g['HopeDraw_Count'][0],len(draws),len(w.debits));g['HopeWood_Sold']()
 check(before==(g['HopeDraw_Count'][0],len(draws),len(w.debits)),'consumed item callback cannot duplicate batch')
 for cause in ['battle','dead','left','computer','wrong_shop','busy','missing_hero']:
  w=Stock();g=w.g;w.resources[0,'lumber']=10;calls=[]
  g['GetRandomInt']=lambda *a:calls.append(a) or 1
  if cause=='battle':g['udg_ZhandouZhong']=True
  if cause=='dead':g['udg_hero'][1].life=0
  if cause=='left':w.playing={1}
  if cause=='computer':w.human={1}
  if cause=='wrong_shop':w.shop=N(kind=rawcode('n00P'),owner=15)
  if cause=='busy':g['HopeDraw_Busy'][0]=True
  if cause=='missing_hero':
   w.debit(0,'lumber',0);w.sold=N(kind=rawcode('IZWT'));g['udg_hero'][1]=None;g['HopeWood_Sold']()
  else:w.purchase('IZWT')
  check(w.resources[0,'lumber']==10 and not calls and not g['HopeDraw_Count'][0],'reject whole batch and refund10: '+cause)
 w=Stock();w.resources[0,'lumber']=10;w.resources[1,'lumber']=10;w.g['GetRandomInt']=lambda *a:1
 w.purchase('IZWT',1)
 check(w.resources[0,'lumber']==10 and w.resources[1,'lumber']==0 and w.g['HopeDraw_Count'][1]==1,'ten debit/results belong to buyer')
 check(not w.g['HopeDraw_Open'],'teammate ten never opens another player panel')
 # Existing event ten-draw remains a separate648-gold path without blank rolls.
 w=Stock();g=w.g;w.resources[0,'gold']=648;w.resources[0,'lumber']=17;calls=[]
 g['HopeDraw_Reward']=lambda p:calls.append(p) or '全属性 +3'
 g['GetRandomInt']=lambda *a:(_ for _ in ()).throw(AssertionError('event ten must not roll wood blanks'))
 check(g['HopeDraw_Ten'](0) and len(calls)==10 and w.resources[0,'gold']==0 and w.resources[0,'lumber']==17,'original event ten:648 gold,10 pool rewards, no wood charge or blank roll')
 expected={'谢谢惠顾（未获得奖励）':'9aa0a6','力量 +1':'959697','敏捷 +1':'959697','智力 +1':'959697','全属性 +3':'e4e5e4','技能伤害 +10% / 法术伤害 +10%':'719fff','暴击率 +5% / 暴击伤害 +10%':'bf80ef','最终伤害 +10%':'fe8a0e','圣剑（英雄满包转入助手；都满才落地）':'fffc01'}
 for result,color in expected.items():check(g['HopeDraw_Quality'](result)=='|cff'+color+result+'|r','restore rarity color: '+result)
 check('return HopeDraw_Quality(result)' in body('HopeDraw_Reward')[3],'both lottery paths color the actual shared rewards')
 print(f'PASS: {COUNT} wood-ten assertions; unique dynamic stock, native1/10wood fees,10 independent blank rolls, full results, refunds, ownership,648gold separation and all rarity colors. Native calls mocked, not KK.')

if __name__=='__main__':run()
