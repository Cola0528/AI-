"""Local My/Teammates tabs over synchronized per-player draw records."""
from modern_choices_patch import block,replace

G='''integer HopeDraw_Serial=0
boolean HopeDraw_Team=false
integer HopeDraw_MyTab=0
integer HopeDraw_TeamTab=0
integer array HopeTeam_Cursor
'''
HELPERS='''function HopeDraw_Mine takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() then
set HopeDraw_Team=false
set HopeLog_Cached=-1
set HopeLog_Offset=0
endif
endfunction
function HopeDraw_Teammates takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() then
set HopeDraw_Team=true
set HopeLog_Cached=-1
set HopeLog_Offset=0
endif
endfunction
function HopeDraw_BuildTeam takes integer owner returns nothing
local integer p=0
local integer n=0
local integer best=0
local integer serial=0
local integer winner=-1
local integer slot=0
local string name=""
loop
exitwhen p>=6
set HopeTeam_Cursor[p]=HopeDraw_Count[p]
set p=p+1
endloop
loop
exitwhen n>=64
set p=0
set best=0
set winner=-1
loop
exitwhen p>=6
if p!=owner and HopeTeam_Cursor[p]>=IMaxBJ(1,HopeDraw_Count[p]-63) then
set slot=ModuloInteger(HopeTeam_Cursor[p],64)*2
set serial=LoadInteger(HopeDraw_History,p,1000+slot)
if serial>best then
set best=serial
set winner=p
endif
endif
set p=p+1
endloop
exitwhen winner<0
set slot=ModuloInteger(HopeTeam_Cursor[winner],64)*2
set name=LoadStr(HopeDraw_History,winner,2000+slot)
if name=="" then
set name=HopeName_Label(Player(winner),100)
else
set name=HopeName_Clip(name,100)
endif
call HopeScroll_Add(1,HopeUI_PlayerText(Player(winner),name+" · #"+I2S(best)))
call HopeScroll_Add(1,"|cffd2b879"+LoadStr(HopeDraw_History,winner,slot)+"|r")
call HopeScroll_Add(1,LoadStr(HopeDraw_History,winner,slot+1))
set HopeTeam_Cursor[winner]=HopeTeam_Cursor[winner]-1
set n=n+1
endloop
endfunction
'''

def apply(src):
    src=src.replace('globals\n','globals\n'+G,1)
    f=block(src,'HopeDraw_SaveRecord')
    f=f.replace('call SaveStr(HopeDraw_History,i,page+1,text)', '''call SaveStr(HopeDraw_History,i,page+1,text)
set HopeDraw_Serial=HopeDraw_Serial+1
call SaveInteger(HopeDraw_History,i,1000+page,HopeDraw_Serial)
call SaveStr(HopeDraw_History,i,2000+page,HopeName_Clean(GetPlayerName(p)))''')
    f=f.replace('if reveal then','if reveal then\nset HopeDraw_Team=false\nset HopeLog_Cached=-1',1)
    src=replace(src,'HopeDraw_SaveRecord',f)
    f=block(src,'HopeDraw_Refresh')
    f=f.replace('"–"','"-"')
    f=f.replace('local integer slot=0','local integer slot=0\nlocal integer version=HopeDraw_Count[owner]',1)
    f=f.replace('if HopeLog_Cached!=HopeDraw_Count[owner] then','''if HopeDraw_Team then
set version=HopeDraw_Serial-HopeDraw_Count[owner]
endif
if HopeLog_Cached!=version then''')
    f=f.replace('set HopeLog_Cached=HopeDraw_Count[owner]','''set HopeLog_Cached=version
if HopeDraw_Team then
call HopeDraw_BuildTeam(owner)
else''',1)
    f=f.replace('set record=record-1\nendloop\nendif','set record=record-1\nendloop\nendif\nendif',1)
    f=f.replace('call HopeJob_SetText(HopeDraw_Title,"抽取记录 · 最新在上")','''call HopeJob_SetText(HopeDraw_Title,"抽取记录")
if HopeDraw_Team then
call HopeJob_SetText(HopeDraw_MyTab,"我的")
call HopeJob_SetText(HopeDraw_TeamTab,"|cffffd060队友|r")
else
call HopeJob_SetText(HopeDraw_MyTab,"|cffffd060我的|r")
call HopeJob_SetText(HopeDraw_TeamTab,"队友")
endif''')
    f=f.replace('call HopeJob_SetText(HopeDraw_Text,"暂无记录。|n十连与木材抽奖的结果将连续列在这里。")','''if HopeDraw_Team then
call HopeJob_SetText(HopeDraw_Text,"暂无队友抽奖记录。|n队友的木材抽奖和十连结果将按时间列出。")
else
call HopeJob_SetText(HopeDraw_Text,"暂无记录。|n十连与木材抽奖的结果将连续列在这里。")
endif''')
    src=replace(src,'HopeDraw_Refresh',HELPERS+'\n'+f)
    f=block(src,'HopeDraw_Create').replace('.010,-.009,.198,.018','.010,-.009,.090,.018')
    marker='call HopeQoL_Bind(f,function HopeDraw_Close,false)'
    assert marker in f
    f=f.replace(marker,marker+'''
set HopeDraw_MyTab=HopeQoL_Button("HopeDrawMineTab",HopeDraw_Panel,.110,-.006,.044,.022,"我的")
call HopeQoL_Bind(HopeDraw_MyTab,function HopeDraw_Mine,false)
set HopeDraw_TeamTab=HopeQoL_Button("HopeDrawTeamTab",HopeDraw_Panel,.162,-.006,.044,.022,"队友")
call HopeQoL_Bind(HopeDraw_TeamTab,function HopeDraw_Teammates,false)''')
    src=replace(src,'HopeDraw_Create',f)
    return src
