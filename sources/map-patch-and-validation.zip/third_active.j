function HopeThird_Cast takes unit u,integer aid,unit target returns nothing
local player owner=GetOwningPlayer(u)
local integer p=GetPlayerId(owner)+1
local integer token=HopeChallenge_TurnToken()
local integer ap=2
local integer j=1
local integer bullets=0
local real amount=0.
local real cx=GetUnitX(u)
local real cy=GetUnitY(u)
local real tx=0.
local real ty=0.
local real dx=0.
local real dy=0.
local real length=0.
local real along=0.
local real across=0.
local real missing=0.
local group g=null
local unit enemy=null
if p<1 or p>6 or u!=udg_hero[p] or not HopeJob_Awakened[p] or HopeThird_Ability[HopeJob_AwakenOption[p]]!=aid or GetUnitAbilityLevel(u,aid)<=0 or GetWidgetLife(u)<=.405 or IsUnitPaused(u) then
set owner=null
return
endif
if aid=='AT16' then
set ap=1
endif
if not udg_ZhandouZhong or udg_xingdong_dian[p]<ap or GetUnitState(u,UNIT_STATE_MANA)<3. or HopeJob_LastCast[p]==token then
call DisplayTimedTextToPlayer(owner,0,0,3.,"觉醒技能：战斗中每回合一次；行动点或魔法不足，或已经使用。")
set owner=null
return
endif
if aid!='AT03' and not HopeThird_Enemy(target,owner) then
call DisplayTimedTextToPlayer(owner,0,0,3.,"请选择存活的当前敌人。")
set owner=null
return
endif
if aid=='AT10' then
set bullets=LoadInteger(YDHT,GetHandleId(u),$30720CCD)
if bullets<=0 then
call DisplayTimedTextToPlayer(owner,0,0,3.,"子弹不足：请先用Q装填，再使用绝命狙击。")
set owner=null
return
endif
elseif aid=='AT13' and HopeStatus_PoisonSourceBase(target,p-1)<=0. then
call DisplayTimedTextToPlayer(owner,0,0,3.,"目标没有自己的有效毒层，请先用毒矛叠毒。")
set owner=null
return
elseif aid=='AT08' then
set dx=GetUnitX(target)-cx
set dy=GetUnitY(target)-cy
set length=SquareRoot(dx*dx+dy*dy)
if length<1. or length>2000. then
call DisplayTimedTextToPlayer(owner,0,0,3.,"贯城重弩：请选择2000距离内、与自己位置不同的敌人。")
set owner=null
return
endif
set dx=dx/length
set dy=dy/length
endif
set udg_xingdong_dian[p]=udg_xingdong_dian[p]-ap
call SetUnitState(u,UNIT_STATE_MANA,GetUnitState(u,UNIT_STATE_MANA)-3.)
set HopeJob_LastCast[p]=token
if aid=='AT03' then
loop
exitwhen j>6
set enemy=udg_hero[j]
if enemy!=null and GetWidgetLife(enemy)>.405 and IsUnitAlly(enemy,owner) then
set amount=GetUnitState(enemy,UNIT_STATE_MAX_LIFE)*.2+I2R(GetHeroInt(u,true))
set missing=RMaxBJ(0.,GetUnitState(enemy,UNIT_STATE_MAX_LIFE)-GetWidgetLife(enemy))
call HopeThird_Heal(enemy,amount,false)
call SetUnitState(enemy,ConvertUnitState(32),GetUnitState(enemy,ConvertUnitState(32))+RMinBJ(I2R(GetHeroInt(u,true))*.5,RMaxBJ(0.,amount-missing)*.5))
call SetUnitState(enemy,UNIT_STATE_MANA,RMinBJ(GetUnitState(enemy,UNIT_STATE_MAX_MANA),GetUnitState(enemy,UNIT_STATE_MANA)+2.))
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Human\\HolyBolt\\HolyBoltSpecialArt.mdl",enemy,"origin"))
endif
set j=j+1
endloop
elseif aid=='AT06' then
set amount=I2R(GetHeroStr(u,true)+GetHeroAgi(u,true))*4.*udg_Skill_Dm[p]
if GetWidgetLife(target)<=GetUnitState(target,UNIT_STATE_MAX_LIFE)*.4 then
set amount=amount*1.5
endif
call UnitDamageTarget(u,target,amount,true,false,ATTACK_TYPE_NORMAL,DAMAGE_TYPE_NORMAL,WEAPON_TYPE_WHOKNOWS)
if GetWidgetLife(target)<=.405 then
call HopeThird_Refund(p)
endif
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Orc\\CriticalStrike\\CriticalStrike.mdl",target,"origin"))
elseif aid=='AT10' then
call SaveInteger(YDHT,GetHandleId(u),$30720CCD,bullets-1)
if LoadTextTagHandle(YDHT,GetHandleId(u),$2CCE269)!=null then
call SetTextTagTextBJ(LoadTextTagHandle(YDHT,GetHandleId(u),$2CCE269),I2S(bullets-1)+"/"+I2S(GetUnitAbilityLevel(u,'A04Q')+1),12.)
endif
set amount=(GetUnitState(u,ConvertUnitState(20))*6.+I2R(GetHeroAgi(u,true))*3.)*udg_Skill_Dm[p]
if LoadBoolean(YDHT,GetHandleId(u),$08E215BC) then
set amount=amount*udg_jingque_Daji_jiacheng[p]
call SaveBoolean(YDHT,GetHandleId(u),$08E215BC,false)
endif
// Chaos attack matches Q so the original headshot flag is consumed by this hit.
call UnitDamageTarget(u,target,amount,true,false,ATTACK_TYPE_CHAOS,DAMAGE_TYPE_NORMAL,WEAPON_TYPE_WHOKNOWS)
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Weapons\\Rifle\\RifleImpact.mdl",target,"origin"))
elseif aid=='AT13' then
set amount=HopeStatus_PoisonSourceBase(target,p-1)*2.*udg_Skill_Dm[p]
call UnitDamageTarget(u,target,amount,true,false,ATTACK_TYPE_NORMAL,DAMAGE_TYPE_NORMAL,WEAPON_TYPE_WHOKNOWS)
call HopeThird_Heal(u,GetUnitState(u,UNIT_STATE_MAX_LIFE)*.1,false)
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Undead\\DeathCoil\\DeathCoilSpecialArt.mdl",target,"origin"))
elseif aid=='AT16' then
call SaveInteger(HopeThird_Data,GetHandleId(target),102,3)
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Other\\HowlOfTerror\\HowlTarget.mdl",target,"origin"))
elseif aid=='AT08' or aid=='AT11' then
set tx=GetUnitX(target)
set ty=GetUnitY(target)
set g=CreateGroup()
call GroupAddGroup(udg_Guaiwu_dwz,g)
loop
set enemy=FirstOfGroup(g)
exitwhen enemy==null
call GroupRemoveUnit(g,enemy)
if HopeThird_Enemy(enemy,owner) then
if aid=='AT08' then
set along=(GetUnitX(enemy)-cx)*dx+(GetUnitY(enemy)-cy)*dy
set across=RAbsBJ((GetUnitX(enemy)-cx)*dy-(GetUnitY(enemy)-cy)*dx)
if along>=0. and along<=2000. and across<=120. then
set amount=(GetUnitState(u,ConvertUnitState(20))*4.+I2R(GetHeroStr(u,true))*2.)*udg_Skill_Dm[p]
if enemy!=target then
set amount=amount*.7
endif
call UnitDamageTarget(u,enemy,amount,true,false,ATTACK_TYPE_NORMAL,DAMAGE_TYPE_NORMAL,WEAPON_TYPE_WHOKNOWS)
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Weapons\\Arrow\\ArrowMissile.mdl",enemy,"origin"))
endif
else
set along=GetUnitX(enemy)-tx
set across=GetUnitY(enemy)-ty
if along*along+across*across<=202500. then
call SaveInteger(HopeThird_Data,GetHandleId(enemy),101,1)
call UnitDamageTarget(u,enemy,I2R(GetHeroInt(u,true))*3.*udg_Skill_Dm[p]*udg_Fashang_Dm[p],false,false,ATTACK_TYPE_MAGIC,DAMAGE_TYPE_MAGIC,WEAPON_TYPE_WHOKNOWS)
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Undead\\FrostNova\\FrostNovaTarget.mdl",enemy,"origin"))
endif
endif
endif
endloop
call DestroyGroup(g)
endif
set enemy=null
set g=null
set owner=null
endfunction
