"""Compare every original event message, plus independently colored result rows."""
from pathlib import Path
import re
from validate_economy import World,body,translate,SCRIPT
from event_text_patch import format_message

COUNT=0
def check(ok,msg):
 global COUNT
 assert ok,msg
 COUNT+=1
def plain(s):return re.sub(r'\|c[0-9a-fA-F]{8}|\|r','',s)

def run():
 w=World();g=w.g;raw=['清风徐来','流浪的剑客','星河入梦','剑心','Cola★','小猫钓鱼'];enum=[2]
 g.update({'GetPlayerName':lambda p:raw[p],'GetPlayerColor':lambda p:5-p,'ModuloInteger':lambda a,b:a%b,
  'GetTriggeringTrigger':lambda:777,'GetEnumPlayer':lambda:enum[0],
  'LoadPlayerHandle':lambda t,p,k:1 if k==0x192409FE else 0,
  'LoadInteger':lambda *args:9,'GetPlayersAll':lambda:0})
 for i,c in re.findall(r'set YDWEBase__yd_PlayerColor\[(\d+)\]="([^"]+)"',SCRIPT):g['YDWEBase__yd_PlayerColor'][int(i)]=c
 w.load('YDWEGetPlayerColorString','HopeEvent_Add','HopeEvent_Write','HopeEvent_Result')
 def color(p):return {0:'|cffff6b6b',1:'|cff719fff',3:'|cffbf80ef'}.get(5-p,g['YDWEBase__yd_PlayerColor'][5-p])
 def luminance(rgb):
  values=[int(rgb[i:i+2],16)/255 for i in [0,2,4]]
  values=[c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in values]
  return sum(c*k for c,k in zip(values,[.2126,.7152,.0722]))
 for index in range(16):
  g['GetPlayerColor']=lambda p,index=index:index
  rendered=g['HopeUI_PlayerText'](0,'结果')
  ratio=(luminance(rendered[4:10])+.05)/(luminance('222528')+.05)
  check(ratio>=4.5,('readable event color contrast on dark panel',index,ratio))
 g['GetPlayerColor']=lambda p:5-p
 original=(Path(__file__).parent/'war3map.j').read_text();messages=[]
 for name in re.findall(r'^function (Trig____________________018\w*) takes',original,re.M):
  messages.extend(l for l in body(name,original)[3].splitlines() if l.startswith('call DisplayTextToForce(GetPlayersAll(),'))
 written=[];old=[];g['DisplayTextToForce']=lambda f,s:old.append(s)
 g['HopeEvent_Write']=lambda p,s,c:written.append((p,s,c))
 for line in messages:
  written.clear();old.clear()
  for fn,code in [('OriginalMessage',line),('CurrentMessage',format_message(line))]:
   source=f'function {fn} takes nothing returns nothing\nlocal integer ydl_localvar_step=1\n{code}\nendfunction'
   exec(translate(fn,source),g);g[fn]()
  check(plain(old[0])==''.join(s for _,s,_ in written),('full original message retained exactly, including spaces and punctuation',line,written))
  p=written[0][0];check(written[0][1]==raw[p] and written[0][2],'full original nickname is colored')
  check(all(owner==p for owner,_,_ in written),'outcome attributed to correct original player')
  if '"全属性+5"+""' in line:check((0,'全属性+5',True) in written,'contract gain colored for actor')
  if '"HP上限-30"+""' in line:check((1,'HP上限-30',True) in written,'contract loss colored for sacrificed teammate')
  if '技能伤害增加' in line:check(any(owner==2 and color and '技能伤害增加9%' in s for owner,s,color in written),'dynamic study amount colored for actual learner')
  if '（攻击力-5）' in line:check((2,'（攻击力-5）',True) in written,'embedded broken weapon result highlighted without losing surrounding flavor')
 check(len(messages)==33,('all original event messages enumerated',len(messages)))
 w.load('HopeEvent_Write')
 for p in range(6):
  text=raw[p]+'：'+'没有删掉的完整故事与实际结算，全属性+5，生命上限-30；'*4
  before=g['HopeEvent_Count'];g['HopeEvent_Write'](p,text,True)
  lines=[g['HopeEvent_Line'][j%512] for j in range(before,g['HopeEvent_Count'])]
  check(''.join(plain(s) for s in lines)==text,'wrapped rows retain complete text')
  for s in lines:
   check(s.startswith(color(p)) and s.endswith('|r'),'each row self-contained color even when scrolled into view')
   check(g['HopeName_Width'](plain(s))<=260,'colored row fits bounded width')
 before=g['HopeEvent_Count'];g['HopeEvent_Write'](0,'虽然用力砸了但是巨石纹丝不动似乎在嘲笑你没吃饭吗 什么也没发生',False)
 lines=[g['HopeEvent_Line'][j%512] for j in range(before,g['HopeEvent_Count'])]
 check(all('|c' not in s for s in lines),'narrative remains neutral text')
 # Execute actual group settlement callbacks with engine-like zero-clamped gold.
 g['GetPlayerState']=lambda p,k:w.resources[p,k]
 g['AdjustPlayerStateBJ']=lambda n,p,k:w.resources.__setitem__((p,k),max(0,w.resources[p,k]+n))
 g['SetPlayerStateBJ']=lambda p,k,n:w.resources.__setitem__((p,k),n)
 poverty='Trig____________________018Func004Func021Func002A'
 for fn in ['Trig____________________018Func004Func015Func002A','Trig____________________018Func004Func016Func004A',poverty,'Trig____________________018Func004Func024Func002Func005Func003A']:w.load(fn)
 for p in range(6):
  enum[0]=p;w.resources[p,'gold']=30 if p%2==0 else 500;before=g['HopeEvent_Count'];g[poverty]()
  result=''.join(plain(g['HopeEvent_Line'][j%512]) for j in range(before,g['HopeEvent_Count']))
  check(result==raw[p]+'：金钱 -'+('30' if p%2==0 else '150'),'poverty reports actual clamped loss in corresponding player color')
  g['Trig____________________018Func004Func015Func002A']();check(w.resources[p,'lumber']==5,'fortune gameplay preserved')
  g['Trig____________________018Func004Func016Func004A']();check(w.resources[p,'gold']==9,'equal-share gameplay preserved')
  before=g['HopeEvent_Count'];g['Trig____________________018Func004Func024Func002Func005Func003A']()
  check(w.resources[p,'gold']==309,'boulder gold gameplay preserved')
  for j in range(before,g['HopeEvent_Count']):check(g['HopeEvent_Line'][j%512].startswith(color(p)),'boulder group recipient uses own color')
 check('你们随机到了特殊小怪关卡，小怪会有数次复活机会' in SCRIPT,'original special-enemy sentence restored')
 print(f'PASS: {COUNT} assertions; all {len(messages)} original messages preserved word-for-word; 6 player colors, dynamic outcomes, wrapped/scrollable colors, actual gold loss and group settlements. Native calls mocked, not KK.')

if __name__=='__main__':run()
