"""Restore the original rarity colors independently from participant colors."""
from modern_choices_patch import block,replace

HELPER='''function HopeDraw_Quality takes string result returns string
local string color=""
if result=="谢谢惠顾（未获得奖励）" then
set color="|cff9aa0a6"
elseif result=="力量 +1" or result=="敏捷 +1" or result=="智力 +1" then
set color="|cff959697"
elseif result=="全属性 +3" then
set color="|cffe4e5e4"
elseif result=="技能伤害 +10% / 法术伤害 +10%" then
set color="|cff719fff"
elseif result=="暴击率 +5% / 暴击伤害 +10%" then
set color="|cffbf80ef"
elseif result=="最终伤害 +10%" then
set color="|cfffe8a0e"
elseif result=="圣剑（英雄满包转入助手；都满才落地）" then
set color="|cfffffc01"
endif
if color=="" then
return result
endif
return color+result+"|r"
endfunction
'''

def apply(src):
    f=block(src,'HopeDraw_Reward')
    assert 'return result' in f
    src=replace(src,'HopeDraw_Reward',HELPER+'\n'+f.replace('return result','return HopeDraw_Quality(result)',1))
    f=block(src,'HopeWood_Sold')
    f=f.replace('local string result="谢谢惠顾（未获得奖励）"','local string result=HopeDraw_Quality("谢谢惠顾（未获得奖励）")')
    return replace(src,'HopeWood_Sold',f)
