"""Full SLK records for v15 skills; retain optimized native object dependencies."""
import re
from hidden_objects import read_slk, raw_value, clone_section, update_section
from third_design import DESIGNS, description


def rank_description(d, rank):
    text = re.sub(r'(\d+(?:\.\d+)?%?)/(\d+(?:\.\d+)?%?)/(\d+(?:\.\d+)?%?)', lambda m:m[rank], description(d))
    if d['id']=='AT05':
        text=text.replace('3级同时恢复2点魔法，不超过上限，为连斩追加段续航。',
                          '同时恢复2点魔法，不超过上限，为连斩追加段续航。' if rank==3 else '升至3级时，返还行动点还会恢复2点魔法。')
    return text


def apply_objects(root, output):
    path=output/'Units_AbilityData.slk'
    lines,rows,heads,objects=read_slk(path)
    original={y:r.copy() for y,r in rows.items()}
    profiles=(output/'Units_campaignabilitystrings.txt').read_text()
    added=[]
    for typ,d in DESIGNS.items():
        alias=d['id']
        if alias=='AZ36':
            profiles=update_section(profiles,alias,{'Ubertip':description(d)})
            continue
        assert alias not in objects
        passive=d['mode']=='passive'
        base='AZHP' if passive else 'AZ35'
        row=objects[base][1].copy()
        values={'alias':alias,'code':'Aamk' if passive else 'ANcl','hero':0,'item':0,'levels':3 if passive else 1,'reqLevel':1,'levelSkip':0}
        for k in range(1,4 if passive else 2):
            values.update({f'Cost{k}':0, f'Cool{k}':0. if passive else .1, f'Area{k}':0., f'Cast{k}':0., f'Dur{k}':0.,f'HeroDur{k}':0.,f'Rng{k}':2000. if alias=='AT08' else 99999., f'targs{k}':'_' if passive or alias=='AT03' else 'enemies,neutral'})
            for key in ['DataA','DataB','DataC','DataD','DataE']:
                values[key+str(k)]=0
        if not passive:
            values.update(DataB1=0 if alias=='AT03' else 1,DataC1=1,DataF1='spellsteal')
        for key,val in values.items():
            assert key in heads,key
            row[heads[key]]=raw_value(val)
        added.append(row)
        profiles=clone_section(profiles,base,alias)
        fields={'Name':d['skill'],'EditorSuffix':'（三转专属）','Art':'ReplaceableTextures\\CommandButtons\\'+d['art']+'.blp','Buttonpos':'2,1','Hotkey':'_' if passive else 'Z','Order':'attributemodskill' if passive else 'spellsteal'}
        if passive:
            fields.update(Researchtip='研习'+d['skill'],Researchubertip=description(d),Researchhotkey='_')
            fields['Tip']=','.join(d['skill']+'（等级'+str(rank)+'/3）' for rank in range(1,4))
            fields['Ubertip']=','.join(rank_description(d,rank) for rank in range(1,4))
        else:
            fields['Tip']=d['skill']+'（Z）'
            fields['Ubertip']=description(d)
        profiles=update_section(profiles,alias,fields)
    last=max(rows)
    lines=[re.sub(r';Y\d+',f';Y{last+len(added)}',l) if l.startswith('B;') else l for l in lines if l!='E']
    for n,row in enumerate(added,1):
        lines.extend(f'C;X{x};Y{last+n};K{v}' for x,v in sorted(row.items()))
    path.write_text('\r\n'.join(lines+['E'])+'\r\n')
    (output/'Units_campaignabilitystrings.txt').write_text(profiles)
    _,written,_,_=read_slk(path)
    assert all(written[y]==row for y,row in original.items())
    print('v15: 16 full SLK skill records; existing ability rows unchanged; 9 rank-three passives / 8 actives including monk.')
