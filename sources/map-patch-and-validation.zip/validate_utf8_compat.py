"""Check final JASS byte stepping against frozen classic hash reference vectors.

Native calls are doubles. Newer-engine partial-UTF8 normalization is modeled,
not evidence of a test in an actual KK or Reforged client.
"""
from pathlib import Path
import json
from validate_economy import World, body, SCRIPT
from warcraft_hash import string_hash

root=Path(__file__).parent
ref=json.loads((root/'fixtures/utf8-hash-reference.json').read_text())
count=0
def check(ok,msg):
    global count
    assert ok,msg
    count+=1

check(len(ref['values'])==255,'complete non-NUL single-byte reference')
for b,h in enumerate(ref['values'],ref['first_byte']):
    check(string_hash(bytes([b]))==h,('independent compiled C++ hash reference',b))
check(body('HopeName_Step')[3].isascii(),'UTF8 detector source contains only ASCII')
check(all(ord(c)<=0xffff for c in SCRIPT),'no non-BMP source characters anywhere in map script')

def classic_ref(s):
    b=s.encode('utf-8',errors='surrogateescape')
    if len(b)==1 and b[0]>0:return ref['values'][b[0]-1]
    return string_hash(b)

def normalized(s):
    b=s.encode('utf-8',errors='surrogateescape')
    try:b.decode('utf-8')
    except UnicodeDecodeError:return 1843378377
    return classic_ref(s)

# Include every valid UTF8 leading byte and first/last valid continuations.
samples=['AéΩЯ中文★𠮷😀', '清风徐来', 'a/Z|r', '中文'*40]
points={1,32,127,128,0x7ff,0x800,0xd7ff,0xe000,0xffff,0x10000,0x10ffff}
for x in range(0x80,0x110000,997):
    if not 0xd800<=x<=0xdfff:points.add(x)
for lo,hi,shift in [(0xc2,0xe0,6),(0xe0,0xf0,12),(0xf0,0xf5,18)]:
    for lead in range(lo,hi):
        base=(lead & (0x7f>>((shift//6)+1)))<<shift
        for x in [base,base+((1<<shift)-1)]:
            if 0<x<=0x10ffff and not 0xd800<=x<=0xdfff:points.add(x)
samples += [chr(x) for x in sorted(points)]
for mode,hashfn in [('classic-reference',classic_ref),('normalized-model',normalized)]:
    w=World();g=w.g;g['StringHash']=hashfn
    for s in samples:
        at=0
        for char in s:
            step=g['HopeName_Step'](s,at)
            check(step==len(char.encode()),(mode,'whole code point',hex(ord(char)),step))
            check(g['SubString'](s,at,at+step)==char,(mode,'round trip'))
            at+=step
        for budget in [6,22,70]:
            clipped=g['HopeName_Clip'](s,budget)
            clipped.encode('utf-8')
            check(clipped==s or (clipped.endswith('…') and s.startswith(clipped[:-1])),(mode,'valid clipped prefix'))
    for b in [b'\xc2',b'\xe4',b'\xe4\xb8',b'\xf0',b'\xf0\x90',b'\xf0\x90\x80']:
        s=b.decode('utf-8',errors='surrogateescape')
        check(1<=g['HopeName_Step'](s,0)<=len(b),(mode,'truncated input bounds'))
print(f'PASS: {count} UTF8/hash compatibility checks; final JASS executed with native doubles, no KK runtime.')
