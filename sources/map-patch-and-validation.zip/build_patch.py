from pathlib import Path
import json,re,struct
R=Path('/workspace/map-edit');D=json.loads((R/'classes.json').read_text());src=(R/'war3map.j').read_text()
def q(s):return '"'+s.replace('\\','\\\\').replace('"','\\"').replace('\n','|n')+'"'
def raw(s):return "'"+s+"'"
classes=D['classes'];normal=[(k,v) for k,v in classes.items() if k!='I019']
# Names, role, stage-three stats and genuinely applied passives.
roles={
'H001':'力量近战 · 盾防嘲讽 · 团队承伤','H003':'敏捷远程 · 高浮动火力 · 多目标输出','N007':'智力远程 · 火球与暴风雪 · 法术输出','E008':'敏捷远程 · 稳定射击 · 精准成长','N00D':'敏捷近战 · 连击追伤 · 行动点成长','N00E':'智力辅助 · 群体护甲 · 治疗与审判','O001':'力量近战 · 重砍爆发 · 狂暴换伤','O003':'力量远程 · 投矛叠毒 · 持续输出',
'H008':'力量坦克 · 嘲讽护甲 · 剑盾输出','H00D':'力量机动 · 冲锋速度 · 单次爆发','N017':'智力辅助 · 治疗回蓝 · 圣光输出','N01G':'力智近战 · 全属性修炼 · 金刚防御','N018':'敏捷连击 · 潜袭多段 · 暴击爆发','N01F':'力敏投矛 · 精确打击 · 蓄力破甲','E00S':'敏捷远程 · 多目标射击 · 稳定输出','E010':'力敏远程 · 穿透弩箭 · 高单次伤害','H004':'敏捷远程 · 三段连射 · 群体乱射','H00E':'敏捷狙击 · 必暴爆头 · 弹匣管理','N016':'智力法系 · 暴风雪 · 法伤成长','N01E':'智力法系 · 炎爆范围伤害 · 火球暴击','O004':'力量毒矛 · 低血防御 · 战后成长','O006':'力敏连击 · 五连斩 · 持续成长','N01A':'力量爆发 · 重砍修炼 · 狂暴换伤','O005':'力敏近战 · 狼骑重砍 · 掠夺经济'}
awakening={
'H008':('钢铁统帅',1,{'str':8,'hp':80,'def':6,'final':.1},'铁壁统御：防御动作额外护甲 +6，最终伤害 +10%。'),
'H00D':('圣锋骑士',1,{'str':8,'agi':6,'final':.15},'锋骑战意：最终伤害 +15%。'),
'N017':('圣光主教',4,{'int':10,'mp':6,'regen':2},'圣光源泉：魔法上限 +6，每回合回蓝 +2。'),
'N01G':('金刚禅师',4,{'str':8,'int':8,'def':6,'hp':60},'金刚禅心：防御动作额外护甲 +6，生命上限 +60。'),
'N018':('影刃宗师',2,{'agi':10,'crit':10,'critd':.25},'影刃杀意：暴击率 +10%，暴击伤害 +25%。'),
'N01F':('幻影刺皇',2,{'agi':10,'dex':2,'prec':.2},'幻影专注：专注上限 +2，精确打击加成 +20%。'),
'E00S':('风暴箭圣',2,{'agi':12,'ap':1},'风暴节奏：行动点上限 +1。'),
'E010':('破城弩王',2,{'str':8,'agi':8,'final':.2},'破城之力：最终伤害 +20%。'),
'H004':('弹幕指挥官',2,{'agi':10,'crit':10,'skill':.15},'弹幕压制：暴击率 +10%，技能伤害 +15%。'),
'H00E':('鹰眼神射',2,{'agi':12,'prec':.3,'critd':.25},'鹰眼锁定：精确打击加成 +30%，暴击伤害 +25%。'),
'N016':('奥术贤者',3,{'int':12,'mp':10,'skill':.2},'奥术储备：魔法上限 +10，技能伤害 +20%。'),
'N01E':('炽焰领主',3,{'int':12,'spell':.3,'skill':.15},'炽焰核心：法术伤害 +30%，技能伤害 +15%。'),
'O004':('血矛战神',1,{'str':12,'critd':.35,'ap':1},'血矛战意：行动点上限 +1，暴击伤害 +35%。'),
'O006':('巨魔战皇',1,{'str':8,'agi':8,'ap':1,'prec':.2},'战皇节奏：行动点上限 +1，精确打击加成 +20%。'),
'N01A':('狂怒战神',1,{'str':15,'crit':15,'critd':.3},'狂怒战意：暴击率 +15%，暴击伤害 +30%。'),
'O005':('荒原狼王',1,{'str':10,'agi':8,'skill':.2},'荒原猎手：技能伤害 +20%。')}
act={1:('战意震荡','全体存活敌人受到力量 ×3 的物理伤害。'),2:('风暴弹幕','全体存活敌人受到敏捷 ×3 的物理伤害。'),3:('奥能洪流','全体存活敌人受到智力 ×3 的法术伤害。'),4:('圣愈祈愿','全体存活队友恢复各自最大生命的20% + 施法者智力。'),5:('万象共鸣','全体存活敌人受到三围总和 ×1.1 的法术伤害。')}
opts=[]
passive_names={'A00P','A00O','A03E','A04J','A03K','A05A','A055','A03H','A04Q','A03G','A04V','A02U','A03N','A03M','A05E'}
for iid,r in normal:
 target=r['CECA6EE8'];stage=1 if r['1F514F64']=='H000' else 2
 ua=D['unitAbilities'][target];learn=ua.get('heroAbilList','').split(',');innate=[a for a in ua.get('abilList','').split(',') if a not in ['AInv','A001','A002','A000']]
 combat=innate+[a for a in learn if a and a not in passive_names]
 def detail(a):
  ad=D['abilities'].get(a,{})
  # Show existing corrected descriptions when available, otherwise the level-one object tooltip.
  body=ad.get('Ubertip','').strip('"')
  match=re.search(r"(?:if|elseif) id=='"+re.escape(a)+r"' then\s*return \"((?:\\.|[^\"\\])*)\"",src)
  if match:body=match[1].replace('\\\"','\"').replace('\\\\','\\')
  if ',发射' in body or ',蓄力' in body:body=body.split(',')[0]
  return '|cffd2b879'+ad.get('Name',a).split('(|')[0]+'|r|n'+body
 skills='|n|n'.join(detail(a) for a in combat)
 ps='|n|n'.join(detail(a) for a in learn if a in passive_names)
 if not ps:ps='没有独立修炼被动；本职优势来自上方战斗技能。'
 extra=[]
 if stage==2:
  if iid in ['I04N','I03M','I03N','I04O','I03S','I054','I04W']:extra.append('转职奖励：行动点上限 +1。')
  if iid in ['I03P','I03R','I04Z']:extra.append('转职奖励：技能伤害 +30%。')
  if iid in ['I03Q','I04U']:extra.append('转职奖励：力量 +10，敏捷 +20。')
  if iid in ['I03O','I04Y']:extra.append('转职奖励：暴击率 +20%。')
  if iid in ['I03T','I053']:extra.append('转职奖励：暴击伤害 +50%。')
 ps='|n'.join(extra)+('|n|n' if extra else '')+ps
 opts.append(dict(source=r['1F514F64'],target=target,item=iid,stage=stage,name=D['units'][target]['Name'],role=roles[target],skills=skills or '平砍与基础防御。',passive=ps,reqStr=r.get('89877F57',0),reqAgi=r.get('5A5B203D',0),reqInt=r.get('BC75CE99',0),level=5 if stage==1 else 15))
# Random is the only entrance into the concealed lineage. No selectable hidden first-stage entry.
opts.append(dict(source='H000',target='H000',item='',stage=1,name='随机转职',role='全属性门槛 · 90% 普通职业 / 10% 隐藏职业',skills='抽取范围：8种普通一转职业等概率；隐藏职业总概率10%。|n隐藏职业「万象行者」：以力量、敏捷、智力的总和驱动攻击。|n抽取结果确定后不可重抽。',passive='隐藏天赋「均衡修炼」：每级力量、敏捷、智力成长各 +0.15。|n可学习「三相修炼」：每级基础三围各 +2，最多3级。|n不附送行动点；一转攻击只吃三围总和的45%，控制前期爆发。|n未抽中隐藏职业时，隐藏进阶不会出现在二转、三转面板。',reqStr=10,reqAgi=10,reqInt=10,level=5))
opts.append(dict(source='HZ01',target='HZ02',item='',stage=2,name='万象织法者',role='隐藏二转 · 全属性输出 · 均衡积累',skills='|cffd2b879三相打击|r|n单体物理伤害基值：攻击力 ×0.65 + 三围总和 ×0.65。|n行动点1，魔法0；不附加随机暴击。|n三转之后获得群体技能「万象共鸣」。',passive='|cffd2b879三相融汇|r|n力量、敏捷、智力各 +3；行动点上限 +1。|n保留一转均衡修炼与三相修炼等级，不再次叠加成长或已学属性。',reqStr=20,reqAgi=20,reqInt=20,level=15))
opts.append(dict(source='HZ02',target='HZ03',item='',stage=3,name='万象天枢',role='隐藏三转 · 全属性共鸣 · 群体输出',skills='|cffd2b879三相打击|r|n单体物理伤害基值：攻击力 ×0.70 + 三围总和 ×0.80。|n行动点1，魔法0；不附加随机暴击。|n|n|cffd2b879万象共鸣（Z）|r|n三围总和 ×1.1 的群体法术伤害。|n行动点2，魔法3；每回合一次。',passive='|cffd2b879万象归一|r|n力量、敏捷、智力各 +5，技能伤害 +15%。|n保留三相修炼（每级基础三围各 +2，最多3级）。|n三转不再额外增加行动点或成长，避免全属性收益重复滚雪球。',reqStr=0,reqAgi=0,reqInt=0,level=0))
for target,(name,kind,bonus,ps) in awakening.items():
 attrs='，'.join(n+' +'+str(bonus[k]) for k,n in [('str','力量'),('agi','敏捷'),('int','智力')] if k in bonus)
 opts.append(dict(source=target,target=target,item='',stage=3,name=name,role=roles[target]+' · 三转觉醒',skills='保留二转的战斗技能与修炼。|n|n|cffd2b879'+act[kind][0]+'（Z）|r|n'+act[kind][1]+'|n行动点2，魔法3；每回合一次。|n范围：当前战斗中的全体敌人／队友。',passive='三转属性：'+attrs+'。|n|n'+ps+'|n只生效一次，保留原有职业效果。',reqStr=0,reqAgi=0,reqInt=0,level=0,kind=kind,bonus=bonus))
from hidden_patch import update_options, apply_script as apply_hidden
update_options(opts)
from priest_patch import update_options as update_priest_options, apply_script as apply_priest
update_priest_options(opts)
from reclass_patch import update_options as update_reclass_options
update_reclass_options(opts)
from presentation_patch import update_options as update_presentation_options
update_presentation_options(opts)
from monk_patch import update_options as update_monk_options
update_monk_options(opts)
(R/'patch-options.json').write_text(json.dumps(opts,ensure_ascii=False,indent=2))
G='''
// Independent promotion UI. Presentation state is local; each gameplay callback has a fixed option.
boolean array HopeMeditation_Active
unit array HopeMeditation_Unit
integer array HopeMeditation_LastCast
integer HopeJob_Panel=0
integer HopeJob_OpenButton=0
integer HopeJob_Title=0
integer HopeJob_Status=0
integer HopeJob_Detail=0
integer HopeJob_Footer=0
integer array HopeJob_Row
integer array HopeJob_Confirm
integer array HopeJob_Source
integer array HopeJob_Target
integer array HopeJob_Item
integer array HopeJob_Stage
integer array HopeJob_Level
integer array HopeJob_Str
integer array HopeJob_Agi
integer array HopeJob_Int
string array HopeJob_Name
string array HopeJob_Role
string array HopeJob_Skills
string array HopeJob_Passive
integer HopeJob_Selected=-1
integer HopeJob_Entry=1
integer HopeJob_Page=0
integer HopeJob_LastType=0
boolean HopeJob_Expanded=false
boolean array HopeJob_Awakened
integer array HopeJob_AwakenOption
integer array HopeJob_UltimateKind
integer array HopeJob_LastCast
boolean HopeJob_RandomPromotion=false
integer HopeJob_DetailPage=0
integer array HopeJob_SkillCount
integer array HopeJob_PassiveCount
string array HopeJob_DetailText
integer HopeJob_PrevButton=0
integer HopeJob_NextButton=0
integer HopeJob_PageLabel=0
integer HopeJob_Count=43
'''
assert len(opts)==43
src=src.replace('globals\n','globals\n'+G,1)
a=src.index('function Trig____________________020Actions')
b=src.index('function InitTrig____________________020 takes',a)
first=src[a:b]
line=next(l for l in first.splitlines() if l.startswith('if GetHeroStr('))
first=first.replace(line,'if HopeJob_RandomPromotion or ('+line[3:-5]+') then',1)
src=src[:a]+first+src[b:]

meditation_helpers='\n// Meditation keeps real mana and mana capacity independent of the temporary intelligence.\nfunction HopeMeditation_Clear takes unit u,integer i returns nothing\nlocal real mana=GetUnitState(u,UNIT_STATE_MANA)\nlocal real maximum=GetUnitState(u,UNIT_STATE_MAX_MANA)\nlocal boolean held=HopeMeditation_Active[i] and HopeMeditation_Unit[i]==u\ncall SetHeroInt(u,GetHeroInt(u,false)-udg_Linshi_Int[i],true)\nif held then\ncall SetUnitState(u,UNIT_STATE_MAX_MANA,maximum)\ncall SetUnitState(u,UNIT_STATE_MANA,RMinBJ(maximum,mana))\nset HopeMeditation_Active[i]=false\nset HopeMeditation_Unit[i]=null\nendif\nendfunction\nfunction HopeMeditation_Apply takes unit u returns nothing\nlocal player p=GetOwningPlayer(u)\nlocal integer i=GetPlayerId(p)+1\nlocal integer token=udg_quanshu*100000+udg_boci*1000+udg_huihe_s+1\nlocal integer intelligence=GetHeroInt(u,true)\nlocal integer bonus=R2I(I2R(intelligence)*.3)\nlocal real mana=GetUnitState(u,UNIT_STATE_MANA)\nlocal real maximum=GetUnitState(u,UNIT_STATE_MAX_MANA)\nlocal real restored=RMinBJ(RMaxBJ(0.,maximum-mana),3.+I2R(intelligence)/5.)\nif i<1 or i>6 or u!=udg_hero[i] or not udg_ZhandouZhong or GetWidgetLife(u)<=.405 then\ncall DisplayTimedTextToPlayer(p,0,0,4.,"冥想只能由当前英雄在战斗中使用。")\nset p=null\nreturn\nendif\nif udg_xingdong_dian[i]<1 then\ncall DisplayTimedTextToPlayer(p,0,0,4.,"冥想需要1行动点。")\nset p=null\nreturn\nendif\nif HopeMeditation_LastCast[i]==token or HopeMeditation_Active[i] then\ncall DisplayTimedTextToPlayer(p,0,0,4.,"冥想每回合只能使用一次。")\nset p=null\nreturn\nendif\nset HopeMeditation_LastCast[i]=token\nset udg_xingdong_dian[i]=udg_xingdong_dian[i]-1\nset udg_Linshi_Int[i]=udg_Linshi_Int[i]+bonus\nset udg_Ls_zj_Int[i]=udg_Ls_zj_Int[i]+bonus\ncall SetHeroInt(u,GetHeroInt(u,false)+bonus,true)\n// Neutralize BOTH the native maximum increase and any native current-mana adjustment.\ncall SetUnitState(u,UNIT_STATE_MAX_MANA,maximum)\ncall SetUnitState(u,UNIT_STATE_MANA,RMinBJ(maximum,mana+restored))\nset HopeMeditation_Active[i]=true\nset HopeMeditation_Unit[i]=u\ncall DisplayTimedTextToPlayer(p,0,0,4.,"冥想：恢复 "+R2S(restored)+" 魔法，本回合智力 +"+I2S(bonus)+"；行动点 -1。")\nset p=null\nendfunction\n'
src=src.replace('function s__YDWEStringFormula__Inventory__allocate',meditation_helpers+'\nfunction s__YDWEStringFormula__Inventory__allocate',1)

F='''
function HopeJob_Round takes nothing returns integer
return udg_quanshu+1
endfunction
function HopeJob_AdvancedOpen takes nothing returns boolean
if udg_quanshu<2 then
return false
endif
if gg_unit_n019_0032!=null and GetUnitTypeId(gg_unit_n019_0032)!=0 and not IsUnitHidden(gg_unit_n019_0032) and GetWidgetLife(gg_unit_n019_0032)>.405 then
return true
endif
return gg_unit_n01C_0003!=null and GetUnitTypeId(gg_unit_n01C_0003)!=0 and not IsUnitHidden(gg_unit_n01C_0003) and GetWidgetLife(gg_unit_n01C_0003)>.405
endfunction
function HopeJob_InRoom takes player p returns boolean
local integer i=GetPlayerId(p)+1
local unit u=udg_hero[i]
local boolean ok=false
if i>=1 and i<=6 and u!=null then
set ok=GetUnitX(u)>=-3328. and GetUnitX(u)<=-1800. and GetUnitY(u)>=1800. and GetUnitY(u)<=3072. and GetWidgetLife(u)>.405 and not udg_ZhandouZhong
endif
set u=null
return ok
endfunction
function HopeJob_Visible takes integer index,integer i returns boolean
if index<0 or index>=HopeJob_Count or i<1 or i>6 then
return false
endif
if HopeJob_Stage[index]>=2 and not HopeJob_AdvancedOpen() then
return false
endif
return udg_hero[i]!=null and HopeJob_Source[index]==GetUnitTypeId(udg_hero[i]) and (not HopeJob_Awakened[i] or HopeJob_AwakenOption[i]==index)
endfunction
// Entrance selection is local presentation state; synchronized promotion never reads it.
function HopeJob_InPanel takes integer index,integer i returns boolean
return HopeJob_Visible(index,i) and ((HopeJob_Entry==1 and HopeJob_Stage[index]==1) or (HopeJob_Entry==2 and HopeJob_Stage[index]>=2))
endfunction
function HopeJob_WoodCost takes integer index returns integer
if index<0 or index>=HopeJob_Count then
return 0
endif
if HopeJob_Stage[index]==3 then
return 30
endif
return 0
endfunction
function HopeJob_Blocker takes integer index,player p returns string
local integer i=GetPlayerId(p)+1
local unit u=udg_hero[i]
local string s=""
if index<0 or index>=HopeJob_Count or i<1 or i>6 then
set s="无效的转职选项。"
elseif HopeJob_Stage[index]>=2 and not HopeJob_AdvancedOpen() then
set s="二转建筑尚未开放；第3轮出现后才能办理二转或三转。"
elseif not HopeJob_Visible(index,i) then
set s="该进阶不属于你的职业路线。"
elseif HopeJob_Awakened[i] then
set s="已完成三转，本局不能再次转职。"
elseif not HopeJob_InRoom(p) then
set s="请回到原来的泉水爬塔房间。"
elseif HopeRoute_RewardPending(i-1) then
set s="请先完成待选奖励。"
elseif HopeJob_Stage[index]==3 and HopeJob_Round()<4 then
set s="三转从第4轮开始解锁；完成前3轮即可，不需要通关第4轮。"
elseif HopeJob_Stage[index]==3 and GetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER)<HopeJob_WoodCost(index) then
set s="木材不足：三转需要 "+I2S(HopeJob_WoodCost(index))+" 木材，当前 "+I2S(GetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER))+"。"
elseif GetHeroLevel(u)<HopeJob_Level[index] then
set s="等级不足，需要等级 "+I2S(HopeJob_Level[index])+"。"
elseif GetHeroStr(u,false)<HopeJob_Str[index] or GetHeroAgi(u,false)<HopeJob_Agi[index] or GetHeroInt(u,false)<HopeJob_Int[index] then
set s="基础属性不足（装备和临时加成不计）。"
endif
set u=null
return s
endfunction
function HopeJob_Close takes nothing returns nothing
set HopeJob_Expanded=false
call DzFrameShow(HopeJob_Panel,false)
endfunction
function HopeJob_Show takes player p,integer entry returns nothing
if GetPlayerId(p)<0 or GetPlayerId(p)>=6 or (entry!=1 and entry!=2) or not HopeJob_InRoom(p) then
return
endif
if entry==2 and not HopeJob_AdvancedOpen() then
return
endif
if p==GetLocalPlayer() and GetPlayerId(p)<6 then
set HopeJob_Entry=entry
set HopeJob_Selected=-1
set HopeJob_Page=0
set HopeJob_DetailPage=0
set HopeJob_Expanded=true
set HopeQoL_Expanded=false
set HopeArchive_Expanded=false
set HopeGift_Expanded=false
set HopeRelic_Expanded=false
set HopeRoute_Details=false
call DzFrameShow(HopeJob_Panel,true)
endif
endfunction
function HopeJob_Open takes nothing returns nothing
local player p=DzGetTriggerUIEventPlayer()
local integer entry=2
if GetUnitTypeId(udg_hero[GetPlayerId(p)+1])=='H000' then
set entry=1
endif
call HopeJob_Show(p,entry)
set p=null
endfunction
function HopeJob_Select takes integer option returns nothing
set HopeJob_Selected=option
set HopeJob_Page=0
set HopeJob_DetailPage=0
endfunction
function HopeJob_Page0 takes nothing returns nothing
set HopeJob_Page=0
set HopeJob_DetailPage=0
endfunction
function HopeJob_Page1 takes nothing returns nothing
set HopeJob_Page=1
set HopeJob_DetailPage=0
endfunction
function HopeJob_Page2 takes nothing returns nothing
set HopeJob_Page=2
set HopeJob_DetailPage=0
endfunction
function HopeJob_Prev takes nothing returns nothing
set HopeJob_DetailPage=IMaxBJ(0,HopeJob_DetailPage-1)
endfunction
function HopeJob_Next takes nothing returns nothing
local integer count=0
if HopeJob_Selected<0 then
return
endif
if HopeJob_Page==1 then
set count=HopeJob_SkillCount[HopeJob_Selected]
elseif HopeJob_Page==2 then
set count=HopeJob_PassiveCount[HopeJob_Selected]
endif
set HopeJob_DetailPage=IMinBJ(IMaxBJ(0,count-1),HopeJob_DetailPage+1)
endfunction
// Replace only the hidden lineage. Keep ordinary first/second promotions on the original item triggers.
function HopeJob_ReplaceHidden takes player p,integer kind returns nothing
local integer i=GetPlayerId(p)+1
local unit old=udg_hero[i]
local unit u=CreateUnit(p,kind,GetUnitX(old),GetUnitY(old),GetUnitFacing(old))
local integer slot=0
local item it=null
local integer aid=0
local integer training=GetUnitAbilityLevel(old,'AZHP')
if GetUnitTypeId(old)=='H000' then
call SetHeroXP(u,0,false)
else
call SetHeroXP(u,GetHeroXP(old),false)
endif
call SetHeroStr(u,GetHeroStr(old,false)-udg_Ls_zj_Str[i],true)
call SetHeroAgi(u,GetHeroAgi(old,false)-udg_Ls_zj_Agi[i],true)
call SetHeroInt(u,GetHeroInt(old,false)-udg_Ls_zj_Int[i],true)
set udg_Ls_zj_Str[i]=0
set udg_Ls_zj_Agi[i]=0
set udg_Ls_zj_Int[i]=0
call SetUnitState(u,UNIT_STATE_MAX_LIFE,GetUnitState(old,UNIT_STATE_MAX_LIFE))
call SetUnitState(u,UNIT_STATE_MAX_MANA,GetUnitState(old,UNIT_STATE_MAX_MANA))
loop
exitwhen slot>=6
set it=UnitItemInSlot(old,slot)
if it!=null then
call UnitRemoveItem(old,it)
call UnitAddItem(u,it)
endif
set slot=slot+1
endloop
set aid=LoadInteger(YDHT,i,$412D8AC6)
if aid!=0 then
call UnitAddAbility(u,aid)
endif
set aid=LoadInteger(YDHT,i,$3FB1F9E0)
if aid!=0 then
call UnitAddAbility(u,aid)
endif
set aid=LoadInteger(YDHT,i,$590EE9FB)
if aid!=0 then
call UnitAddAbility(u,aid)
endif
if udg_R_Skill[i]!=0 and udg_R_Skill[i]!=$4130314C then
call UnitAddAbility(u,udg_R_Skill[i])
endif
call SetUnitState(u,ConvertUnitState(18),GetUnitState(u,ConvertUnitState(18))+I2R(udg_Gongjili_Jc[i]))
set udg_Minjie_jiaGong[i]=0
call SetUnitMoveSpeed(u,GetUnitMoveSpeed(old))
if GetUnitTypeId(old)!='H000' then
if training>0 then
call UnitAddAbility(u,'AZHP')
call SetUnitAbilityLevel(u,'AZHP',training)
call UnitMakeAbilityPermanent(u,true,'AZHP')
endif
call UnitModifySkillPoints(u,GetHeroSkillPoints(old)-GetHeroSkillPoints(u))
endif
set udg_hero[i]=u
call RemoveUnit(old)
call SetUnitState(u,UNIT_STATE_LIFE,GetUnitState(u,UNIT_STATE_MAX_LIFE))
call SetUnitState(u,UNIT_STATE_MANA,GetUnitState(u,UNIT_STATE_MAX_MANA))
call SelectUnitForPlayerSingle(u,p)
set old=null
set u=null
set it=null
endfunction
function HopeJob_AddStats takes integer i,integer strength,integer agility,integer intelligence returns nothing
call SetHeroStr(udg_hero[i],GetHeroStr(udg_hero[i],false)+strength,true)
call SetHeroAgi(udg_hero[i],GetHeroAgi(udg_hero[i],false)+agility,true)
call SetHeroInt(udg_hero[i],GetHeroInt(udg_hero[i],false)+intelligence,true)
endfunction
function HopeJob_Awaken takes integer index,integer i returns nothing
local unit u=udg_hero[i]
local integer kind=0
'''
for index,o in enumerate(opts):
 if o['stage']!=3:continue
 F+=('if' if index==26 else 'elseif')+' index=='+str(index)+' then\n'
 if index==26:
  F+="call HopeJob_ReplaceHidden(Player(i-1),'HZ03')\nset u=udg_hero[i]\ncall HopeJob_AddStats(i,5,5,5)\nset udg_Skill_Dm[i]=udg_Skill_Dm[i]+.15\nset kind=5\n"
 else:
  b=o['bonus'];F+=f"call HopeJob_AddStats(i,{b.get('str',0)},{b.get('agi',0)},{b.get('int',0)})\nset kind={o['kind']}\n"
  variables={'def':'udg_Defend_fangyu','final':'udg_Zuizhong_Dm','regen':'udg_huihe_huilan','crit':'udg_Baoji_Lv','critd':'udg_Baoji_Damage','dex':'udg_DEX','prec':'udg_jingque_Daji_jiacheng','ap':'udg_xingdong_dianSx','skill':'udg_Skill_Dm','spell':'udg_Fashang_Dm'}
  for k,v in b.items():
   if k in variables:F+=f'set {variables[k]}[i]={variables[k]}[i]+{v}\n'
   if k in ['hp','mp']:
    state='LIFE' if k=='hp' else 'MANA';F+=f'call SetUnitState(u,UNIT_STATE_MAX_{state},GetUnitState(u,UNIT_STATE_MAX_{state})+{v}.)\n'
F+='''endif
set HopeJob_Awakened[i]=true
set HopeJob_AwakenOption[i]=index
set HopeJob_UltimateKind[i]=kind
set HopeJob_LastCast[i]=-1
call UnitAddAbility(u,'AZ31'+kind-1)
call UnitMakeAbilityPermanent(u,true,'AZ31'+kind-1)
call SetUnitState(u,UNIT_STATE_LIFE,GetUnitState(u,UNIT_STATE_MAX_LIFE))
call SetUnitState(u,UNIT_STATE_MANA,GetUnitState(u,UNIT_STATE_MAX_MANA))
set udg_xingdong_dian[i]=udg_xingdong_dianSx[i]
set u=null
endfunction
function HopeJob_Commit takes integer index returns nothing
local player p=DzGetTriggerUIEventPlayer()
local integer i=GetPlayerId(p)+1
local string blocker=HopeJob_Blocker(index,p)
local integer pick=index
local item it=null
if blocker!="" then
call DisplayTimedTextToPlayer(p,0,0,5.,blocker)
set p=null
return
endif
if index==24 then
// Gameplay RNG runs only in this synchronized callback, never during preview/refresh.
if GetRandomInt(1,100)<=10 then
call HopeJob_ReplaceHidden(p,'HZ01')
set udg_cz1Str_up[i]=udg_cz1Str_up[i]+.15
set udg_cz2Agi_up[i]=udg_cz2Agi_up[i]+.15
set udg_cz3Int_up[i]=udg_cz3Int_up[i]+.15
call DisplayTextToPlayer(p,0,0,"|cffffd36a随机转职：万象行者（隐藏职业）！|r")
else
set pick=GetRandomInt(0,7)
set HopeJob_RandomPromotion=true
set it=CreateItem(HopeJob_Item[pick],GetUnitX(udg_hero[i]),GetUnitY(udg_hero[i]))
call UnitAddItem(udg_hero[i],it)
call RemoveItem(it)
set HopeJob_RandomPromotion=false
call DisplayTextToPlayer(p,0,0,"随机转职："+HopeJob_Name[pick])
endif
elseif index==25 then
call HopeJob_ReplaceHidden(p,'HZ02')
call HopeJob_AddStats(i,3,3,3)
set udg_xingdong_dianSx[i]=udg_xingdong_dianSx[i]+1
set udg_xingdong_dian[i]=udg_xingdong_dianSx[i]
call DisplayTextToPlayer(p,0,0,"已进阶为隐藏二转：万象织法者。")
elseif HopeJob_Stage[index]==3 then
// Eligibility and the current balance were checked in this synchronized callback.
call SetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER,GetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER)-HopeJob_WoodCost(index))
call HopeJob_Awaken(index,i)
call DisplayTextToPlayer(p,0,0,"|cffffd36a三转完成："+HopeJob_Name[index]+"；消耗 "+I2S(HopeJob_WoodCost(index))+" 木材。按Z使用觉醒技能。|r")
else
set it=CreateItem(HopeJob_Item[index],GetUnitX(udg_hero[i]),GetUnitY(udg_hero[i]))
call UnitAddItem(udg_hero[i],it)
call RemoveItem(it)
call SelectUnitForPlayerSingle(udg_hero[i],p)
if GetUnitTypeId(udg_hero[i])==HopeJob_Target[index] then
call DisplayTextToPlayer(p,0,0,"已转职为："+HopeJob_Name[index])
else
call DisplayTextToPlayer(p,0,0,"转职未完成，请检查原职业条件。")
endif
endif
set HopeRoute_Ready[i-1]=false
if p==GetLocalPlayer() then
set HopeJob_Expanded=false
call DzFrameShow(HopeJob_Panel,false)
endif
set it=null
set p=null
endfunction
'''
# Fixed callbacks keep locally selected data out of synchronized operations.
for index in range(len(opts)):
 F+=f'''function HopeJob_Select{index} takes nothing returns nothing
call HopeJob_Select({index})
endfunction
function HopeJob_Commit{index} takes nothing returns nothing
call HopeJob_Commit({index})
endfunction
'''
F+='''function HopeJob_OnSelect takes nothing returns nothing
local integer kind=GetUnitTypeId(GetTriggerUnit())
if IsUnitHidden(GetTriggerUnit()) or GetWidgetLife(GetTriggerUnit())<=.405 then
return
endif
if kind=='n008' then
call HopeJob_Show(GetTriggerPlayer(),1)
elseif kind=='n019' or kind=='n01C' then
call HopeJob_Show(GetTriggerPlayer(),2)
endif
if kind=='n008' or kind=='n019' or kind=='n01C' then
if GetTriggerPlayer()==GetLocalPlayer() and udg_hero[GetPlayerId(GetTriggerPlayer())+1]!=null then
call SelectUnitForPlayerSingle(udg_hero[GetPlayerId(GetTriggerPlayer())+1],GetTriggerPlayer())
endif
endif
endfunction
function HopeJob_RemoveStock takes nothing returns nothing
local unit u=GetEnumUnit()
local integer kind=GetUnitTypeId(u)
local integer index=0
if kind=='n008' or kind=='n019' or kind=='n01C' then
loop
exitwhen index>=24
call RemoveItemFromStock(u,HopeJob_Item[index])
set index=index+1
endloop
call RemoveUnitFromStock(u,'H000')
endif
set u=null
endfunction
function HopeJob_Refresh takes nothing returns nothing
local player p=GetLocalPlayer()
local integer i=GetPlayerId(p)+1
local integer index=0
local integer row=0
local integer typ=GetUnitTypeId(udg_hero[i])
local integer chosen=HopeJob_Selected
local boolean room=HopeJob_InRoom(p)
local boolean available=room and (typ=='H000' or HopeJob_AdvancedOpen())
local boolean picking=HopeChoice_HasPending() and not HopeChoice_Hidden
local string detail=""
local string block=""
local string level=""
local string current=GetUnitName(udg_hero[i])
local integer count=0
if HopeJob_Panel==0 then
set p=null
return
endif
call DzFrameShow(HopeJob_OpenButton,available and not picking)
// Entering the fountain only reveals the manual entry button.
if not room or (HopeJob_Entry==2 and not HopeJob_AdvancedOpen()) then
set HopeJob_Expanded=false
endif
if HopeQoL_Expanded or HopeArchive_Expanded or HopeGift_Expanded or HopeRelic_Expanded or HopeRoute_Details then
set HopeJob_Expanded=false
endif
call DzFrameShow(HopeJob_Panel,HopeJob_Expanded and not picking)
if not HopeJob_Expanded or i>6 then
set p=null
return
endif
if HopeJob_LastType!=typ then
set chosen=-1
set HopeJob_Selected=-1
set HopeJob_Page=0
set HopeJob_DetailPage=0
set HopeJob_LastType=typ
endif
if chosen>=0 and not HopeJob_InPanel(chosen,i) then
set chosen=-1
set HopeJob_Selected=-1
set HopeJob_Page=0
set HopeJob_DetailPage=0
endif
loop
exitwhen index>=HopeJob_Count
call DzFrameShow(HopeJob_Row[index],HopeJob_InPanel(index,i))
call DzFrameShow(HopeJob_Confirm[index],false)
if HopeJob_InPanel(index,i) then
if HopeJob_Row[index]!=0 then
call DzFrameSetPoint(HopeJob_Row[index],0,HopeJob_Panel,0,.012,-.078-.030*I2R(row))
endif
if chosen==-1 then
set chosen=index
set HopeJob_Selected=index
endif
set row=row+1
endif
set index=index+1
endloop
if HopeJob_Awakened[i] then
set current=HopeJob_Name[HopeJob_AwakenOption[i]]
endif
if HopeJob_Entry==1 then
call DzFrameSetText(HopeJob_Title,"|cffd2b879一转职业|r · "+current)
else
call DzFrameSetText(HopeJob_Title,"|cffd2b879二转 / 三转|r · "+current)
endif
call DzFrameSetText(HopeJob_Status,"当前第 "+I2S(HopeJob_Round())+" 轮 · 二转第3轮 · 三转第4轮 / 30木材")
if chosen>=0 then
set block=HopeJob_Blocker(chosen,p)
if HopeJob_Page==0 then
set level="等级 "+I2S(HopeJob_Level[chosen])+"；基础力量 "+I2S(HopeJob_Str[chosen])+" / 敏捷 "+I2S(HopeJob_Agi[chosen])+" / 智力 "+I2S(HopeJob_Int[chosen])
if HopeJob_Stage[chosen]==3 then
set level="已完成二转；进入第4轮；在原二转建筑办理。|n三转费用："+I2S(HopeJob_WoodCost(chosen))+" 木材；当前木材："+I2S(GetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER))+"。"
elseif HopeJob_Stage[chosen]==2 then
set level=level+"；第3轮二转建筑出现后开放。"
endif
set detail="|cffd2b879"+HopeJob_Name[chosen]+" · "+I2S(HopeJob_Stage[chosen])+"转|r|n|n"+HopeJob_Role[chosen]+"|n|n|cffd2b879转职条件|r|n"+level+"|n|n属性门槛按基础值判断，装备与临时加成不计。|n一转沿用原规则；二转保留英雄等级。|n三转保留二转技能、修炼、装备和本局成长。"
elseif HopeJob_Page==1 then
set count=HopeJob_SkillCount[chosen]
set detail=HopeJob_DetailText[chosen*16+HopeJob_DetailPage]
else
set count=HopeJob_PassiveCount[chosen]
set detail=HopeJob_DetailText[chosen*16+8+HopeJob_DetailPage]
endif
call DzFrameShow(HopeJob_PrevButton,count>1 and HopeJob_DetailPage>0)
call DzFrameShow(HopeJob_NextButton,count>1 and HopeJob_DetailPage+1<count)
call DzFrameShow(HopeJob_PageLabel,count>1)
call DzFrameSetText(HopeJob_PageLabel,I2S(HopeJob_DetailPage+1)+" / "+I2S(count))
call DzFrameSetText(HopeJob_Detail,detail)
call DzFrameShow(HopeJob_Confirm[chosen],true)
if block=="" then
if HopeJob_Stage[chosen]==3 then
call DzFrameSetText(HopeJob_Confirm[chosen],"确认："+HopeJob_Name[chosen]+"（"+I2S(HopeJob_WoodCost(chosen))+"木材）")
else
call DzFrameSetText(HopeJob_Confirm[chosen],"确认："+HopeJob_Name[chosen])
endif
set block="条件已满足。转职确认后本局不可撤销。"
else
if HopeJob_Stage[chosen]==3 then
call DzFrameSetText(HopeJob_Confirm[chosen],"暂不可转职 · 需"+I2S(HopeJob_WoodCost(chosen))+"木材")
else
call DzFrameSetText(HopeJob_Confirm[chosen],"暂不可转职：查看下方条件")
endif
endif
call DzFrameSetText(HopeJob_Footer,block)
else
call DzFrameShow(HopeJob_PrevButton,false)
call DzFrameShow(HopeJob_NextButton,false)
call DzFrameShow(HopeJob_PageLabel,false)
call DzFrameSetText(HopeJob_Footer,"")
if HopeJob_Entry==1 and typ!='H000' then
call DzFrameSetText(HopeJob_Detail,"你已完成一转。请在二转建筑出现后，前往该建筑继续二转或三转。")
elseif HopeJob_Entry==2 and typ=='H000' then
call DzFrameSetText(HopeJob_Detail,"请先在一转建筑完成一转，再来选择本职业的二转路线。")
else
call DzFrameSetText(HopeJob_Detail,"当前没有可用的进阶路线。")
endif
endif
set p=null
endfunction
function HopeJob_CreateUI takes nothing returns nothing
local integer index=0
local integer f=0
call DestroyTimer(GetExpiredTimer())
set HopeJob_Panel=HopeQoL_Surface("HopeJobPanel",.19,.545,.47,.395)
if HopeJob_Panel==0 then
return
endif
set HopeJob_Title=HopeQoL_Label("HopeJobTitle",HopeJob_Panel,.012,-.010,.405,.022,"")
set HopeJob_Status=HopeQoL_Label("HopeJobStatus",HopeJob_Panel,.012,-.037,.446,.022,"")
set f=HopeQoL_Button("HopeJobClose",HopeJob_Panel,.421,-.009,.037,.022,"关闭")
call HopeQoL_Bind(f,function HopeJob_Close,false)
set f=HopeQoL_Button("HopeJobOverview",HopeJob_Panel,.165,-.066,.087,.022,"定位 / 条件")
call HopeQoL_Bind(f,function HopeJob_Page0,false)
set f=HopeQoL_Button("HopeJobSkills",HopeJob_Panel,.259,-.066,.087,.022,"战斗技能")
call HopeQoL_Bind(f,function HopeJob_Page1,false)
set f=HopeQoL_Button("HopeJobPassive",HopeJob_Panel,.353,-.066,.099,.022,"被动 / 收益")
call HopeQoL_Bind(f,function HopeJob_Page2,false)
set HopeJob_Detail=HopeQoL_Label("HopeJobDetail",HopeJob_Panel, .165,-.101,.290,.191,"")
set HopeJob_PrevButton=HopeQoL_Button("HopeJobPrev",HopeJob_Panel,.165,-.302,.083,.020,"上一项")
call HopeQoL_Bind(HopeJob_PrevButton,function HopeJob_Prev,false)
set HopeJob_NextButton=HopeQoL_Button("HopeJobNext",HopeJob_Panel,.370,-.302,.083,.020,"下一项")
call HopeQoL_Bind(HopeJob_NextButton,function HopeJob_Next,false)
set HopeJob_PageLabel=HopeQoL_Label("HopeJobPage",HopeJob_Panel,.278,-.303,.070,.018,"")
set HopeJob_Footer=HopeQoL_Label("HopeJobFooter",HopeJob_Panel,.012,-.365,.446,.022,"")
set HopeJob_OpenButton=HopeQoL_Button("HopeJobOpen",DzGetGameUI(),.014,.218,.134,.024,"转职 / 三转觉醒")
call HopeQoL_Bind(HopeJob_OpenButton,function HopeJob_Open,false)
'''
for index,o in enumerate(opts):
 F+=f'''set HopeJob_Row[{index}]=HopeQoL_Button("HopeJobRow{index}",HopeJob_Panel,.012,-.078,.143,.025,{q(o['name'])})
call HopeQoL_Bind(HopeJob_Row[{index}],function HopeJob_Select{index},false)
set HopeJob_Confirm[{index}]=HopeQoL_Button("HopeJobConfirm{index}",HopeJob_Panel,.165,-.333,.290,.024,"确认："+HopeJob_Name[{index}])
call HopeQoL_Bind(HopeJob_Confirm[{index}],function HopeJob_Commit{index},true)
call DzFrameShow(HopeJob_Confirm[{index}],false)
'''
F+='''call DzFrameShow(HopeJob_OpenButton,false)
call DzFrameShow(HopeJob_Panel,false)
call TimerStart(CreateTimer(),.2,true,function HopeJob_Refresh)
endfunction
function HopeJob_Cast takes nothing returns nothing
local integer aid=GetSpellAbilityId()
local unit u=GetTriggerUnit()
local player p=GetOwningPlayer(u)
local integer i=GetPlayerId(p)+1
local integer kind=0
local integer stage=0
local integer token=udg_quanshu*100000+udg_boci*1000+udg_huihe_s
local integer j=1
local real amount=0.
local real factor=1.
local unit target=GetSpellTargetUnit()
local group g=null
if i>6 or u!=udg_hero[i] then
set u=null
set target=null
set p=null
return
endif
if aid=='AZHA' then
if GetUnitTypeId(u)=='HZ01' then
set amount=GetUnitState(u,ConvertUnitState(20))*.60+I2R(GetHeroStr(u,true)+GetHeroAgi(u,true)+GetHeroInt(u,true))*.45
elseif GetUnitTypeId(u)=='HZ02' then
set amount=GetUnitState(u,ConvertUnitState(20))*.65+I2R(GetHeroStr(u,true)+GetHeroAgi(u,true)+GetHeroInt(u,true))*.65
elseif GetUnitTypeId(u)=='HZ03' then
set amount=GetUnitState(u,ConvertUnitState(20))*.70+I2R(GetHeroStr(u,true)+GetHeroAgi(u,true)+GetHeroInt(u,true))*.80
else
set u=null
set target=null
set p=null
return
endif
if not udg_ZhandouZhong or udg_xingdong_dian[i]<1 or target==null or not IsUnitInGroup(target,udg_Guaiwu_dwz) or GetWidgetLife(target)<=.405 then
call DisplayTimedTextToPlayer(p,0,0,4.,"三相打击：需要战斗中、1行动点和存活的当前敌人。")
else
set udg_xingdong_dian[i]=udg_xingdong_dian[i]-1
call UnitDamageTarget(u,target,amount*udg_Skill_Dm[i]*udg_Zuizhong_Dm[i],true,false,ATTACK_TYPE_NORMAL,DAMAGE_TYPE_NORMAL,WEAPON_TYPE_WHOKNOWS)
call DestroyEffect(AddSpecialEffectTarget("Abilities\\\\Spells\\\\Other\\\\Monsoon\\\\MonsoonBoltTarget.mdl",target,"origin"))
endif
elseif aid>='AZ31' and aid<='AZ35' then
set kind=HopeJob_UltimateKind[i]
if not HopeJob_Awakened[i] or kind!=aid-'AZ31'+1 then
set u=null
set target=null
set p=null
return
endif
if not udg_ZhandouZhong or udg_xingdong_dian[i]<2 or GetUnitState(u,UNIT_STATE_MANA)<3. or HopeJob_LastCast[i]==token then
call DisplayTimedTextToPlayer(p,0,0,4.,"觉醒技能：战斗中每回合一次，需要2行动点、3魔法。")
else
set udg_xingdong_dian[i]=udg_xingdong_dian[i]-2
call SetUnitState(u,UNIT_STATE_MANA,GetUnitState(u,UNIT_STATE_MANA)-3.)
set HopeJob_LastCast[i]=token
if kind==4 then
loop
exitwhen j>6
if udg_hero[j]!=null and GetWidgetLife(udg_hero[j])>.405 and IsUnitAlly(udg_hero[j],p) then
call SetUnitState(udg_hero[j],UNIT_STATE_LIFE,GetUnitState(udg_hero[j],UNIT_STATE_LIFE)+GetUnitState(udg_hero[j],UNIT_STATE_MAX_LIFE)*.2+I2R(GetHeroInt(u,true)))
call DestroyEffect(AddSpecialEffectTarget("Abilities\\\\Spells\\\\Human\\\\HolyBolt\\\\HolyBoltSpecialArt.mdl",udg_hero[j],"origin"))
endif
set j=j+1
endloop
else
if kind==1 then
set amount=I2R(GetHeroStr(u,true))*3.
elseif kind==2 then
set amount=I2R(GetHeroAgi(u,true))*3.
elseif kind==3 then
set amount=I2R(GetHeroInt(u,true))*3.
else
set amount=I2R(GetHeroStr(u,true)+GetHeroAgi(u,true)+GetHeroInt(u,true))*1.1
endif
set factor=udg_Skill_Dm[i]*udg_Zuizhong_Dm[i]
if kind==3 or kind==5 then
set factor=factor*udg_Fashang_Dm[i]
endif
// Snapshot targets; death callbacks may remove units from the live battle group.
set g=CreateGroup()
call GroupAddGroup(udg_Guaiwu_dwz,g)
loop
set target=FirstOfGroup(g)
exitwhen target==null
call GroupRemoveUnit(g,target)
if GetWidgetLife(target)>.405 and IsUnitEnemy(target,p) then
if kind==3 or kind==5 then
call UnitDamageTarget(u,target,amount*factor,false,false,ATTACK_TYPE_MAGIC,DAMAGE_TYPE_MAGIC,WEAPON_TYPE_WHOKNOWS)
else
call UnitDamageTarget(u,target,amount*factor,true,false,ATTACK_TYPE_NORMAL,DAMAGE_TYPE_NORMAL,WEAPON_TYPE_WHOKNOWS)
endif
call DestroyEffect(AddSpecialEffectTarget("Abilities\\\\Spells\\\\Other\\\\Monsoon\\\\MonsoonBoltTarget.mdl",target,"origin"))
endif
endloop
call DestroyGroup(g)
endif
endif
endif
set g=null
set target=null
set u=null
set p=null
endfunction
function HopeJob_Learn takes nothing returns nothing
local unit u=GetTriggerUnit()
local integer i=GetPlayerId(GetOwningPlayer(u))+1
local integer kind=GetUnitTypeId(u)
if i>=1 and i<=6 and u==udg_hero[i] and GetLearnedSkill()=='AZHP' and (kind=='HZ01' or kind=='HZ02' or kind=='HZ03') then
call HopeJob_AddStats(i,2,2,2)
endif
set u=null
endfunction
function HopeJob_Init takes nothing returns nothing
local integer i=0
local trigger selected=CreateTrigger()
local trigger spells=CreateTrigger()
local trigger learning=CreateTrigger()
local group shops=CreateGroup()
call DestroyTimer(GetExpiredTimer())
'''
for index,o in enumerate(opts):
 for page,key in [(0,'skills'),(8,'passive')]:
  chunks=o[key].split('|n|n')
  # At most 8 individual skills/passives. Each page is independently readable.
  assert len(chunks)<=8
  field='SkillCount' if page==0 else 'PassiveCount'
  F+=f'set HopeJob_{field}[{index}]={len(chunks)}\n'
  for sub,chunk in enumerate(chunks):F+=f'set HopeJob_DetailText[{index*16+page+sub}]={q(chunk)}\n'
 for name,key in [('Source','source'),('Target','target')]:F+=f'set HopeJob_{name}[{index}]={raw(o[key])}\n'
 F+=f"set HopeJob_Item[{index}]={raw(o['item']) if o['item'] else '0'}\n"
 for name,key in [('Stage','stage'),('Level','level'),('Str','reqStr'),('Agi','reqAgi'),('Int','reqInt')]:F+=f'set HopeJob_{name}[{index}]={o[key]}\n'
 for name,key in [('Name','name'),('Role','role'),('Skills','skills'),('Passive','passive')]:F+=f'set HopeJob_{name}[{index}]={q(o[key])}\n'
F+='''loop
exitwhen i>=6
call TriggerRegisterPlayerUnitEvent(selected,Player(i),EVENT_PLAYER_UNIT_SELECTED,null)
set i=i+1
endloop
call TriggerAddAction(selected,function HopeJob_OnSelect)
call TriggerRegisterAnyUnitEventBJ(spells,EVENT_PLAYER_UNIT_SPELL_EFFECT)
call TriggerAddAction(spells,function HopeJob_Cast)
call TriggerRegisterAnyUnitEventBJ(learning,EVENT_PLAYER_HERO_SKILL)
call TriggerAddAction(learning,function HopeJob_Learn)
call GroupEnumUnitsOfPlayer(shops,Player(PLAYER_NEUTRAL_PASSIVE),null)
call ForGroup(shops,function HopeJob_RemoveStock)
call DestroyGroup(shops)
call DzTriggerRegisterKeyEventByCode(null,27,1,false,function HopeJob_Close)
call TimerStart(CreateTimer(),.1,false,function HopeJob_CreateUI)
set selected=null
set spells=null
set learning=null
set shops=null
endfunction
'''
# A failed optional frame must not be passed to the platform's frame natives.
F=F.replace('call DzFrameShow(', 'call HopeJob_ShowFrame(')
F=F.replace('call DzFrameSetText(', 'call HopeJob_SetText(')
F='''function HopeJob_ShowFrame takes integer frame,boolean visible returns nothing
if frame!=0 then
call DzFrameShow(frame,visible)
endif
endfunction
function HopeJob_SetText takes integer frame,string value returns nothing
if frame!=0 then
call DzFrameSetText(frame,value)
endif
endfunction
'''+F
src=src.replace('function main takes nothing returns nothing\n',F+'\nfunction main takes nothing returns nothing\n',1)
src=src.replace('call HopeQoL_Init()\nendfunction','call HopeQoL_Init()\ncall TimerStart(CreateTimer(),.01,false,function HopeJob_Init)\nendfunction',1)

# Replace the original channel-time meditation with an effect-time, guarded implementation.
a=src.index('function Trig_RJN_______003Actions takes')
b=src.index('endfunction',a)
src=src[:a]+"function Trig_RJN_______003Actions takes nothing returns nothing\ncall HopeMeditation_Apply(GetTriggerUnit())\n"+src[b:]
src=src.replace('TriggerRegisterAnyUnitEventBJ(gg_trg_RJN_______003,EVENT_PLAYER_UNIT_SPELL_CHANNEL)','TriggerRegisterAnyUnitEventBJ(gg_trg_RJN_______003,EVENT_PLAYER_UNIT_SPELL_EFFECT)')
# Use exact original cleanup expressions, preserving their player indices and surrounding reset logic.
pattern=r'call ModifyHeroStat\(bj_HEROSTAT_INT,(.*),bj_MODIFYMETHOD_SUB,udg_Linshi_Int\[(.*)\]\)'
src,n=re.subn(pattern,lambda m:'call HopeMeditation_Clear('+m[1]+','+m[2]+')',src)
assert n==3,n
src=src.replace('冥想，原实际效果不恢复魔法值|n该回合内智力提高30%|n每回合限用一次|n','恢复施法前3+（智力/5）点魔法，最多补满当前魔法上限。|n本回合智力提高30%（取整），不增加魔法上限。|n消耗1行动点、0魔法；每回合一次。|n回合结束移除临时智力，保留已恢复魔法。')
src=src.replace('return "本次临时智力 +"+I2S(R2I(i*.3))+"；原触发没有实际回蓝"','return "本次回蓝 "+HopeSkill_Number(RMinBJ(RMaxBJ(0.,GetUnitState(u,UNIT_STATE_MAX_MANA)-mana),3.+i/5.))+"；临时智力 +"+I2S(R2I(i*.3))+"；行动点 -1；魔法上限不变"')

from points_patch import apply as apply_points
from shop_patch import apply as apply_shop
from growth_patch import apply as apply_growth
from poison_patch import apply as apply_poison
src=apply_poison(apply_hidden(apply_growth(apply_shop(apply_points(src)))))
src=apply_priest(src)
from challenge_patch import apply as apply_challenge
from enemies_patch import apply as apply_enemies
from coop_patch import apply as apply_coop
from reclass_patch import apply as apply_reclass
src=apply_reclass(apply_coop(apply_enemies(apply_challenge(src))))

from presentation_patch import apply as apply_presentation
src=apply_presentation(src)

from modern_choices_patch import apply as apply_modern_choices
from route_ui_patch import apply as apply_route_ui
from draw_ui_patch import apply as apply_draw_ui
from damage_board_patch import apply as apply_damage_board
src=apply_modern_choices(src)
src=apply_route_ui(src)
src=apply_draw_ui(src)
src=apply_damage_board(src)
extra='function HopeV8_Refresh takes nothing returns nothing\ncall HopeModern_Refresh()\ncall HopeRoute_RefreshPicker()\ncall HopeDraw_Refresh()\ncall HopeDamage_Refresh()\nendfunction\nfunction HopeV8_Init takes nothing returns nothing\ncall DestroyTimer(GetExpiredTimer())\ncall HopeModern_Create()\ncall HopeRoute_CreateExtra()\ncall HopeDraw_Create()\ncall HopeDamage_Create()\ncall TimerStart(CreateTimer(),.1,true,function HopeV8_Refresh)\nendfunction\n'
src=src.replace('function main takes nothing returns nothing',extra+'\nfunction main takes nothing returns nothing',1)
src=src.replace('call HopeQoL_Init()','call HopeQoL_Init()\ncall TimerStart(CreateTimer(),.3,false,function HopeV8_Init)',1)

from layout_patch import apply as apply_layout
src=apply_layout(src)
from wood_shop_patch import apply as apply_wood_shop
src=apply_wood_shop(src)
from compact_ui_patch import apply as apply_compact_ui
src=apply_compact_ui(src)
from inventory_event_patch import apply as apply_inventory_event
src=apply_inventory_event(src)
from monk_patch import apply as apply_monk
src=apply_monk(src)

(R/'war3map-patched.j').write_text(src,encoding='utf-8')
print('Options',len(opts),'script bytes',len(src.encode()))
