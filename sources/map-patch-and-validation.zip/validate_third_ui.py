"""Actual-font checks of all third job cards, research states and class HUD rows."""
from pathlib import Path
import json,re
from fontTools.ttLib import TTFont
from PIL import ImageFont
from validate_layout import Layout
import validate_layout
from validate_economy import rawcode,SCRIPT
from validate_object_dependencies import parse_profile,parse_slk
from third_design import DESIGNS,description

ROOT=Path(__file__).parent
OPTIONS=json.loads((ROOT/'patch-options.json').read_text())
COUNT=0
def check(ok,msg):
    global COUNT
    assert ok,msg
    COUNT+=1


def objects():
    profiles={}
    for name in ['Units_campaignabilityfunc.txt','Units_campaignabilitystrings.txt']:
        p=ROOT/'modified'/name
        if not p.exists():p=ROOT/name
        for a,data in parse_profile(p.read_bytes(),name).items():profiles.setdefault(a,{}).update(data)
    skills=parse_slk((ROOT/'modified/Units_AbilityData.slk').read_bytes(),'abilities').rows
    units=parse_slk((ROOT/'modified/Units_UnitAbilities.slk').read_bytes(),'units').rows
    for typ,d in DESIGNS.items():
        abilities=[]
        for k in ['abilList','heroAbilList']:abilities+=units[typ][k].value.split(',')
        a=d['id'];new=profiles[a]
        for old in abilities:
            if old not in profiles:continue
            check(profiles[old].get('buttonpos')!=new['buttonpos'],('no command-grid overlap',typ,old,a))
            if d['mode']=='active':
                check(profiles[old].get('hotkey')!=new['hotkey'],('no shortcut overlap',typ,old,a))
                if skills[old]['code'].value=='ANcl' and skills[old].get('DataF1'):
                    check(skills[old]['DataF1'].value!=skills[a]['DataF1'].value,('no ready-spell order collision',typ,old,a))
        check(new['name']==d['skill'] and new['buttonpos']=='2,1','each class has its own actual command name and slot')
        if d['mode']=='passive':
            tips=new['ubertip'].split(',')
            check(len(tips)==3 and len(set(tips))==3,'three different actual rank tooltips '+typ)
            check(skills[a]['hero'].value==0 and new['hotkey']=='_','passive not a phantom active command '+typ)
        else:check(new['hotkey']=='Z','active Z consistent '+typ)
    check(len({d['skill'] for d in DESIGNS.values()})==17,'17 unique mechanisms/names, no shared ultimate template')
    check(all(name not in SCRIPT for name in ['HopeThird_Rename','DzSetUnitName','DzSetUnitProperName']),'no name-changing function, native or Lua bridge remains')


def layout():
    w=Layout();g=w.g
    w.font_path=str(ROOT/'map-chinese-font.ttf')
    w.shot=Path('/workspace/outputs/ui-layout-v17');w.shot.mkdir(exist_ok=True)
    cmap=TTFont(w.font_path).getBestCmap()
    chars={c for d in DESIGNS.values() for c in description(d)+d['skill']+d['role'] if ord(c)>127}
    check(all(ord(c) in cmap for c in chars),'original font covers all new class wording')
    g['InitHashtable']=lambda:'third-ui';g['HopeThird_Init']()
    g.update({'GetUnitAbilityLevel':lambda u,a:u.abilities.get(a,0) if u else 0,
              'GetHeroSkillPoints':lambda u:u.points,'GetHeroStr':lambda u,b:30,'GetHeroAgi':lambda u,b:40,'GetHeroInt':lambda u,b:50,
              'HopeJob_InRoom':lambda p:True,'HopeJob_AdvancedOpen':lambda:True,'HopeJob_Round':lambda:4,
              'HopeRoute_RewardPending':lambda p:False})
    w.load('HopeJob_Visible','HopeJob_WoodCost','HopeJob_GoldCost','HopeJob_Blocker','HopeProfession_Text')
    u=g['udg_hero'][1];u.abilities={};u.points=2
    g['HopeJob_Entry']=2;g['HopeJob_LastType']=u.kind;g['HopeJob_Expanded']=True
    g['HopeJob_InPanel']=lambda index,p:index==g['HopeJob_Selected']
    w.resources[0,'lumber']=30;w.resources[0,'gold']=1000
    g['HopeLayout_Focus'](5)
    for index,o in enumerate(OPTIONS):
        if o['stage']!=3:continue
        d=DESIGNS[o['target']]
        u.kind=rawcode(o['source']);g['HopeJob_LastType']=u.kind;g['HopeJob_Selected']=index
        g['HopeJob_Awakened'][1]=False
        for page in range(3):
            g['HopeJob_Page']=page
            count=1 if page==0 else g['HopeJob_SkillCount' if page==1 else 'HopeJob_PassiveCount'][index]
            for detail in range(count):
                g['HopeJob_DetailPage']=detail;g['HopeJob_RefreshContent']();g['HopeLayout_Apply']()
                w.audit('third-card')
                save=page==1 and detail==1 and o['target'] in ['H00E','E010']
                w.render('third-'+o['target']+'-'+str(page)+'-'+str(detail),save)
        if d['mode']=='passive':
            u.kind=rawcode(o['target']);g['HopeJob_LastType']=u.kind
            g['HopeJob_Awakened'][1]=True;g['HopeJob_AwakenOption'][1]=index
            g['HopeJob_Page']=1;g['HopeJob_DetailPage']=1
            for rank in range(1,4):
                u.abilities[rawcode(d['id'])]=rank
                for points in [0,2]:
                    u.points=points;g['HopeJob_RefreshContent']();g['HopeLayout_Apply']()
                    status=w.frames[g['HopeJob_Status']].text
                    check(str(rank)+'/3级' in status and '技能点 '+str(points) in status,'research displays actual rank and points')
                    button=w.frames[g['HopeJob_Confirm'][index]].text
                    check(('已满级' in button) if rank==3 else ('1技能点' in button),'completed card uses research action instead of fee')
                    check('1000' not in button and '30木' not in button,'research never presents awakening cost')
                    w.audit('third-research')
                    w.render('research-'+o['target']+'-'+str(rank)+'-'+str(points),o['target']=='N018' and rank==1 and points==2)
    # Same compact row for new class counters, in every display state.
    g['HopeLayout_Focus'](0);g['HopeJob_Expanded']=False
    g['HopeLayout_Apply']();w.show(g['HopeQoL_Hud'],True)
    font=ImageFont.truetype(w.font_path,round(.0095*2400))
    for index,o in enumerate(OPTIONS):
        if o['stage']!=3:continue
        u.kind=rawcode(o['target']);g['HopeJob_Awakened'][1]=True;g['HopeJob_AwakenOption'][1]=index
        u.abilities[rawcode(DESIGNS[o['target']]['id'])]=3
        for n in range(8):
            token=g['HopeChallenge_TurnToken']()
            g['HopeThird_Cavalry'][1]=n%2==1
            g['HopeThird_ComboToken'][1]=token;g['HopeThird_ComboCount'][1]=n%2;g['HopeThird_ComboPaid'][1]=n>2
            g['HopeThird_PressureToken'][1]=token;g['HopeThird_Pressure'][1]=n%4
            g['HopeThird_HitsToken'][1]=token;g['HopeThird_Hits'][1]=n%3
            g['HopeThird_HiddenToken'][1]=token;g['HopeThird_HiddenMask'][1]=n
            value=g['HopeProfession_Text'](u,1)
            w.frames[g['HopeQoL_Status']].text=value+'|n背包 6/6 · 助手 6/6'
            text=re.sub(r'\|c[0-9a-fA-F]{8}|\|r','',value)
            check(font.getlength(text)<=.120*2400,('class counter stays on one line',text))
            w.audit('third-resource')
    print('Actual font:',len(chars),'Chinese/symbol characters checked.')


if __name__=='__main__':
    objects();layout()
    print(f'PASS: {COUNT} v15 command/profile/research/resource assertions; {validate_layout.CASES} actual-font geometry checks.')
    print('Coordinate/font simulation, not KK rendering.')
