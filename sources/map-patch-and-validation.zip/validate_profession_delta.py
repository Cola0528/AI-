"""Verify the HUD patch changes only two existing UI functions versus shipped v13."""
from pathlib import Path
import hashlib
import json
import re
import sys

sys.path.insert(0, '/workspace/map-tools')
from mpq import op, read, L
from modern_choices_patch import block
from profession_hud_patch import GLOBALS, HELPERS

ROOT = Path(__file__).parent
baseline = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/workspace/outputs/AI-Tower-Chinese-Names-v13.w3x')
assert hashlib.sha256(baseline.read_bytes()).hexdigest() == '9cdf5d11c3587032a32d2a4e646cd00803dc0dc845acc249341c40dc1013e3af'
h = op(baseline, 0x100)
try:
    old = read(h, 'war3map.j').decode('utf-8')
    objects = {'war3map.w3a': ROOT/'modified/war3map.w3a'}
    objects.update({'Units\\'+p.name[6:]: p for p in (ROOT/'modified').glob('Units_*')})
    for name, path in objects.items():
        assert read(h, name) == path.read_bytes(), name
finally:
    L.SFileCloseArchive(h)
new = (ROOT/'war3map-patched.j').read_text()
pattern = r'^function (\w+) takes.*?^endfunction'
old_functions = {m[1]: m[0] for m in re.finditer(pattern, old, re.M | re.S)}
new_functions = {m[1]: m[0] for m in re.finditer(pattern, new, re.M | re.S)}
changed = [k for k in old_functions if old_functions[k] != new_functions[k]]
added = sorted(set(new_functions)-set(old_functions))
assert set(changed) == {'HopeQoL_CreateUI', 'HopeQoL_RefreshContent'}, changed
assert added == ['HopeProfession_Text', 'HopeProfession_Update'], added
# Reverse the exact allowed additions, including globals and constructor lines.
restored = new.replace('globals\n'+GLOBALS, 'globals\n', 1).replace(HELPERS+'\n', '', 1)
for name in changed:
    restored = restored.replace(block(restored, name), block(old, name), 1)
assert restored == old, 'Unexpected changes outside the two UI functions'
report = {
    'baseline': baseline.name,
    'jass_sha256': hashlib.sha256(new.encode()).hexdigest(),
    'changed_existing_functions': changed,
    'new_functions': added,
    'unchanged_functions': len(old_functions)-len(changed),
    'unchanged_object_files': len(objects),
    'all_other_script_text_identical': True,
}
print(json.dumps(report, ensure_ascii=False, indent=2))
