"""Actual local tab callbacks and a six-player shared record stream."""
from pathlib import Path
import re
from validate_player_names import ActualFontLayout,original_font
from validate_economy import body,SCRIPT

COUNT=0
def check(ok,msg):
 global COUNT
 assert ok,msg
 COUNT+=1
def plain(s):return re.sub(r'\|c[0-9a-fA-F]{8}|\|r','',s)
def lines(w):return [w.g['HopeLog_Line'][i] for i in range(w.g['HopeLog_Count'])]

def run():
 original_font();clients=[ActualFontLayout(),ActualFontLayout()]
 names=['清风徐来','流浪的剑客','星河入梦','剑心','Cola★','小猫钓鱼']
 for local,w in enumerate(clients):
  w.playing=set(range(6));w.human=set(range(6));w.sender=local
  w.g['GetLocalPlayer']=lambda local=local:local
  w.g['GetPlayerName']=lambda p:names[p]
  w.load('HopeDraw_SaveRecord','HopeScroll_LogUp','HopeScroll_LogDown','HopeScroll_EnterLog','HopeScroll_Wheel','HopeScroll_Latest')
  for p in range(6):w.hero(p)
 def record(p,title,result,reveal=False):
  for w in clients:w.g['HopeDraw_SaveRecord'](p,title,result,reveal)
 record(1,'木材抽取结果 · 消耗1木材',clients[0].g['HopeDraw_Quality']('力量 +1'))
 record(0,'木材抽取结果 · 消耗1木材',clients[0].g['HopeDraw_Quality']('谢谢惠顾（未获得奖励）'))
 record(2,'木材十连结果 · 消耗10木材','|n'.join(str(i)+'. '+clients[0].g['HopeDraw_Quality']('全属性 +3') for i in range(1,11)),True)
 for w in clients:check(not w.g['HopeDraw_Open'],'teammate draw never opens local panel')
 w=clients[0];g=w.g;g['HopeDraw_Open']=True;g['HopeDraw_Teammates']();g['HopeDraw_Refresh']();g['HopeLayout_Apply']()
 text='|n'.join(lines(w));check('#3' in text and '#1' in text and '#2' not in text,'team tab contains teammates in newest-first order, excludes own')
 check(text.index('#3')<text.index('#1'),'global chronological order across owners')
 check('10. ' in text and '全属性 +3' in text,'full teammate ten-draw retained')
 check('星河入梦' in text and '流浪的剑客' in text,'Chinese teammate nicknames visible')
 check('|cffe4e5e4全属性 +3|r' in text and '|cff959697力量 +1|r' in text,'reward quality colors preserved independently of player header color')
 check(w.frames[g['HopeDraw_Panel']].w==.280 and w.frames[g['HopeDraw_Panel']].h==.226,'tabs keep compact existing panel size')
 w.audit('teammate-draw');w.render('teammate-draw')
 g['HopeScroll_LogDown']();g['HopeDraw_Refresh']();check(g['HopeLog_Offset']>0,'team history scrolls across multiple records')
 g['HopeDraw_Mine']();g['HopeDraw_Refresh']();check('谢谢惠顾' in '|n'.join(lines(w)) and '#3' not in '|n'.join(lines(w)),'own tab still isolated')
 check(g['HopeLog_Offset']==0,'tab switch resets scroll to newest')
 snapshot=dict(w.tables['HopeDraw_History']);debits=list(w.debits)
 for _ in range(4):g['HopeDraw_Teammates']();g['HopeDraw_Refresh']();g['HopeDraw_Mine']();g['HopeDraw_Refresh']()
 check(snapshot==w.tables['HopeDraw_History'] and debits==w.debits and not w.writes,'viewing tabs never awards, spends or writes cloud data')
 g['HopeDraw_Teammates']();g['HopeDraw_Refresh']()
 record(0,'十连抽结果 · 消耗648金币','本人奖励',True)
 check(g['HopeDraw_Open'] and not g['HopeDraw_Team'],'own revealed ten-draw selects own tab')
 check(not clients[1].g['HopeDraw_Open'],'other client remains closed')
 g['HopeDraw_Teammates']();g['HopeDraw_Refresh']()
 expected=[]
 for i in range(75):
  owner=1+i%5;record(owner,'木材抽取结果 · 消耗1木材','队友结果'+str(i));expected.append(g['HopeDraw_Serial'])
 # Own activity cannot evict teammate records: storage is bounded per owner.
 for i in range(80):record(0,'木材抽取结果 · 消耗1木材','我的结果'+str(i))
 g['HopeDraw_Refresh']();log=lines(w)
 serials=[int(re.search(r'#(\d+)',plain(s))[1]) for s in log if re.search(r' · #\d+',plain(s))]
 check(serials==list(reversed(expected[-64:])),'latest64 teammate batches survive heavy own activity')
 check(g['HopeLog_Count']==192,'64 teammate single draws list all 3 rows each')
 g['HopeScroll_LogDown']();g['HopeDraw_Refresh']();check(g['HopeLog_Offset']==3,'scroll increment remains3')
 g['HopeScroll_Latest']();g['HopeDraw_Refresh']();check(g['HopeLog_Offset']==0,'latest works on teammate tab')
 # Each client receives identical synchronized storage; local tabs differ.
 check(dict(clients[0].tables['HopeDraw_History'])==dict(clients[1].tables['HopeDraw_History']),'same records on both clients')
 check(clients[0].g['HopeDraw_Team'] and not clients[1].g['HopeDraw_Team'],'tabs remain local')
 for frame in [g['HopeDraw_MyTab'],g['HopeDraw_TeamTab']]:check(w.frames[frame].w==.044,'small tab button')
 empty=ActualFontLayout();empty.g['HopeDraw_Open']=True;empty.g['HopeDraw_Teammates']();empty.g['HopeDraw_Refresh']();empty.g['HopeLayout_Apply']()
 check('暂无队友' in empty.frames[empty.g['HopeDraw_Text']].text,'single-player empty state');empty.audit('empty-team');empty.render('empty-team',False)
 for offset in range(0,g['HopeLog_Count']-12,13):
  g['HopeLog_Offset']=offset;g['HopeDraw_Refresh']();g['HopeLayout_Apply']();w.render('team-scroll',False)
 print(f'PASS: {COUNT} teammate-tab assertions; synchronized records, six-player order, full ten results, latest64 retention, own/team isolation, local-only tabs, colors, scrolling and unchanged compact dimensions. Native calls mocked, not KK.')

if __name__=='__main__':run()
