"""New difficulty modes; all new pacing rules are gated to modes 5 and 6.

The input is the final class/economy script; apply before challenge_enemies.apply.
Original difficulty/default branches and map spawn points remain intact.
"""
from __future__ import annotations
import re

EARLY_HELPERS = r'''
// Keep turn identity separate from the unbounded challenge round counter.
function HopeChallenge_TurnToken takes nothing returns integer
if udg_Yx_Nd_Dj>=5 then
return HopeChallenge_TurnSerial
endif
return udg_quanshu*100000+udg_boci*1000+udg_huihe_s
endfunction
function HopeChallenge_NextTurn takes nothing returns nothing
local integer i=1
if udg_Yx_Nd_Dj<5 then
return
endif
if HopeChallenge_TurnSerial>=2000000000 then
set HopeChallenge_TurnSerial=1
loop
exitwhen i>6
set HopeMeditation_LastCast[i]=-1
set HopeHidden_LastHeal[i]=-1
set HopeHidden_LastDrain[i]=-1
set HopeJob_LastCast[i]=-1
set i=i+1
endloop
else
set HopeChallenge_TurnSerial=HopeChallenge_TurnSerial+1
endif
endfunction
function HopeChallenge_Won takes nothing returns boolean
if udg_Yx_Nd_Dj==6 then
return false
elseif udg_Yx_Nd_Dj==5 then
return udg_quanshu>=5
elseif udg_Yx_Nd_Dj<3 then
return udg_quanshu>=3
endif
return udg_quanshu>=4
endfunction
function HopeChallenge_BossPoints takes nothing returns integer
if udg_Yx_Nd_Dj>=5 then
if udg_quanshu>=19 then
return 25
endif
return udg_quanshu+6
endif
return udg_quanshu+1+udg_Yx_Nd_Dj
endfunction
function HopeChallenge_EnemyHp takes real base returns real
// Recalculate from this newly created unit, never from a previous round.
return RMinBJ(10000000.,base*(1.+.30*I2R(udg_quanshu))+100.*I2R(udg_quanshu))
endfunction
function HopeChallenge_EnemyAttack takes real base returns real
return RMinBJ(1000000.,base*(1.+.12*I2R(udg_quanshu)))
endfunction
function HopeChallenge_ScaleEnemy takes unit u returns nothing
if udg_Yx_Nd_Dj<5 or LoadBoolean(YDHT,GetHandleId(u),$487A4301) then
return
endif
call SaveBoolean(YDHT,GetHandleId(u),$487A4301,true)
call SaveReal(YDHT,GetHandleId(u),$3449D65E,RMinBJ(.65,RMaxBJ(0.,LoadReal(YDHT,GetHandleId(u),$3449D65E))))
call SetUnitState(u,UNIT_STATE_MAX_LIFE,HopeChallenge_EnemyHp(GetUnitState(u,UNIT_STATE_MAX_LIFE)))
call SetUnitLifePercentBJ(u,100.)
call SetUnitState(u,ConvertUnitState(18),HopeChallenge_EnemyAttack(GetUnitState(u,ConvertUnitState(18))))
endfunction
function HopeChallenge_NextMonsterCount takes nothing returns nothing
if udg_Yx_Nd_Dj>=5 then
// The map contains exactly 13 spawn markers. Normal fights may add one.
set udg_Guaiwu_sl=IMinBJ(12,udg_Guaiwu_sl+1)
else
set udg_Guaiwu_sl=udg_Guaiwu_sl+1
endif
endfunction
function HopeChallenge_ReleaseNode takes unit u returns nothing
local group links=null
if udg_Yx_Nd_Dj>=5 then
set links=LoadGroupHandle(YDHT,GetHandleId(u),$B5EB8DB8)
if links!=null then
call DestroyGroup(links)
endif
endif
set links=null
endfunction
'''


def replace_once(src: str, old: str, new: str, label: str) -> str:
    assert src.count(old) == 1, (label, src.count(old))
    return src.replace(old, new, 1)


def edit_function(src: str, name: str, edit) -> str:
    pattern = re.compile(r'(^function ' + name + r' takes .*?\n)(.*?)(^endfunction)', re.M | re.S)
    match = pattern.search(src)
    assert match, name
    return src[:match.start(2)] + edit(match[2]) + src[match.end(2):]


def apply(src: str) -> str:
    assert 'function HopeChallenge_Won ' not in src
    src, count = re.subn(r'^globals\n', 'globals\ninteger HopeChallenge_TurnSerial=1\n', src, count=1, flags=re.M)
    assert count == 1
    # All prior modes retain the existing token formula. New modes use a serial
    # advanced once per actual combat turn, including transitions between rooms.
    expected = src.count('udg_quanshu*100000+udg_boci*1000+udg_huihe_s')
    assert expected == 3, expected
    src = src.replace('udg_quanshu*100000+udg_boci*1000+udg_huihe_s', 'HopeChallenge_TurnToken()')
    first = re.search(r'^function ', src, re.M).start()
    src = src[:first] + EARLY_HELPERS + '\n' + src[first:]
    src = replace_once(src, 'set udg_huihe_s=udg_huihe_s+1', 'set udg_huihe_s=udg_huihe_s+1\ncall HopeChallenge_NextTurn()', 'turn identity')
    dialog = 'call SaveInteger(YDHT,GetHandleId(GetLastCreatedButtonBJ()),$340FE72,4)'
    src = replace_once(src, dialog, dialog + '\ncall DialogAddButtonBJ(udg_Youxi_ND_XZ,"炼狱（5轮）")\ncall SaveInteger(YDHT,GetHandleId(GetLastCreatedButtonBJ()),$340FE72,5)\ncall DialogAddButtonBJ(udg_Youxi_ND_XZ,"无限挑战（无限轮）")\ncall SaveInteger(YDHT,GetHandleId(GetLastCreatedButtonBJ()),$340FE72,6)', 'difficulty buttons')
    def selection(body):
        anchor = 'call ForForce(GetPlayersAll(),function Trig____________________006Func006A)'
        new = r'''if LoadInteger(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$B43FB128)==5 or LoadInteger(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$B43FB128)==6 then
set udg_Yx_Nd_Dj=LoadInteger(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$B43FB128)
set udg_ND_sz=5
set udg_diren_xueliang=250.
call SetPlayerHandicapBJ(Player(11),250.)
call ForForce(GetPlayersAll(),function Trig____________________006Func005Func004A)
call SaveReal(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$FBEDEC54,.5)
if udg_Yx_Nd_Dj==5 then
call DisplayTimedTextToForce(GetPlayersAll(),15.,"炼狱：击败第5轮最终BOSS通关。怪物基础生命250%，每轮生命和攻击继续增长；第5轮出现新敌人。")
else
call DisplayTimedTextToForce(GetPlayersAll(),15.,"无限挑战：没有通关轮数，击败本轮BOSS后继续下一轮，直到队伍失败。以炼狱为基础，第5轮起新敌人轮换，怪物逐轮变强。")
endif
endif
'''
        return replace_once(body, anchor, new + anchor, 'new difficulty state')
    src = edit_function(src, 'Trig____________________006Actions', selection)
    def rounds(body):
        start = body.index('if udg_Yx_Nd_Dj<3 then\n')
        stop = body.index('set udg_boci=1', start)
        victory = '''if HopeChallenge_Won() then
call CustomVictoryBJ(Player(0),true,true)
call CustomVictoryBJ(Player(1),true,true)
call CustomVictoryBJ(Player(2),true,true)
call CustomVictoryBJ(Player(3),true,true)
call CustomVictoryBJ(Player(4),true,true)
call CustomVictoryBJ(Player(5),true,true)
call DisableTrigger(GetTriggeringTrigger())
else
if udg_Yx_Nd_Dj>=5 then
call DisplayTimedTextToForce(GetPlayersAll(),12.,"即将进入第"+I2S(udg_quanshu+1)+"轮。三转需要30木材；新一轮敌人已强化。")
endif
endif
'''
        body = body[:start] + victory + body[stop:]
        return replace_once(body, 'set udg_Guaiwu_sl=udg_Guaiwu_sl+1', 'call HopeChallenge_NextMonsterCount()', 'monster count')
    src = edit_function(src, 'Trig_X_____________004Actions', rounds)
    def spawn(body):
        return replace_once(body, 'if udg_quanshu>1 then', 'if udg_Yx_Nd_Dj>=5 then\ncall HopeChallenge_ScaleEnemy(GetTriggerUnit())\nelseif udg_quanshu>1 then', 'new enemy progression')
    src = edit_function(src, 'Trig_G_____________004Actions', spawn)
    src = edit_function(src, 'Trig_X_____________004Func001A', lambda body: replace_once(body, 'call RemoveUnit(GetEnumUnit())', 'call HopeChallenge_ReleaseNode(GetEnumUnit())\ncall RemoveUnit(GetEnumUnit())', 'release route links'))
    src = replace_once(src, '$E58119D,udg_quanshu+1+udg_Yx_Nd_Dj)', '$E58119D,HopeChallenge_BossPoints())', 'bounded reward')
    return src
