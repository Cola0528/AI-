# v16 加载兼容修复源码

当前地图输出为AI-Tower-LoadFix-v16.w3x。路径、原图和StormLib/pjass依赖沿用下方v15说明。

本次新增third_name_compat.py；第三转生成器仅在觉醒后调用其可选改名桥接，不声明新的KK native。对象生成器未改动。

本版验证顺序：

```sh
python -m pip install --target /tmp/map-lua-test lupa==2.8
cd /workspace/map-edit
python build_patch.py
python build_objects.py
/workspace/map-tools/pjass/pjass /workspace/map-tools/common.j /workspace/map-tools/Blizzard.j war3map-patched.j
python validate_load_compat.py
python validate_name_bridge.py
python validate_third.py
python -c 'from validate_player_names import original_font; original_font()'
python validate_third_ui.py
python validate_third_delta.py
python pack_map.py
```

Lupa的Lua 5.1仅用于执行兼容性检查，不进入地图文件。validate_load_compat.py需要/workspace/outputs下的原发布v14/v15地图，固定哈希防止基准被覆盖。v14下载地址见下方历史说明；v15地址：https://github.com/Cola0528/AI-/raw/abd44e212baca239796f24f7167e7515ea7e5d92/maps/AI-Tower-Class-Awakening-v15.w3x。

本版记录为load-compat-v16-check.log、name-compat-v16-check.log、third-v16-check.log、third-ui-v16-check.log、delta-v16-check.log、pack-v16-check.log、patch-check.log及verification-manifest.json。历史版本的日志保留但未全部重跑；当前没有KK客户端。

---

# v15 修改源码与验证

本版构建输入仍是最初上传的原地图，SHA-256为fa23c768f274abfe6a44e8e62cfe8aa63bfe30c52cbda9cd83dc122991d07174。解压到/workspace/map-edit；原图放/workspace/attachments，输出/workspace/outputs。

复用当前云环境的/workspace/map-tools/mpq.py、storm-build/libstorm.so、pjass/pjass、common.j、Blizzard.j，以及Python的mpyq、Pillow、fontTools。工具依赖不包含在本源码包内。

本版推荐构建与验证命令：

```sh
python /workspace/map-edit/build_patch.py
python /workspace/map-edit/build_objects.py
/workspace/map-tools/pjass/pjass /workspace/map-tools/common.j /workspace/map-tools/Blizzard.j /workspace/map-edit/war3map-patched.j
python /workspace/map-edit/validate_object_dependencies.py
python /workspace/map-edit/validate_awaken_cost.py
python /workspace/map-edit/validate_third.py
python /workspace/map-edit/validate_third_calls.py
python /workspace/map-edit/validate_firemage.py
python /workspace/map-edit/validate_v12.py
cd /workspace/map-edit
python -c 'from validate_player_names import original_font; original_font()'
python validate_third_ui.py
python validate_layout.py
python validate_profession_hud.py
python validate_third_delta.py /path/to/AI-Tower-Class-Resources-v14.w3x
python pack_map.py
```

最后一项差异比较使用原发布v14文件，获取地址：https://github.com/Cola0528/AI-/raw/8f7d8fc2eb760cc8dab0c72e8802156e8927460a/maps/AI-Tower-Class-Resources-v14.w3x。

产物为AI-Tower-Class-Awakening-v15.w3x；pack_map.py重新读取每个写入文件并核对未改资源块。归档时间等元数据可能造成重打包整图哈希不同，以本次verification-manifest.json为准。

third_design.py集中定义17职业机制与专属奖励；build_patch在monk选项之后应用这些定义。最终追加third_patch和third_presentation；对象构建最后运行third_objects，写入完整SLK模板。third_combat.j与third_active.j是生成器必需输入，不可遗漏。研究操作沿用既有同步转职消息，消耗真实英雄技能点；UI预览与状态刷新只读取数据。原生改名只操作本英雄实例。

当前有效检查记录见修改说明与测试要点.md中的v15部分及*-v15-check.log。下面的说明保留历史版本设计与旧检查命令；旧验证器中的历史模板断言不一定适用于v15，不是本版完整验证入口。运行检查不能替代KK客户端加载与联机验证。

---

# v14 修改源码与界面验证

这份源码包包含补丁生成器、原始脚本与必要数据、生成结果、旧版错误技能样例以及验证器。原始 .w3x 地图需使用最初上传的原文件；其 SHA-256 见 verification-manifest.json。

在当前云工作区中的路径约定：

- 本目录解压为 /workspace/map-edit。
- 最初上传的原地图位于 /workspace/attachments 下，保持该目录只有一张用于本次构建的原图。
- /workspace/map-tools 中包含 mpq.py、StormLib 动态库、mpyq 和 pjass；这些构建依赖不在本源码包中。
- /workspace/outputs 为输出目录。

按以下顺序运行：

```sh
python /workspace/map-edit/build_patch.py
python /workspace/map-edit/build_objects.py
python /workspace/map-edit/validate_patch.py
python /workspace/map-edit/validate_economy.py
python /workspace/map-edit/validate_hidden.py
python /workspace/map-edit/validate_poison.py
python /workspace/map-edit/validate_firemage.py
python /workspace/map-edit/validate_commands.py
python /workspace/map-edit/validate_awaken_cost.py
python /workspace/map-edit/validate_v8_ui.py
python /workspace/map-edit/validate_layout.py
python /workspace/map-edit/validate_wood_shop.py
python /workspace/map-edit/validate_compact_ui.py
python /workspace/map-edit/validate_v12.py
python /workspace/map-edit/validate_player_names.py
python /workspace/map-edit/validate_event_text.py
python /workspace/map-edit/validate_team_draw.py
python /workspace/map-edit/validate_wood_ten.py
python /workspace/map-edit/validate_challenge.py
python /workspace/map-edit/validate_enemies.py
python /workspace/map-edit/validate_coop.py
python /workspace/map-edit/validate_priest.py
python /workspace/map-edit/validate_reclass.py
/workspace/map-tools/pjass/pjass /workspace/map-tools/common.j /workspace/map-tools/Blizzard.j /workspace/map-edit/war3map-patched.j
python /workspace/map-edit/pack_map.py
```

主生成器应用 points_patch.py、shop_patch.py、growth_patch.py，新增共享积分扣款、永久礼包抽奖与成长界面；hidden_patch.py/hidden_objects.py 完善隐藏职业主动技能及各阶段Q说明，poison_patch.py 修正范围数值分隔文字。validate_economy.py 验证消费与成长状态边界；validate_hidden.py 验证实际随机转职回调和治疗/汲取边界；validate_poison.py 验证毒伤范围显示及原伤害逻辑保留；firemage_patch.py 只修复炎爆三个等级的命令及按钮位置；validate_firemage.py 检查命令分离和原战斗逻辑保留，validate_commands.py 对17条三转路线核对Z快捷键、位置与命令冲突；validate_patch.py 会执行独立对象依赖验证。validate_awaken_cost.py 验证所有三转的30木材门槛、确认时余额重检、重复点击与多人扣费隔离。fixtures/v1-invalid-abilities.w3a 是已知有问题的 v1 数据，只用于确认检查能发现缺失基类，不会写入新地图。

v7在既有补丁之后依次应用priest_patch、challenge_patch、enemies_patch、coop_patch、reclass_patch；职业选项生成前同步priest/reclass文案。对象构建末尾应用priest_patch.apply_objects和challenge_objects.apply_objects。新增五份验证器分别覆盖模式与轮次、敌人池/真实技能、多人数值快照、牧师伤害与恢复保留，以及重新转职的扣费/被动/装备/技能点回滚。新模式的每回合技能次数使用独立令牌，旧模式仍使用原轮次公式；公共模拟器自动载入实际令牌与重转资格函数。

pack_map.py 总是从原地图复制再写补丁，跳过内容相同的文件，核对封装后的修改内容和未修改资源块。生成的地图文件名为 AI-Tower-Class-Resources-v14.w3x。重新打包可能产生不同归档时间等元数据，以本次 verification-manifest.json 的完整文件哈希为准。

本验证环境不包含魔兽争霸 III 或 KK 对战平台，模拟检查与静态检查不等于客户端加载、UI、联机及平衡测试。请对最终打包文件进行实机测试。

v8依次应用presentation_patch、modern_choices_patch、route_ui_patch、draw_ui_patch、damage_board_patch。选择窗口保留原隐藏对话框的数据句柄和奖励处理器，展示使用现代frame；木材抽取与十连共用原概率树，并保存本局最近64条记录。路线选择、玩家指定与出发均经同步回调，只有显示开关与榜单页签为本地状态。validate_v8_ui覆盖真实回调及800组原奖池对照。

v9最后应用layout_patch.py，集中处理入口、弹窗尺寸和本地可见性。validate_layout.py调用真实生成脚本的界面构造/定位函数并检查矩形与文字；PNG使用Pillow与NotoSansCJK-Regular.ttc，仅作布局示意。layout-check.log与patch-check.log分别记录本次布局检查和编译结果。

v10在layout补丁后应用wood_shop_patch和compact_ui_patch；对象构建新增原生ItemData及itemstrings商品，只有能力商人出售。新物品由原生商店收取1木，回调不重复扣费；拒绝时退款。记录改为本地连续滚动，R说明在生成期进行UTF-8安全换行。validate_wood_shop和validate_compact_ui覆盖新商品与交互，均不代替KK实机。

v11直接在build_patch.py移除泉水定时刷新中的自动打开分支，并删除reclass_patch.py对该旧分支的替换。手动按钮和建筑选择回调保持有效。manual-career-check.log为本次定向验证记录；其余布局/滚动日志记录此前版本检查。


v12最后应用inventory_event_patch与monk_patch；生成职业选项时先运行monk_patch.update_options。物品表修改采用显式坐标写回，保留原表各值，只变更已列明字段。phea改成不占格、无原生治疗的次数商品；四件被动装备关闭usable。共用装备投递接入奖励、抽奖和合成；事件文本成为全客户端共享记录，本地窗口开关不进入游戏逻辑。秘籍领悟改为每个枚举队友收到自己的加成。

monk_patch重做N01G的三个主动和专属三转AZ36，新增气与每回合记录；原生A059/A05C费用清零，由脚本单独扣费，避免双扣，原A05A修炼保留。完整的运行验证与边界在validate_v12.py。v12发布时日志为v12-check.log、layout-v12-check.log、compact-v12-check.log、v8-regression-v12-check.log、wood-shop-v12-check.log、patch-check.log、validation-check.log、commands-check.log、priest-check.log、awaken-cost-check.log、hidden-check.log与pack-v12-check.log。其他日志为历史版本运行结果，尤其manual-career-check.log记录v11相对v10的差异，不是v12的完整差异。

validate_monk_layout.py与monk-layout-v12-check.log检查最终9个僧侣二/三转页面，断言实际选项保留、面板可见和文字不越界。


v13最后依次应用player_names_patch、team_draw_patch、draw_quality_patch、wood_ten_patch。inventory_event_patch使用event_text_patch保留全部原事件文字、分开故事与彩色结算；UTF-8名字辅助最早注入，供换行及本地显示共用。颜色辅助保留玩家色系并提亮深色。队友记录共享已同步的每人64批数据，并保存全局序号/昵称；页签和合并缓存只用于本地UI，不进入奖励或存档逻辑。木材十连是独立10木材商品，每次仍50%空奖，原648金币十连保留。

对象构建最后执行wood_ten_patch.apply_objects：新增完整IZWT行和物品说明；原商人保留三本属性书，两个抽奖商品仅动态供货，售后先移除再补回。生成地图保留原二进制技能数据。

validate_player_names使用fontTools/Pillow从原MPQ提取map-chinese-font.ttf作为临时输入，源码包不重复包含该字体。公共模拟器以surrogateescape模拟JASS的UTF-8字节切片，避免截断字节被Python默默丢弃。昵称/事件/队友页签检查使用原图字体；通用validate_layout仍默认替代字体，可设置font_path覆盖。

本版日志以*-v13-check.log、names-v13-check.log、patch-check.log、verification-manifest.json为准；v12及更早的日志保留为历史记录，不表示本版重新运行。所有脚本动态检查使用原生函数替身，没有KK客户端。完整本版检查清单见修改说明与测试要点.md。


v14最终新增profession_hud_patch，只在HopeQoL_CreateUI构造子标签，在HopeQoL_RefreshContent中读取实际资源；每0.2秒刷新。profession_hud_patch不修改任何对象或战斗函数。

本版新增验证：`python /workspace/map-edit/validate_profession_hud.py`。需先提取原图字体，可运行`python -c "from validate_player_names import original_font; original_font()"`，或使用已有的map-chinese-font.ttf。新增行在validate_layout的模拟图中按实际状态色显示。

与v13精确差异验证：`python /workspace/map-edit/validate_profession_delta.py /path/to/AI-Tower-Chinese-Names-v13.w3x`，要求v13原发布文件（SHA-256校验固定）。可从https://github.com/Cola0528/AI-/raw/31aeb155474569196bb9f3efa8a1950a40941c6b/maps/AI-Tower-Chinese-Names-v13.w3x取得。

本版日志为profession-hud-v14-check.log、layout-v14-check.log、v12-regression-v14-check.log、delta-v14-check.log、pack-v14-check.log、patch-check.log及verification-manifest.json。v13及更早日志保留为历史，不表示本版重新运行。当前没有KK/魔兽客户端；所有动态检查使用原生函数替身。
