# v11 修改源码与界面验证

这份源码包包含补丁生成器、原始脚本与必要数据、生成结果、旧版错误技能样例以及验证器。原始 .w3x 地图需使用最初上传的原文件；其 SHA-256 见 verification-manifest.json。

在当前云工作区中的路径约定：

- 本目录解压为 /workspace/map-edit。
- 最初上传的原地图位于 /workspace/attachments 下，保持该目录只有一张用于本次构建的原图。
- /workspace/map-tools 中包含 mpq.py、StormLib 动态库、mpyq 和 pjass；这些构建依赖不在本源码包中。
- /workspace/outputs 为输出目录。

按以下顺序运行：

```sh
python /workspace/map-edit/build_patch.py
python /workspace/map-edit/build_objects.py
python /workspace/map-edit/validate_patch.py
python /workspace/map-edit/validate_economy.py
python /workspace/map-edit/validate_hidden.py
python /workspace/map-edit/validate_poison.py
python /workspace/map-edit/validate_firemage.py
python /workspace/map-edit/validate_commands.py
python /workspace/map-edit/validate_awaken_cost.py
python /workspace/map-edit/validate_v8_ui.py
python /workspace/map-edit/validate_layout.py
python /workspace/map-edit/validate_wood_shop.py
python /workspace/map-edit/validate_compact_ui.py
python /workspace/map-edit/validate_challenge.py
python /workspace/map-edit/validate_enemies.py
python /workspace/map-edit/validate_coop.py
python /workspace/map-edit/validate_priest.py
python /workspace/map-edit/validate_reclass.py
/workspace/map-tools/pjass/pjass /workspace/map-tools/common.j /workspace/map-tools/Blizzard.j /workspace/map-edit/war3map-patched.j
python /workspace/map-edit/pack_map.py
```

主生成器应用 points_patch.py、shop_patch.py、growth_patch.py，新增共享积分扣款、永久礼包抽奖与成长界面；hidden_patch.py/hidden_objects.py 完善隐藏职业主动技能及各阶段Q说明，poison_patch.py 修正范围数值分隔文字。validate_economy.py 验证消费与成长状态边界；validate_hidden.py 验证实际随机转职回调和治疗/汲取边界；validate_poison.py 验证毒伤范围显示及原伤害逻辑保留；firemage_patch.py 只修复炎爆三个等级的命令及按钮位置；validate_firemage.py 检查命令分离和原战斗逻辑保留，validate_commands.py 对17条三转路线核对Z快捷键、位置与命令冲突；validate_patch.py 会执行独立对象依赖验证。validate_awaken_cost.py 验证所有三转的30木材门槛、确认时余额重检、重复点击与多人扣费隔离。fixtures/v1-invalid-abilities.w3a 是已知有问题的 v1 数据，只用于确认检查能发现缺失基类，不会写入新地图。

v7在既有补丁之后依次应用priest_patch、challenge_patch、enemies_patch、coop_patch、reclass_patch；职业选项生成前同步priest/reclass文案。对象构建末尾应用priest_patch.apply_objects和challenge_objects.apply_objects。新增五份验证器分别覆盖模式与轮次、敌人池/真实技能、多人数值快照、牧师伤害与恢复保留，以及重新转职的扣费/被动/装备/技能点回滚。新模式的每回合技能次数使用独立令牌，旧模式仍使用原轮次公式；公共模拟器自动载入实际令牌与重转资格函数。

pack_map.py 总是从原地图复制再写补丁，跳过内容相同的文件，核对封装后的修改内容和未修改资源块。生成的地图文件名为 AI-Tower-Manual-Career-v11.w3x。重新打包可能产生不同归档时间等元数据，以本次 verification-manifest.json 的完整文件哈希为准。

本验证环境不包含魔兽争霸 III 或 KK 对战平台，模拟检查与静态检查不等于客户端加载、UI、联机及平衡测试。请对最终打包文件进行实机测试。

v8依次应用presentation_patch、modern_choices_patch、route_ui_patch、draw_ui_patch、damage_board_patch。选择窗口保留原隐藏对话框的数据句柄和奖励处理器，展示使用现代frame；木材抽取与十连共用原概率树，并保存本局最近64条记录。路线选择、玩家指定与出发均经同步回调，只有显示开关与榜单页签为本地状态。validate_v8_ui覆盖真实回调及800组原奖池对照。

v9最后应用layout_patch.py，集中处理入口、弹窗尺寸和本地可见性。validate_layout.py调用真实生成脚本的界面构造/定位函数并检查矩形与文字；PNG使用Pillow与NotoSansCJK-Regular.ttc，仅作布局示意。layout-check.log与patch-check.log分别记录本次布局检查和编译结果。

v10在layout补丁后应用wood_shop_patch和compact_ui_patch；对象构建新增原生ItemData及itemstrings商品，只有能力商人出售。新物品由原生商店收取1木，回调不重复扣费；拒绝时退款。记录改为本地连续滚动，R说明在生成期进行UTF-8安全换行。validate_wood_shop和validate_compact_ui覆盖新商品与交互，均不代替KK实机。

v11直接在build_patch.py移除泉水定时刷新中的自动打开分支，并删除reclass_patch.py对该旧分支的替换。手动按钮和建筑选择回调保持有效。manual-career-check.log为本次定向验证记录；其余布局/滚动日志记录此前版本检查。
