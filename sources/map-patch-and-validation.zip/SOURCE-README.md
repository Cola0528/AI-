# v4 修改源码与静态验证

这份源码包包含补丁生成器、原始脚本与必要数据、生成结果、旧版错误技能样例以及验证器。原始 .w3x 地图需使用最初上传的原文件；其 SHA-256 见 verification-manifest.json。

在当前云工作区中的路径约定：

- 本目录解压为 /workspace/map-edit。
- 最初上传的原地图位于 /workspace/attachments 下，保持该目录只有一张用于本次构建的原图。
- /workspace/map-tools 中包含 mpq.py、StormLib 动态库、mpyq 和 pjass；这些构建依赖不在本源码包中。
- /workspace/outputs 为输出目录。

按以下顺序运行：

```sh
python /workspace/map-edit/build_patch.py
python /workspace/map-edit/build_objects.py
python /workspace/map-edit/validate_patch.py
python /workspace/map-edit/validate_economy.py
python /workspace/map-edit/validate_hidden.py
python /workspace/map-edit/validate_poison.py
/workspace/map-tools/pjass/pjass /workspace/map-tools/common.j /workspace/map-tools/Blizzard.j /workspace/map-edit/war3map-patched.j
python /workspace/map-edit/pack_map.py
```

主生成器应用 points_patch.py、shop_patch.py、growth_patch.py，新增共享积分扣款、永久礼包抽奖与成长界面；hidden_patch.py/hidden_objects.py 完善隐藏职业主动技能及各阶段Q说明，poison_patch.py 修正范围数值分隔文字。validate_economy.py 验证消费与成长状态边界；validate_hidden.py 验证实际随机转职回调和治疗/汲取边界；validate_poison.py 验证毒伤范围显示及原伤害逻辑保留；validate_patch.py 会执行独立对象依赖验证。fixtures/v1-invalid-abilities.w3a 是已知有问题的 v1 数据，只用于确认检查能发现缺失基类，不会写入新地图。

pack_map.py 总是从原地图复制再写补丁，跳过内容相同的文件，核对封装后的修改内容和未修改资源块。生成的地图文件名为 AI-Tower-Growth-GiftDraw-v4.w3x。重新打包可能产生不同归档时间等元数据，以本次 verification-manifest.json 的完整文件哈希为准。

本验证环境不包含魔兽争霸 III 或 KK 对战平台，模拟检查与静态检查不等于客户端加载、UI、联机及平衡测试。请对最终打包文件进行实机测试。
