# v17 源码与验证

输出AI-v17.w3x。用户确认可进入的基准是v12；v13～v16均报告加载崩溃。本版没有KK实机测试，详见修改说明与测试要点.md。

## 当前环境

解压到/workspace/map-edit。原地图放在/workspace/attachments下，保持该目录仅有最初上传的.w3x；SHA-256为fa23c768f274abfe6a44e8e62cfe8aa63bfe30c52cbda9cd83dc122991d07174。输出目录/workspace/outputs。

当前云环境已验证的工具为/workspace/map-tools/mpq.py、storm-build/libstorm.so、python/mpyq、pjass/pjass、common.j、Blizzard.j，以及Python Pillow和fontTools。工具和原地图不在源码ZIP内。直接复用现有checkout，无须创建worktree。

旧版接口库放在/workspace/map-tools/legacy24/common.j和Blizzard.j，来源为https://github.com/actboy168/YDWE/tree/a69c315ebf2886ec54d66200707ab6e38bd3484d/Development/Component/compiler/jass/24 。common.j SHA-256为8357c64cb94b7a6fc2fb7b7e7846eb6e2e884828f6b4df4d685bcc5c2a7a5e05，Blizzard.j为2940674ddd5d9dbaf84df2490b609d3d606c66db6c70fbf11a7940d4209ddfed。核对原始字节后再使用。

## 本版构建和检查

```sh
cd /workspace/map-edit
python build_patch.py
python build_objects.py
/workspace/map-tools/pjass/pjass /workspace/map-tools/legacy24/common.j /workspace/map-tools/legacy24/Blizzard.j war3map-patched.j
python validate_load_v17.py
python validate_utf8_compat.py
python validate_player_names.py
python validate_profession_hud.py
python validate_third.py
python validate_third_calls.py
python validate_third_ui.py
python validate_event_text.py
python validate_wood_ten.py
python validate_team_draw.py
python validate_object_dependencies.py
python pack_map.py
```

validate_player_names.py会从原图提取字体，需在HUD/三转布局验证前执行。以上全部已在当前工作区运行通过；图像为字体/坐标模拟，不是KK截图。没有后台服务需要启动。

validate_load_v17.py需要/workspace/outputs中以下不可变历史地图，脚本会核对固定哈希：

- v12：https://github.com/Cola0528/AI-/raw/332dd9089a0e0e95d360cf4cc9231bd2817c6f99/maps/AI-Tower-Team-Events-Monk-v12.w3x
- v13：https://github.com/Cola0528/AI-/raw/31aeb155474569196bb9f3efa8a1950a40941c6b/maps/AI-Tower-Chinese-Names-v13.w3x
- v16：https://github.com/Cola0528/AI-/raw/153cdb49b81760859505ffbcb3b319f7ade4a1df/maps/AI-Tower-LoadFix-v16.w3x

warcraft_hash.py生成纯ASCII的字符分派代码；fixtures/utf8-hash-reference.json来自独立编译的公开C++参考实现。地图运行调用原生StringHash，Python实现仅用于生成与验证。

profession_hud_patch.py复用现有状态框。third_patch.py已移除全部运行时改名；源码包不再包含废弃的改名桥接及其验证器。third_objects.py只缩短多级被动的重复说明。third_combat.j和third_active.j仍是构建所需输入。

本版日志为*-v17-check.log、object-build-v17.log、patch-check.log、verification-manifest.json。保留的其它日志/验证器供历史追踪，含旧模板断言，不是当前统一入口；不要以历史通过日志代替重跑结果。重打包可能因MPQ元数据时间而改变整图哈希，以当次manifest为准。
