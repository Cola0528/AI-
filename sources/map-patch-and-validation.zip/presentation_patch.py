"""Clear learned descriptions without changing combat formulas."""
import re
from hidden_objects import update_section

POISON = ('投矛命中时，为目标叠加自己来源的2层毒；已有30层或以上时改为1层。'
          '|n敌方回合结算：当前攻击力×30%×毒层数×毒矛等级。'
          '|n这是结算前基值；最终伤害、暴击和目标减伤按战斗规则另算。'
          '|n结算后毒层数减少1；不同玩家的毒独立计算。')

def update_options(options):
    for o in options:
        for field in ('passive','skills'):
            o[field]=o[field].replace('每层每轮毒伤基值 ', POISON)

def apply(src):
    start=src.index("elseif id=='A02U' then",src.index('function HopeSkill_Original '))
    end=src.index("elseif id=='A03B' then",start)
    src=src[:start]+"elseif id=='A02U' then\nreturn \""+POISON+"\"\n"+src[end:]
    src=src.replace('elseif HaveSavedString(HopeSkill_Base,h,key) then',"elseif id!='A02U' and HaveSavedString(HopeSkill_Base,h,key) then")
    src=src.replace('每层每轮毒伤基值 ', '每层每个敌方回合的毒伤基值 ')
    src=src.replace('玩家选择了简单难度,该难度下所有怪物血量为80%','已选择简单难度：敌方基础生命倍率100%。')
    src=src.replace('|n|cff959697杀戮尖塔最垃圾技能之一|r','')
    src=src.replace('|n|cff959697就是原版的刀阵旋风，站原地当然打不到人了|r','|n以施法者为中心；范围外敌人不会受伤。')
    return src

def apply_objects(root, output):
    p=output/'Units_campaignabilitystrings.txt'
    s=p.read_text()
    s=update_section(s,'A02U',{'Researchubertip':POISON,'Ubertip':','.join([POISON]*3)})
    p.write_text(s)
