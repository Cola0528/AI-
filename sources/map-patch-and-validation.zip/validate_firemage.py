"""Check shipped Channel orders and unchanged fire-mage combat dispatch.

These are data and script checks, not a Warcraft/KK engine simulation.
"""
from pathlib import Path
import argparse
import re
from validate_object_dependencies import parse_slk, parse_profile, value


def functions(src):
    pattern = (r'^function ((?:Trig_JN_______005\w*|InitTrig_JN_______005|'
               r'Trig_JN__________0001\w*|InitTrig_JN__________0001)) '
               r'takes.*?^endfunction$')
    return {m[1]: m[0] for m in re.finditer(pattern, src, re.M | re.S)}


def without_priest_branch(block):
    """Retain the complete fireball branch and shared projectile/resource code."""
    lines = block.splitlines(keepends=True)
    start = next(i for i, line in enumerate(lines) if line.strip() == 'if GetSpellAbilityId()==$41303046 then')
    depth = 0
    split = None
    for i in range(start, len(lines)):
        line = lines[i].strip()
        if line.startswith('if '):
            depth += 1
        elif line == 'else' and depth == 1:
            split = i
        elif line == 'endif':
            depth -= 1
            if depth == 0:
                assert split is not None
                return ''.join(lines[:split + 1]) + '// priest damage validated separately\n' + ''.join(lines[i:])
    raise AssertionError('Missing shared fireball/priest branch')


def validate(root=None, modified=None, script=None):
    root = Path(root) if root else Path(__file__).resolve().parent
    modified = Path(modified) if modified else root / 'modified'
    script = Path(script) if script else root / 'war3map-patched.j'
    original = parse_slk((root / 'Units_AbilityData.slk').read_bytes(), 'original abilities')
    current = parse_slk((modified / 'Units_AbilityData.slk').read_bytes(), 'shipped abilities')
    old_profiles = parse_profile((root / 'Units_campaignabilitystrings.txt').read_bytes(), 'original profiles')
    profiles = parse_profile((modified / 'Units_campaignabilitystrings.txt').read_bytes(), 'shipped profiles')
    units = parse_slk((modified / 'Units_UnitAbilities.slk').read_bytes(), 'shipped unit skills')
    pyro = current.rows['A04U']
    assert value(pyro, 'code') == 'ANcl'
    assert value(pyro, 'levels') == 3
    assert value(current.rows['A00F'], 'DataF1') == 'channel'
    assert current.rows['A00F'] == original.rows['A00F'], 'Fireball data must remain unchanged'
    changed = set(pyro) - set(original.rows['A04U'])
    assert changed == {'DataF1', 'DataF2', 'DataF3'}, changed
    assert {k: v for k, v in pyro.items() if k not in changed} == original.rows['A04U']
    assert profiles['A00F'] == old_profiles['A00F'], 'Fireball command and description must remain unchanged'
    expected_profile = {**old_profiles['A04U'], 'order': 'acidbomb', 'buttonpos': '2,2'}
    assert profiles['A04U'] == expected_profile, 'Only pyroblast order/button position may change'
    assert profiles['A04U']['hotkey'] == 'E' and profiles['A00F']['hotkey'] == 'Q'
    assert profiles['A04U']['buttonpos'] != profiles['A00F']['buttonpos']
    assert 'A00F' in value(units.rows['N01E'], 'abilList').split(',')
    assert 'A04U' in value(units.rows['N01E'], 'heroAbilList').split(',')

    # With both abilities ready, each command must select one unique rawcode.
    # The old configuration has two candidates for "channel". Cooldown only
    # hides the conflict; it cannot be used as a dispatch mechanism.
    for rank in range(1, 4):
        key = 'DataF' + str(rank)
        assert key not in original.rows['A04U']
        assert old_profiles['A04U']['order'] == 'channel'
        assert value(pyro, key) == 'acidbomb'
        assert value(pyro, 'Cool' + str(rank)) == 1800
        assert value(pyro, 'DataB' + str(rank)) == 1
        orders = {'A00F': value(current.rows['A00F'], 'DataF1'), 'A04U': value(pyro, key)}
        for pyro_ready in (False, True):
            ready = ['A00F'] + (['A04U'] if pyro_ready else [])
            assert [a for a in ready if orders[a] == 'channel'] == ['A00F']
            assert [a for a in ready if orders[a] == 'acidbomb'] == (['A04U'] if pyro_ready else [])
        # Existing ability orders anywhere in the map cannot compete for the
        # new pyro command if one is later carried onto this hero.
        for alias, row in current.rows.items():
            if alias != 'A04U':
                assert row.get(key) != pyro[key], ('acidbomb conflict', rank, alias)

    baseline = (root / 'war3map.j').read_text(encoding='utf-8-sig')
    current_script = script.read_text(encoding='utf-8-sig')
    old_functions = functions(baseline)
    assert len(old_functions) >= 9, len(old_functions)
    current_functions = functions(current_script)
    # v15 permits exactly two additive awakening hooks. Strip only those exact
    # additions before checking every original command/cost/projectile function.
    shared_hook='call HopeThird_AfterAction(GetTriggerUnit(),GetSpellAbilityId(),GetSpellTargetUnit())\n'
    ember_hook='+HopeThird_Embers(GetTriggerUnit(),GetSpellTargetUnit())'
    assert current_functions['Trig_JN_______005Actions'].count(shared_hook)==1
    assert current_functions['Trig_JN__________0001Actions'].count(ember_hook)==1
    current_functions['Trig_JN_______005Actions']=current_functions['Trig_JN_______005Actions'].replace(shared_hook,'')
    current_functions['Trig_JN__________0001Actions']=current_functions['Trig_JN__________0001Actions'].replace(ember_hook,'')
    shared = 'Trig_JN_______005Actions'
    assert without_priest_branch(current_functions[shared]) == without_priest_branch(old_functions[shared]), 'Fireball or shared projectile/resource logic changed'
    assert {k:v for k,v in current_functions.items() if k != shared} == {k:v for k,v in old_functions.items() if k != shared}, 'Original fireball/pyro cost, cooldown and event handlers changed'
    assert 'return GetSpellAbilityId()==$41303046 or GetSpellAbilityId()==$4130334A' in old_functions['Trig_JN_______005Conditions']
    assert 'return GetSpellAbilityId()==$41303455' in old_functions['Trig_JN__________0001Conditions']
    assert (modified / 'war3map.w3a').read_bytes() == (root / 'war3map.w3a').read_bytes()
    print('PASS: fireball/pyroblast commands unique at all three ranks with pyro ready or cooling down; separate Q/E buttons; original handlers preserved apart from the two explicit v15 hooks; w3a unchanged')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path)
    parser.add_argument('--modified', type=Path)
    parser.add_argument('--script', type=Path)
    args = parser.parse_args()
    validate(args.root, args.modified, args.script)
