"""Run shipped callbacks with deterministic native doubles; no client emulation."""
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace
import random,re,zipfile
from validate_economy import World,translate,body,rawcode,SCRIPT

N=0
def check(x,message):
 global N
 assert x,message
 N+=1

class UIWorld(World):
 def __init__(self):
  super().__init__();self.sender=0;self.buttons=100;self.items=[];self.debits=[];self.advances=[];self.effects=[]
  self.playing={0,1};self.human={0,1}
  self.g.update({
   'GetPlayerState':lambda p,k:self.resources[p,k], 'SetPlayerState':self.debit,
   'ModuloInteger':lambda a,b:a%b,'HopeInventory_Give':lambda item,u:self.items.append((u.owner,item)),'UnitAddItemByIdSwapped':lambda item,u:self.items.append((u.owner,item)),
   'GetPlayerName':lambda p:'Player '+str(p), 'DisplayTextToForce':lambda *x:self.messages.append(x),
   'GetTriggeringTrigger':lambda:99,'GetExpiredTimer':lambda:777,
   'YDWEGetPlayerColorString':lambda p,s:s,'GetPlayersAll':lambda:0,
   'GetTriggerPlayer':lambda:self.sender,'DzGetTriggerUIEventPlayer':lambda:self.sender,
   'GetClickedDialogBJ':lambda:None,'GetClickedButtonBJ':lambda:None,
   'GetAbilityName':lambda a:str(a),
   'GetLastCreatedButtonBJ':lambda:self.g['bj_lastCreatedButton'],
   'DialogAddButton':self.button,'DialogClear':lambda d:None,
   'FlushChildHashtable':self.flush,'RemoveSavedInteger':lambda t,p,k:self.tables[t].pop((p,k),None),
   'UnitRemoveAbilityBJ':lambda a,u:u.abilities.discard(a),
   'UnitAddAbility':lambda u,a:u.abilities.add(a),
   'IsPlayerInForce':lambda p,f:p in self.playing,
   'GetUnitName':lambda u:'商店节点', 'GetUnitX':lambda u:u.x,'GetUnitY':lambda u:0,
   'SetUnitVertexColorBJ':lambda *x:None,'YDWETimerDestroyEffect':lambda *x:None,
   'AddSpecialEffectTarget':lambda *x:self.effects.append(x) or len(self.effects),
   'DestroyEffect':lambda e:None,'CreateTextTag':lambda:42,
   'SetTextTagPermanent':lambda *x:None,'SetTextTagText':lambda *x:None,
   'SetTextTagPosUnit':lambda *x:None,'SetTextTagVisibility':lambda *x:None,
   'GroupAddUnitSimple':lambda *x:None,'ForGroupBJ':lambda *x:None,
   'YDWEGetUnitsOfPlayerAllNull':lambda *x:None,'PLAYER_NEUTRAL_PASSIVE':15,
   'ConditionalTriggerExecute':lambda t:self.advances.append((self.g['udg_boci'],self.g['udg_Youxi_xzgq'])),
   'Trig______________012Func001Func008A':lambda:None,
   'R2SW':lambda v,a,b:f'{v:.{b}f}', 'StringLength':lambda s:len(s.encode()),
   'HopeJob_SetText':lambda *x:self.ui_calls.append(x),
  })
  for kind in ['ButtonHandle','PlayerHandle']:
   self.g['Save'+kind]=lambda t,p,k,v:self.tables[t].__setitem__((p,k),v)
   self.g['Load'+kind]=lambda t,p,k:self.tables[t].get((p,k))
  for p in range(2):
   u=self.hero(p);u.abilities=set()
  for name in ['HopeModern_Data','HopeDraw_History'] :self.g[name]=name
 def flush(self,t,p):
  for k in list(self.tables[t]):
   if k[0]==p:del self.tables[t][k]
 def debit(self,p,k,v):
  self.debits.append((p,k,self.resources[p,k],v));self.resources[p,k]=v
 def button(self,*x):self.buttons+=1;return self.buttons
 def seed(self,n):self.rng=random.Random(n);self.g['GetRandomInt']=self.rng.randint
 def node(self,x=0):
  u=SimpleNamespace(kind=rawcode('n00K'),x=x,owner=15,life=100)
  self.g['SaveBoolean']('YDHT',id(u),0xC31B86D5,True)
  self.g['SaveInteger']('YDHT',id(u),0x66256FC7,self.g['udg_boci'])
  return u

def test_draws():
 w=UIWorld();w.load('HopeDraw_Reward','HopeDraw_Record','HopeDraw_Ten','HopeDraw_SaveRecord')
 w.resources[0,'gold']=647;w.seed(1)
 check(not w.g['HopeDraw_Ten'](0) and not w.debits,'insufficient ten-draw balance never charges')
 w.resources[0,'gold']=648
 check(w.g['HopeDraw_Ten'](0) and w.resources[0,'gold']==0,'ten draws cost exactly648')
 text=w.tables['HopeDraw_History'][0,3]
 check(len(re.findall(r'(?:^|\|n)\d+\. ',text))==10,'all ten rewards retained together')
 check(not w.g['HopeDraw_Ten'](0) and w.g['HopeDraw_Count'][0]==1,'repeat on stale balance cannot charge')
 # Native 1-wood sale cases are covered by validate_wood_shop.py.
 for n in range(70):w.g['HopeDraw_Record'](0,str(n),str(n))
 check(sum(k[0]==0 for k in w.tables['HopeDraw_History'])==128,'bounded64history retained')
 # Same seeded native draws against untouched original award function.
 original=Path(__file__).with_name('war3map.j').read_text()
 name='Trig____________________023Func036Func001Func004T'
 for seed in range(800):
  a=UIWorld();b=UIWorld();a.seed(seed);b.seed(seed)
  a.load('HopeDraw_Reward');exec(translate(name,original),b.g)
  for key,value,kind in [(0xFBEDEC54,0,'Integer'),(0x877546F4,1,'Integer'),(0x48656946,0,'PlayerHandle'),(0x9F0C6E00,b.g['udg_hero'][1],'UnitHandle'),(0x458B7DE9,b.g['udg_hero'][1],'UnitHandle')]:b.g['Save'+kind]('YDLOC',777,key,value)
  a.g['HopeDraw_Reward'](0);b.g[name]()
  for field in ['str','agi','int']:check(getattr(a.g['udg_hero'][1],field)==getattr(b.g['udg_hero'][1],field),'original lottery stat '+field)
  for field in ['udg_Skill_Dm','udg_Fashang_Dm','udg_Baoji_Lv','udg_Baoji_Damage','udg_Zuizhong_Dm']:check(a.g[field][1]==b.g[field][1],'original lottery '+field)
  check(a.items==b.items,'original rare item odds/order retained')

CHOICES=['HopeModern_Message','HopeModern_Add','HopeModern_Clear','HopeModern_NativeDisplay','HopeModern_GetPlayer','HopeModern_GetDialog','HopeModern_GetButton','HopeChoice_FindDialog','HopeChoice_DialogDisplay','HopeChoice_DialogClear','HopeChoice_DialogClicked','HopeChoice_DeferSkill','HopeChoice_ShowNextSkill','HopeModern_Choose','HopeModern_Fold','Trig____________________013________2Actions','Trig_R_____________018Actions']
def test_choices():
 w=UIWorld();w.load(*CHOICES)
 def offer(owner,d,values):
  w.g['HopeModern_Message'](d,'选择')
  for id,amount in values:
   w.g['HopeModern_Add'](d,'option');b=w.g['bj_lastCreatedButton'];w.g['SaveInteger']('YDHT',b,0x340FE72,id);w.g['SaveReal']('YDHT',b,0x80E7EB49,amount)
  w.g['HopeChoice_DialogDisplay'](owner,d,True)
 w.g['udg_Wj_sj_xz'][2]=201;offer(1,201,[(1,7),(2,4),(3,3),(99,0)])
 i=w.g['HopeChoice_FindDialog'](201)
 w.sender=0;w.g['HopeModern_Choose'](i,1)
 check(w.g['udg_hero'][2].str==5 and w.g['HopeChoice_DialogPending'][i],'foreign player cannot choose teammate reward')
 w.sender=1;w.g['HopeModern_Choose'](i,7)
 check(w.g['HopeChoice_PlayerPending'][1]==1,'invalid row does not consume choice')
 w.g['HopeModern_Choose'](i,1)
 check(w.g['udg_hero'][2].str==12 and w.g['udg_hero'][1].str==5,'frame routes exact original upgrade reward to sender')
 check(w.g['HopeChoice_PlayerPending'][1]==0,'resolved choice unlocks preparation')
 w.g['HopeModern_Choose'](i,1)
 check(w.g['udg_hero'][2].str==12,'resolved click cannot duplicate upgrade')
 # Real R replacement applies new passive, cleans old, drains preserved queue.
 w.g['udg_Rskill_shifoutihuan'][2]=202;w.g['udg_R_Skill'][2]=rawcode('A020');w.g['udg_Baoji_Lv'][2]=15;w.g['udg_Baoji_Damage'][2]=1.5
 offer(1,202,[(1,0),(2,0)]);w.g['SaveInteger']('YDHT',202,0xD59B01E6,rawcode('A01D'))
 w.g['HopeChoice_SkillQueue']='queue'
 check(w.g['HopeChoice_DeferSkill'](1,rawcode('A01H')),'second R purchase queues without replacing first')
 i=w.g['HopeChoice_FindDialog'](202);w.g['HopeModern_Tick']+=3;w.g['HopeModern_Choose'](i,1)
 check(w.g['udg_R_Skill'][2]==rawcode('A01D') and w.g['udg_Baoji_Lv'][2]==0 and w.g['udg_Fashang_Dm'][2]==.3,'R passive cleanup and learning preserved')
 check(w.g['HopeChoice_PlayerPending'][1]==1 and w.g['HopeChoice_DialogPending'][i],'queued R remains pending after first')
 w.g['HopeModern_Choose'](i,1)
 check(w.g['udg_R_Skill'][2]==rawcode('A01D'),'rapid stale click cannot accept next queued R')
 w.g['HopeModern_Tick']+=3;w.g['HopeModern_Choose'](i,2)
 check(w.g['udg_R_Skill'][2]==rawcode('A01D') and w.g['HopeChoice_PlayerPending'][1]==0,'decline preserves R and clears pending')
 check('call DialogDisplay(' not in SCRIPT,'no visible native modal calls remain')
 check('not HopeRoute_Assigning' in body('HopeGrowth_Refresh')[3],'captain popup cannot overlap growth choice')
 for i in range(1,14):
  for j in range(1,7):check(f'function HopeModern_Click{i}_{j},true)' in SCRIPT,'choice mutations use fixed synchronized callbacks')

def test_routes():
 w=UIWorld();w.load('HopeRoute_Active','HopeRoute_Host','HopeRoute_Leader','HopeRoute_ClearMarker','HopeRoute_Mark','HopeRoute_ClearReady','HopeChoice_PendingForPlayer','HopeRoute_RewardPending','HopeRoute_Valid','HopeRoute_Status','HopeRoute_AllReady','HopeRoute_SetReady','HopeRoute_Select','HopeRoute_Depart','HopeRoute_Assign','HopeRoute_Leave')
 w.g['udg_boci']=1;w.g['HopeRoute_Assigning']=True
 check(not w.g['HopeRoute_Assign'](1,1),'only host assigns picker')
 check(not w.g['HopeRoute_Assign'](0,5),'inactive picker rejected')
 check(w.g['HopeRoute_Assign'](0,1) and w.g['HopeRoute_Leader']()==1,'host can delegate to teammate')
 node=w.node(-100);node2=w.node(100)
 w.g['HopeRoute_Select'](0,node);check(w.g['HopeRoute_Node'] is None,'former host no longer selects route')
 w.g['HopeRoute_Select'](1,node);check(w.g['HopeRoute_Node'] is node and w.g['HopeRoute_Ready'][1] and w.g['HopeRoute_Marker'] is not None,'selection proposes, auto-readies picker and marks node')
 w.g['HopeRoute_Select'](1,node);check(not w.advances,'reselect never auto departs')
 w.g['HopeRoute_SetReady'](0,True);check(w.g['HopeRoute_AllReady'](),'all humans ready')
 check(not w.g['HopeRoute_Depart'](0),'nonpicker cannot depart')
 w.g['HopeChoice_PlayerPending'][0]=1
 check(not w.g['HopeRoute_Depart'](1),'new reward blocks stale all-ready state')
 w.g['HopeChoice_PlayerPending'][0]=0;w.g['HopeRoute_Select'](1,node2)
 check(not w.g['HopeRoute_Ready'][0] and w.g['HopeRoute_Node'] is node2,'destination change clears teammate consent')
 w.g['HopeRoute_SetReady'](0,True)
 check(w.g['HopeRoute_Depart'](1) and len(w.advances)==1 and w.g['udg_boci']==2,'departure invokes original room transition once')
 check(w.g['HopeRoute_Node'] is None and w.g['HopeRoute_Marker'] is None,'departure consumes proposal and marker')
 check(not w.g['HopeRoute_Depart'](1) and len(w.advances)==1,'duplicate departure cannot skip room')
 w.sender=1;w.g['HopeRoute_Leave']();check(w.g['HopeRoute_Leader']()==0,'picker leaving transfers permission')
 check('call HopeRoute_Select(GetTriggerPlayer(),GetTriggerUnit())' in body('Trig______________012Actions')[3],'map clicks only propose')
 check('双击' not in body('Trig______________012Actions')[3],'no doubleclick progression branch remains')


def test_damage_and_tooltips():
 w=UIWorld();w.g['HopeLayout_Place']=lambda *a:None;w.load('HopeDamage_Value','HopeDamage_Refresh','HopeDamage_RunClick','HopeDamage_Battle')
 w.g['udg_Shuchu_dm_tj'][1]=10.;w.g['udg_Shuchu_dm_tj'][2]=20.;w.g['HopeDamage_Total'][1]=100.;w.g['HopeDamage_Total'][2]=50.
 w.g['HopeDamage_Refresh']();check(w.g['HopeDamage_Order'][1]==2,'battle sorting')
 w.g['HopeDamage_RunClick']();w.g['HopeDamage_Refresh']();check(w.g['HopeDamage_Order'][1]==1,'whole run sorting')
 w.g['udg_Shuchu_dm_tj'][1]=0;check(w.g['HopeDamage_Value'](1)==100.,'new battle does not reset totals')
 writes=re.findall(r'^set HopeDamage_Total\[.*$',SCRIPT,re.M)
 check(len(writes)==1 and '+LoadReal' in writes[0],'total has one damage observation and no reset')
 f=body('Trig____________________005Actions')[3]
 check(f.count('set HopeDamage_Total[')==1 and f.index('call YDWESetEventDamage')<f.index('set HopeDamage_Total['),'single existing final-damage settlement source')
 w.load('HopeSkill_Original')
 for rank in [1,2,3]:
  text=w.g['HopeSkill_Original'](rawcode('A02U'),rank)
  check(all(s in text for s in ['当前攻击力×30%×毒层数×毒矛等级','30层','减少1','独立计算']),'poison full formula at every learned rank')
 check("id!='A02U' and HaveSavedString" in body('HopeSkill_RefreshOne')[3],'broken cached description cannot override poison formula')
 profile=Path(__file__).with_name('modified').joinpath('Units_campaignabilitystrings.txt').read_text()
 poison=re.search(r'^\[A02U\]\n(.*?)(?=^\[)',profile,re.M|re.S)[1]
 check(poison.count('当前攻击力×30%×毒层数×毒矛等级')==4,'research and three learned profiles repaired')

if __name__=='__main__':
 test_draws();test_choices();test_routes();test_damage_and_tooltips()
 print(f'PASS: {N} assertions; original lottery800seeds, charges/history, real upgrade/R callbacks, multiplayer route/departure/leave, damage tabs, learned poison descriptions.')
