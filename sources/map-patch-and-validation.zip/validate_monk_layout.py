"""Render every current monk profession page using the shipped UI callbacks."""
from pathlib import Path
import json
from validate_layout import Layout,check
from validate_economy import rawcode
w=Layout();g=w.g;opts=json.loads(Path(__file__).with_name('patch-options.json').read_text())
w.shot=Path('/workspace/outputs/ui-layout-v12')
g['HopeJob_Expanded']=True;g['HopeLayout_Focus'](5)
g['HopeJob_InPanel']=lambda index,owner:index==g['HopeJob_Selected']
g['HopeJob_Entry']=2;g['HopeJob_AdvancedOpen']=lambda:True;g['HopeJob_Round']=lambda:4
pages=0
for chosen in [i for i,o in enumerate(opts) if o['target']=='N01G']:
 g['udg_hero'][1].kind=rawcode(opts[chosen]['source']);g['HopeJob_LastType']=g['udg_hero'][1].kind
 g['HopeJob_Selected']=chosen
 for page in range(3):
  g['HopeJob_Page']=page
  count=1 if page==0 else g['HopeJob_SkillCount' if page==1 else 'HopeJob_PassiveCount'][chosen]
  for detail in range(count):
   g['HopeJob_DetailPage']=detail;g['HopeJob_RefreshContent']();g['HopeLayout_Apply']()
   check(g['HopeJob_Selected']==chosen,'actual monk selection retained')
   check(w.visible(g['HopeJob_Panel']),'career panel visible')
   w.render('monk-'+str(chosen)+'-'+str(page)+'-'+str(detail),page==1 and detail==0);pages+=1
print('PASS:',pages,'final monk second/third career pages fit; actual selected option retained and visible.')
