"""Check the actual native-sale callback and its complete optimized item data."""
from pathlib import Path
from types import SimpleNamespace
import re
from validate_v8_ui import UIWorld
from validate_economy import body,rawcode,SCRIPT
from validate_object_dependencies import parse_slk

N=0
def check(v,msg):
 global N
 assert v,msg
 N+=1

class ShopWorld(UIWorld):
 def __init__(self):
  super().__init__();self.shop=SimpleNamespace(kind=rawcode('n00Q'),owner=15)
  self.buyer=self.g['udg_hero'][1];self.sold=None;self.stock=[]
  self.g.update({'gg_unit_n00Q_0028':self.shop,'GetSoldItem':lambda:self.sold,
    'GetSellingUnit':lambda:self.shop,'GetBuyingUnit':lambda:self.buyer,
    'GetItemTypeId':lambda item:0 if item is None else item.kind,
    'RemoveItem':lambda item:setattr(item,'kind',0),
    'AddItemToStock':lambda *args:self.stock.append(args)})
  self.load('HopeDraw_SaveRecord','HopeDraw_Record','HopeDraw_Reward','HopeWood_Allowed','HopeWood_Sold')
 def buy(self,owner=0):
  self.buyer=self.g['udg_hero'][owner+1]
  if self.resources[owner,'lumber']<1:return False
  # Native Warcraft charges the ItemData price before dispatching SELL_ITEM.
  self.debit(owner,'lumber',self.resources[owner,'lumber']-1)
  self.sold=SimpleNamespace(kind=rawcode('IZWD'))
  self.g['HopeWood_Sold']();return True

def run():
 root=Path(__file__).parent
 old=parse_slk((root/'Units_ItemData.slk').read_bytes(),'original items')
 new=parse_slk((root/'modified/Units_ItemData.slk').read_bytes(),'new items')
 for alias,row in old.rows.items():check(new.rows[alias]==row,'original item unchanged '+alias)
 check(set(new.rows)-set(old.rows)=={'IZWD'},'one complete new item')
 row=new.rows['IZWD']
 for key,val in [('goldcost',0),('lumbercost',1),('stockMax',1),('stockRegen',0),('stockStart',0),('pickRandom',0),('powerup',1),('pawnable',0),('droppable',0)]:check(row[key].value==val,'native product '+key)
 check(row['abilList'].value=='_','no inherited automatic attribute or mana reward')
 profile=(root/'modified/Units_itemstrings.txt').read_text()
 desc=re.search(r'^\[IZWD\]\n(.*?)(?=^\[|\Z)',profile,re.M|re.S)[1]
 check('Buttonpos=3,0' in desc and 'Hotkey=' not in desc,'dedicated top-row slot without conflicting shortcut')
 for s in ['50%谢谢惠顾','25%单项属性+1','15%全属性+3','8%伤害/暴击','2%圣剑','1木材','抽取记录']:check(s in desc,'complete tooltip '+s)
 units=(root/'modified/Units_campaignunitstrings.txt').read_text()
 stock=[(m[1],m[2]) for m in re.finditer(r'^\[([^\]]+)\]\n(.*?)(?=^\[|\Z)',units,re.M|re.S) if 'IZWD' in m[2]]
 check(len(stock)==1 and stock[0][0]=='n00Q','only ability merchant carries the icon')
 check('Sellitems=tin2,tst2,tdx2,IZWD' in stock[0][1],'original three attribute books retained')
 check(all(name not in SCRIPT for name in ['HopeDraw_OnSelect','HopeDraw_WoodClick','HopeDraw_WoodOpen','HopeWoodBuy','返回木材抽取']),'no old automatic shop window or secondary purchase path')
 check('EVENT_PLAYER_UNIT_SELL_ITEM' in body('HopeWood_Init')[3] and SCRIPT.count('call HopeWood_Init()')==1,'single synchronized native sale registration')
 check('EVENT_PLAYER_UNIT_SELECTED' not in body('HopeDraw_Create')[3],'result frame does not subscribe to shop selection')
 w=ShopWorld();g=w.g;w.resources[0,'lumber']=1;g['GetRandomInt']=lambda a,b:50
 check(w.buy() and w.resources[0,'lumber']==0,'last wood purchases once without second charge')
 check(len(w.debits)==1 and len(w.stock)==1,'native charge only; stock replenishes')
 check('谢谢惠顾' in w.tables['HopeDraw_History'][0,3],'blank retained in history')
 check(g['HopeDraw_Count'][0]==1 and not g['HopeDraw_Open'],'purchase records result without opening a popup')
 check(w.sold.kind==0,'product consumed')
 before=(len(w.debits),g['HopeDraw_Count'][0]);g['HopeWood_Sold']()
 check(before==(len(w.debits),g['HopeDraw_Count'][0]),'duplicate delivery of consumed item cannot reward/refund')
 check(not w.buy() and g['HopeDraw_Count'][0]==1,'native balance gate prevents purchase at zero wood')
 for roll in [1,50,51,100]:
  w=ShopWorld();w.resources[0,'lumber']=1;calls=[]
  w.g['GetRandomInt']=lambda a,b,r=roll:r
  w.g['HopeDraw_Reward']=lambda p:calls.append(p) or '原奖池奖励'
  w.buy();check(len(calls)==int(roll>50),'50% boundary '+str(roll))
 for state in ['battle','dead','left','computer','wrong_shop','missing_hero','busy']:
  w=ShopWorld();w.resources[0,'lumber']=1;calls=[];w.g['GetRandomInt']=lambda a,b:calls.append((a,b)) or 1
  if state=='battle':w.g['udg_ZhandouZhong']=True
  if state=='dead':w.g['udg_hero'][1].life=0
  if state=='left':w.playing={1}
  if state=='computer':w.human={1}
  if state=='wrong_shop':w.shop=SimpleNamespace(kind=rawcode('n00P'),owner=15)
  if state=='busy':w.g['HopeDraw_Busy'][0]=True
  if state=='missing_hero':
   w.sold=SimpleNamespace(kind=rawcode('IZWD'));w.debit(0,'lumber',0);w.g['udg_hero'][1]=None;w.g['HopeWood_Sold']()
  else:w.buy()
  check(w.resources[0,'lumber']==1 and not calls and not w.g['HopeDraw_Count'][0],state+' refunds native price with no draw')
 w=ShopWorld();w.resources[0,'lumber']=3;w.resources[1,'lumber']=2;w.g['GetRandomInt']=lambda a,b:1
 for i in range(3):check(w.buy(),'repeat purchase '+str(i))
 check(w.resources[0,'lumber']==0 and len(w.stock)==3 and w.g['HopeDraw_Count'][0]==3,'unlimited sequential stock; correct total price')
 check(w.buy(1) and w.resources[1,'lumber']==1 and w.resources[0,'lumber']==0 and w.g['HopeDraw_Count'][1]==1,'buyer ownership and balance isolation')
 check(not w.writes,'wood purchase never writes cloud points')
 # An actual nonblank result must still use the existing shared reward function.
 w=ShopWorld();w.resources[0,'lumber']=1;w.g['GetRandomInt']=lambda a,b:{(1,100):51,(1,10):6,(1,3):1}[a,b]
 check(w.buy() and w.g['udg_hero'][1].str==6 and w.resources[0,'lumber']==0,'real reward pipeline: strength +1, native charge only')
 g=w.g;g['HopeDraw_Record'](0,'十连抽结果','奖励')
 check(g['HopeDraw_Open'] and g['HopeDraw_Count'][0]==2,'ten-draw result still opens its retained popup')
 print('PASS:',N,'native merchant item, sale pricing/refund, stock, repeat/ownership, blank boundary, real reward, record/visibility assertions.')

if __name__=='__main__':run()
