"""Execute paid/rejected original casts; inspect final projectile snapshots."""
import re,math
from validate_third import Third,rawcode,body,check,close
import validate_third

NAMES=['Trig_JN_______001Actions','Trig_JN_______002Actions','Trig_JN_____________0010Actions','Trig_JN_______004Actions','Trig_JN_______005Actions','Trig_JN__________0001Actions']
class Casts(Third):
    def __init__(self,kind,rank=3):
        super().__init__(kind,rank)
        g=self.g
        g.update({'GetUnitLoc':lambda u:(u.x,u.y),'GetSpellTargetLoc':lambda:(self.target.x,self.target.y),
                  'GetUnitStateSwap':lambda k,u:self.state(u,k),'YDWEUnitHasItemOfTypeBJNull':lambda *a:False,
                  'YDWEDistanceBetweenUnits':lambda a,b:math.hypot(a.x-b.x,a.y-b.y),
                  'YDWEAngleBetweenUnits':lambda *a:0.,'AngleBetweenPoints':lambda *a:0.,
                  'AddSpecialEffectLoc':lambda *a:700,'GetUnitMoveSpeed':lambda u:300.})
        for typ in ['LocationHandle','GroupHandle','EffectHandle']:
            g['Save'+typ]=lambda t,p,k,v:self.tables[t].__setitem__((p,k),v)
            g['Load'+typ]=lambda t,p,k:self.tables[t].get((p,k))
        for name in ['DzFrameSetText','DoNothing','RemoveLocation','EXEffectMatRotateZ','EXSetEffectZ','EXSetEffectSize']:
            g[name]=lambda *a:None
        for name in NAMES:
            for callback in re.findall(r'\bfunction (\w+)',body(name)[3]):g[callback]=lambda *a:None
        self.load(*NAMES)

    def use(self,name,aid,ap):
        self.cast_id=rawcode(aid);self.g['udg_xingdong_dian'][1]=ap
        self.g[name]()

def run():
    for typ,aid,name in [('H008','A00E',NAMES[1]),('H00D','A04I',NAMES[2]),('N018','A00I',NAMES[0]),('E00S','A00D',NAMES[3]),('N01E','A00F',NAMES[4])]:
        w=Casts(typ);g=w.g
        before=(w.u.armor,g['HopeThird_Cavalry'][1],g['HopeThird_ComboCount'][1],len(w.hits),len(w.tables[g['HopeThird_Data']]))
        w.use(name,aid,0)
        check(before==(w.u.armor,g['HopeThird_Cavalry'][1],g['HopeThird_ComboCount'][1],len(w.hits),len(w.tables[g['HopeThird_Data']])),'no AP cast has no passive effect '+typ)
        w.use(name,aid,5)
        check(g['udg_xingdong_dian'][1]==4,'original cast charges exactly one AP '+typ)
        if typ=='H008':check(w.u.armor>20+30*.8,'shield receives both original armor and third bonus')
        elif typ=='H00D':check(g['HopeThird_Cavalry'][1],'actual charge sets stance')
        elif typ=='N018':
            check(g['HopeThird_ComboCount'][1]==1,'actual paid slash counted once')
            w.use(name,aid,4)
            check(g['udg_xingdong_dian'][1]==4 and w.u.mana==22,'second actual slash pays then refunds AP and mana')
        elif typ=='E00S':check(len(w.hits)==2,'actual arrow emits two separate side hits')
        else:check(g['LoadInteger'](g['HopeThird_Data'],id(w.target),1)==1,'actual fireball sets own seed')
    w=Casts('N01E');g=w.g
    w.u.abilities[rawcode('A04U')]=2
    g['SaveInteger'](g['HopeThird_Data'],id(w.target),1,3)
    w.use(NAMES[5],'A04U',2)
    check(g['LoadInteger'](g['HopeThird_Data'],id(w.target),1)==3 and not w.timers,'rejected pyro retains seeds')
    w.use(NAMES[5],'A04U',3)
    amount=g['LoadReal']('YDLOC',g['GetHandleId'](w.timers[-1][0]),0xBB4B7313)
    close(amount,(50*4.5+50*1.6*3)*1.5*1.3,'pyro seed base enters spell and skill modifiers once before projectile')
    check(g['LoadInteger'](g['HopeThird_Data'],id(w.target),1)==0,'actual pyro consumes own seeds')
    for typ,aid,base in [('H008','A03D',100+20+20*.8),('H00D','A000',100*1.75),('N01A','A01R',(100+30*.5)*(1+.5*.8))]:
        w=Casts(typ);g=w.g;w.u.life=500.;g['HopeThird_Cavalry'][1]=True
        w.use(NAMES[0],aid,5)
        close(g['LoadReal']('YDLOC',g['GetHandleId'](w.timers[-1][0]),0xBB4B7313),base,'actual melee projectile receives third base '+typ)
    print(f'PASS: {validate_third.COUNT} paid-cast, rejection and projectile-formula integration assertions.')
    print('Final JASS handlers executed with native doubles; projectile motion not simulated.')

if __name__=='__main__':run()
