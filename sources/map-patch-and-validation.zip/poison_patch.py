"""Keep poison's combat formula intact and make the preview range readable.

The old U+2013 separator may be absent in KK's selected Warcraft font, causing
``450–715.5`` to look like ``450715.5``. Use a normal Chinese word with spaces,
which remains legible with the same font as the rest of this Chinese panel.
"""
from __future__ import annotations

import re


def apply(src: str) -> str:
    pattern = r"(^function HopeStatus_PoisonRange takes .*?^endfunction)"
    match = re.search(pattern, src, re.M | re.S)
    assert match, "Missing poison range formatter"
    old = match[1]
    separator = 'return left+"–"+right'
    assert old.count(separator) == 1, "Poison range separator changed upstream"
    new = old.replace(separator, '// KK fonts may omit the en dash and join both values.\nreturn left+" 至 "+right')
    return src[:match.start()] + new + src[match.end():]
