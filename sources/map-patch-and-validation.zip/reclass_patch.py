"""Paid first-career reselection with a fresh, non-leveling hero replacement."""
import re

G='''
boolean array HopeReclass_Busy
boolean HopeReclass_Replacing=false
integer array HopeReclass_PotionRank
item array HopeReclass_Items
'''

EARLY='''
function HopeReclass_PotionLearn takes unit u returns nothing
local integer i=GetPlayerId(GetOwningPlayer(u))+1
local integer rank=GetUnitAbilityLevel(u,'A00N')
if i>=1 and i<=6 and rank>HopeReclass_PotionRank[i] then
set udg_Yaoshui_shenyu_cs[i]=udg_Yaoshui_shenyu_cs[i]+1
set HopeReclass_PotionRank[i]=rank
endif
endfunction
'''

ELIGIBILITY='''
function HopeReclass_First takes integer kind returns boolean
return kind=='N00D' or kind=='H003' or kind=='H001' or kind=='N007' or kind=='E008' or kind=='N00E' or kind=='O001' or kind=='O003' or kind=='HZ01'
endfunction
function HopeReclass_Can takes integer i returns boolean
return i>=1 and i<=6 and udg_hero[i]!=null and HopeReclass_First(GetUnitTypeId(udg_hero[i])) and not HopeJob_Awakened[i]
endfunction
function HopeReclass_Training takes unit u returns integer
if GetUnitTypeId(u)=='HZ01' then
return GetUnitAbilityLevel(u,'AZHP')*2
endif
return 0
endfunction
function HopeReclass_Points takes unit u returns integer
local integer kind=GetUnitTypeId(u)
if kind=='N00D' then
return GetUnitAbilityLevel(u,'A00P')
elseif kind=='H003' then
return GetUnitAbilityLevel(u,'A00Q')
elseif kind=='H001' then
return GetUnitAbilityLevel(u,'A00K')
elseif kind=='N007' then
return GetUnitAbilityLevel(u,'A00L')
elseif kind=='E008' then
return GetUnitAbilityLevel(u,'A00O')
elseif kind=='N00E' then
return GetUnitAbilityLevel(u,'A00N')+GetUnitAbilityLevel(u,'A04W')
elseif kind=='O001' then
return GetUnitAbilityLevel(u,'A01S')
elseif kind=='O003' then
return GetUnitAbilityLevel(u,'A02U')
elseif kind=='HZ01' then
return GetUnitAbilityLevel(u,'AZHP')
endif
return 0
endfunction
function HopeReclass_Blocker takes integer index,player p returns string
local integer i=GetPlayerId(p)+1
local unit u=udg_hero[i]
local integer deduction=HopeReclass_Training(u)
local string reason=""
if p==null or i<1 or i>6 or not HopeReclass_Can(i) then
set reason="重新转职仅限已一转、尚未二转的英雄。"
elseif index<0 or index>=HopeJob_Count or HopeJob_Stage[index]!=1 then
set reason="无效的重转职业。"
elseif HopeReclass_Busy[i] then
set reason="正在重新转职，请稍候。"
elseif not HopeJob_InRoom(p) then
set reason="请回到原泉水爬塔房间的一转入口。"
elseif HopeRoute_RewardPending(i-1) or HopeChoice_PlayerPending[i-1]>0 then
set reason="请先完成待选奖励。"
elseif udg_Ls_zj_Str[i]!=0 or udg_Ls_zj_Agi[i]!=0 or udg_Ls_zj_Int[i]!=0 or udg_Linshi_Str[i]!=0 or HopeMeditation_Active[i] then
set reason="请等待临时属性效果结束后再重新转职。"
elseif index!=24 and HopeJob_Target[index]==GetUnitTypeId(u) then
set reason="你已经是该职业，不会扣除积分。"
elseif GetHeroStr(u,false)-deduction<HopeJob_Str[index] or GetHeroAgi(u,false)-deduction<HopeJob_Agi[index] or GetHeroInt(u,false)-deduction<HopeJob_Int[index] then
set reason="移除旧职业修炼后的基础属性不足；装备和临时加成不计。"
elseif not HopeCloud_CanWrite(p) then
set reason="存档积分尚未就绪，暂时不能重新转职。"
elseif udg_Wj_jf[i]<10 then
set reason="重新转职需要10存档积分，当前 "+I2S(udg_Wj_jf[i])+"。"
endif
set u=null
return reason
endfunction
'''

COMMIT='''
// Eligibility and payment use synchronized player/hero state, never UI selection.
function HopeReclass_Commit takes integer index,player p returns nothing
local integer i=GetPlayerId(p)+1
local string reason=HopeReclass_Blocker(index,p)
local unit old=udg_hero[i]
local unit u=null
local integer oldkind=GetUnitTypeId(old)
local integer pick=index
local integer target=0
local integer passive=0
local integer passivelevel=0
local integer refund=HopeReclass_Points(old)
local integer deduction=HopeReclass_Training(old)
local integer slot=0
local integer aid=0
local integer str=0
local integer agi=0
local integer intel=0
local integer oldpoints=GetHeroSkillPoints(old)
local integer points=oldpoints+refund
local real life=GetUnitState(old,UNIT_STATE_LIFE)
local real mana=GetUnitState(old,UNIT_STATE_MANA)
local real maximumlife=0.
local real maximummana=0.
if reason!="" then
call DisplayTimedTextToPlayer(p,0,0,5.,reason)
set old=null
return
endif
set HopeReclass_Busy[i]=true
// Query attributes after removing the actual native Aamk effect: do not assume
// whether a Warcraft build exposes that modifier through base-stat getters.
if oldkind=='N00D' then
set passive='A00P'
elseif oldkind=='E008' then
set passive='A00O'
endif
if passive!=0 then
set passivelevel=GetUnitAbilityLevel(old,passive)
if passivelevel>0 then
call UnitRemoveAbility(old,passive)
endif
endif
set str=GetHeroStr(old,false)-deduction
set agi=GetHeroAgi(old,false)-deduction
set intel=GetHeroInt(old,false)-deduction
if str<HopeJob_Str[index] or agi<HopeJob_Agi[index] or intel<HopeJob_Int[index] then
set reason="移除旧职业修炼后属性不足，未扣积分。"
else
if index==24 then
if GetRandomInt(1,100)<=10 then
set target='HZ01'
else
set pick=GetRandomInt(0,7)
set target=HopeJob_Target[pick]
endif
else
set target=HopeJob_Target[index]
endif
set u=CreateUnit(p,target,GetUnitX(old),GetUnitY(old),GetUnitFacing(old))
if u==null then
set reason="新职业创建失败，未扣积分，请重试。"
elseif not HopePoints_Spend(p,10) then
set reason="积分扣除未通过，原职业保留。"
call RemoveUnit(u)
set u=null
endif
endif
if reason!="" then
if passivelevel>0 then
call UnitAddAbility(old,passive)
call SetUnitAbilityLevel(old,passive,passivelevel)
endif
call UnitModifySkillPoints(old,oldpoints-GetHeroSkillPoints(old))
call SetUnitState(old,UNIT_STATE_LIFE,RMinBJ(life,GetUnitState(old,UNIT_STATE_MAX_LIFE)))
call SetUnitState(old,UNIT_STATE_MANA,RMinBJ(mana,GetUnitState(old,UNIT_STATE_MAX_MANA)))
set HopeReclass_Busy[i]=false
call DisplayTimedTextToPlayer(p,0,0,5.,reason)
set old=null
set u=null
return
endif
// SetHeroXP normally runs the map's HERO_LEVEL trigger. Suppress only that
// trigger's action while copying XP, preserving every earned global reward.
set HopeReclass_Replacing=true
call SetHeroXP(u,GetHeroXP(old),false)
set HopeReclass_Replacing=false
// Drop on the old hero first, so scripted equipment bonuses are undone once.
loop
exitwhen slot>=6
set HopeReclass_Items[i*6+slot]=UnitItemInSlot(old,slot)
if HopeReclass_Items[i*6+slot]!=null then
call UnitRemoveItem(old,HopeReclass_Items[i*6+slot])
endif
set slot=slot+1
endloop
set maximumlife=GetUnitState(old,UNIT_STATE_MAX_LIFE)
set maximummana=GetUnitState(old,UNIT_STATE_MAX_MANA)
// Remove the scripted hidden training on the old unit, letting the engine adjust
// its capacities before they are copied to the fresh class.
// The old hero is removed below; keep it alive while native capacities change.
if deduction>0 then
call SetUnitState(old,UNIT_STATE_LIFE,GetUnitState(old,UNIT_STATE_MAX_LIFE))
call SetHeroStr(old,GetHeroStr(old,false)-deduction,true)
call SetHeroAgi(old,GetHeroAgi(old,false)-deduction,true)
call SetHeroInt(old,GetHeroInt(old,false)-deduction,true)
set maximumlife=GetUnitState(old,UNIT_STATE_MAX_LIFE)
set maximummana=GetUnitState(old,UNIT_STATE_MAX_MANA)
endif
call SetHeroStr(u,GetHeroStr(old,false),true)
call SetHeroAgi(u,GetHeroAgi(old,false),true)
call SetHeroInt(u,GetHeroInt(old,false),true)
call SetUnitState(u,UNIT_STATE_MAX_LIFE,maximumlife)
call SetUnitState(u,UNIT_STATE_MAX_MANA,maximummana)
if oldkind=='N00D' and passivelevel>0 then
set udg_xingdong_dianSx[i]=udg_xingdong_dianSx[i]-1
set udg_xingdong_dian[i]=IMinBJ(udg_xingdong_dian[i],udg_xingdong_dianSx[i])
endif
if oldkind=='HZ01' then
set udg_cz1Str_up[i]=udg_cz1Str_up[i]-.15
set udg_cz2Agi_up[i]=udg_cz2Agi_up[i]-.15
set udg_cz3Int_up[i]=udg_cz3Int_up[i]-.15
endif
if target=='HZ01' then
set udg_cz1Str_up[i]=udg_cz1Str_up[i]+.15
set udg_cz2Agi_up[i]=udg_cz2Agi_up[i]+.15
set udg_cz3Int_up[i]=udg_cz3Int_up[i]+.15
endif
set aid=LoadInteger(YDHT,i,$412D8AC6)
if aid!=0 then
call UnitAddAbility(u,aid)
endif
set aid=LoadInteger(YDHT,i,$3FB1F9E0)
if aid!=0 then
call UnitAddAbility(u,aid)
endif
set aid=LoadInteger(YDHT,i,$590EE9FB)
if aid!=0 then
call UnitAddAbility(u,aid)
endif
if udg_R_Skill[i]!=0 and udg_R_Skill[i]!=$4130314C then
call UnitAddAbility(u,udg_R_Skill[i])
endif
call SetUnitState(u,ConvertUnitState(18),GetUnitState(u,ConvertUnitState(18))+I2R(udg_Gongjili_Jc[i]))
set udg_Minjie_jiaGong[i]=0
call SetUnitMoveSpeed(u,GetUnitMoveSpeed(old))
call UnitModifySkillPoints(u,points-GetHeroSkillPoints(u))
if udg_shengji_dian[i]>0 then
call UnitAddAbility(u,'Asud')
call AddUnitToStock(u,'h00F',udg_shengji_dian[i],udg_shengji_dian[i])
endif
// Auxiliary spell caster abilities belong to the chosen first profession.
call UnitRemoveAbility(udg_Mj_Danwei[i],'A00G')
call UnitRemoveAbility(udg_Mj_Danwei[i],'A00H')
if target=='N007' then
call UnitAddAbility(udg_Mj_Danwei[i],'A00G')
elseif target=='E008' then
call UnitAddAbility(udg_Mj_Danwei[i],'A00H')
endif
set udg_hero[i]=u
set slot=0
loop
exitwhen slot>=6
if HopeReclass_Items[i*6+slot]!=null then
call UnitAddItem(u,HopeReclass_Items[i*6+slot])
set HopeReclass_Items[i*6+slot]=null
endif
set slot=slot+1
endloop
call RemoveUnit(old)
call SetUnitState(u,UNIT_STATE_LIFE,RMinBJ(life,GetUnitState(u,UNIT_STATE_MAX_LIFE)))
call SetUnitState(u,UNIT_STATE_MANA,RMinBJ(mana,GetUnitState(u,UNIT_STATE_MAX_MANA)))
call SelectUnitForPlayerSingle(u,p)
set HopeRoute_Ready[i-1]=false
set HopeReclass_Busy[i]=false
call DisplayTextToPlayer(p,0,0,"重新转职完成："+GetUnitName(u)+"；消耗10存档积分，返还职业技能点 "+I2S(refund)+"。")
if p==GetLocalPlayer() then
set HopeJob_Expanded=false
call HopeJob_ShowFrame(HopeJob_Panel,false)
endif
set old=null
set u=null
endfunction
'''

def replace_once(src, old, new):
    assert src.count(old)==1, (old[:100],src.count(old))
    return src.replace(old,new,1)


def update_options(options):
    for option in options:
        option['skills'] = option['skills'].replace('抽取结果确定后不可重抽。', '首次抽取免费；一转期间可花10存档积分重新转职。')


def apply(src):
    assert 'function HopeReclass_Commit takes' not in src
    src=src.replace('globals\n','globals\n'+G,1)
    # Functions needed by original learning and level triggers appear early.
    src=replace_once(src,'function Trig_JN_____________012Actions takes',EARLY+'\nfunction Trig_JN_____________012Actions takes')
    a=src.index('function Trig_JN_____________012Actions takes');b=src.index('\nendfunction',a)
    body=src[a:b]
    line=next(l for l in body.splitlines() if l.startswith('set udg_Yaoshui_shenyu_cs['))
    body=body.replace(line,'call HopeReclass_PotionLearn(GetTriggerUnit())',1)
    src=src[:a]+body+src[b:]
    a=src.index('function Trig____________________001Actions takes');b=src.index('\nendfunction',a)
    body=src[a:b]
    body=body.replace('set ydl_localvar_step=ydl_localvar_step+3','if HopeReclass_Replacing then\nreturn\nendif\nset ydl_localvar_step=ydl_localvar_step+3',1)
    src=src[:a]+body+src[b:]
    src=replace_once(src,'function HopeJob_Visible takes',ELIGIBILITY+'\nfunction HopeJob_Visible takes')
    src=replace_once(src,"return udg_hero[i]!=null and HopeJob_Source[index]==GetUnitTypeId(udg_hero[i])", "if HopeJob_Stage[index]==1 and HopeReclass_Can(i) then\nreturn true\nendif\nreturn udg_hero[i]!=null and HopeJob_Source[index]==GetUnitTypeId(udg_hero[i])")
    src=replace_once(src,'local string s=""\nif index<0 or index>=HopeJob_Count', 'local string s=""\nif index>=0 and index<HopeJob_Count and HopeJob_Stage[index]==1 and HopeReclass_Can(i) then\nset u=null\nreturn HopeReclass_Blocker(index,p)\nendif\nif index<0 or index>=HopeJob_Count')
    src=replace_once(src,'function HopeJob_Commit takes',COMMIT+'\nfunction HopeJob_Commit takes')
    src=replace_once(src,'local item it=null\nif blocker!="" then','local item it=null\nif index>=0 and index<HopeJob_Count and HopeJob_Stage[index]==1 and HopeReclass_Can(i) then\ncall HopeReclass_Commit(index,p)\nset p=null\nreturn\nendif\nif blocker!="" then')
    # Original fountain building still opens entry 1; toolbar also remains usable
    # in rounds 1/2 while no second-promotion building exists.
    src=replace_once(src,"if GetUnitTypeId(udg_hero[GetPlayerId(p)+1])=='H000' then", "if GetUnitTypeId(udg_hero[GetPlayerId(p)+1])=='H000' or (HopeReclass_Can(GetPlayerId(p)+1) and not HopeJob_AdvancedOpen()) then")
    src=replace_once(src,"local boolean available=room and (typ=='H000' or HopeJob_AdvancedOpen())","local boolean available=room and (typ=='H000' or HopeReclass_Can(i) or HopeJob_AdvancedOpen())")
    src=replace_once(src,"if typ=='H000' then\ncall HopeJob_Show(p,1)","if typ=='H000' or (HopeReclass_Can(i) and not HopeJob_AdvancedOpen()) then\ncall HopeJob_Show(p,1)")
    src=replace_once(src,'call HopeJob_SetText(HopeJob_Title,"|cffd2b879一转职业|r · "+current)', 'if HopeReclass_Can(i) then\ncall HopeJob_SetText(HopeJob_Title,"|cffd2b879重新转职 · 10存档积分|r · "+current)\nelse\ncall HopeJob_SetText(HopeJob_Title,"|cffd2b879一转职业|r · "+current)\nendif')
    src=replace_once(src,'elseif HopeJob_Page==1 then\nset count=HopeJob_SkillCount[chosen]', 'if HopeJob_Entry==1 and HopeReclass_Can(i) then\nset detail="|cffd2b879重新转职："+HopeJob_Name[chosen]+"|r|n费用：10存档积分；当前 "+I2S(udg_Wj_jf[i])+"。|n仅一转可用，二转后关闭。|n|n所需基础力量 "+I2S(HopeJob_Str[chosen])+" / 敏捷 "+I2S(HopeJob_Agi[chosen])+" / 智力 "+I2S(HopeJob_Int[chosen])+"。|n扣费前移除旧修炼复核，属性不足不扣费。|n保留等级、既得升级收益与装备；旧职业被动移除，返还职业技能点。|n牧师同级赠药不重复领取。|n随机10%隐藏；抽到同职业也消耗积分。"\nendif\nelseif HopeJob_Page==1 then\nset count=HopeJob_SkillCount[chosen]')
    src=replace_once(src,'if block=="" then\nif HopeJob_Stage[chosen]==3 then','if block=="" then\nif HopeJob_Entry==1 and HopeReclass_Can(i) then\ncall HopeJob_SetText(HopeJob_Confirm[chosen],"确认重转："+HopeJob_Name[chosen]+"（10存档积分）")\nelseif HopeJob_Stage[chosen]==3 then')
    src=replace_once(src,'set block="条件已满足。转职确认后本局不可撤销。"','if HopeJob_Entry==1 and HopeReclass_Can(i) then\nset block="确认即扣10积分并换职业；二转后不能重新转职。"\nelseif HopeJob_Stage[chosen]==1 then\nset block="首次转职免费；一转期间可花10积分重新转职。"\nelse\nset block="条件已满足。转职确认后本局不可撤销。"\nendif')
    src=src.replace('抽取结果确定后不可重抽。','首次抽取免费；一转期间可花10存档积分重新转职。')
    return src
