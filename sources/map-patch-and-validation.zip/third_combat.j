// v15 per-hero awakenings. Gameplay helpers run only in synchronized callbacks.
function HopeThird_Level takes unit u returns integer
local integer p=GetPlayerId(GetOwningPlayer(u))+1
if p<1 or p>6 or u!=udg_hero[p] or not HopeJob_Awakened[p] then
return 0
endif
return GetUnitAbilityLevel(u,HopeThird_Ability[HopeJob_AwakenOption[p]])
endfunction
function HopeThird_Enemy takes unit target,player p returns boolean
return target!=null and GetWidgetLife(target)>.405 and IsUnitInGroup(target,udg_Guaiwu_dwz) and IsUnitEnemy(target,p)
endfunction
function HopeThird_Heal takes unit u,real amount,boolean overflow returns nothing
local real missing=RMaxBJ(0.,GetUnitState(u,UNIT_STATE_MAX_LIFE)-GetWidgetLife(u))
call SetUnitState(u,UNIT_STATE_LIFE,GetWidgetLife(u)+RMinBJ(missing,amount))
if overflow and amount>missing then
call SetUnitState(u,ConvertUnitState(32),GetUnitState(u,ConvertUnitState(32))+amount-missing)
endif
endfunction
function HopeThird_Refund takes integer p returns nothing
set udg_xingdong_dian[p]=IMinBJ(udg_xingdong_dianSx[p],udg_xingdong_dian[p]+1)
endfunction
function HopeThird_Reset takes nothing returns nothing
local integer p=1
call FlushParentHashtable(HopeThird_Data)
loop
exitwhen p>6
set HopeThird_Cavalry[p]=false
set HopeThird_ComboToken[p]=-1
set HopeThird_PressureToken[p]=-1
set HopeThird_HitsToken[p]=-1
set HopeThird_HiddenToken[p]=-1
set HopeThird_FireTarget[p]=null
set HopeThird_PressureTarget[p]=null
set p=p+1
endloop
endfunction
function HopeThird_HiddenAction takes unit u,integer aid returns nothing
local integer p=GetPlayerId(GetOwningPlayer(u))+1
local integer level=HopeThird_Level(u)
local integer token=HopeChallenge_TurnToken()
local integer mask=0
if level<=0 or GetUnitTypeId(u)!='HZ03' then
return
endif
if HopeThird_HiddenToken[p]!=token then
set HopeThird_HiddenToken[p]=token
set HopeThird_HiddenMask[p]=0
endif
set mask=HopeThird_HiddenMask[p]
if mask>=7 then
return
endif
if aid=='AZH3' and ModuloInteger(mask,2)==0 then
set mask=mask+1
elseif aid=='AZHR' and ModuloInteger(mask,4)<2 then
set mask=mask+2
elseif aid=='AZHD' and mask<4 then
set mask=mask+4
endif
set HopeThird_HiddenMask[p]=mask
if mask==7 then
call HopeThird_Refund(p)
call HopeThird_Heal(u,I2R(GetHeroStr(u,true)+GetHeroAgi(u,true)+GetHeroInt(u,true))*(.04+.04*I2R(level)),false)
endif
endfunction
function HopeThird_AfterAction takes unit u,integer aid,unit target returns nothing
local integer p=GetPlayerId(GetOwningPlayer(u))+1
local integer level=HopeThird_Level(u)
local integer kind=GetUnitTypeId(u)
local integer token=HopeChallenge_TurnToken()
local integer limit=0
local integer count=0
local group g=null
local unit enemy=null
if level<=0 or not udg_ZhandouZhong then
return
endif
if kind=='H008' and aid=='A00E' then
call SetUnitState(u,ConvertUnitState(32),GetUnitState(u,ConvertUnitState(32))+I2R(GetHeroStr(u,true))*(.2+.2*I2R(level)))
elseif kind=='H00D' and aid=='A04I' then
set HopeThird_Cavalry[p]=true
elseif kind=='N018' and aid=='A00I' and HopeThird_Enemy(target,GetOwningPlayer(u)) then
if HopeThird_ComboToken[p]!=token then
set HopeThird_ComboToken[p]=token
set HopeThird_ComboCount[p]=0
set HopeThird_ComboPaid[p]=false
endif
set HopeThird_ComboCount[p]=HopeThird_ComboCount[p]+1
set limit=2
if level==1 then
set limit=3
endif
if not HopeThird_ComboPaid[p] and HopeThird_ComboCount[p]>=limit then
set HopeThird_ComboPaid[p]=true
call HopeThird_Refund(p)
if level==3 then
call SetUnitState(u,UNIT_STATE_MANA,RMinBJ(GetUnitState(u,UNIT_STATE_MAX_MANA),GetUnitState(u,UNIT_STATE_MANA)+2.))
endif
endif
elseif kind=='E00S' and aid=='A00D' and HopeThird_Enemy(target,GetOwningPlayer(u)) then
set limit=IMinBJ(2,level)
set g=CreateGroup()
call GroupAddGroup(udg_Guaiwu_dwz,g)
loop
set enemy=FirstOfGroup(g)
exitwhen enemy==null or count>=limit
call GroupRemoveUnit(g,enemy)
if enemy!=target and HopeThird_Enemy(enemy,GetOwningPlayer(u)) then
if level==3 then
call UnitDamageTarget(u,enemy,I2R(GetHeroAgi(u,true))*1.6*udg_Skill_Dm[p],true,false,ATTACK_TYPE_NORMAL,DAMAGE_TYPE_NORMAL,WEAPON_TYPE_WHOKNOWS)
else
call UnitDamageTarget(u,enemy,I2R(GetHeroAgi(u,true))*1.2*udg_Skill_Dm[p],true,false,ATTACK_TYPE_NORMAL,DAMAGE_TYPE_NORMAL,WEAPON_TYPE_WHOKNOWS)
endif
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Weapons\\Arrow\\ArrowMissile.mdl",enemy,"origin"))
set count=count+1
endif
endloop
call DestroyGroup(g)
elseif kind=='N01E' and aid=='A00F' and HopeThird_Enemy(target,GetOwningPlayer(u)) then
call SaveInteger(HopeThird_Data,GetHandleId(target),p,IMinBJ(3,LoadInteger(HopeThird_Data,GetHandleId(target),p)+1))
set HopeThird_FireTarget[p]=target
endif
set enemy=null
set g=null
endfunction
function HopeThird_Base takes unit u,integer aid,real amount,boolean consume returns real
local integer p=GetPlayerId(GetOwningPlayer(u))+1
local integer level=HopeThird_Level(u)
local integer kind=GetUnitTypeId(u)
if level<=0 then
return amount
endif
if kind=='H008' and aid=='A03D' then
return amount+RMaxBJ(0.,GetUnitState(u,ConvertUnitState(32)))*(.2+.2*I2R(level))
elseif kind=='H00D' and aid=='A000' and HopeThird_Cavalry[p] then
if consume then
set HopeThird_Cavalry[p]=false
endif
return amount*(1.+.15+.2*I2R(level))
elseif kind=='N01A' and aid=='A01R' and GetUnitState(u,UNIT_STATE_MAX_LIFE)>0. then
return amount*(1.+RMaxBJ(0.,1.-GetWidgetLife(u)/GetUnitState(u,UNIT_STATE_MAX_LIFE))*(.2+.2*I2R(level)))
endif
return amount
endfunction
function HopeThird_Embers takes unit u,unit target returns real
local integer p=GetPlayerId(GetOwningPlayer(u))+1
local integer level=HopeThird_Level(u)
local integer count=0
if level<=0 or GetUnitTypeId(u)!='N01E' or not udg_ZhandouZhong or not HopeThird_Enemy(target,GetOwningPlayer(u)) then
return 0.
endif
set count=LoadInteger(HopeThird_Data,GetHandleId(target),p)
call SaveInteger(HopeThird_Data,GetHandleId(target),p,0)
return I2R(count*GetHeroInt(u,true))*(.4+.4*I2R(level))
endfunction
function HopeThird_Damage takes unit u,unit target,real amount returns real
local integer p=GetPlayerId(GetOwningPlayer(u))+1
local integer owner=GetPlayerId(GetOwningPlayer(target))+1
local integer kind=GetUnitTypeId(u)
local integer level=HopeThird_Level(u)
local integer token=HopeChallenge_TurnToken()
local integer h=GetHandleId(target)
local integer marks=0
if amount<=0. or not udg_ZhandouZhong then
return amount
endif
// Frost affects the marked enemy's next positive damage event against a hero.
if owner>=1 and owner<=6 and target==udg_hero[owner] and IsUnitEnemy(u,GetOwningPlayer(target)) and LoadInteger(HopeThird_Data,GetHandleId(u),101)>0 then
call SaveInteger(HopeThird_Data,GetHandleId(u),101,0)
set amount=amount*.6
endif
if p<1 or p>6 or u!=udg_hero[p] or not HopeThird_Enemy(target,GetOwningPlayer(u)) then
return amount
endif
// Hunt belongs to the target: teammates also benefit, one charge per damage event.
set marks=LoadInteger(HopeThird_Data,h,102)
if marks>0 then
call SaveInteger(HopeThird_Data,h,102,marks-1)
set amount=amount*1.25
call AdjustPlayerStateBJ(10,GetOwningPlayer(u),PLAYER_STATE_RESOURCE_GOLD)
endif
if level<=0 then
return amount
endif
if kind=='H004' then
if HopeThird_PressureToken[p]!=token or HopeThird_PressureTarget[p]!=target then
set HopeThird_PressureToken[p]=token
set HopeThird_PressureTarget[p]=target
set HopeThird_Pressure[p]=0
endif
set amount=amount*(1.+I2R(HopeThird_Pressure[p])*(.05+.05*I2R(level)))
set HopeThird_Pressure[p]=IMinBJ(3,HopeThird_Pressure[p]+1)
elseif kind=='O006' then
if HopeThird_HitsToken[p]!=token then
set HopeThird_HitsToken[p]=token
set HopeThird_Hits[p]=0
endif
set HopeThird_Hits[p]=HopeThird_Hits[p]+1
if HopeThird_Hits[p]>=3 then
set HopeThird_Hits[p]=0
call HopeThird_Heal(u,I2R(GetHeroStr(u,true)+GetHeroAgi(u,true))*(.1+.1*I2R(level)),true)
endif
endif
return amount
endfunction
