"""Exercise shipped first-career reselection with alternate native-stat models."""
from collections import defaultdict
import json
from pathlib import Path
from types import SimpleNamespace
from validate_economy import World, rawcode, body, SCRIPT

R=Path(__file__).resolve().parent
OPTIONS=json.loads((R/'patch-options.json').read_text())
CASES=0

def check(value, message):
 global CASES
 assert value,message
 CASES+=1

class ReclassWorld(World):
 def __init__(self,kind='N00D',native_base=False):
  super().__init__(); self.native_base=native_base; self.units=[];self.fail_create=False;self.fail_pay=False;self.level_events=0;self.item_events=[];self.room=True;self.pending=False;self.rolls=[1]
  self.current=None
  for i,o in enumerate(OPTIONS):
   for field,key in [('Target','target'),('Source','source')]:self.g['HopeJob_'+field][i]=rawcode(o[key])
   for field,key in [('Stage','stage'),('Str','reqStr'),('Agi','reqAgi'),('Int','reqInt')]:self.g['HopeJob_'+field][i]=o[key]
  for state in ['LIFE','MAX_LIFE','MANA','MAX_MANA']:self.g['UNIT_STATE_'+state]=state.lower()
  self.g.update({
   'HopeJob_InRoom':lambda p:self.room and self.g['udg_hero'][p+1].life>.405 and not self.g['udg_ZhandouZhong'],
   'HopeRoute_RewardPending':lambda i:self.pending,
   'GetUnitAbilityLevel':lambda u,a:0 if u is None else u.abilities.get(a,0),
   'GetHeroStr':lambda u,b:0 if u is None else u.str,
   'GetHeroAgi':lambda u,b:0 if u is None else u.agi,
   'GetHeroInt':lambda u,b:0 if u is None else u.int,
   'GetHeroXP':lambda u:0 if u is None else u.xp,
   'GetHeroSkillPoints':lambda u:0 if u is None else u.points,
   'GetUnitState':lambda u,s:0. if u is None else getattr(u,s),
   'SetUnitState':lambda u,s,v:setattr(u,s,v),
   'GetUnitX':lambda u:0.,'GetUnitY':lambda u:0.,'GetUnitFacing':lambda u:180.,
   'GetUnitName':lambda u:str(u.kind), 'CreateUnit':self.create,
   'RemoveUnit':lambda u:setattr(u,'removed',True),
   'UnitAddAbility':self.addability,'UnitRemoveAbility':self.removeability,
   'SetUnitAbilityLevel':self.setability,'SetHeroStr':self.setstr,'SetHeroAgi':lambda u,v,b:setattr(u,'agi',v),'SetHeroInt':self.setint,
   'SetHeroXP':self.setxp,'UnitModifySkillPoints':lambda u,v:setattr(u,'points',u.points+v),
   'UnitItemInSlot':lambda u,s:u.items[s], 'UnitRemoveItem':self.drop,'UnitAddItem':self.pickup,
   'ConvertUnitState':lambda s:'attack' if s==18 else str(s),
   'GetUnitMoveSpeed':lambda u:u.speed,'SetUnitMoveSpeed':lambda u,v:setattr(u,'speed',v),
   'AddUnitToStock':lambda *a:None,'SelectUnitForPlayerSingle':lambda *a:None,
   'HopeJob_ShowFrame':lambda *a:None,'DzGetTriggerUIEventPlayer':lambda:0,
   'GetRandomInt':self.random,'GetTriggeringTrigger':lambda:123,'GetTriggerUnit':lambda:self.current,
  })
  self.load('HopePoints_Spend','HopeReclass_First','HopeReclass_Can','HopeReclass_Training','HopeReclass_Points','HopeReclass_Blocker','HopeReclass_Commit','HopeReclass_PotionLearn','Trig____________________001Actions')
  self.pay=self.g['HopePoints_Spend'];self.g['HopePoints_Spend']=lambda p,c:False if self.fail_pay else self.pay(p,c)
  self.u=self.newunit(0,rawcode(kind));self.g['udg_hero'][1]=self.u;self.g['udg_Mj_Danwei'][1]=self.newunit(0,rawcode('h000'))
  self.g['udg_Wj_jf'][1]=100;self.g['udg_xingdong_dianSx'][1]=6;self.g['udg_xingdong_dian'][1]=5
  self.g['udg_cz1Str_up'][1]=2.;self.g['udg_cz2Agi_up'][1]=2.5;self.g['udg_cz3Int_up'][1]=1.5
  self.g['udg_DEX'][1]=7.;self.g['udg_shengji_dian'][1]=4;self.g['udg_Skill_Dm'][1]=1.7
  self.g['udg_Yaoshui_shenyu_cs'][1]=2
 def newunit(self,p,kind):
  u=SimpleNamespace(owner=p,kind=kind,hero=True,paused=False,level=12,life=100.,mana=11.,max_life=200.,max_mana=30.,str=25,agi=30,int=20,xp=900,points=2,abilities={},items=[None]*6,removed=False,attack=10.,speed=280.)
  self.units.append(u);return u
 def create(self,p,k,*a):
  if self.fail_create:return None
  u=self.newunit(p,k);u.level=1;u.xp=0;u.points=1;return u
 def random(self,lo,hi):
  self.integer_random_calls.append((lo,hi));v=self.rolls.pop(0);assert lo<=v<=hi;return v
 def nativebonus(self,a,rank):
  return rank*(5 if a==rawcode('A00P') else 3) if a in (rawcode('A00P'),rawcode('A00O')) else 0
 def addability(self,u,a):
  if u is not None and a not in u.abilities:self.setability(u,a,1)
  return True
 def removeability(self,u,a):
  if u is not None:
   if self.native_base:u.agi-=self.nativebonus(a,u.abilities.get(a,0))
   u.abilities.pop(a,None)
  return True
 def setability(self,u,a,r):
  if self.native_base:u.agi+=self.nativebonus(a,r)-self.nativebonus(a,u.abilities.get(a,0))
  u.abilities[a]=r
  return r
 def setstr(self,u,v,b):u.max_life+=(v-u.str)*2;u.str=v
 def setint(self,u,v,b):u.max_mana+=v-u.int;u.int=v
 def setxp(self,u,v,b):
  self.current=u;self.level_events+=1
  self.g['Trig____________________001Actions']()
  u.xp=v;u.level=12;u.points=12
 def drop(self,u,it):
  self.item_events.append(('drop',u,it));u.items[u.items.index(it)]=None
  u.agi-=it.agi;u.max_life-=it.hp;u.max_mana-=it.mp
  self.g['udg_cz2Agi_up'][u.owner+1]-=it.growth
 def pickup(self,u,it):
  self.item_events.append(('pickup',u,it));u.items[u.items.index(None)]=it
  u.agi+=it.agi;u.max_life+=it.hp;u.max_mana+=it.mp
  self.g['udg_cz2Agi_up'][u.owner+1]+=it.growth
  return True
 def commit(self,i):self.g['HopeReclass_Commit'](i,0)

# Eight ordinary routes plus hidden are allowed; all later stages denied.
w=ReclassWorld()
for kind in ['N00D','H003','H001','N007','E008','N00E','O001','O003','HZ01']:
 w.u.kind=rawcode(kind);check(w.g['HopeReclass_Can'](1),'Eligible first profession '+kind)
for kind in ['H000','HZ02','HZ03','N016','N01E','H008','O004']:
 w.u.kind=rawcode(kind);check(not w.g['HopeReclass_Can'](1),'No reselection from '+kind)

# Success preserves all unrelated earned stats and equipment, independently of
# whether an engine exposes Aamk stats as base or as a native bonus.
for native in [False,True]:
 for source,passive in [('N00D','A00P'),('E008','A00O')]:
  w=ReclassWorld(source,native);old=w.u;w.setability(old,rawcode(passive),3)
  it=SimpleNamespace(agi=4,hp=10.,mp=5.,growth=.25);w.pickup(old,it);w.item_events.clear()
  before=(old.str,old.agi-(w.nativebonus(rawcode(passive),3) if native else 0),old.int,old.max_life,old.max_mana)
  old.life=73.;old.mana=9.;growth=w.g['udg_cz2Agi_up'][1]
  w.commit(2);u=w.g['udg_hero'][1]
  check(u is not old and old.removed,'Fresh target replaces old hero')
  check((u.str,u.agi,u.int,u.max_life,u.max_mana)==before,'Native passive removed once; non-career stats and item stats retained')
  check((u.life,u.mana)==(73.,9.),'Reselection does not heal or regenerate mana')
  check((u.level,u.xp,u.points)==(12,900,5),'XP preserved; only three spent profession points refunded')
  check(w.g['udg_Wj_jf'][1]==90 and w.writes==[(0,'boss_jf',90)],'Exactly one ten-point spend')
  check(w.g['udg_cz2Agi_up'][1]==growth and w.g['udg_DEX'][1]==7 and w.g['udg_shengji_dian'][1]==4 and w.g['udg_Skill_Dm'][1]==1.7,'No repeated level/growth/global rewards')
  check([x[0] for x in w.item_events]==['drop','pickup'] and u.items[0] is it,'Each inventory item transferred once')
  check(w.g['udg_xingdong_dianSx'][1]==(5 if source=='N00D' else 6),'Rogue learned AP reclaimed only from rogue')
  check(not w.g['HopeReclass_Busy'][1] and not w.g['HopeReclass_Replacing'],'Transaction locks released')

# Hidden training and future growth detach, but earned level stats stay.
w=ReclassWorld('HZ01');w.u.abilities[rawcode('AZHP')]=3
for a in ['str','agi','int']:setattr(w.u,a,getattr(w.u,a)+6)
w.u.max_life+=12;w.u.max_mana+=6
for a in ['udg_cz1Str_up','udg_cz2Agi_up','udg_cz3Int_up']:w.g[a][1]+=.15
w.commit(2);u=w.g['udg_hero'][1]
check((u.str,u.agi,u.int)==(25,30,20),'Only hidden training removed from base stats')
check((u.max_life,u.max_mana)==(200.,30.),'Hidden stat-derived capacities reclaimed')
check(abs(w.g['udg_cz1Str_up'][1]-2.)<1e-9,'Hidden future growth removed')
check(u.points==5,'Hidden skill points refunded')

# Random remains 10/90; hidden -> hidden is a paid valid roll without stacking.
for roll in range(1,101):
 w=ReclassWorld('HZ01');w.rolls=[roll,4]
 for a in ['udg_cz1Str_up','udg_cz2Agi_up','udg_cz3Int_up']:w.g[a][1]+=.15
 w.commit(24);u=w.g['udg_hero'][1]
 check(u.kind==(rawcode('HZ01') if roll<=10 else rawcode('E008')),'Random first-stage chance '+str(roll))
 check(abs(w.g['udg_cz1Str_up'][1]-(2.15 if roll<=10 else 2.))<1e-9,'No hidden growth stacking')
 check(w.g['udg_Wj_jf'][1]==90,'All accepted random outcomes cost ten')

# Guard and rollback scenarios: no payment, no new state, no inappropriate RNG.
for situation in ['same','funds','cloud','battle','outside','reward','pending','temporary','busy','advanced','create','payment','clean_native','clean_hidden']:
 w=ReclassWorld('N00D',True);old=w.u;w.setability(old,rawcode('A00P'),3);index=2
 if situation=='same':index=0
 elif situation=='funds':w.g['udg_Wj_jf'][1]=9
 elif situation=='cloud':w.cloud_ready.clear()
 elif situation=='battle':w.g['udg_ZhandouZhong']=True
 elif situation=='outside':w.room=False
 elif situation=='reward':w.pending=True
 elif situation=='pending':w.g['HopeChoice_PlayerPending'][0]=1
 elif situation=='temporary':w.g['udg_Ls_zj_Agi'][1]=3
 elif situation=='busy':w.g['HopeReclass_Busy'][1]=True
 elif situation=='advanced':old.kind=rawcode('N018')
 elif situation=='create':w.fail_create=True
 elif situation=='payment':w.fail_pay=True
 elif situation=='clean_native':old.agi=20;index=4 # passive removal leaves five, below ten
 elif situation=='clean_hidden':old.kind=rawcode('HZ01');old.abilities[rawcode('AZHP')]=3;old.str=14;index=24
 before=(old.str,old.agi,old.int,old.life,old.mana,old.points,dict(old.abilities),w.g['udg_Wj_jf'][1])
 w.commit(index)
 after=(old.str,old.agi,old.int,old.life,old.mana,old.points,dict(old.abilities),w.g['udg_Wj_jf'][1])
 check(before==after and w.g['udg_hero'][1] is old and not old.removed,'Rejected transaction unchanged: '+situation)
 check(not w.writes and not w.integer_random_calls,'No charge/RNG on rejection: '+situation)

w=ReclassWorld('N00E')
for rank in [1,2,3,1,2,3]:
 w.u.abilities[rawcode('A00N')]=rank;w.g['HopeReclass_PotionLearn'](w.u)
check(w.g['udg_Yaoshui_shenyu_cs'][1]==5,'Same priest rank grants potion only once across relearning')
w.u.abilities[rawcode('A04W')]=2;w.commit(2)
check(w.g['udg_hero'][1].points==7,'Both priest skills refunded; existing consumables retained')
check(w.g['udg_Yaoshui_shenyu_cs'][1]==5,'Prior potion ownership retained')

commit=body('HopeJob_Commit')[3]
check(commit.index('call HopeReclass_Commit')<commit.index('if index==24 then'),'Shared fixed confirm routes first-career reselection before normal promotion')
check('HopeJob_Selected' not in body('HopeReclass_Commit')[3] and 'HopeJob_Entry' not in body('HopeReclass_Commit')[3],'Gameplay never depends on local selection state')
check('HopeReclass_Replacing' in body('Trig____________________001Actions')[3],'Actual level reward callback has replacement suppression')
check('call HopeReclass_PotionLearn(GetTriggerUnit())' in body('Trig_JN_____________012Actions')[3],'Actual priest learning uses anti-duplicate gift ledger')
print(f'PASS: {CASES} first-career reselection assertions (fee, stage guards, two native Aamk models, refund, equipment, rollback, hidden odds, no repeated level/potion rewards).')
