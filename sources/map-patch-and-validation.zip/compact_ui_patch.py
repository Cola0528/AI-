"""v10 compact choices and a continuous scrollable draw log; local UI state only."""
import re,json
from modern_choices_patch import block,replace

GLOBALS='''
integer HopeScroll_Hover=0
integer HopeLog_Count=0
integer HopeLog_Cached=-1
integer HopeLog_Offset=0
integer HopeLog_Status=0
boolean HopeLog_Visible=false
string array HopeLog_Line
integer HopeR_Count=0
integer HopeR_Offset=0
integer HopeR_Key=0
integer HopeR_Current=0
integer HopeR_Active=0
string array HopeR_Line
integer array HopeR_Viewport
integer array HopeR_Body
integer array HopeR_Up
integer array HopeR_Down
integer array HopeR_Notice
'''
EARLY='''function HopeScroll_Add takes integer target,string text returns nothing
local integer p=0
local integer start=0
local integer size=StringLength(text)
local string line=""
loop
exitwhen p>size
if p==size or SubString(text,p,p+2)=="|n" then
set line=SubString(text,start,p)
if line!="" then
if target==1 then
set HopeLog_Line[HopeLog_Count]=line
set HopeLog_Count=HopeLog_Count+1
else
set HopeR_Line[HopeR_Count]=line
set HopeR_Count=HopeR_Count+1
endif
endif
set p=p+2
set start=p
else
set p=p+1
endif
endloop
endfunction
function HopeScroll_View takes integer target,integer offset,integer rows returns string
local integer i=0
local integer count=HopeLog_Count
local string text=""
if target==2 then
set count=HopeR_Count
endif
loop
exitwhen i>=rows or offset+i>=count
if i>0 then
set text=text+"|n"
endif
if target==1 then
set text=text+HopeLog_Line[offset+i]
else
set text=text+HopeR_Line[offset+i]
endif
set i=i+1
endloop
return text
endfunction
function HopeScroll_Move takes integer target,integer delta returns nothing
if target==1 then
set HopeLog_Offset=IMaxBJ(0,IMinBJ(IMaxBJ(0,HopeLog_Count-13),HopeLog_Offset+delta))
else
set HopeR_Offset=IMaxBJ(0,IMinBJ(IMaxBJ(0,HopeR_Count-5),HopeR_Offset+delta))
endif
endfunction
function HopeScroll_Capturing takes nothing returns boolean
if HopeScroll_Hover==1 then
return HopeDraw_Open and HopeLog_Visible and not HopeRoute_Assigning
elseif HopeScroll_Hover==2 then
return HopeR_Active>0 and not HopeChoice_Hidden and not HopeRoute_Assigning and HopeChoice_DialogPending[HopeR_Active]
endif
return false
endfunction
function HopeScroll_EnterLog takes nothing returns nothing
set HopeScroll_Hover=1
endfunction
function HopeScroll_EnterR takes nothing returns nothing
set HopeScroll_Hover=2
endfunction
function HopeScroll_Leave takes nothing returns nothing
set HopeScroll_Hover=0
endfunction
function HopeScroll_Wheel takes nothing returns nothing
if HopeScroll_Capturing() then
if DzGetWheelDelta()<0 then
call HopeScroll_Move(HopeScroll_Hover,3)
elseif DzGetWheelDelta()>0 then
call HopeScroll_Move(HopeScroll_Hover,-3)
endif
endif
endfunction
function HopeScroll_LogUp takes nothing returns nothing
call HopeScroll_Move(1,-3)
endfunction
function HopeScroll_LogDown takes nothing returns nothing
call HopeScroll_Move(1,3)
endfunction
function HopeScroll_Latest takes nothing returns nothing
set HopeLog_Offset=0
endfunction
function HopeScroll_RUp takes nothing returns nothing
call HopeScroll_Move(2,-2)
endfunction
function HopeScroll_RDown takes nothing returns nothing
call HopeScroll_Move(2,2)
endfunction
'''

LOG='''function HopeDraw_Refresh takes nothing returns nothing
local integer owner=GetPlayerId(GetLocalPlayer())
local integer record=HopeDraw_Count[owner]
local integer slot=0
local integer last=IMaxBJ(1,record-63)
local boolean show=HopeDraw_Open and not (HopeChoice_HasPending() and not HopeChoice_Hidden) and not HopeRoute_Assigning
set HopeLog_Visible=show
call HopeJob_ShowFrame(HopeDraw_Panel,show)
if not show then
return
endif
if HopeLog_Cached!=HopeDraw_Count[owner] then
set HopeLog_Count=0
set HopeLog_Offset=0
set HopeLog_Cached=HopeDraw_Count[owner]
loop
exitwhen record<last
set slot=ModuloInteger(record,64)*2
call HopeScroll_Add(1,"|cffd2b879#"+I2S(record)+" "+LoadStr(HopeDraw_History,owner,slot)+"|r")
call HopeScroll_Add(1,LoadStr(HopeDraw_History,owner,slot+1))
set record=record-1
endloop
endif
call HopeJob_SetText(HopeDraw_Title,"抽取记录 · 最新在上")
if HopeLog_Count==0 then
call HopeJob_SetText(HopeDraw_Text,"暂无记录。|n十连与木材抽奖的结果将连续列在这里。")
call HopeJob_SetText(HopeLog_Status,"滚轮查看 · 保留64次")
else
call HopeJob_SetText(HopeDraw_Text,HopeScroll_View(1,HopeLog_Offset,13))
call HopeJob_SetText(HopeLog_Status,I2S(HopeLog_Offset+1)+"–"+I2S(IMinBJ(HopeLog_Count,HopeLog_Offset+13))+" / "+I2S(HopeLog_Count)+" 行 · 滚轮查看")
endif
endfunction'''

CREATE=r'''function HopeDraw_Create takes nothing returns nothing
local integer f=0
local integer viewport=0
set HopeDraw_Panel=HopeQoL_Surface("HopeDrawResults",.260,.500,.280,.226)
set HopeDraw_Title=HopeQoL_Label("HopeDrawTitle",HopeDraw_Panel,.010,-.009,.198,.018,"")
set f=HopeQoL_Button("HopeDrawClose",HopeDraw_Panel,.230,-.006,.040,.022,"关闭")
call HopeQoL_Bind(f,function HopeDraw_Close,false)
set viewport=HopeQoL_Button("HopeLogViewport",HopeDraw_Panel,.010,-.034,.260,.155,"")
call DzFrameSetScriptByCode(viewport,2,function HopeScroll_EnterLog,false)
call DzFrameSetScriptByCode(viewport,3,function HopeScroll_Leave,false)
set HopeDraw_Text=HopeQoL_Label("HopeDrawText",viewport,.006,-.005,.248,.145,"")
call DzFrameSetFont(HopeDraw_Text,"Fonts\\ZiTi.ttf",.0085,0)
set f=HopeQoL_Button("HopeLogUp",HopeDraw_Panel,.010,-.197,.028,.020,"上")
call HopeQoL_Bind(f,function HopeScroll_LogUp,false)
set f=HopeQoL_Button("HopeLogDown",HopeDraw_Panel,.043,-.197,.028,.020,"下")
call HopeQoL_Bind(f,function HopeScroll_LogDown,false)
set HopeLog_Status=HopeQoL_Label("HopeLogStatus",HopeDraw_Panel,.077,-.199,.140,.016,"")
call DzFrameSetFont(HopeLog_Status,"Fonts\\ZiTi.ttf",.008,0)
set f=HopeQoL_Button("HopeLogLatest",HopeDraw_Panel,.224,-.197,.046,.020,"最新")
call HopeQoL_Bind(f,function HopeScroll_Latest,false)
set f=HopeQoL_Button("HopeDrawHistory",DzGetGameUI(),0.,0.,.064,.021,"抽取记录")
set HopeLayout_History=f
call DzFrameSetAbsolutePoint(f,0,.084,.196)
call HopeQoL_Bind(f,function HopeDraw_OpenHistory,false)
call HopeJob_ShowFrame(HopeDraw_Panel,false)
endfunction'''

LAYOUT=r'''function HopeLayout_Choice takes integer i,dialog d returns nothing
local integer j=1
local real w=.280
local real h=.155
local real x=0.
local real y=0.
local integer count=LoadInteger(HopeModern_Data,GetHandleId(d),0)
local boolean isR=d==udg_Rskill_shifoutihuan[GetPlayerId(GetLocalPlayer())+1]
if d==udg_Youxi_ND_XZ then
set w=.280
set h=.179
elseif isR then
set w=.268
set h=.155
endif
call HopeLayout_Place(HopeModern_Panel[i],0,(.8-w)/2.,.495,w,h)
call HopeLayout_Place(HopeModern_Title[i],HopeModern_Panel[i],.010,-.009,w-.076,.019)
call HopeLayout_Place(HopeLayout_Fold[i],HopeModern_Panel[i],w-.056,-.007,.046,.021)
call DzFrameSetText(HopeLayout_Fold[i],"收起")
call HopeLayout_Show(HopeR_Viewport[i],isR)
call HopeLayout_Show(HopeR_Up[i],isR)
call HopeLayout_Show(HopeR_Down[i],isR)
call HopeLayout_Show(HopeR_Notice[i],isR)
call HopeLayout_Show(HopeModern_Description[i],not isR)
if not isR then
call HopeLayout_Place(HopeModern_Description[i],HopeModern_Panel[i],.010,-.036,w-.020,.037)
call DzFrameSetFont(HopeModern_Description[i],"Fonts\\ZiTi.ttf",.009,0)
endif
loop
exitwhen j>count
if isR then
set x=.010+I2R(j-1)*.130
call HopeLayout_Place(HopeModern_Row[i*8+j],HopeModern_Panel[i],x,-.123,.118,.023)
if j==1 then
call DzFrameSetText(HopeModern_Row[i*8+j],"替换")
else
call DzFrameSetText(HopeModern_Row[i*8+j],"保留原技能")
endif
else
set x=.010+I2R(ModuloInteger(j-1,2))*.134
set y=-.080-I2R((j-1)/2)*.031
call HopeLayout_Place(HopeModern_Row[i*8+j],HopeModern_Panel[i],x,y,.126,.026)
endif
set j=j+1
endloop
endfunction'''

RREFRESH='''function HopeCompact_RRefresh takes integer i,dialog d,integer abilityId returns nothing
local integer owner=GetPlayerId(GetLocalPlayer())+1
local string current="无"
if HopeR_Key!=abilityId or HopeR_Current!=udg_R_Skill[owner] then
set HopeR_Key=abilityId
set HopeR_Current=udg_R_Skill[owner]
set HopeR_Count=0
set HopeR_Offset=0
if udg_R_Skill[owner]!=0 then
set current=GetAbilityName(udg_R_Skill[owner])
endif
call HopeScroll_Add(2,"当前："+current+"|n新技能："+GetAbilityName(abilityId))
call HopeScroll_Add(2,HopeCompact_RText(abilityId))
endif
set HopeR_Active=i
call HopeJob_SetText(HopeModern_Title[i],"替换 R 技能")
call HopeJob_SetText(HopeR_Body[i],HopeScroll_View(2,HopeR_Offset,5))
call HopeJob_SetText(HopeR_Notice[i],"放弃不退费用 · 滚轮/上下按钮查看详情")
endfunction
'''

def wrap(text,limit=23):
    text=re.sub(r'\|c[0-9a-fA-F]{8}|\|r','',text)
    result=[]
    for line in text.split('|n'):
        if not line:continue
        chunk='';width=0
        for char in line:
            size=1 if ord(char)>127 else .62
            if chunk and width+size>limit:
                result.append(chunk);chunk='';width=0
            chunk+=char;width+=size
        result.append(chunk)
    return '|n'.join(result)

def apply(src):
    src=src.replace('endglobals',GLOBALS+'\nendglobals',1)
    # Helpers use the established pending functions and precede existing camera wheel.
    pos=src.index('function s__hardware_OnWheel takes')
    src=src[:pos]+EARLY+src[pos:]
    f=block(src,'s__hardware_OnWheel').replace('local integer delta=DzGetWheelDelta()',
      'local integer delta=DzGetWheelDelta()\nif HopeScroll_Capturing() then\nreturn\nendif')
    src=replace(src,'s__hardware_OnWheel',f)
    # Preserve every R description; wrap UTF-8 safely at build time.
    from pathlib import Path
    profiles=(Path('/workspace/map-edit/Units_campaignabilitystrings.txt')).read_text()
    ids=[]
    for m in re.finditer(r'^\[(.*?)\]\n(.*?)(?=^\[|\Z)',profiles,re.M|re.S):
        if re.search(r'^Name=R',m[2],re.M):ids.append(m[1])
    function=block(src,'HopeSkill_Original');rtext='function HopeCompact_RText takes integer id returns string\n'
    for i,alias in enumerate(ids):
        m=re.search(r"(?:if|elseif) id=='"+alias+r"' then\nreturn (\".*\")",function)
        assert m,alias
        text=wrap(json.loads(m[1]))
        rtext+=('if' if i==0 else 'elseif')+" id=='"+alias+"' then\nreturn "+json.dumps(text,ensure_ascii=False)+'\n'
    rtext+='endif\nreturn HopeSkill_Original(id,1)\nendfunction\n'
    src=src.replace('function HopeModern_Refresh takes',rtext+RREFRESH+'\nfunction HopeModern_Refresh takes',1)
    f=block(src,'HopeModern_Refresh').replace('set HopeModern_Tick=HopeModern_Tick+1','set HopeModern_Tick=HopeModern_Tick+1\nset HopeR_Active=0')
    f=f.replace('call HopeLayout_Choice(i,d)','call HopeLayout_Choice(i,d)\nif d==udg_Rskill_shifoutihuan[owner+1] then\ncall HopeCompact_RRefresh(i,d,abilityId)\nendif')
    src=replace(src,'HopeModern_Refresh',f)
    src=replace(src,'HopeLayout_Choice',LAYOUT)
    f=block(src,'HopeModern_Create')
    for i in range(1,14):
        anchor=f'call HopeJob_ShowFrame(HopeModern_Panel[{i}],false)'
        viewport=f'''set HopeR_Viewport[{i}]=HopeQoL_Button("HopeRViewport{i}",HopeModern_Panel[{i}],.010,-.034,.216,.066,"")
call DzFrameSetScriptByCode(HopeR_Viewport[{i}],2,function HopeScroll_EnterR,false)
call DzFrameSetScriptByCode(HopeR_Viewport[{i}],3,function HopeScroll_Leave,false)
set HopeR_Body[{i}]=HopeQoL_Label("HopeRBody{i}",HopeR_Viewport[{i}],.004,-.003,.208,.059,"")
call DzFrameSetFont(HopeR_Body[{i}],"Fonts\\\\ZiTi.ttf",.0085,0)
set HopeR_Up[{i}]=HopeQoL_Button("HopeRUp{i}",HopeModern_Panel[{i}],.235,-.034,.023,.023,"上")
call HopeQoL_Bind(HopeR_Up[{i}],function HopeScroll_RUp,false)
set HopeR_Down[{i}]=HopeQoL_Button("HopeRDown{i}",HopeModern_Panel[{i}],.235,-.076,.023,.023,"下")
call HopeQoL_Bind(HopeR_Down[{i}],function HopeScroll_RDown,false)
set HopeR_Notice[{i}]=HopeQoL_Label("HopeRNotice{i}",HopeModern_Panel[{i}],.010,-.105,.248,.012,"")
call DzFrameSetFont(HopeR_Notice[{i}],"Fonts\\\\ZiTi.ttf",.008,0)
'''
        assert anchor in f;f=f.replace(anchor,viewport+anchor)
    src=replace(src,'HopeModern_Create',f)
    src=replace(src,'HopeDraw_Create',CREATE)
    src=replace(src,'HopeDraw_Refresh',LOG)
    for name in ['HopeDraw_Previous','HopeDraw_Next']:
        src=src.replace(block(src,name),'',1)
    src=src.replace('call HopeWood_Init()','call HopeWood_Init()\ncall DzTriggerRegisterMouseWheelEventByCode(null,false,function HopeScroll_Wheel)',1)
    # Rules belong to the product tooltip; log entries contain outcomes only.
    src=src.replace('result+"|n|n木材抽取50%谢谢惠顾；未抽空时沿用十连奖池。",false','result,false')
    return src
