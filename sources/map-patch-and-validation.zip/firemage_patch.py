"""Separate the fire mage's two Channel commands without changing combat logic.

A00F explicitly uses ``channel``. A04U used the same profile order and omitted
its Channel DataF field at every rank, so the engine selected either ready
ability for the same order. Write a distinct Base Order ID at all three ranks.
"""
import re
from hidden_objects import read_slk, update_section


def apply_script(src):
    """The existing rawcode-based combat handlers need no modification."""
    assert 'return GetSpellAbilityId()==$41303455' in src
    assert 'return GetSpellAbilityId()==$41303046 or GetSpellAbilityId()==$4130334A' in src
    return src


def apply_objects(root, output):
    path = output / 'Units_AbilityData.slk'
    lines, rows, heads, objects = read_slk(path)
    original_rows = {y: row.copy() for y, row in rows.items()}
    pyro_y, pyro = objects['A04U']
    assert pyro[heads['code']] == '"ANcl"'
    assert pyro[heads['levels']] == '3'
    assert objects['A00F'][1][heads['DataF1']] == '"channel"'
    for alias, (_, row) in objects.items():
        if alias != 'A04U':
            assert all(row.get(heads['DataF' + str(rank)]) != '"acidbomb"'
                       for rank in range(1, 4)), ('acidbomb is already assigned', alias)
    cells = []
    for rank in range(1, 4):
        column = heads['DataF' + str(rank)]
        # The optimized original row leaves all three fields absent. Reject
        # unexpected edits rather than silently overriding another fix.
        assert column not in pyro, ('unexpected original pyro order', rank)
        cells.append(f'C;X{column};Y{pyro_y};K"acidbomb"')
    assert lines[-1] == 'E'
    path.write_text('\r\n'.join(lines[:-1] + cells + ['E']) + '\r\n', encoding='utf-8')
    _, written, _, _ = read_slk(path)
    for y, old in original_rows.items():
        expected = old.copy()
        if y == pyro_y:
            expected.update({heads['DataF' + str(rank)]: '"acidbomb"' for rank in range(1, 4)})
        assert written[y] == expected, ('unexpected SLK modification', y)

    path = output / 'Units_campaignabilitystrings.txt'
    profile = path.read_text(encoding='utf-8-sig')
    match = re.search(r'^\[A04U\]\n(.*?)(?=^\[|\Z)', profile, re.M | re.S)
    assert match and re.search(r'^Order=channel$', match[1], re.M)
    assert re.search(r'^Hotkey=E$', match[1], re.M)
    profile = update_section(profile, 'A04U', {'Order': 'acidbomb', 'Buttonpos': '2,2'})
    path.write_text(profile, encoding='utf-8')
    print('Fire mage: Q fireball and E pyroblast have distinct Channel orders; pyroblast has its own button position')
