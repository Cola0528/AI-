"""Bound v15 changes against the immutable published v14 map."""
from pathlib import Path
import sys,hashlib,json,re
sys.path.insert(0,'/workspace/map-tools')
from mpq import op,read,L
from third_patch import G
from third_design import DESIGNS
from validate_object_dependencies import parse_slk,parse_profile

root=Path(__file__).parent
baseline=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/outputs/AI-Tower-Class-Resources-v14.w3x')
assert hashlib.sha256(baseline.read_bytes()).hexdigest()=='86db039c6fb76b155adffed5e71f3d15ec60f55703766b23623461f541cc3d02'
expected={'HopeSkill_InitIds','HopeSkill_Original','HopeSkill_Preview','Trig_JN_______001Actions','Trig_JN_______004Actions','Trig_JN_______005Actions','Trig_JN__________0001Actions','Trig_JN_____________0010Actions','Trig_JN_______002Actions','Trig________________________________028Actions','Trig____________________005Actions','HopeProfession_Text','HopeJob_Visible','HopeJob_Blocker','HopeJob_Awaken','HopeJob_Commit','HopeJob_RefreshContent','HopeHidden_Cast','HopeJob_Cast','HopeJob_Init'}
h=op(baseline,0x100)
try:
    old=read(h,'war3map.j').decode();new=(root/'war3map-patched.j').read_text()
    pattern=r'^function (\w+) takes.*?^endfunction'
    a={m[1]:m[0] for m in re.finditer(pattern,old,re.M|re.S)}
    b={m[1]:m[0] for m in re.finditer(pattern,new,re.M|re.S)}
    assert not a.keys()-b.keys(),'existing functions removed'
    changed={k for k in a if a[k]!=b[k]}
    assert changed==expected,changed^expected
    added=sorted(b.keys()-a.keys())
    assert len(added)==17 and all(k.startswith('HopeThird_') or k=='HopeJob_GoldCost' for k in added)
    def outside(s):
        s=re.sub(pattern,'',s,flags=re.M|re.S)
        return '\n'.join(line for line in s.splitlines() if line.strip() and not line.strip().startswith('//'))
    restored=new.replace('globals\n'+G,'globals\n',1)
    for native in ['native DzSetUnitName takes unit whichUnit,string name returns nothing\n','native DzSetUnitProperName takes unit whichUnit,string name returns nothing\n']:
        assert restored.count(native)==1
        restored=restored.replace(native,'',1)
    assert outside(restored)==outside(old),'other global/init declarations changed'
    identical=[];different=[]
    for p in (root/'modified').iterdir():
        if not p.name.startswith('Units_') and p.name!='war3map.w3a':continue
        key='Units\\'+p.name[6:] if p.name.startswith('Units_') else p.name
        before=read(h,key);after=p.read_bytes()
        if before==after:identical.append(key)
        else:
            different.append(key)
            if p.name=='Units_AbilityData.slk':
                x=parse_slk(before,'v14').rows;y=parse_slk(after,'v15').rows
                assert all(y[k]==v for k,v in x.items())
                assert y.keys()-x.keys()=={d['id'] for d in DESIGNS.values() if d['id']!='AZ36'}
            elif p.name=='Units_campaignabilitystrings.txt':
                x=parse_profile(before,'v14');y=parse_profile(after,'v15')
                assert {k for k in x if x[k]!=y[k]}=={'AZ36'}
                assert {k for k in x['AZ36'] if x['AZ36'][k]!=y['AZ36'][k]}=={'ubertip'}
            else:raise AssertionError('Unexpected object delta '+key)
    assert len(identical)==9 and len(different)==2
finally:L.SFileCloseArchive(h)
print(json.dumps({'baseline':baseline.name,'jass_sha256':hashlib.sha256(new.encode()).hexdigest(),'changed_existing_functions':sorted(changed),'new_functions':added,'unchanged_functions':len(a)-len(changed),'unchanged_objects':identical,'changed_objects':different,'all_other_script_declarations_identical':True,'existing_ability_slk_rows_unchanged':True},ensure_ascii=False,indent=2))
