"""Scale multiplayer combat once per newly spawned enemy in every difficulty.

Apply after challenge_patch/challenge_enemies; no UI refresh mutates combat stats.
The original player-count monster curve and handicap remain, now recalculated
per room so departed players do not permanently increase later fights.
"""
from __future__ import annotations
import re

HELPERS = r'''
// Count participating human slots, including fallen heroes who can be revived.
// A player who left is excluded at the next room, never partway through a fight.
function HopeCoop_CountPlayers takes nothing returns integer
local integer i=0
local integer count=0
loop
exitwhen i>=6
if not HopeRoute_Left[i] and GetPlayerSlotState(Player(i))==PLAYER_SLOT_STATE_PLAYING and GetPlayerController(Player(i))==MAP_CONTROL_USER and IsPlayerInForce(Player(i),udg_WJZ) and udg_hero[i+1]!=null and GetUnitTypeId(udg_hero[i+1])!=0 then
set count=count+1
endif
set i=i+1
endloop
return IMaxBJ(1,count)
endfunction
function HopeCoop_MonsterCount takes integer players,integer rounds returns integer
local integer base=players+3
if players<3 then
set base=1+2*players
endif
// There are 13 spawn positions; normal encounters can add one random monster.
return IMinBJ(12,IMaxBJ(1,base+IMinBJ(12,IMaxBJ(0,rounds))))
endfunction
function HopeCoop_LifeFactor takes integer players,boolean boss returns real
local real extra=I2R(IMinBJ(6,IMaxBJ(1,players))-1)
if boss then
return 1.+.45*extra
endif
return 1.+.20*extra
endfunction
function HopeCoop_AttackFactor takes integer players returns real
return 1.+.10*I2R(IMinBJ(6,IMaxBJ(1,players))-1)
endfunction
function HopeCoop_IsBoss takes unit u returns boolean
local integer kind=GetUnitTypeId(u)
return IsUnitType(u,UNIT_TYPE_HERO) or LoadBoolean(YDHT,kind,$FB89B46C) or kind==udg_BOSS_LX_______DA[1] or kind==udg_BOSS_LX[0] or kind==udg_BOSS_LX[1] or kind==udg_BOSS_LX[2]
endfunction
function HopeCoop_BeginRoom takes nothing returns nothing
local integer players=HopeCoop_CountPlayers()
if not HopeCoop_Started then
// Capture the actual original single-player setting, including default mode.
set HopeCoop_BaseHandicap=GetPlayerHandicapBJ(Player(11))
set HopeCoop_Started=true
endif
if players>=3 then
call SetPlayerHandicapBJ(Player(11),HopeCoop_BaseHandicap+20.)
else
call SetPlayerHandicapBJ(Player(11),HopeCoop_BaseHandicap)
endif
set udg_Guaiwu_sl=HopeCoop_MonsterCount(players,udg_quanshu)
if HopeCoop_RoomPlayers!=players or not HopeCoop_Announced then
call DisplayTimedTextToForce(udg_WJZ,10.,"本房按 "+I2S(players)+" 名在场玩家计算：每多1人，小怪生命+20%、BOSS生命+45%、攻击力+10%。离开人数在下一房重新计算。")
set HopeCoop_Announced=true
endif
set HopeCoop_RoomPlayers=players
endfunction
function HopeCoop_ScaleEnemy takes unit u returns nothing
local integer h=GetHandleId(u)
local real hp=0.
local real attack=0.
if u==null or GetUnitTypeId(u)==0 or GetOwningPlayer(u)!=Player(11) or LoadBoolean(YDHT,h,$487A4302) then
return
endif
call SaveBoolean(YDHT,h,$487A4302,true)
if HopeCoop_RoomPlayers<=1 then
return
endif
set hp=GetUnitState(u,UNIT_STATE_MAX_LIFE)*HopeCoop_LifeFactor(HopeCoop_RoomPlayers,HopeCoop_IsBoss(u))
set attack=GetUnitState(u,ConvertUnitState(18))*HopeCoop_AttackFactor(HopeCoop_RoomPlayers)
if udg_Yx_Nd_Dj>=5 then
// Numeric guards compose with challenge scaling; subsequent boss room bonuses
// remain bounded by the capped monster count. No repeated display-time scaling.
set hp=RMinBJ(10000000.,hp)
set attack=RMinBJ(1000000.,attack)
endif
call SetUnitState(u,UNIT_STATE_MAX_LIFE,hp)
call SetUnitLifePercentBJ(u,100.)
call SetUnitState(u,ConvertUnitState(18),attack)
endfunction
'''


def once(src: str, old: str, new: str, label: str) -> str:
    assert src.count(old) == 1, (label, src.count(old))
    return src.replace(old, new, 1)


def edit_function(src: str, name: str, edit) -> str:
    match = re.search(r'(^function ' + re.escape(name) + r' takes .*?\n)(.*?)(^endfunction)', src, re.M | re.S)
    assert match, name
    return src[:match.start(2)] + edit(match[2]) + src[match.end(2):]


def apply(src: str) -> str:
    assert 'function HopeCoop_CountPlayers ' not in src
    assert src.count('\nglobals\n') + int(src.startswith('globals\n')) == 1
    src = src.replace('globals\n', 'globals\ninteger HopeCoop_RoomPlayers=1\nboolean HopeCoop_Started=false\nboolean HopeCoop_Announced=false\nreal HopeCoop_BaseHandicap=100.\n', 1)
    first = re.search(r'^function ', src, re.M).start()
    src = src[:first] + HELPERS + '\n' + src[first:]
    # The same initialization exists in selected difficulty and the 60s default.
    handicap = 'call SetPlayerHandicapBJ(Player(11),udg_diren_xueliang+20.)'
    assert src.count(handicap) == 2, src.count(handicap)
    src = src.replace(handicap, '// Multiplayer handicap is recalculated by HopeCoop_BeginRoom.')
    src = edit_function(src, 'Trig______________011Actions', lambda body: once(body, 'if GetUnitTypeId(udg_Youxi_xzgq)==$6E303049 then', 'call HopeCoop_BeginRoom()\nif GetUnitTypeId(udg_Youxi_xzgq)==$6E303049 then', 'room population snapshot'))
    anchor = 'call SaveInteger(YDHT,GetHandleId(GetTriggerUnit()),$2F140B6F,GetRandomInt(0,3))'
    src = edit_function(src, 'Trig_G_____________004Actions', lambda body: once(body, anchor, 'call HopeCoop_ScaleEnemy(GetTriggerUnit())\n' + anchor, 'scale before enemy AI reads attack'))
    return src
