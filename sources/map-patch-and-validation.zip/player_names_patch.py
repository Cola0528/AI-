"""UTF-8-safe local display labels; keep native player names untouched."""
import re
from modern_choices_patch import block,replace
from warcraft_hash import utf8_step_jass

G='''string array HopeName_Raw
string array HopeName_Plain
boolean array HopeName_Active
string array HopeName_Cached
integer array HopeName_Stamp
integer HopeName_Version=1
'''
STEP=utf8_step_jass()
HELPERS='''function HopeName_Clean takes string s returns string
local string result=""
local string c=""
local integer n=StringLength(s)
local integer at=0
local integer step=1
loop
exitwhen at>=n
if SubString(s,at,at+2)=="|c" and at+10<=n then
set at=at+10
elseif SubString(s,at,at+2)=="|r" then
set at=at+2
elseif SubString(s,at,at+2)=="|n" then
set result=result+" "
set at=at+2
else
set step=HopeName_Step(s,at)
set c=SubString(s,at,at+step)
set result=result+c
set at=at+step
endif
endloop
return result
endfunction
function HopeName_CharWidth takes string c returns integer
if StringLength(c)>1 or c=="W" or c=="M" or c=="w" or c=="m" or c=="@" or c=="%" then
return 10
endif
return 7
endfunction
function HopeName_Width takes string s returns integer
local integer at=0
local integer step=1
local integer width=0
loop
exitwhen at>=StringLength(s)
set step=HopeName_Step(s,at)
set width=width+HopeName_CharWidth(SubString(s,at,at+step))
set at=at+step
endloop
return width
endfunction
function HopeName_Clip takes string s,integer limit returns string
local integer at=0
local integer step=1
local integer width=0
local integer next=0
if HopeName_Width(s)<=limit then
return s
endif
loop
exitwhen at>=StringLength(s)
set step=HopeName_Step(s,at)
set next=width+HopeName_CharWidth(SubString(s,at,at+step))
exitwhen next>limit-10
set width=next
set at=at+step
endloop
return SubString(s,0,at)+"…"
endfunction
function HopeName_Refresh takes nothing returns nothing
local integer i=0
local string raw=""
local boolean active=false
loop
exitwhen i>=6
set raw=GetPlayerName(Player(i))
set active=GetPlayerSlotState(Player(i))==PLAYER_SLOT_STATE_PLAYING
if raw!=HopeName_Raw[i] or active!=HopeName_Active[i] then
set HopeName_Raw[i]=raw
set HopeName_Plain[i]=HopeName_Clean(raw)
set HopeName_Active[i]=active
set HopeName_Version=HopeName_Version+1
endif
set i=i+1
endloop
endfunction
function HopeName_Label takes player p,integer limit returns string
local integer i=GetPlayerId(p)
local integer j=0
local integer key=0
local string name=""
local string result=""
local string suffix=""
if i<0 or i>=6 then
return GetPlayerName(p)
endif
set limit=IMaxBJ(36,IMinBJ(120,limit))
set key=i*128+limit
call HopeName_Refresh()
if HopeName_Stamp[key]==HopeName_Version then
return HopeName_Cached[key]
endif
set name=HopeName_Plain[i]
if name=="" then
set result="玩家"+I2S(i+1)
else
set result=HopeName_Clip(name,limit)
loop
exitwhen j>=6
if j!=i and HopeName_Active[j] and HopeName_Clip(HopeName_Plain[j],limit)==result then
set suffix="#"+I2S(i+1)
exitwhen true
endif
set j=j+1
endloop
if suffix!="" then
set result=HopeName_Clip(name,limit-HopeName_Width(suffix))+suffix
endif
endif
set HopeName_Cached[key]=result
set HopeName_Stamp[key]=HopeName_Version
return result
endfunction
'''

def apply(src):
    src=src.replace('globals\n','globals\n'+G,1)
    pos=re.search(r'^function \w+',src,re.M).start()
    src=src[:pos]+STEP+HELPERS+src[pos:]
    src=replace(src,'HopeIntent_PlayerLabel','''function HopeIntent_PlayerLabel takes player p returns string
return HopeName_Label(p,70)
endfunction''')
    for name,budget,owner,oldlen in [('HopeRoute_CompactStatus',70,'i',10),('HopeDamage_Refresh',50,'id-1',10)]:
        f=block(src,name)
        pat=r'set name=GetPlayerName\(Player\('+re.escape(owner)+r'\)\)\nif StringLength\(name\)>'+str(oldlen)+r' then\nset name="玩家 ".*?\nendif'
        f,n=re.subn(pat,f'set name=HopeName_Label(Player({owner}),{budget})',f);assert n==1,name
        src=replace(src,name,f)
    f=block(src,'HopeDamage_Refresh')
    f=f.replace('name+"  "+HopeDamage_Number(amount)','name+" "+HopeDamage_Number(amount)')
    old='set line=line+" ("+R2SW(amount/sum*100.,1,1)+"%)"'
    assert old in f
    f=f.replace(old,'''if amount/sum>=0.9995 then
set line=line+" 100%"
else
set line=line+" "+R2SW(amount/sum*100.,1,1)+"%"
endif''')
    src=replace(src,'HopeDamage_Refresh',f)
    f=block(src,'HopeRoute_UpdateUI')
    old='''set name=GetPlayerName(Player(i))
if count>3 or StringLength(name)>12 then
set name="P"+I2S(i+1)
endif'''
    assert old in f
    f=f.replace(old,'''if count>3 then
set name=HopeName_Label(Player(i),50)
else
set name=HopeName_Label(Player(i),70)
endif''')
    # A compact state mark preserves room for a real nickname in both columns.
    # The panel's departure header still states whether the whole party is ready.
    f=f.replace('state="|cffffc060待选|r"','state="|cffffc060…|r"')
    f=f.replace('state="等待"','state="|cffaaaaaa…|r"')
    f=f.replace('state="|cff80ef90已备|r"','state="|cff80ef90√|r"')
    f=f.replace('state="|cffaaaaaa未备|r"','state="|cffaaaaaa×|r"')
    f=f.replace('HopeLayout_Member[i],name+" "+state','HopeLayout_Member[i],YDWEGetPlayerColorString(Player(i),name)+" "+state')
    src=replace(src,'HopeRoute_UpdateUI',f)
    f=block(src,'HopeLayout_Assignment')
    old='''set name=GetPlayerName(Player(i))
if StringLength(name)>12 then
set name="玩家 "+I2S(i+1)
else
set name=I2S(i+1)+" · "+name
endif'''
    assert old in f
    f=f.replace(old,'set name=I2S(i+1)+" · "+HopeName_Label(Player(i),100)')
    src=replace(src,'HopeLayout_Assignment',f)
    # Before layout applies its final two-column captions, use the same safe label.
    src=src.replace('"玩家 "+I2S(i)+" · "+GetPlayerName(Player(i-1))','I2S(i)+" · "+HopeName_Label(Player(i-1),100)')
    src=src.replace('长名或同名队友使用玩家编号，队友行动点旁显示相同名字。','昵称按完整字符显示；长名省略，同名或缩写相同时附加编号，队友行动点旁显示相同名字。')
    src=src.replace('// UTF-8 names must not be cut at a byte offset. Use a player number for long names.','// Compact labels retain UTF-8 characters; the full roster remains available.')
    # Every custom Chinese label must use the actual font already shipped in map.
    src=src.replace('FRIZQT__.TTF','ZiTi.ttf')
    src=src.replace(r'"fonts\\fonts.ttf"',r'"Fonts\\ZiTi.ttf"')
    return src
