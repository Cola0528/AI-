"""Compare loader dependencies to v14 and limit the v16 repair to optional names."""
from pathlib import Path
import hashlib,json,re,sys
sys.path.insert(0,'/workspace/map-tools')
from mpq import op,read,L

ROOT=Path(__file__).parent
OUT=Path('/workspace/outputs')
HASHES={'AI-Tower-Class-Resources-v14.w3x':'86db039c6fb76b155adffed5e71f3d15ec60f55703766b23623461f541cc3d02',
        'AI-Tower-Class-Awakening-v15.w3x':'774c9c27c98a928ec55ca6433304b3f5c0ff5af24f43c33dc600489cb243f4f5'}

def natives(s):return set(re.findall(r'^(?:constant )?native .+$',s,re.M))
def functions(s):return {m[1]:m[0] for m in re.finditer(r'^function (\w+) takes.*?^endfunction',s,re.M|re.S)}

def read_baseline(name):
    p=OUT/name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==HASHES[name]
    h=op(p,0x100)
    try:return read(h,'war3map.j').decode()
    finally:L.SFileCloseArchive(h)

v14=read_baseline('AI-Tower-Class-Resources-v14.w3x')
v15=read_baseline('AI-Tower-Class-Awakening-v15.w3x')
current=(ROOT/'war3map-patched.j').read_text()
assert natives(current)==natives(v14),'new required engine binding'
risky=natives(v15)-natives(v14)
assert {x.split()[1] for x in risky}=={'DzSetUnitName','DzSetUnitProperName'}
assert not natives(v14)-natives(v15)
# The regression fixture (v15) must fail the now-required baseline check.
assert natives(v15)!=natives(v14)
old=functions(v15);new=functions(current)
assert new.keys()-old.keys()=={'HopeThird_Rename'} and not old.keys()-new.keys()
changed={n for n in old if old[n]!=new[n]}
assert changed=={'HopeThird_Unlock'},changed
expected=old['HopeThird_Unlock'].replace('// These are instance names, not type-wide object strings. All clients execute.\ncall DzSetUnitName(u,HopeJob_Name[index])\ncall DzSetUnitProperName(u,HopeJob_Name[index])',
'// Optional per-instance names; no new native binding during map loading.\ncall HopeThird_Rename(u,index)')
assert expected==new['HopeThird_Unlock']
def remainder(s):
    s=re.sub(r'^function \w+ takes.*?^endfunction','',s,flags=re.M|re.S)
    return '\n'.join(line for line in s.splitlines() if line.strip())
restored=''.join(line+'\n' for line in sorted(risky))+current
assert remainder(restored)==remainder(v15)
handle=op(OUT/'AI-Tower-Class-Awakening-v15.w3x',0x100)
objects=[]
try:
    for p in (ROOT/'modified').iterdir():
        if not p.name.startswith('Units_') and p.name!='war3map.w3a':continue
        key='Units\\'+p.name[6:] if p.name.startswith('Units_') else p.name
        assert read(handle,key)==p.read_bytes(),key
        objects.append(key)
finally:L.SFileCloseArchive(handle)
assert len(objects)==11
report={'jass_sha256':hashlib.sha256(current.encode()).hexdigest(),'required_natives_match_v14':True,
        'removed_load_dependencies':sorted(risky),'v15_regression_detected':True,'unchanged_v15_functions':len(old)-1,
        'changed_function':'HopeThird_Unlock','added_function':'HopeThird_Rename','unchanged_object_files':objects,
        'gameplay_and_cost_functions_identical_to_v15':True,'kk_runtime_tested':False}
print(json.dumps(report,ensure_ascii=False,indent=2))
