"""Execute the shipped poison preview JASS with deterministic native doubles.

Exercises numeric/range display without invoking Warcraft/KK font rendering.
The actual original poison tick and damage trigger must remain byte identical.
"""
from __future__ import annotations

from pathlib import Path
import math
from types import SimpleNamespace

from validate_economy import SCRIPT, World, body, rawcode


ROOT = Path(__file__).resolve().parent
CASES = 0


def check(condition, message):
    global CASES
    assert condition, message
    CASES += 1


def close(actual, expected, message):
    check(math.isclose(actual, expected, rel_tol=1e-7, abs_tol=1e-6), message)


def world():
    w = World()
    w.g.update({
        "RAbsBJ": abs,
        "R2SW": lambda value, width, precision: format(value, f"{width}.{precision}f"),
        "IsUnitAliveBJ": lambda u: u is not None and u.life > .405,
        "ConvertUnitState": lambda value: value,
        "GetUnitState": lambda u, state: u.attack if state == 20 else 0.,
        "GetUnitAbilityLevel": lambda u, ability: u.poison_rank if ability == rawcode("A02U") else 0,
    })
    w.g["HopeStatus_History"] = "history"
    w.load("HopeStatus_Number", "HopeStatus_PoisonLastLine", "HopeStatus_RecordPoison",
           "HopeStatus_PoisonKey", "HopeStatus_PoisonCount", "HopeStatus_PoisonTotal",
           "HopeStatus_PoisonSourceBase", "HopeStatus_PoisonBase",
           "HopeStatus_PoisonSourceReference", "HopeStatus_PoisonReference",
           "HopeStatus_PoisonRange", "HopeStatus_PoisonPreviewLine", "HopeStatus_PoisonDetails")
    target = SimpleNamespace(kind=rawcode("n000"), life=10000.)
    return w, target


def source(w, target, index, count, attack, rank=1, final=1., crit_chance=20, crit=1.5):
    unit = w.hero(index)
    unit.attack = float(attack)
    unit.poison_rank = rank
    w.tables["YDHT"][id(target), w.g["HopeStatus_PoisonKey"](index)] = count
    w.g["udg_Zuizhong_Dm"][index + 1] = final
    w.g["udg_Baoji_Lv"][index + 1] = crit_chance
    w.g["udg_Baoji_Damage"][index + 1] = crit
    return unit


def test_reported_display():
    w, target = world()
    source(w, target, 0, 10, 150, crit=1.59)
    close(w.g["HopeStatus_PoisonBase"](target), 450., "Ten layers give 450 raw base")
    close(w.g["HopeStatus_PoisonReference"](target, False), 450., "Lower reference is 450")
    close(w.g["HopeStatus_PoisonReference"](target, True), 715.5, "Upper reference is 715.5")
    check(w.g["HopeStatus_PoisonTotal"](target) == 10, "Ten stacks are kept separate from damage text")
    for compact in (False, True):
        check(w.g["HopeStatus_PoisonRange"](target, compact) == "450 至 715.5", "Range endpoints cannot concatenate when en dash is absent")
    check(w.g["HopeStatus_PoisonPreviewLine"](target) == "本轮毒伤参考 450 至 715.5", "Panel uses readable range")
    w.g["HopeStatus_RecordPoison"](target, 490.)
    check(w.g["HopeStatus_PoisonLastLine"](target) == "上次毒结算净扣血 490", "Previous observed damage stays distinct")
    check(w.g["HopeStatus_PoisonRange"](target, False) == "450 至 715.5", "Previous actual damage does not replace current estimate")
    # Demonstrate the failure mode in the original shipped formatter, without
    # claiming to have run a KK client/font renderer in this environment.
    original = (ROOT / "war3map.j").read_text()
    check('return left+"–"+right' in body("HopeStatus_PoisonRange", original)[3], "Original separator is U+2013")
    check("450–715.5".replace("–", "") == "450715.5", "Missing en dash reproduces reported digit concatenation")


def test_reference_formula_and_guards():
    w, target = world()
    source(w, target, 0, 6, 100, rank=2, final=1.2, crit_chance=20, crit=1.5)
    source(w, target, 1, 4, 200, final=1.5, crit_chance=100, crit=2.)
    w.tables["YDHT"][id(target), 0x3449D65E] = .25
    close(w.g["HopeStatus_PoisonBase"](target), 600., "Different owners/ranks retain separate bases")
    close(w.g["HopeStatus_PoisonReference"](target, False), 864., "Each source final multiplier and target resistance apply once")
    close(w.g["HopeStatus_PoisonReference"](target, True), 1026., "Only eligible sources widen crit range")
    check(w.g["HopeStatus_PoisonRange"](target, False) == "864 至 1026", "Multiple sources have readable total bounds")
    before = dict(w.tables["YDHT"])
    for _ in range(5):
        w.g["HopeStatus_PoisonPreviewLine"](target)
    check(before == w.tables["YDHT"] and not w.random_calls and not w.integer_random_calls,
          "Repeated previews never consume poison, crit rolls or gameplay state")

    # Crit rates outside 1..99 must produce a single value; no misleading range.
    w, target = world()
    source(w, target, 0, 10, 150, crit_chance=0, crit=1.59)
    check(w.g["HopeStatus_PoisonRange"](target, False) == "450", "Zero crit chance displays a single value")
    w.g["udg_Baoji_Lv"][1] = 100
    check(w.g["HopeStatus_PoisonRange"](target, False) == "715.5", "Guaranteed crit displays a single value")
    w.g["udg_Baoji_Lv"][1] = 20
    w.g["udg_Baoji_Damage"][1] = .5
    check(w.g["HopeStatus_PoisonRange"](target, False) == "225 至 450", "Low critical damage still sorts endpoints")
    w.tables["YDHT"][id(target), 0x3449D65E] = 1.
    check(w.g["HopeStatus_PoisonRange"](target, False) == "0", "Full script resistance displays zero")

    w, target = world()
    unit = source(w, target, 0, 10, 150)
    unit.poison_rank = 0
    check(w.g["HopeStatus_PoisonReference"](target, True) == 0., "Missing poison skill contributes no damage")
    w.g["udg_hero"][1] = None
    check(w.g["HopeStatus_PoisonReference"](target, True) == 0., "Missing source hero contributes no damage")
    w.tables["YDHT"][id(target), w.g["HopeStatus_PoisonKey"](0)] = -5
    check(w.g["HopeStatus_PoisonPreviewLine"](target) == "", "Negative stacks do not display poison")
    target.life = 0.
    check(w.g["HopeStatus_PoisonPreviewLine"](target) == "", "Dead target has no current preview")
    check(w.g["HopeStatus_PoisonPreviewLine"](None) == "", "Null target has no current preview")
    for value, expected in ((0., "0"), (490., "490"), (715.5, "715.5"), (10000., "1.0万"), (100000000., "1.0亿")):
        check(w.g["HopeStatus_Number"](value) == expected, "Magnitude formatting remains correct for " + str(value))


def test_combat_unchanged():
    original = (ROOT / "war3map.j").read_text()
    for name in ("HopeStatus_Number", "HopeStatus_RecordPoison", "HopeStatus_PoisonLastLine",
                 "HopeStatus_PoisonKey", "HopeStatus_PoisonCount", "HopeStatus_PoisonTotal",
                 "HopeStatus_PoisonSourceBase", "HopeStatus_PoisonBase",
                 "HopeStatus_PoisonSourceReference", "HopeStatus_PoisonReference",
                 "Trig______________003Func006A", "Trig____________________005Actions"):
        check(body(name, SCRIPT)[0] == body(name, original)[0], name + " preserves original combat/reference behavior")
    range_body = body("HopeStatus_PoisonRange")[3]
    check('return left+" 至 "+right' in range_body, "Chinese range separator shipped")
    check('return left+"–"+right' not in range_body, "Fragile en dash is not shipped")


if __name__ == "__main__":
    test_reported_display()
    test_reference_formula_and_guards()
    test_combat_unchanged()
    print(f"Poison display regression: {CASES} assertions passed (JASS logic; no KK renderer)")
