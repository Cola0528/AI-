"""v9: shared frame geometry, content-specific dialogs and one local overlay.

Only presentation changes. No prices, reward callbacks, route permissions or
random calls are changed. Coordinates use Warcraft's 0.8 x 0.6 UI space.
"""
import re
from modern_choices_patch import block, replace

GLOBALS='''
integer HopeLayout_Save=0
integer HopeLayout_Relic=0
integer HopeLayout_Route=0
integer HopeLayout_History=0
integer array HopeLayout_Member
integer array HopeLayout_Fold
'''
EARLY=r'''function HopeLayout_Place takes integer frame,integer parent,real x,real y,real w,real h returns nothing
if frame==0 then
return
endif
call DzFrameClearAllPoints(frame)
if parent==0 then
call DzFrameSetAbsolutePoint(frame,0,x,y)
else
call DzFrameSetPoint(frame,0,parent,0,x,y)
endif
call DzFrameSetSize(frame,w,h)
endfunction
function HopeLayout_Show takes integer frame,boolean show returns nothing
if frame!=0 then
call DzFrameShow(frame,show)
endif
endfunction
// Called exclusively inside local presentation branches, including local parts
// of synchronized actions. Choice pending counts and gameplay stay untouched.
function HopeLayout_Focus takes integer view returns nothing
if view!=1 then
set HopeQoL_Expanded=false
endif
if view!=2 then
set HopeArchive_Expanded=false
endif
if view!=3 then
set HopeGift_Expanded=false
endif
if view!=4 then
set HopeRelic_Expanded=false
endif
if view!=5 then
set HopeJob_Expanded=false
endif
if view!=6 then
set HopeRoute_PickerOpen=false
endif
if view!=7 then
set HopeDraw_Open=false
endif
if view!=8 then
set HopeDraw_WoodOpen=false
endif
if view!=9 then
set HopeRoute_Details=false
endif
set HopeChoice_Hidden=true
endfunction
'''

MODE='''function HopeLayout_Mode takes nothing returns integer
local integer owner=GetPlayerId(GetLocalPlayer())
local integer i=1
if HopeRoute_Assigning then
return 10
endif
if not HopeChoice_Hidden then
if HopeGrowth_Pending[owner] then
return 11
endif
if HopeChoice_LootPending() then
return 12
endif
loop
exitwhen i>HopeChoice_DialogCount
if HopeChoice_DialogPending[i] and HopeChoice_Owner[i]==owner then
return 13
endif
set i=i+1
endloop
endif
if HopeQoL_Expanded then
return 1
elseif HopeArchive_Expanded then
return 2
elseif HopeGift_Expanded then
return 3
elseif HopeRelic_Expanded then
return 4
elseif HopeJob_Expanded then
return 5
elseif HopeRoute_PickerOpen and not udg_ZhandouZhong and HopeRoute_AvailableCount>0 then
return 6
elseif HopeDraw_Open then
return 7
elseif HopeDraw_WoodOpen and not udg_ZhandouZhong and GetUnitTypeId(udg_Youxi_xzgq)=='n00K' then
return 8
elseif HopeRoute_Details and HopeRoute_Valid() then
return 9
endif
return 0
endfunction
function HopeLayout_Apply takes nothing returns nothing
local integer mode=HopeLayout_Mode()
local integer owner=GetPlayerId(GetLocalPlayer())
local integer i=1
local integer newest=0
local boolean active=owner>=0 and owner<6 and udg_hero[owner+1]!=null
local boolean dock=active and mode<10
call HopeLayout_Show(HopeQoL_StatsButton,dock)
call HopeLayout_Show(HopeLayout_Save,dock)
call HopeLayout_Show(HopeLayout_Relic,dock)
call HopeLayout_Show(HopeGift_OpenButton,dock)
call HopeLayout_Show(HopeLayout_History,dock)
call HopeLayout_Show(HopeLayout_Route,dock and not udg_ZhandouZhong)
call HopeLayout_Show(HopeQoL_Panel,mode==1 and active)
call HopeLayout_Show(HopeArchive_Panel,mode==2 and HopeArchive_UIReady)
call HopeLayout_Show(HopeGift_Panel,mode==3 and HopeGift_UIReady)
call HopeLayout_Show(HopeRelic_Panel,mode==4 and HopeRelic_UIReady)
call HopeLayout_Show(HopeJob_Panel,mode==5)
call HopeLayout_Show(HopeRoute_Picker,mode==6)
call HopeLayout_Show(HopeDraw_Panel,mode==7)
call HopeLayout_Show(HopeDraw_WoodPanel,mode==8)
call HopeLayout_Show(HopeRoute_InfoPanel,mode==9)
call HopeLayout_Show(HopeRoute_AssignPanel,mode==10 and owner==HopeRoute_Host())
call HopeLayout_Show(HopeGrowth_Panel,mode==11 and HopeGrowth_UIReady)
call HopeLayout_Show(udg_UI_sg[1],mode==12)
loop
exitwhen i>HopeChoice_DialogCount
if HopeChoice_DialogPending[i] and HopeChoice_Owner[i]==owner then
set newest=i
endif
set i=i+1
endloop
set i=1
loop
exitwhen i>13
call HopeLayout_Show(HopeModern_Panel[i],mode==13 and i==newest)
set i=i+1
endloop
// Passive readouts yield to overlays, rather than covering their content.
call HopeLayout_Show(HopeDamage_Panel,mode==0 and active)
if mode!=0 then
call HopeLayout_Show(HopeIntent_Panel,false)
call HopeLayout_Show(HopeTurn_Panel,false)
call HopeLayout_Show(HopeJob_OpenButton,false)
endif
endfunction
'''

MODERN_LAYOUT='''function HopeLayout_Choice takes integer i,dialog d returns nothing
local integer j=1
local real w=.340
local real h=.239
local real x=0.
local real y=0.
local integer count=LoadInteger(HopeModern_Data,GetHandleId(d),0)
if d==udg_Youxi_ND_XZ then
set w=.310
set h=.222
elseif d==udg_Rskill_shifoutihuan[GetPlayerId(GetLocalPlayer())+1] then
set w=.360
set h=.280
endif
call HopeLayout_Place(HopeModern_Panel[i],0,(.8-w)/2.,.520,w,h)
call HopeLayout_Place(HopeModern_Title[i],HopeModern_Panel[i],.012,-.012,w-.098,.024)
call HopeLayout_Place(HopeLayout_Fold[i],HopeModern_Panel[i],w-.080,-.010,.068,.024)
if d==udg_Youxi_ND_XZ then
call HopeLayout_Place(HopeModern_Description[i],HopeModern_Panel[i],.012,-.045,w-.024,.042)
elseif count==2 then
call HopeLayout_Place(HopeModern_Description[i],HopeModern_Panel[i],.012,-.046,w-.024,.174)
else
call HopeLayout_Place(HopeModern_Description[i],HopeModern_Panel[i],.012,-.044,w-.024,.036)
endif
loop
exitwhen j>count
if d==udg_Youxi_ND_XZ then
set x=.012+I2R(ModuloInteger(j-1,2))*.148
set y=-.098-I2R((j-1)/2)*.038
call HopeLayout_Place(HopeModern_Row[i*8+j],HopeModern_Panel[i],x,y,.138,.030)
elseif count==2 then
set x=.012+I2R(j-1)*.172
call HopeLayout_Place(HopeModern_Row[i*8+j],HopeModern_Panel[i],x,-.237,.164,.030)
if j==1 then
call DzFrameSetText(HopeModern_Row[i*8+j],"替换技能")
else
call DzFrameSetText(HopeModern_Row[i*8+j],"保留当前技能")
endif
else
call HopeLayout_Place(HopeModern_Row[i*8+j],HopeModern_Panel[i],.012,-.091-I2R(j-1)*.035,w-.024,.028)
endif
set j=j+1
endloop
endfunction
'''

READY='''function HopeRoute_UpdateUI takes nothing returns nothing
local integer owner=GetPlayerId(GetLocalPlayer())
local integer i=0
local integer count=0
local integer slot=0
local integer rows=0
local boolean show=HopeRoute_Valid() and HopeRoute_Active(owner) and not HopeRoute_RewardPending(owner)
local string name=""
local string state=""
local real x=.007
local real y=-.080
local real width=.120
loop
exitwhen i>=6
if HopeRoute_Active(i) then
set count=count+1
endif
call HopeLayout_Show(HopeLayout_Member[i],false)
set i=i+1
endloop
set rows=count
if count>3 then
set rows=(count+1)/2
set width=.058
endif
call HopeLayout_Show(HopeRoute_Panel,show)
if show then
call HopeLayout_Place(HopeRoute_Panel,0,.014,.375,.134,.086+.012*I2R(rows))
call HopeLayout_Show(HopeRoute_Text,false)
call HopeLayout_Show(HopeRoute_ReadyButton,not HopeRoute_Ready[owner])
call HopeLayout_Show(HopeRoute_WaitButton,HopeRoute_Ready[owner])
call HopeLayout_Show(HopeRoute_DepartButton,owner==HopeRoute_Leader())
if HopeRoute_AllReady() then
call DzFrameSetText(HopeRoute_TitleText,"|cffd2b879"+HopeRoute_Title(HopeRoute_Node)+"|r · |cff80ef90已齐|r")
call DzFrameSetText(HopeRoute_DepartButton,"全员已准备 · 出发")
else
call DzFrameSetText(HopeRoute_TitleText,"|cffd2b879"+HopeRoute_Title(HopeRoute_Node)+"|r")
call DzFrameSetText(HopeRoute_DepartButton,"等待队友 · 出发")
endif
set i=0
loop
exitwhen i>=6
if HopeRoute_Active(i) then
set name=GetPlayerName(Player(i))
if count>3 or StringLength(name)>12 then
set name="P"+I2S(i+1)
endif
if i==HopeRoute_Leader() then
set name=name+"*"
endif
if HopeRoute_RewardPending(i) then
set state="|cffffc060待选|r"
elseif udg_hero[i+1]==null then
set state="等待"
elseif HopeRoute_Ready[i] then
set state="|cff80ef90已备|r"
else
set state="|cffaaaaaa未备|r"
endif
set x=.007
set y=-.080-.012*I2R(slot)
if count>3 then
set x=.007+.064*I2R(ModuloInteger(slot,2))
set y=-.080-.012*I2R(slot/2)
endif
call HopeLayout_Place(HopeLayout_Member[i],HopeRoute_Panel,x,y,width,.011)
if HopeLayout_Member[i]!=0 then
call DzFrameSetText(HopeLayout_Member[i],name+" "+state)
endif
call HopeLayout_Show(HopeLayout_Member[i],true)
set slot=slot+1
endif
set i=i+1
endloop
if HopeRoute_LastPreview!=HopeRoute_Node then
set HopeRoute_Details=false
set HopeRoute_LastPreview=HopeRoute_Node
endif
if HopeRoute_Details then
call DzFrameSetText(HopeRoute_DescriptionText,HopeRoute_Description(HopeRoute_Node)+"|n|n完整队伍状态（*为选路玩家）：|n"+HopeRoute_Status())
endif
endif
call HopeLayout_Show(HopeRoute_InfoPanel,show and HopeRoute_Details)
endfunction'''

LATE=r'''function HopeLayout_Assignment takes nothing returns nothing
local integer i=0
local integer count=0
local integer slot=0
local real x=0.
local real y=0.
local string name=""
loop
exitwhen i>=6
if HopeRoute_Active(i) then
set count=count+1
endif
set i=i+1
endloop
call HopeLayout_Place(HopeRoute_AssignPanel,0,.249,.500,.302,.074+.034*I2R((count+1)/2))
set i=0
loop
exitwhen i>=6
if HopeRoute_Active(i) then
set x=.012+.144*I2R(ModuloInteger(slot,2))
set y=-.064-.034*I2R(slot/2)
call HopeLayout_Place(HopeRoute_AssignButton[i+1],HopeRoute_AssignPanel,x,y,.134,.027)
set name=GetPlayerName(Player(i))
if StringLength(name)>12 then
set name="玩家 "+I2S(i+1)
else
set name=I2S(i+1)+" · "+name
endif
call DzFrameSetText(HopeRoute_AssignButton[i+1],name)
set slot=slot+1
endif
set i=i+1
endloop
endfunction
function HopeLayout_Init takes nothing returns nothing
local integer i=0
call HopeLayout_Place(HopeQoL_StatsButton,0,.014,.248,.064,.021)
call HopeLayout_Place(HopeLayout_Route,0,.084,.248,.064,.021)
call HopeLayout_Place(HopeLayout_Save,0,.014,.222,.064,.021)
call HopeLayout_Place(HopeLayout_Relic,0,.084,.222,.064,.021)
call HopeLayout_Place(HopeGift_OpenButton,0,.014,.196,.064,.021)
call HopeLayout_Place(HopeLayout_History,0,.084,.196,.064,.021)
call HopeLayout_Place(HopeChoice_Button,0,.014,.375,.134,.022)
call HopeLayout_Place(HopeJob_OpenButton,0,.160,.248,.100,.021)
call DzFrameSetText(HopeLayout_Route,"选择路线")
call DzFrameSetText(HopeGift_OpenButton,"礼包抽奖")
call HopeLayout_Place(HopeRoute_ReadyButton,HopeRoute_Panel,.007,-.025,.077,.022)
call HopeLayout_Place(HopeRoute_WaitButton,HopeRoute_Panel,.007,-.025,.077,.022)
call HopeLayout_Place(HopeRoute_DepartButton,HopeRoute_Panel,.007,-.051,.120,.023)
loop
exitwhen i>=6
set HopeLayout_Member[i]=HopeQoL_Label("HopeReadyMember"+I2S(i),HopeRoute_Panel,.007,-.080,.058,.011,"")
call DzFrameSetFont(HopeLayout_Member[i],"Fonts\\ZiTi.ttf",.0085,0)
set i=i+1
endloop
endfunction
'''

def apply(src):
    src=src.replace('endglobals',GLOBALS+'\nendglobals',1)
    pos=src.index('\nfunction ')
    src=src[:pos]+'\n'+EARLY+src[pos:]
    # Capture the handles that v8 left in temporary locals.
    for name,handle in [('HopeRoutePickerOpen','HopeLayout_Route'),('HopeDrawHistory','HopeLayout_History')]:
        pattern=r'(set f=HopeQoL_Button\("'+name+r'"[^\n]*\n)'
        src,n=re.subn(pattern,lambda m:m[0]+'set '+handle+'=f\n',src);assert n==1
    for key,handle in [('$F0726BC6','HopeLayout_Save'),('$8C984976','HopeLayout_Relic')]:
        line=next(l for l in block(src,'Trig_______SD_017Actions').splitlines() if l.startswith('call DzFrameSetScriptByCode(') and key in l)
        value='LoadInteger(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,'+key+')'
        src=src.replace(line,line+'\nset '+handle+'='+value,1)
    # Keep the dock independent from refresh order; original handlers stay bound.
    src=replace(src,'HopeRoute_UpdateUI',READY)
    src=src.replace('"HopeRouteInfoPanel",.154,.375,.150,.090','"HopeRouteInfoPanel",.164,.445,.266,.250')
    src=src.replace('HopeRoute_InfoPanel,.007,-.006,.136,.014','HopeRoute_InfoPanel,.012,-.010,.242,.017')
    src=src.replace('HopeRoute_InfoPanel,.007,-.025,.136,.061','HopeRoute_InfoPanel,.012,-.039,.242,.199')
    src=src.replace('HopeRoute_Panel,.089,-.023,.038,.025','HopeRoute_Panel,.089,-.025,.038,.022')
    # Use both columns for small choice sets; reserve text space only where needed.
    for i in range(1,14):
        anchor=f'call HopeQoL_Bind(f,function HopeModern_Fold,false)'
        # Capture in each concrete constructor, not with a local-only allocation.
        pat=rf'(set f=HopeQoL_Button\("HopeChoiceFold{i}"[^\n]*\n)'
        src,n=re.subn(pat,lambda m:m[0]+f'set HopeLayout_Fold[{i}]=f\n',src);assert n==1
    src=src.replace('function HopeModern_Refresh takes',MODERN_LAYOUT+'\nfunction HopeModern_Refresh takes',1)
    f=block(src,'HopeModern_Refresh')
    # Resize after applying button captions, so short yes/no captions remain.
    f=f.replace('set j=j+1\nendloop\nendif','set j=j+1\nendloop\ncall HopeLayout_Choice(i,d)\nendif')
    src=replace(src,'HopeModern_Refresh',f)
    # Required choice windows never leave large blank bottom areas at construction.
    src=src.replace('.195,.558,.410,.450','.245,.520,.310,.222')
    # Make all optional center windows mutually exclusive when explicitly opened.
    openings=[('HopeQoL_Expanded','1'),('HopeArchive_Expanded','2'),('HopeGift_Expanded','3'),('HopeRelic_Expanded','4'),('HopeJob_Expanded','5'),('HopeRoute_PickerOpen','6'),('HopeDraw_Open','7'),('HopeDraw_WoodOpen','8'),('HopeRoute_Details','9')]
    for field,view in openings:
        for value in ['true','not '+field]:
            target='set '+field+'='+value
            # Existing assignments occur inside local branches or local-only callbacks.
            src=src.replace(target+'\n',target+'\nif '+field+' then\ncall HopeLayout_Focus('+view+')\nendif\n')
    # Compact layout-only changes for route lists, records, and merchant controls.
    src=src.replace('"HopeRouteAssign",.229,.540,.342,.340','"HopeRouteAssign",.249,.500,.302,.176')
    src=src.replace('HopeRoute_AssignPanel,.014,-.012,.310,.054','HopeRoute_AssignPanel,.012,-.010,.278,.044')
    src=src.replace('"HopeRoutePicker",.159,.500,.272,.325','"HopeRoutePicker",.249,.500,.302,.210')
    src=src.replace('HopeRoute_Picker,.012,-.012,.244,.040','HopeRoute_Picker,.012,-.010,.278,.030')
    src=src.replace('HopeRoute_Picker,.184,-.282,.076,.027','HopeRoute_Picker,.214,-.174,.076,.025')
    for i in range(1,7):
        old=f'HopeRoute_Picker,.012,{-.050-(i-1)*.037:.3f},.248,.031'
        new=f'HopeRoute_Picker,{.012+((i-1)%2)*.144:.3f},{-.049-((i-1)//2)*.038:.3f},.134,.030'
        assert old in src;src=src.replace(old,new)
    replacements={
      '"HopeDrawResults",.200,.550,.400,.360':'"HopeDrawResults",.215,.525,.370,.308',
      'HopeDraw_Panel,.014,-.012,.300,.025':'HopeDraw_Panel,.012,-.012,.266,.025',
      'HopeDraw_Panel,.014,-.052,.372,.254':'HopeDraw_Panel,.012,-.050,.346,.210',
      'HopeDraw_Panel,.318,-.012,.067,.026':'HopeDraw_Panel,.292,-.010,.066,.025',
      'HopeDraw_Panel,.014,-.318,.100,.028':'HopeDraw_Panel,.012,-.271,.102,.025',
      'HopeDraw_Panel,.128,-.318,.100,.028':'HopeDraw_Panel,.122,-.271,.102,.025',
      'HopeDraw_Panel,.242,-.318,.144,.028':'HopeDraw_Panel,.232,-.271,.126,.025',
      '"HopeWoodDraw",.214,.442,.372,.252':'"HopeWoodDraw",.229,.490,.342,.224',
      'HopeDraw_WoodPanel,.014,-.012,.280,.028':'HopeDraw_WoodPanel,.012,-.012,.318,.025',
      'HopeDraw_WoodPanel,.014,-.051,.344,.104':'HopeDraw_WoodPanel,.012,-.046,.318,.093',
      'HopeDraw_WoodPanel,.014,-.153,.344,.040':'HopeDraw_WoodPanel,.012,-.143,.318,.033',
      'HopeDraw_WoodPanel,.014,-.205,.210,.030':'HopeDraw_WoodPanel,.012,-.187,.208,.025',
      'HopeDraw_WoodPanel,.260,-.205,.098,.030':'HopeDraw_WoodPanel,.232,-.187,.098,.025',
      '"HopeGiftPanel",.24,.55,.34,.390':'"HopeGiftPanel",.230,.570,.34,.390',
      '"HopeJobPanel",.19,.545,.47,.395':'"HopeJobPanel",.170,.560,.47,.380',
      'HopeJob_Panel, .165,-.101,.290,.191':'HopeJob_Panel, .165,-.101,.290,.174',
      'HopeJob_Panel,.165,-.302,.083,.020':'HopeJob_Panel,.165,-.285,.083,.020',
      'HopeJob_Panel,.370,-.302,.083,.020':'HopeJob_Panel,.370,-.285,.083,.020',
      'HopeJob_Panel,.278,-.303,.070,.018':'HopeJob_Panel,.278,-.286,.070,.018',
      'HopeJob_Panel,.165,-.333,.290,.024':'HopeJob_Panel,.165,-.317,.290,.024',
      'HopeJob_Panel,.012,-.365,.446,.022':'HopeJob_Panel,.012,-.349,.446,.023',
    }
    for old,new in replacements.items():
        assert old in src,old;src=src.replace(old,new)
    f=block(src,'HopeDamage_Refresh')
    f=f.replace('StringLength(name)>18','StringLength(name)>10')
    f=f.replace('结算伤害（含溢出），与原输出榜口径一致。','结算伤害含溢出')
    f=f.replace('call HopeJob_SetText(HopeDamage_Text,text)',
      'call HopeLayout_Place(HopeDamage_Panel,0,.642,.574,.144,.051+.011*I2R(count))\n'
      'call HopeLayout_Place(HopeDamage_Text,HopeDamage_Panel,.007,-.029,.130,.015+.011*I2R(count))\n'
      'call HopeJob_SetText(HopeDamage_Text,text)')
    src=replace(src,'HopeDamage_Refresh',f)
    src=src.replace('function HopeQoL_Refresh takes',MODE+'\nfunction HopeQoL_Refresh takes',1)
    src=src.replace('function HopeV8_Refresh takes',LATE+'\nfunction HopeV8_Refresh takes',1)
    src=src.replace('call HopeDamage_Create()','call HopeDamage_Create()\ncall HopeLayout_Init()',1)
    src=src.replace('call HopeRoute_RefreshPicker()','call HopeRoute_RefreshPicker()\ncall HopeLayout_Assignment()',1)
    # Every periodic painter finishes with the same visibility decision, so
    # independent timers cannot repeatedly show another window underneath it.
    for name in ['HopeQoL_Refresh','HopeJob_Refresh','HopeV8_Refresh']:
        f=block(src,name)
        drawn=f.replace('function '+name+' takes','function '+name+'Content takes',1)
        wrapper=f'\nfunction {name} takes nothing returns nothing\ncall {name}Content()\ncall HopeLayout_Apply()\nendfunction'
        src=replace(src,name,drawn+wrapper)
    return src
