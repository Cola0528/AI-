"""Two unique native shop entries: one wood / ten wood, same per-draw odds."""
import re
from modern_choices_patch import block,replace
from hidden_objects import read_slk,raw_value,clone_section,update_section

SOLD='''function HopeWood_Sold takes nothing returns nothing
local item sold=GetSoldItem()
local integer kind=GetItemTypeId(sold)
local unit shop=GetSellingUnit()
local unit buyer=GetBuyingUnit()
local player p=GetOwningPlayer(buyer)
local integer i=GetPlayerId(p)
local integer count=1
local integer n=1
local string result=""
local string text=""
if kind!='IZWD' and kind!='IZWT' then
set sold=null
set shop=null
set buyer=null
set p=null
return
endif
if kind=='IZWT' then
set count=10
endif
// The native shop already charged count wood; script never charges again.
call RemoveItem(sold)
if shop==gg_unit_n00Q_0028 then
call RemoveItemFromStock(shop,kind)
call AddItemToStock(shop,kind,1,1)
endif
if HopeWood_Allowed(shop,buyer) then
set HopeDraw_Busy[i]=true
loop
exitwhen n>count
set result=HopeDraw_Quality("谢谢惠顾（未获得奖励）")
if GetRandomInt(1,100)>50 then
set result=HopeDraw_Reward(p)
endif
if count>1 then
set text=text+I2S(n)+". "+result+"|n"
else
set text=result
endif
set n=n+1
endloop
if count==10 then
call HopeDraw_SaveRecord(p,"木材十连结果 · 消耗10木材",text+"|n每次独立50%谢谢惠顾；其余沿用原奖池。",true)
else
call HopeDraw_SaveRecord(p,"木材抽取结果 · 消耗1木材",text+"|n|n木材抽取50%谢谢惠顾；未抽空时沿用十连奖池。",false)
call DisplayTimedTextToPlayer(p,0,0,5.,"木材抽奖（1木材）："+result+"。可在抽取记录中回看。")
endif
set HopeDraw_Busy[i]=false
elseif buyer!=null then
call SetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER,GetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER)+count)
call DisplayTextToPlayer(p,0,0,"当前不能进行木材抽奖，已退回"+I2S(count)+"木材。请在非战斗时由能力商人购买。")
endif
set sold=null
set shop=null
set buyer=null
set p=null
endfunction'''

def apply(src):
    src=replace(src,'HopeWood_Sold',SOLD)
    f=block(src,'HopeWood_Init')
    f=f.replace('local trigger t=CreateTrigger()','''local trigger t=CreateTrigger()
// These two items are dynamic stock only, never also in static Sellitems.
call RemoveItemFromStock(gg_unit_n00Q_0028,'IZWD')
call RemoveItemFromStock(gg_unit_n00Q_0028,'IZWT')
call AddItemToStock(gg_unit_n00Q_0028,'IZWD',1,1)
call AddItemToStock(gg_unit_n00Q_0028,'IZWT',1,1)''')
    return replace(src,'HopeWood_Init',f)

def apply_objects(root,output):
    path=output/'Units_ItemData.slk'
    lines,rows,heads,objects=read_slk(path)
    assert 'IZWT' not in objects
    row=objects['IZWD'][1].copy();row[heads['itemID']]=raw_value('IZWT');row[heads['lumbercost']]=raw_value(10)
    last=max(rows)+1
    lines=[re.sub(r';Y\d+',f';Y{last}',l) if l.startswith('B;') else l for l in lines if l!='E']
    lines += [f'C;X{x};Y{last};K{v}' for x,v in sorted(row.items())]+['E']
    path.write_text('\r\n'.join(lines)+'\r\n',encoding='utf-8')
    path=output/'Units_itemstrings.txt';text=path.read_text()
    text=clone_section(text,'IZWD','IZWT')
    desc='消耗10木材，连续进行10次木材抽奖。|n每次独立50%谢谢惠顾；其余沿用原十连奖池。|n每次概率：25%单项属性+1，15%全属性+3，8%伤害/暴击，2%圣剑。|n与原事件的648金币十连分开计费；完整结果可在抽取记录查看。'
    text=update_section(text,'IZWT',{'Name':'木材十连抽','Tip':'木材十连抽 · 10木材','Description':desc,'Ubertip':desc,'Art':'ReplaceableTextures\\CommandButtons\\BTNChestOfGold.blp','Buttonpos':'0,1'})
    path.write_text(text)
    path=output/'Units_campaignunitstrings.txt';text=path.read_text()
    section=re.search(r'^\[n00Q\]\n(.*?)(?=^\[|\Z)',text,re.M|re.S)[1]
    stock=re.search(r'^Sellitems=(.*)$',section,re.M)[1].split(',')
    assert stock.count('IZWD')==1
    text=update_section(text,'n00Q',{'Sellitems':','.join(x for x in stock if x not in ('IZWD','IZWT'))})
    path.write_text(text)
    print('Wood lottery: dynamic IZWD/IZWT only; 1 or 10 wood, one stock entry each, original 648-gold event unchanged.')
