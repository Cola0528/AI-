"""Hidden-lineage changes applied after the shared promotion generator.

The original map owns damage final multipliers and critical strikes. New spell
handlers submit skill/spell-scaled damage exactly once to that shared pipeline.
"""
import re

Q_DESCRIPTIONS = {
    'AZHA': '消耗1行动点，0魔法。|n单体物理伤害基值：攻击力*0.60 + 三围总和*0.45。|n三围=当前力量+敏捷+智力。|n技能、最终倍率、暴击与减伤按原图规则结算。',
    'AZH2': '消耗1行动点，0魔法。|n单体物理伤害基值：攻击力*0.65 + 三围总和*0.65。|n三围=当前力量+敏捷+智力。|n技能、最终倍率、暴击与减伤按原图规则结算。',
    'AZH3': '消耗1行动点，0魔法。|n单体物理伤害基值：攻击力*0.70 + 三围总和*0.80。|n三围=当前力量+敏捷+智力。|n技能、最终倍率、暴击与减伤按原图规则结算。',
}
HEAL_DESCRIPTION = '恢复自身15+三围总和*0.5点生命，最多为生命上限的30%，不超过缺失生命。|n消耗1行动点、2魔法；战斗中每回合一次。|n满血时不消耗资源和使用次数。'
DRAIN_DESCRIPTION = '对当前敌人造成三围总和*1.75的法术伤害。|n按目标实际损失生命的25%恢复自身，最多恢复自身生命上限的15%。|n消耗2行动点、3魔法；战斗中每回合一次。|n技能、法伤、最终倍率、暴击与减伤按原图规则结算。'
RESONANCE_DESCRIPTION = '全体存活敌人受到三围总和*1.1的法术伤害。|n消耗2行动点、3魔法；战斗中每回合一次。|n技能、法伤、最终倍率、暴击与减伤按原图规则结算。'


def update_options(options):
    assert len(options) == 43
    random, second, third = options[24:27]
    assert random['name'] == '随机转职' and second['target'] == 'HZ02' and third['target'] == 'HZ03'
    random['skills'] = ('抽取范围：8种普通一转职业等概率；隐藏职业总概率10%。|n'
                        '抽取结果确定后不可重抽。|n隐藏一转「万象行者」拥有以下技能：|n|n'
                        '|cffd2b879三相打击（Q）|r|n' + Q_DESCRIPTIONS['AZHA'] + '|n|n'
                        '|cffd2b879三相回元（D）|r|n' + HEAL_DESCRIPTION)
    random['passive'] = ('隐藏天赋「均衡修炼」：每级力量、敏捷、智力成长各 +0.15。|n|n'
                         '可学习「三相修炼」：每级基础三围各 +2，最多3级。|n'
                         '一转不附送行动点；回元需要行动点和魔法，兼顾输出与续航。|n'
                         '未抽中隐藏职业时，隐藏进阶不会出现在二转、三转面板。')
    second['skills'] = ('|cffd2b879三相打击（Q）|r|n' + Q_DESCRIPTIONS['AZH2'] + '|n|n'
                        '|cffd2b879三相回元（D）|r|n' + HEAL_DESCRIPTION + '|n|n'
                        '|cffd2b879万象汲取（V）|r|n' + DRAIN_DESCRIPTION)
    third['skills'] = ('|cffd2b879三相打击（Q）|r|n' + Q_DESCRIPTIONS['AZH3'] + '|n|n'
                       '|cffd2b879三相回元（D）|r|n' + HEAL_DESCRIPTION + '|n|n'
                       '|cffd2b879万象汲取（V）|r|n' + DRAIN_DESCRIPTION + '|n|n'
                       '|cffd2b879万象共鸣（E）|r|n' + RESONANCE_DESCRIPTION)


HELPERS = r'''
// Separate spell tokens prevent cooldown resets from granting extra casts.
function HopeHidden_Stage takes unit u returns integer
local integer kind=GetUnitTypeId(u)
if kind=='HZ01' then
return 1
elseif kind=='HZ02' then
return 2
elseif kind=='HZ03' then
return 3
endif
return 0
endfunction
function HopeHidden_HealAmount takes unit u returns real
local real maximum=GetUnitState(u,UNIT_STATE_MAX_LIFE)
local real total=I2R(GetHeroStr(u,true)+GetHeroAgi(u,true)+GetHeroInt(u,true))
return RMaxBJ(0.,RMinBJ(maximum-GetWidgetLife(u),RMinBJ(maximum*.30,15.+total*.5)))
endfunction
function HopeHidden_DrainHealing takes unit u,real before,real after returns real
local real actual=RMaxBJ(0.,RMinBJ(before,before-RMaxBJ(0.,after)))
local real maximum=GetUnitState(u,UNIT_STATE_MAX_LIFE)
return RMaxBJ(0.,RMinBJ(maximum-GetWidgetLife(u),RMinBJ(maximum*.15,actual*.25)))
endfunction
function HopeHidden_Cast takes unit u,integer aid,unit target returns nothing
local player p=GetOwningPlayer(u)
local integer i=GetPlayerId(p)+1
local integer stage=HopeHidden_Stage(u)
local integer token=udg_quanshu*100000+udg_boci*1000+udg_huihe_s+1
local real amount=0.
local real before=0.
if i<1 or i>6 or u!=udg_hero[i] or stage==0 or GetWidgetLife(u)<=.405 or IsUnitPaused(u) or not udg_ZhandouZhong then
call DisplayTimedTextToPlayer(p,0,0,4.,"隐藏职业技能只能由当前英雄在自己的战斗回合使用。")
set p=null
return
endif
if aid=='AZHR' then
set amount=HopeHidden_HealAmount(u)
if amount<=0. then
call DisplayTimedTextToPlayer(p,0,0,4.,"三相回元：生命已满，不消耗资源。")
elseif HopeHidden_LastHeal[i]==token then
call DisplayTimedTextToPlayer(p,0,0,4.,"三相回元每回合只能使用一次。")
elseif udg_xingdong_dian[i]<1 or GetUnitState(u,UNIT_STATE_MANA)<2. then
call DisplayTimedTextToPlayer(p,0,0,4.,"三相回元需要1行动点、2魔法。")
else
set HopeHidden_LastHeal[i]=token
set udg_xingdong_dian[i]=udg_xingdong_dian[i]-1
call SetUnitState(u,UNIT_STATE_MANA,GetUnitState(u,UNIT_STATE_MANA)-2.)
call SetUnitState(u,UNIT_STATE_LIFE,GetWidgetLife(u)+amount)
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Human\\HolyBolt\\HolyBoltSpecialArt.mdl",u,"origin"))
call DisplayTimedTextToPlayer(p,0,0,4.,"三相回元：恢复 "+R2S(amount)+" 生命。")
endif
elseif aid=='AZHD' then
if stage<2 then
call DisplayTimedTextToPlayer(p,0,0,4.,"万象汲取需要完成隐藏二转。")
elseif target==null or not IsUnitInGroup(target,udg_Guaiwu_dwz) or not IsUnitEnemy(target,p) or GetWidgetLife(target)<=.405 then
call DisplayTimedTextToPlayer(p,0,0,4.,"万象汲取：请选择当前战斗中存活的敌人。")
elseif HopeHidden_LastDrain[i]==token then
call DisplayTimedTextToPlayer(p,0,0,4.,"万象汲取每回合只能使用一次。")
elseif udg_xingdong_dian[i]<2 or GetUnitState(u,UNIT_STATE_MANA)<3. then
call DisplayTimedTextToPlayer(p,0,0,4.,"万象汲取需要2行动点、3魔法。")
else
set HopeHidden_LastDrain[i]=token
set udg_xingdong_dian[i]=udg_xingdong_dian[i]-2
call SetUnitState(u,UNIT_STATE_MANA,GetUnitState(u,UNIT_STATE_MANA)-3.)
set before=GetWidgetLife(target)
set amount=I2R(GetHeroStr(u,true)+GetHeroAgi(u,true)+GetHeroInt(u,true))*1.75*udg_Skill_Dm[i]*udg_Fashang_Dm[i]
// The original damage callback applies final multiplier, criticals and resistance.
call UnitDamageTarget(u,target,amount,false,false,ATTACK_TYPE_MAGIC,DAMAGE_TYPE_MAGIC,WEAPON_TYPE_WHOKNOWS)
set amount=HopeHidden_DrainHealing(u,before,GetWidgetLife(target))
if GetWidgetLife(u)>.405 and amount>0. then
call SetUnitState(u,UNIT_STATE_LIFE,GetWidgetLife(u)+amount)
call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Human\\HolyBolt\\HolyBoltSpecialArt.mdl",u,"origin"))
endif
call DisplayTimedTextToPlayer(p,0,0,4.,"万象汲取：实际吸取 "+R2S(amount)+" 生命。")
endif
endif
set p=null
endfunction
'''


def replace_once(source, old, new):
    assert source.count(old) == 1, (old, source.count(old))
    return source.replace(old, new, 1)


def apply_script(source):
    assert 'function HopeHidden_Cast takes' not in source
    source, count = re.subn(r'^globals\n', 'globals\ninteger array HopeHidden_LastHeal\ninteger array HopeHidden_LastDrain\n', source, flags=re.M)
    assert count == 1
    source = replace_once(source, 'function HopeJob_Cast takes nothing returns nothing', HELPERS + '\nfunction HopeJob_Cast takes nothing returns nothing')
    match = re.search(r'function HopeJob_Cast takes nothing returns nothing\n.*?\nendfunction', source, re.S)
    assert match
    body = match[0]
    body = replace_once(body, "if aid=='AZHA' then", "if aid=='AZHR' or aid=='AZHD' then\ncall HopeHidden_Cast(u,aid,target)\nelseif aid=='AZHA' or aid=='AZH2' or aid=='AZH3' then")
    body = replace_once(body, 'amount*udg_Skill_Dm[i]*udg_Zuizhong_Dm[i]', 'amount*udg_Skill_Dm[i]')
    body = replace_once(body, 'set factor=udg_Skill_Dm[i]*udg_Zuizhong_Dm[i]', 'set factor=udg_Skill_Dm[i]')
    body = replace_once(body, 'if i>6 or u!=udg_hero[i] then', 'if i<1 or i>6 or u!=udg_hero[i] or GetWidgetLife(u)<=.405 or IsUnitPaused(u) then')
    source = source[:match.start()] + body + source[match.end():]
    assert 'GetRandomInt(1,100)<=10' in source
    return source
