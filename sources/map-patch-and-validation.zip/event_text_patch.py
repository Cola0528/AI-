"""Preserve every original fate-event sentence; color individual outcomes."""
import re
from modern_choices_patch import block,replace

HELPERS='''function HopeUI_PlayerText takes player p,string text returns string
local integer color=GetHandleId(GetPlayerColor(p))
local string prefix=YDWEBase__yd_PlayerColor[color]
if color==0 then
set prefix="|cffff6b6b"
elseif color==1 then
set prefix="|cff719fff"
elseif color==3 then
set prefix="|cffbf80ef"
elseif color==10 then
set prefix="|cff6fbea0"
elseif color==11 then
set prefix="|cffc79365"
elseif color>=12 then
set prefix="|cffa8a8a8"
endif
return prefix+text+"|r"
endfunction
function HopeEvent_Write takes player p,string text,boolean colored returns nothing
local integer at=0
local integer step=1
local integer width=0
local integer next=0
local string line=""
local string c=""
loop
exitwhen at>=StringLength(text)
set step=HopeName_Step(text,at)
set c=SubString(text,at,at+step)
set next=width+HopeName_CharWidth(c)
if next>260 and line!="" then
if colored then
call HopeEvent_Add(HopeUI_PlayerText(p,line))
else
call HopeEvent_Add(line)
endif
set line=""
set width=0
endif
set line=line+c
set width=width+HopeName_CharWidth(c)
set at=at+step
endloop
if line!="" then
if colored then
call HopeEvent_Add(HopeUI_PlayerText(p,line))
else
call HopeEvent_Add(line)
endif
endif
endfunction
function HopeEvent_Result takes player p,string result returns nothing
call HopeEvent_Write(p,HopeName_Clean(GetPlayerName(p))+"："+result,true)
endfunction
'''

def split_top(s,separator):
    parts=[];at=0;depth=0;quoted=False
    for i,c in enumerate(s):
        if c=='"' and (i==0 or s[i-1]!='\\'):quoted=not quoted
        if quoted:continue
        if c=='(':depth+=1
        elif c==')':depth-=1
        elif c==separator and depth==0:parts.append(s[at:i]);at=i+1
    assert depth==0 and not quoted,s
    parts.append(s[at:]);return parts

def format_message(line):
    prefix='call DisplayTextToForce(GetPlayersAll(),'
    assert line.startswith(prefix) and line.endswith(')')
    expr=line[len(prefix):-1]
    parts=split_top(expr,'+')
    colored_name=parts.pop(0)
    assert colored_name.startswith('YDWEGetPlayerColorString(')
    player,name=split_top(colored_name[len('YDWEGetPlayerColorString('):-1],',')
    assert name==f'GetPlayerName({player})'
    first=parts[0]
    assert first.startswith('"') and first.endswith('"')
    text=first[1:-1]
    rest='+'.join(parts[1:])
    out=[f'call HopeEvent_Write({player},HopeName_Clean({name}),true)']
    def emit(expr,colored):
        if expr and expr!='""':out.append(f'call HopeEvent_Write({player},{expr},{str(colored).lower()})')
    def literal(s):return '"'+s+'"'
    if text in ('全属性+5','HP上限-30'):
        emit('+'.join(parts),True)
    elif text=='没躲开机关受了伤 HP-30':
        emit(literal('没躲开机关受了伤'),False);emit(literal(' HP-30'),True);emit(rest,True)
    elif '技能伤害增加' in text:
        start=text.index('技能伤害增加')
        emit(literal(text[:start]),False);emit(literal(text[start:])+'+'+rest,True)
    elif text=='用力一砸武器坏了！（攻击力-5）巨石纹丝不动':
        emit(literal('用力一砸武器坏了！'),False)
        emit(literal('（攻击力-5）'),True)
        emit(literal('巨石纹丝不动'),False);emit(rest,False)
    else:
        emit(first,False)
        # Group summaries are narrative; the actual per-player settlements
        # are appended by their existing ForForce callbacks below.
        group=rest in ('"所有玩家金钱+300 木材+5"','"所有玩家金钱平分了"','"所有玩家金钱-150"','"大家各自凭智力领悟了里面的内容"')
        emit(rest,not group)
    return '\n'.join(out)

def add_team_results(src):
    edits={
      'Trig____________________018Func004Func015Func002A':'call HopeEvent_Result(GetEnumPlayer(),"金钱 +300，木材 +5")',
      'Trig____________________018Func004Func016Func004A':'call HopeEvent_Result(GetEnumPlayer(),"均分后金钱："+I2S(GetPlayerState(GetEnumPlayer(),PLAYER_STATE_RESOURCE_GOLD)))',
      'Trig____________________018Func004Func021Func002A':'call HopeEvent_Result(GetEnumPlayer(),"金钱 -"+I2S(goldBefore-GetPlayerState(GetEnumPlayer(),PLAYER_STATE_RESOURCE_GOLD)))',
      'Trig____________________018Func004Func024Func002Func005Func003A':'call HopeEvent_Result(GetEnumPlayer(),"金钱 +300")',
    }
    for name,call in edits.items():
        f=block(src,name)
        if 'goldBefore' in call:
            f=f.replace('returns nothing\n','returns nothing\nlocal integer goldBefore=GetPlayerState(GetEnumPlayer(),PLAYER_STATE_RESOURCE_GOLD)\n',1)
        src=replace(src,name,f.replace('\nendfunction','\n'+call+'\nendfunction',1))
    return src
