"""Execute the shipped new-enemy rosters/skills and validate complete SLK objects.

Uses deterministic doubles only at Warcraft natives; not a KK client test.
Usage: python validate_enemies.py [war3map-patched.j] [modified-object-directory]
"""
from pathlib import Path
from types import SimpleNamespace
import sys
import re
from validate_economy import World, rawcode, body, SCRIPT
from validate_object_dependencies import parse_slk

ROOT = Path(__file__).resolve().parent
OBJECTS = Path(sys.argv[2]) if len(sys.argv)>2 else ROOT/'modified'
ENEMIES = {'nZ01','nZ02','nZ03','nZ04','UZ01','UZ02'}
MOBS = {rawcode(x) for x in ['nZ01','nZ02','nZ03','nZ04']}
BOSSES = {rawcode('UZ01'),rawcode('UZ02')}
CASES = 0

def check(ok, message):
    global CASES
    assert ok, message
    CASES += 1

w=World()
w.g['ModuloInteger']=lambda a,b:a%b
w.load('HopeChallenge_SetRoster')
for mode in range(7):
    for completed in range(0,105):
        w.g['udg_Yx_Nd_Dj']=mode;w.g['udg_quanshu']=completed
        for name, slots in [('udg_boci_gw_lx',range(5)),('udg_BOSS_LX',range(3)),('udg_BOSS_LX_______DA',[1])]:
            for slot in slots:w.g[name][slot]=-123
        w.g['HopeChallenge_SetRoster']()
        changed=mode>=5 and completed>=4
        values=[w.g['udg_boci_gw_lx'][i] for i in range(5)]
        check(all(x in MOBS for x in values) if changed else values==[-123]*5,'Every round has valid troop slots; old modes/early rounds preserved')
        bosses=[w.g['udg_BOSS_LX'][i] for i in range(3)]+[w.g['udg_BOSS_LX_______DA'][1]]
        check(all(x in BOSSES for x in bosses) if changed else bosses==[-123]*4,'Elite/final boss pools are actually changed only in new late rounds')
        if changed:
            check(set(values)==MOBS,'Every new mob remains obtainable')
            check(w.g['udg_BOSS_LX_______DA'][1]==rawcode('UZ01' if completed%2==0 else 'UZ02'),'Final bosses alternate each round')
for alias in ENEMIES:
    check(bool(w.g['LoadStr']('YDHT',rawcode(alias),0x2AAC512D)),'New unit has actual AI skill-intent registration')
    check(w.g['LoadReal']('YDHT',rawcode(alias),0x73299135)>=3.,'New unit armor restores correctly next turn')
for alias in BOSSES:
    check(w.g['LoadBoolean']('YDHT',alias,0xFB89B46C),'New bosses marked for original reward/death logic')
check(body('Trig_X_____________004Actions')[3].count('call HopeChallenge_SetRoster()')==1,'Roster hook runs once at the round transition')
check('call HopeChallenge_EnemyCast(GetTriggerUnit())' in body('Trig_S_______001Actions')[3],'Real AI spell-effect dispatcher reaches new skills')
check('GetSpellAbilityId()==$41303055' in body('Trig_S_______001Conditions')[3],'New skills remain under existing A00U effect event')
check('852526' in body('Trig______________003Func008T')[3],'Original AI issues the actual A00U cast order')
check('call HopeChallenge_PrepareSkill(LoadUnitHandle(YDLOC,GetHandleId(GetExpiredTimer()),$9F0C6E00))\ncall IssueImmediateOrderById(' in body('Trig______________003Func008T')[3],'New enemies prepare cooldown and mana immediately before executing the announced skill')
check('$2AAC512D' in body('Trig______________0001Func007A')[3],'Every-round AI resolves registered new skill intents')

v=World();enemies=[];damage_calls=[];shielded=set();cooldown_resets=[]
v.g.update({'UNIT_STATE_LIFE':'life','UNIT_STATE_MAX_LIFE':'maximum','UNIT_STATE_MANA':'mana',
            'ATTACK_TYPE_MAGIC':1,'DAMAGE_TYPE_MAGIC':2,'ATTACK_TYPE_CHAOS':3,'DAMAGE_TYPE_NORMAL':4,'WEAPON_TYPE_WHOKNOWS':5,
            'UnitResetCooldown':lambda u:cooldown_resets.append(u),
            'SetUnitManaPercentBJ':lambda u,percent:setattr(u,'mana',20.*percent/100.),
            'ConvertUnitState':lambda key:key,'GetUnitState':lambda u,key:u.attack if key==20 else u.armor if key==32 else getattr(u,key),
            'SetUnitState':lambda u,key,value:setattr(u,'armor' if key==32 else key,value),
            'IsPlayerInForce':lambda p,force:p in force,'udg_WJZ_______cunhuo':{0,1,2},
            'IsUnitInGroup':lambda u,group:u in group,'udg_Guaiwu_dwz':enemies,
            'DestroyEffect':lambda effect:None,'AddSpecialEffectTarget':lambda *args:None,
            'CreateGroup':lambda:[],'GroupAddGroup':lambda source,dest:dest.extend(source),
            'FirstOfGroup':lambda group:group[0] if group else None,
            'GroupRemoveUnit':lambda group,u:group.remove(u),'DestroyGroup':lambda group:None,
            'udg_quanshu':4})
def damage(source,target,amount,*args):
    damage_calls.append((target,amount,args))
    if target.owner not in shielded:
        target.life=max(0.,target.life-amount)
v.g['UnitDamageTarget']=damage
v.load('HopeChallenge_IsEnemy','HopeChallenge_PrepareSkill','HopeChallenge_HeroAlive','HopeChallenge_Heal','HopeChallenge_Ward','HopeChallenge_EnemyCast')
cast=v.g['HopeChallenge_EnemyCast']
def enemy(alias, life=500., maximum=1000., attack=100.):
    u=SimpleNamespace(kind=rawcode(alias),owner=11,life=life,maximum=maximum,attack=attack,armor=5.,mana=20.)
    enemies.append(u)
    v.g['SaveReal']('YDHT',u.kind,0x73299135,5.)
    return u
heroes=[]
for owner in range(3):
    h=v.hero(owner);h.maximum=1000.;h.life=1000.;h.mana=10.
    heroes.append(h)
# More than three immediate consecutive prepared casts cannot exhaust MP or CD.
for alias in ENEMIES:
    u=enemy(alias)
    for attempt in range(10):
        for h in heroes:h.life=1000.
        u.mana=0.;before=len(cooldown_resets)
        v.g['HopeChallenge_PrepareSkill'](u)
        check(u.mana==20. and len(cooldown_resets)==before+1,'Preparation guarantees MP and cooldown for '+alias)
        u.mana-=10.  # Existing A00U engine cost, not hidden free player mana.
        cast(u)
    enemies.remove(u)
for h in heroes:h.life=1000.;h.mana=10.
u=enemy('n011');u.mana=3.;before=len(cooldown_resets)
v.g['HopeChallenge_PrepareSkill'](u)
check(u.mana==3. and len(cooldown_resets)==before,'Old enemies retain original cooldown and resource rules')
enemies.remove(u);damage_calls.clear()
# Iron ward reaches living allies, cannot stack, and dead allies are untouched.
u=enemy('nZ01');ally=enemy('nZ02');dead=enemy('nZ04',life=0.)
cast(u);check(u.armor==25. and ally.armor==25. and dead.armor==5.,'Ward is real non-stacking armor on living enemy team')
cast(u);check(ally.armor==25.,'Repeated wards do not stack')
# The original end-of-turn reset is still what expires this protection.
check('SetUnitState(GetEnumUnit(),ConvertUnitState(32),LoadReal(YDHT,GetUnitTypeId(GetEnumUnit()),$73299135))' in body('Trig______________003Func006A')[3], 'Enemy-turn reset expires extra armor')
# Flame rain hits every living player using current ATK (which already includes scaling).
cast(ally);check([h.life for h in heroes]==[900.,900.,900.],'Flame rain deals .85*100 + 5*3 magic damage to all three heroes')
check(all(c[2][2:4]==(1,2) for c in damage_calls),'Flame rain enters the magic damage pipeline')
# Marksman selects the lowest health fraction and clamps MP to zero.
u=enemy('nZ03');heroes[0].life=800.;heroes[1].life=300.;heroes[2].life=450.;heroes[1].mana=1.
cast(u);check((heroes[0].life,heroes[1].life,heroes[2].life,heroes[1].mana)==(800.,135.,450.,0.),'Marksman chooses wounded hero and drains real mana')
check(damage_calls[-1][2][2:4]==(3,4),'Marksman uses physical damage pipeline')
# Healing never resurrects dead allies, never overheals, and applies to the group.
u=enemy('nZ04');ally.life=990.;before=[a.life for a in enemies]
cast(u);check(ally.life==1000. and dead.life==0.,'Priest healing clamps to max HP and excludes dead allies')
check(u.life==630.,'Priest healing applies maxHP*.08 + attack*.5')
# Forge boss damages all living heroes and shields itself once.
u=enemy('UZ01');heroes[1].life=0.;before=[h.life for h in heroes];cast(u)
check(heroes[0].life==before[0]-115. and heroes[1].life==0. and heroes[2].life==before[2]-115. and u.armor==25.,'Forge boss really performs AoE physical damage and self ward')
# Void boss healing uses actual damage after mitigation and caps one cast at 6%.
u=enemy('UZ02');heroes[0].life=5.;heroes[1].life=1000.;heroes[2].life=1000.;heroes[0].mana=2.;heroes[1].mana=7.;heroes[2].mana=7.
shielded.add(1);cast(u)
check((heroes[0].life,heroes[1].life,heroes[2].life)==(0.,1000.,910.),'Void damage respects prevented damage and overkill')
check(abs(u.life-523.75)<1e-6,'Void life steal is 25% of actual 95 HP lost, not nominal 270 damage')
check([h.mana for h in heroes]==[0.,4.,4.],'Void mana drains are clamped to zero')
shielded.clear();u.attack=2000.;u.life=500.
heroes[0].life=1000.;heroes[1].life=1000.;heroes[2].life=1000.;cast(u)
check(u.life==560.,'Void life steal cap is six percent max HP even with several heroes')
# Invalid casters / heroes outside active force cannot receive the new AI action.
for invalid in ('dead','friendly','not in battle','ordinary'):
    for h in heroes:h.life=1000.
    u=enemy('nZ02');before=len(damage_calls)
    if invalid=='dead':u.life=0.
    elif invalid=='friendly':u.owner=0
    elif invalid=='not in battle':enemies.remove(u)
    else:u.kind=rawcode('n011')
    cast(u);check(len(damage_calls)==before,'Invalid caster rejected: '+invalid)
u=enemy('nZ02');v.g['udg_WJZ_______cunhuo']={0};before=len(damage_calls);cast(u)
check(len(damage_calls)==before+1 and damage_calls[-1][0].owner==0,'Dead/left player slots cannot be targeted')

# Independent typed SLK parser checks actual packaged records and mana required
# by the existing A00U cast. No builder is imported to derive these assertions.
tables={name:parse_slk((OBJECTS/f'Units_{name}.slk').read_bytes(),name) for name in ['UnitData','UnitBalance','UnitUI','UnitWeapons','UnitAbilities','AbilityData']}
for name,table in tables.items():
    if name!='AbilityData':check(ENEMIES<=table.rows.keys(),name+' contains all six new units')
ability=tables['AbilityData'].rows['A00U'];check(ability['code'].value=='AEfk','Enemy cast uses existing supported engine object')
for alias in ENEMIES:
    a=tables['UnitAbilities'].rows[alias];bal=tables['UnitBalance'].rows[alias]
    check(a['abilList'].value=='A00U' and a['heroAbilList'].value=='_','Every new unit can cast its actual AI channel and has no stray hero spells')
    check(bal['manaN'].value>=ability['Cost1'].value and bal['mana0'].value>=ability['Cost1'].value,'Every new enemy has sufficient MP for skill order')
    for field in ['HP','def','level','mana0','manaN']:
        check(bal[field].kind=='number',alias+': numeric SLK field remains numeric')
    check(tables['UnitWeapons'].rows[alias]['dmgplus1'].kind=='number','Attack SLK remains numeric')
for alias in ['nZ03','UZ02']:
    check(tables['UnitBalance'].rows[alias]['type'].value=='undead','Skeleton/lich are actual undead')
for alias in ['nZ01','nZ02','nZ04','UZ01']:
    types=tables['UnitBalance'].rows[alias].get('type')
    check(types is None or 'undead' not in types.value.split(','),'Non-undead models do not inherit unintended priest weakness')
check(tables['UnitBalance'].rows['nZ04']['type'].value=='mechanical','Stone construct is mechanical')
print(f'PASS: {CASES} new enemy roster, real skill-effect, target/cap, AI dispatch, typed-object and undead-classification checks.')
