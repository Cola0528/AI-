"""Execute shipped handlers with native doubles. This is not KK engine testing."""
from pathlib import Path
from types import SimpleNamespace as N
import re,math,json
from validate_economy import World,rawcode,body,SCRIPT
from validate_layout import Layout
from validate_object_dependencies import parse_slk
ROOT=Path(__file__).parent
COUNT=0

def check(v,msg):
 global COUNT
 assert v,msg
 COUNT+=1

def close(a,b,msg):check(math.isclose(a,b,rel_tol=1e-7,abs_tol=1e-7),msg)

class Bags(World):
 def __init__(self):
  super().__init__();self.h=self.hero();self.a=N(owner=0,kind=rawcode('hfoo'),life=100)
  self.bags={id(self.h):[],id(self.a):[]};self.created=[];self.mode='normal'
  self.g['udg_Bei_bao_danwei'][1]=self.a
  self.g.update({'UnitAddItem':self.put,'CreateItem':self.create,'GetItemTypeId':lambda it:0 if it is None else it.kind,'IsItemOwned':lambda it:it.carrier is not None,'GetUnitX':lambda u:77.,'GetUnitY':lambda u:88.,'SetItemPosition':lambda it,x,y:setattr(it,'position',(x,y)),'RemoveItem':lambda it:setattr(it,'kind',0),'GetTriggerUnit':lambda:self.h,'GetManipulatedItem':lambda:self.sold})
  self.g['SaveInteger']('YDHT',1,0x3FB1F9E0,rawcode('A00Y'))
  self.load('HopeInventory_Put','HopeInventory_Give','Trig____________________035_______uActions')
 def create(self,kind,x,y):
  it=N(kind=kind,position=(x,y),carrier=None);self.created.append(it);return it
 def put(self,u,it):
  if len(self.bags[id(u)])>=6:return False
  if self.mode=='consume':it.kind=0;return False
  self.bags[id(u)].append(it);it.carrier=u;return True

def inventory():
 for hero_slots in range(7):
  for helper_slots in range(7):
   w=Bags();w.bags[id(w.h)]=[None]*hero_slots;w.bags[id(w.a)]=[None]*helper_slots
   it=w.g['HopeInventory_Give'](rawcode('I04V'),w.h)
   expected=w.h if hero_slots<6 else w.a if helper_slots<6 else None
   check(it.carrier is expected,f'49 capacity combinations {hero_slots}/{helper_slots}')
   check(len(w.created)==1 and w.g['bj_lastCreatedItem'] is it,'single stable created item')
   if expected is None:check(it.position==(77,88),'both full drop at receiver')
 w=Bags();w.mode='consume';it=w.g['HopeInventory_Give'](rawcode('I04V'),w.h)
 check(it.kind==0 and not w.bags[id(w.a)],'combine callback consumed item never duplicated')
 w=Bags();w.g['udg_Bei_bao_danwei'][1]=None;w.bags[id(w.h)]=[None]*6
 it=w.g['HopeInventory_Give'](rawcode('I04V'),w.h);check(it.carrier is None,'missing assistant safely drops')
 data=parse_slk((ROOT/'modified/Units_ItemData.slk').read_bytes(),'items').rows
 check(data['phea']['powerup'].value==1 and data['phea']['abilList'].value=='_','full-inventory powerup without native heal')
 check(data['phea']['goldcost'].value==200,'original potion price retained')
 for a in ['I01A','I01I','I01J','I03A']:check(data[a]['usable'].value==0,a+' passive')
 for a in ['I01Y','I034','ckng']:check(data[a]['usable'].value==1,a+' genuine active retained')
 for hero_slots in [0,6]:
  for helper_slots in [0,6]:
   w=Bags();w.bags[id(w.h)]=[None]*hero_slots;w.bags[id(w.a)]=[None]*helper_slots
   for buyer in [w.h,w.a]:
    w.g['GetTriggerUnit']=lambda:buyer
    w.sold=w.create(rawcode('phea'),0,0);before=w.g['udg_Yaoshui_shenyu_cs'][1]
    w.g['Trig____________________035_______uActions']()
    check(w.g['udg_Yaoshui_shenyu_cs'][1]==before+1 and w.sold.kind==0,'potion single count for hero/helper at every capacity')
    check(w.ui_calls[-1][0] is w.h,'potion tooltip belongs to hero even helper buys')

 w=Bags();w.g['udg_hero'][1]=None;w.sold=w.create(rawcode('phea'),0,0);w.g['Trig____________________035_______uActions']()
 check(w.g['udg_Yaoshui_shenyu_cs'][1]==1,'starting potion before hero registered still granted')

class Combat(World):
 def __init__(self):
  super().__init__();self.u=self.hero();self.u.kind=rawcode('N01G');self.hits=[]
  for i in range(1,7):
   h=self.g['udg_hero'][i] if i==1 else self.hero(i-1)
   h.maximum=1000.;h.life=500.;h.attack=60.;h.armor=0.;h.mana=30.;h.str=h.agi=h.int=20
  self.u.level=15;self.enemy=N(owner=11,life=1e6,maximum=1e6,active=True)
  self.enemies=[self.enemy];self.ranks={rawcode('A059'):3}
  self.g.update({'UNIT_STATE_LIFE':'life','UNIT_STATE_MAX_LIFE':'maximum','UNIT_STATE_MANA':'mana','UNIT_STATE_MAX_MANA':'mana',
    'ATTACK_TYPE_NORMAL':'normal','DAMAGE_TYPE_NORMAL':'normal','ATTACK_TYPE_MAGIC':'magic','DAMAGE_TYPE_MAGIC':'magic','WEAPON_TYPE_WHOKNOWS':0,
    'ConvertUnitState':lambda k:k,'GetUnitState':self.state,'SetUnitState':self.setstate,
    'GetHeroStr':lambda u,b:u.str,'GetHeroAgi':lambda u,b:u.agi,'GetHeroInt':lambda u,b:u.int,
    'GetUnitAbilityLevel':lambda u,a:self.ranks.get(a,0),'IsUnitInGroup':lambda u,g:u in self.enemies,
    'IsUnitAlly':lambda u,p:u.owner<6,'IsUnitEnemy':lambda u,p:u.owner>=6,
    'AddSpecialEffectTarget':lambda *a:0,'DestroyEffect':lambda e:None,'UnitDamageTarget':self.damage,
    'CreateGroup':lambda:[],'GroupAddGroup':lambda s,g:g.extend(s),'FirstOfGroup':lambda g:g[0] if g else None,
    'GroupRemoveUnit':lambda g,u:g.remove(u),'DestroyGroup':lambda g:None,
    'udg_Guaiwu_dwz':self.enemies,'udg_ZhandouZhong':True,'GetTriggerUnit':lambda:self.u,'GetSpellTargetUnit':lambda:self.enemy,
    'GetSpellAbilityId':lambda:rawcode('A05C'),'GetTriggeringTrigger':lambda:1})
  self.g['udg_xingdong_dian'][1]=20;self.g['udg_Skill_Dm'][1]=1.3;self.g['udg_Fashang_Dm'][1]=1.5;self.g['udg_Zuizhong_Dm'][1]=2
  self.load('HopeMonk_Total','HopeMonk_Reset','HopeMonk_Ally','HopeMonk_Heal','HopeMonk_Lowest','HopeMonk_Cast','HopeSkill_Number','HopeSkill_Preview','Trig_JN_______001_______uActions','Trig_JN______006_______uActions','Trig_JN_______002Actions')
 def state(self,u,k):return getattr(u,{18:'attack',20:'attack',32:'armor'}.get(k,k))
 def setstate(self,u,k,v):setattr(u,{18:'attack',20:'attack',32:'armor'}.get(k,k),v)
 def damage(self,u,t,v,*args):
  self.hits.append((t,v,args));t.life=max(0.,t.life-v*2)
  if t.life==0 and t in self.enemies:self.enemies.remove(t)
  return True
 def cast(self,a,target=True):self.g['HopeMonk_Cast'](self.u,rawcode(a),self.enemy if target else None)

def monk():
 w=Combat();g=w.g;u=w.u
 g['Trig_JN_______001_______uActions']();close(w.hits[-1][1],102*1.3,'Q allstats + attack without preapplied final')
 check(g['HopeMonk_Qi'][1]==1 and g['udg_xingdong_dian'][1]==19 and u.mana==30,'Q 1AP zero mana +qi')
 for _ in range(6):w.cast('A058')
 check(g['HopeMonk_Qi'][1]==3,'qi capped at three')
 g['udg_hero'][2].life=20;g['udg_hero'][3].life=0;g['udg_hero'][4].owner=11
 before=g['udg_hero'][2].life
 g['Trig_JN______006_______uActions']()
 close(w.hits[-1][1],60*2*1.45*1.3*1.5,'rank3 E damage')
 close(g['udg_hero'][2].life-before,42,'E heals lowest living ally from allstats/qi')
 check(g['udg_hero'][3].life==0 and g['udg_hero'][4].life==500,'no dead/enemy recovery')
 check(g['HopeMonk_Qi'][1]==0 and u.mana==27,'E consumed qi and 3 mana once')
 before=(u.mana,g['udg_xingdong_dian'][1],len(w.hits));w.cast('A059');check(before==(u.mana,g['udg_xingdong_dian'][1],len(w.hits)),'repeated E blocked')
 g['HopeMonk_Qi'][1]=3;g['Trig_JN_______002Actions']()
 for j in [1,2,5,6]:close(g['udg_hero'][j].armor,11.4,'W allied armor')
 check(g['udg_hero'][3].armor==0 and g['udg_hero'][4].armor==0,'W skips dead/hostile')
 check(u.mana==25 and g['HopeMonk_Qi'][1]==0,'W single debit, not original defense too')
 w.cast('A05C',False);check(u.mana==25,'W once per turn')
 g['udg_huihe_s']+=1;g['udg_Defend_fangyu'][1]=6;w.cast('A05C',False);close(u.armor,23.4,'zero qi W includes third bonus')
 g['HopeJob_Awakened'][1]=True;g['HopeJob_UltimateKind'][1]=6
 w.enemies.extend([N(owner=11,life=1,active=True),N(owner=11,life=1,active=True)])
 w.hits.clear();oldlife=u.life;w.cast('AZ36',False)
 check(len(w.hits)==3,'Z snapshots group during kill removal')
 close(w.hits[0][1],66*1.3*1.5,'Z allstats damage')
 close(u.life-oldlife,15,'Z group healing');close(u.armor,29.4,'Z group armor');check(g['HopeMonk_Qi'][1]==3,'Z fills qi')
 before=(u.mana,g['udg_xingdong_dian'][1],len(w.hits));w.cast('AZ36',False);check(before==(u.mana,g['udg_xingdong_dian'][1],len(w.hits)),'Z once per turn')
 g['HopeMonk_Reset']();check(all(g['HopeMonk_Qi'][i]==0 for i in range(1,7)),'battle reset all players')
 for attr in ['str','agi','int']:
  v=Combat();before=v.g['HopeMonk_Total'](v.u);setattr(v.u,attr,30);v.cast('A058');close(v.hits[-1][1],(48+70*.9)*1.3,attr+' feeds damage equally')
  v.g['HopeMonk_Qi'][1]=0;v.cast('A05C',False);close(v.u.armor,7,attr+' feeds protection equally')
 for rank in [1,2,3]:
  for qi in range(4):
   v=Combat();v.ranks[rawcode('A059')]=rank;v.g['HopeMonk_Qi'][1]=qi;v.cast('A059')
   close(v.hits[-1][1],60*(.8+rank*.4)*(1+qi*.15)*1.3*1.5,'all E ranks and qi')
 for case in ['dead','paused','outside','no_ap','no_mana','wrong_hero','wrong_target','unlearned','unawakened']:
  v=Combat();a='A059'
  if case=='dead':v.u.life=0
  if case=='paused':v.u.paused=True
  if case=='outside':v.g['udg_ZhandouZhong']=False
  if case=='no_ap':v.g['udg_xingdong_dian'][1]=0
  if case=='no_mana':v.u.mana=2
  if case=='wrong_hero':v.u.kind=rawcode('N017')
  if case=='wrong_target':v.enemies.clear()
  if case=='unlearned':v.ranks.clear()
  if case=='unawakened':a='AZ36'
  v.g['HopeMonk_Qi'][1]=2;before=(v.u.mana,v.g['udg_xingdong_dian'][1]);v.cast(a)
  check(not v.hits and v.g['HopeMonk_Qi'][1]==2 and before==(v.u.mana,v.g['udg_xingdong_dian'][1]),'reject without spending '+case)
 v=Combat()
 for j in range(1,7):v.g['udg_hero'][j].life=999
 v.g['HopeMonk_Qi'][1]=3;v.cast('A059');check(v.u.life==1000,'healing capped')
 for a in ['A058','A059','A05C']:check('气' in v.g['HopeSkill_Preview'](v.u,rawcode(a),3),'live qi preview '+a)
 v=Combat();v.g['udg_Yx_Nd_Dj']=6;v.g['HopeChallenge_TurnSerial']=10000001;v.cast('A059');v.g['HopeChallenge_TurnSerial']+=1;v.cast('A059');check(len(v.hits)==2,'endless tokens permit next turn')
 opts=json.loads((ROOT/'patch-options.json').read_text());o=next(x for x in opts if x['target']=='N01G' and x['stage']==3)
 check(o['kind']==6 and o['bonus']['agi']==8,'third unique skill and third agility')
 check('call HopeMonk_Cast(u,aid,target)' in body('HopeJob_Cast')[3],'third dispatch hooked')


def event_ui():
 clients=[Layout() for _ in range(2)]
 for local,w in enumerate(clients):
  g=w.g;g['GetLocalPlayer']=lambda local=local:local
  # Same synchronized event lines are delivered on both clients.
  g['HopeEvent_Begin']()
  g['HopeEvent_Add']('|cffff0303队友甲|r|n与恶魔签订契约，出卖了队友。|n队友甲：全属性 +5|n|cff0042ff队友乙|r|n生命上限 -30')
  g['HopeLayout_Apply']();check(g['HopeEvent_Open'] and w.visible(g['HopeEvent_Panel']),'public popup on client '+str(local))
  check('队友乙' in w.frames[g['HopeEvent_Body']].text,'affected teammate visible')
  w.audit('shared-event-'+str(local))
 latest=clients[0].g
 latest['HopeEvent_Begin']();latest['HopeEvent_Add']('短结果');latest['HopeLayout_Apply']()
 before=latest['HopeEvent_Offset'];latest['HopeEvent_Move'](3)
 check(latest['HopeEvent_Offset']==before,'short newest event Down does not jump backward')
 # Deliver the same second synchronized event to the other client.
 clients[1].g['HopeEvent_Begin']();clients[1].g['HopeEvent_Add']('短结果');clients[1].g['HopeLayout_Apply']()
 clients[0].g['HopeEvent_Close']();clients[0].g['HopeLayout_Apply']()
 check(not clients[0].g['HopeEvent_Open'] and clients[1].g['HopeEvent_Open'],'closing is local only')
 check(dict(clients[0].g['HopeEvent_Line'])==dict(clients[1].g['HopeEvent_Line']),'all players identical outcomes')
 w=clients[1];g=w.g
 for j in range(6):g['HopeEvent_Add']('队友'+str(j)+'|n力大无穷，击碎巨石！|n全团金币 +300')
 g['HopeLayout_Apply']();check('全团金币' in w.frames[g['HopeEvent_Body']].text,'multiple teammates coexist')
 g['HopeEvent_Offset']=0;g['HopeLayout_Apply']();first=w.frames[g['HopeEvent_Body']].text;g['HopeEvent_Move'](3);g['HopeLayout_Apply']();check(first!=w.frames[g['HopeEvent_Body']].text,'scroll longer team event')
 w.shot=Path('/workspace/outputs/ui-layout-v12');w.shot.mkdir(exist_ok=True);w.render('shared-fate-event')
 for j in range(600):g['HopeEvent_Add']('记录'+str(j))
 g['HopeEvent_Move'](-99999);check(g['HopeEvent_Offset']==g['HopeEvent_Count']-512,'bounded ring oldest accessible')
 g['HopeEvent_Move'](99999);check(g['HopeEvent_Offset']==g['HopeEvent_Count']-13,'ring newest accessible')
 # All original event gameplay statements must remain byte-for-byte in order.
 original=(ROOT/'war3map.j').read_text()
 for name in re.findall(r'^function (Trig____________________018\w*) takes',original,re.M):
  old=body(name,original)[3];new=body(name)[3]
  if name=='Trig____________________018Func004Func023Func002A':
   old=old.replace('LoadInteger(YDLOC,GetHandleId(GetTriggeringTrigger())*LoadInteger(YDLOC,GetHandleId(GetTriggeringTrigger()),$ECE825E7),$877546F4)','GetConvertedPlayerId(GetEnumPlayer())')
  def effects(b):
   return [l for l in b.splitlines() if re.match(r'(call (?:ModifyHeroStat|AddHeroXP|AdjustPlayerState|SetUnit|SaveBoolean|SaveInteger|SaveReal|ForForce)|set udg_)',l)]
  check(effects(old)==effects(new),'event gameplay unchanged '+name)
  check('DisplayTextToForce' not in new,'no event public chat '+name)
 # Potion and fate data never depend on local close/offset.
 for name in ['HopeEvent_Add','HopeEvent_Begin','HopeInventory_Put','HopeMonk_Cast']:
  check('GetLocalPlayer' not in body(name)[3],'synchronized state independent of local UI '+name)
 check('HopeJob_WasInRoom' not in SCRIPT and 'call HopeJob_Show(' not in body('HopeJob_RefreshContent')[3],'fountain no auto career popup retained')

def event_outcomes():
 # Execute all 21 real event branches, including both random extremes for
 # per-player outcomes. All six participant names/results must fit the ledger.
 ui=Layout();ui.shot=Path('/workspace/outputs/ui-layout-v12')
 for roll in range(1,22):
  for extreme in [False,True]:
   w=Combat();g=w.g;state={'enum':0};w.u.str=80
   for j in range(1,7):
    g['udg_hero'][j].str=80 if extreme else 5
    g['udg_hero'][j].agi=80 if extreme else 5
   def for_force(force,callback):
    old=state['enum']
    for j in range(6):state['enum']=j;callback()
    state['enum']=old
   g.update({'GetTriggeringTrigger':lambda:777,'GetEnumPlayer':lambda:state['enum'],
    'GetRandomInt':lambda lo,hi:roll if (lo,hi)==(1,21) else hi if extreme else lo,
    'GetPlayerName':lambda p:'测试队友名字'+str(p), 'YDWEGetPlayerColorString':lambda p,s:s,
    'ForcePickRandomPlayer':lambda f:1,'ForForce':for_force,
    'GetPlayersAll':lambda:0,'DisplayTextToForce':lambda *a:w.messages.append(a),
    'TriggerSleepAction':lambda seconds:None,'AddHeroXPSwapped':lambda *a:None,
    'SetUnitLifePercentBJ':lambda u,pct:setattr(u,'life',u.maximum*pct/100),
    'GetUnitStateSwap':lambda k,u:w.state(u,k),'SetPlayerStateBJ':lambda p,k,v:w.resources.__setitem__((p,k),v),
    'GetPlayerState':lambda p,k:w.resources[p,k],'CountPlayersInForceBJ':lambda f:6,
    'FlushChildHashtable':lambda t,p:None,'ModuloInteger':lambda a,b:a%b,
    'StringLength':lambda s:len(s.encode()),'SubString':lambda s,a,b:s.encode()[a:b].decode(errors='ignore'),
    'bj_MODIFYMETHOD_SUB':'sub','ModifyHeroStat':lambda stat,u,mode,n:setattr(u,stat,getattr(u,stat)+(n if mode=='add' else -n))})
   for typ in ['PlayerHandle']:
    g['Save'+typ]=lambda t,p,k,v:w.tables[t].__setitem__((p,k),v)
    g['Load'+typ]=lambda t,p,k:w.tables[t].get((p,k))
   w.load('HopeEvent_Add','HopeEvent_Begin')
   for name in re.findall(r'^function (Trig____________________018\w*) takes',SCRIPT,re.M):
    if name.endswith('Conditions'):continue
    w.load(name)
   g['Trig____________________018Actions']()
   check(g['HopeEvent_Sequence']==1 and g['HopeEvent_Count']>1,'actual event recorded '+str(roll))
   check(not w.messages,'actual event chat removed '+str(roll))
   if roll==20 and extreme:
    for j in range(1,7):close(g['udg_Skill_Dm'][j],(1.3 if j==1 else 0)+.05,'study buff credited to each named teammate')
   ui.g['HopeEvent_Count']=g['HopeEvent_Count'];ui.g['HopeEvent_Line']=g['HopeEvent_Line']
   ui.g['HopeEvent_Sequence']=1;ui.g['HopeEvent_Seen']=0;ui.g['HopeEvent_Start']=0
   ui.g['HopeLayout_Apply']()
   for offset in range(max(1,g['HopeEvent_Count']-12)):
    ui.g['HopeEvent_Offset']=offset;ui.g['HopeLayout_Apply']()
    ui.render('event-'+str(roll)+'-'+str(extreme)+'-'+str(offset),False)
   check(True,'all rows fit for actual event '+str(roll))
 print('All 21 event outcomes and six-player subresults executed at both random extremes; all scroll offsets fit.')

if __name__=='__main__':
 inventory();monk();event_ui();event_outcomes();print(f'PASS: {COUNT} v12 inventory/potion/passive item, monk combat, all-client event/UI and unchanged event outcome assertions; native calls mocked, not KK.')
