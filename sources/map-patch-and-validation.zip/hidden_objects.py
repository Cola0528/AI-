"""Append complete SLK skill records; keep original optimized objects intact."""
import re
from hidden_patch import Q_DESCRIPTIONS, HEAL_DESCRIPTION, DRAIN_DESCRIPTION, RESONANCE_DESCRIPTION


def read_slk(path):
    lines = path.read_text(encoding='utf-8-sig').splitlines()
    rows = {}; x = y = 1
    for line in lines:
        if not line.startswith('C;'):
            continue
        m = re.search(r';X(\d+)', line)
        if m: x = int(m[1])
        m = re.search(r';Y(\d+)', line)
        if m: y = int(m[1])
        if ';K' in line:
            assert x not in rows.setdefault(y, {})
            rows[y][x] = line.split(';K', 1)[1]
    heads = {v.strip('"'): x for x, v in rows[1].items()}
    objects = {row[1].strip('"'): (y, row) for y, row in rows.items() if y != 1}
    return lines, rows, heads, objects


def update_section(text, alias, fields):
    pattern = r'^\[' + re.escape(alias) + r'\]\n(.*?)(?=^\[|\Z)'
    m = re.search(pattern, text, re.M | re.S)
    assert m, alias
    section = m[0].rstrip('\n')
    for key, value in fields.items():
        field = r'^' + re.escape(key) + r'=.*$'
        if re.search(field, section, re.M):
            section, n = re.subn(field, lambda _: key + '=' + value, section, flags=re.M)
            assert n == 1
        else:
            section += '\n' + key + '=' + value
    return text[:m.start()] + section + '\n\n' + text[m.end():]


def clone_section(text, base, alias):
    assert not re.search(r'^\[' + re.escape(alias) + r'\]', text, re.M)
    m = re.search(r'^\[' + re.escape(base) + r'\]\n(.*?)(?=^\[|\Z)', text, re.M | re.S)
    assert m, base
    return text + '\n[' + alias + ']\n' + m[1].rstrip('\n') + '\n\n'


def raw_value(value):
    if isinstance(value, str):
        return '"' + value.replace('"', '""') + '"'
    return str(value)


def apply_objects(root, output):
    path = output / 'Units_AbilityData.slk'
    lines, rows, heads, objects = read_slk(path)
    original_cells = {y: row.copy() for y, row in rows.items()}
    profiles = (output / 'Units_campaignabilitystrings.txt').read_text(encoding='utf-8-sig')
    new_objects = [
        ('AZH2', 'AZHA', '三相打击', 'Q', '0,2', 'cripple', 1, Q_DESCRIPTIONS['AZH2'], 'BTNSpellBreaker'),
        ('AZH3', 'AZHA', '三相打击', 'Q', '0,2', 'cripple', 1, Q_DESCRIPTIONS['AZH3'], 'BTNSpellBreaker'),
        ('AZHR', 'AZ35', '三相回元', 'D', '0,1', 'rejuvenation', 0, HEAL_DESCRIPTION, 'BTNRejuvenation'),
        ('AZHD', 'AZHA', '万象汲取', 'V', '2,2', 'drain', 1, DRAIN_DESCRIPTION, 'BTNDrain'),
    ]
    used_orders = {row.get(heads['DataF1']) for _, row in objects.values() if row[heads['code']] == '"ANcl"'}
    assert '"rejuvenation"' not in used_orders and '"drain"' not in used_orders
    last = max(rows)
    generated = []
    for index, (alias, base, name, hotkey, position, order, target, desc, art) in enumerate(new_objects, 1):
        assert alias not in objects, alias
        row = objects[base][1].copy()
        changes = {'alias': alias, 'code': 'ANcl', 'hero': 0, 'item': 0,
                   'race': 'human', 'levels': 1, 'reqLevel': 1, 'levelSkip': 0,
                   'Area1': 0.0, 'Cast1': 0.0, 'Cost1': 0, 'Cool1': 0.1,
                   'Rng1': 99999.0, 'Dur1': 0.0, 'HeroDur1': 0.0,
                   'DataA1': 0.0, 'DataB1': target, 'DataC1': 1,
                   'DataD1': 0.0, 'DataE1': 0, 'DataF1': order,
                   'targs1': 'enemies,neutral' if target else '_'}
        for key, value in changes.items():
            assert key in heads, key
            row[heads[key]] = raw_value(value)
        for column, value in sorted(row.items()):
            generated.append(f'C;X{column};Y{last+index};K{value}')
        profiles = clone_section(profiles, base, alias)
        profiles = update_section(profiles, alias, {'Name': name, 'Tip': name + '（' + hotkey + '）',
            'Ubertip': desc, 'Hotkey': hotkey, 'Order': order, 'Buttonpos': position,
            'Art': 'ReplaceableTextures\\CommandButtons\\' + art + '.blp'})
    lines = [line for line in lines if line != 'E']
    lines = [re.sub(r';Y\d+', f';Y{last+len(new_objects)}', line) if line.startswith('B;') else line for line in lines]
    path.write_text('\r\n'.join(lines + generated + ['E']) + '\r\n', encoding='utf-8')
    _, written_rows, _, written_objects = read_slk(path)
    for y, row in original_cells.items():
        assert written_rows[y] == row, y
    assert all(alias in written_objects for alias, *_ in new_objects)

    profiles = update_section(profiles, 'AZHA', {'Ubertip': Q_DESCRIPTIONS['AZHA']})
    profiles = update_section(profiles, 'AZ35', {'Ubertip': RESONANCE_DESCRIPTION})
    # The other newly introduced awakenings use the same original damage pipeline.
    for alias in ['AZ31', 'AZ32', 'AZ33']:
        section = re.search(r'^\[' + alias + r'\]\n(.*?)(?=^\[|\Z)', profiles, re.M | re.S)[1]
        old = re.search(r'^Ubertip=(.*)$', section, re.M)[1]
        old = old.replace('伤害计入技能与最终倍率，法术另计法伤倍率。', '技能、最终倍率、暴击和目标减伤按原图规则结算；法术另计法伤倍率。')
        profiles = update_section(profiles, alias, {'Ubertip': old})
    profiles = update_section(profiles, 'AZ34', {'Ubertip': '全体存活队友恢复各自生命上限的20% + 施法者智力。|n消耗2行动点、3魔法；战斗中每回合一次。|n治疗量不超过各自缺失生命。'})
    # Skill-learning text describes the currently learned effect, not future stages.
    profiles = update_section(profiles, 'AZHP', {'Researchubertip': '每学习一级，永久基础力量、敏捷、智力各+2；最多3级。|n每级消耗1技能点。'})
    (output / 'Units_campaignabilitystrings.txt').write_text(profiles, encoding='utf-8')

    path = output / 'Units_UnitAbilities.slk'
    lines, _, heads, objects = read_slk(path)
    for alias, abilities in {
        'HZ01': 'A001,AZHA,AInv,A002,AZHR',
        'HZ02': 'A001,AZH2,AInv,A002,AZHR,AZHD',
        'HZ03': 'A001,AZH3,AInv,A002,AZHR,AZHD',
    }.items():
        row, data = objects[alias]
        column = heads['abilList']
        old = f'C;X{column};Y{row};K' + data[column]
        assert lines.count(old) == 1, alias
        lines[lines.index(old)] = f'C;X{column};Y{row};K"{abilities}"'
    path.write_text('\r\n'.join(lines) + '\r\n', encoding='utf-8')
    # F/H are inherited focus/potion skills at their original top-row positions.
    # D at (0,1), V at (2,2), E at (2,1) avoid Q/W/R/G and AZHP at (1,1).
    print('Hidden abilities: stage-specific Q + D recovery + V life drain; original F focus retained')
