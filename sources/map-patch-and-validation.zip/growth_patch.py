"""Replace only the initial growth dialog with synchronized modern controls.

Apply after the class/round, shared points, and optional shop patches. No native
declarations or initial difficulty/hero generation are changed.
"""
import re


GLOBALS = r'''
// Synchronized initial-growth lifecycle; frame visibility is local only.
boolean array HopeGrowth_Started
boolean array HopeGrowth_Pending
unit array HopeGrowth_Hero
boolean HopeGrowth_UIReady=false
integer HopeGrowth_Panel=0
integer HopeGrowth_Title=0
integer HopeGrowth_Summary=0
integer HopeGrowth_Footer=0
integer HopeGrowth_FreeButton=0
integer HopeGrowth_PaidButton=0
integer HopeGrowth_AcceptButton=0
integer array HopeGrowth_ValueText
'''


EARLY = r'''
// The enter-region event fires during CreateUnit, before udg_hero is assigned.
// Save that unit here; callbacks later require it to be the current hero.
function HopeGrowth_Begin takes unit u returns nothing
local player p=GetOwningPlayer(u)
local integer owner=GetPlayerId(p)
if u==null or owner<0 or owner>=6 or GetUnitTypeId(u)!=$48303030 then
set p=null
return
endif
if GetPlayerSlotState(p)!=PLAYER_SLOT_STATE_PLAYING or GetPlayerController(p)!=MAP_CONTROL_USER or HopeGrowth_Started[owner] then
set p=null
return
endif
set HopeGrowth_Started[owner]=true
set HopeGrowth_Pending[owner]=true
set HopeGrowth_Hero[owner]=u
set HopeChoice_PlayerPending[owner]=HopeChoice_PlayerPending[owner]+1
if p==GetLocalPlayer() then
set HopeChoice_Hidden=false
set HopeQoL_Expanded=false
set HopeArchive_Expanded=false
set HopeGift_Expanded=false
set HopeRelic_Expanded=false
set HopeRoute_Details=false
set HopeJob_Expanded=false
endif
set p=null
endfunction

function HopeGrowth_CanAct takes player p returns boolean
local integer owner=GetPlayerId(p)
local unit u=null
if p==null or owner<0 or owner>=6 then
return false
endif
if GetPlayerSlotState(p)!=PLAYER_SLOT_STATE_PLAYING or GetPlayerController(p)!=MAP_CONTROL_USER then
return false
endif
if not HopeGrowth_Started[owner] or not HopeGrowth_Pending[owner] then
return false
endif
set u=udg_hero[owner+1]
if u==null or u!=HopeGrowth_Hero[owner] or GetOwningPlayer(u)!=p or GetUnitTypeId(u)!=$48303030 or GetWidgetLife(u)<=.405 then
set u=null
return false
endif
set u=null
return true
endfunction

'''


LATE = r'''
function HopeGrowth_UpdateTooltip takes integer i returns nothing
local integer abilityId=LoadInteger(YDHT,i,$412D8AC6)
local string s="力量成长: "+HopeQoL_GradedGrowth(udg_cz1Str_up[i],false)
set s=s+"|n敏捷成长: "+HopeQoL_GradedGrowth(udg_cz2Agi_up[i],false)
set s=s+"|n智力成长: "+HopeQoL_GradedGrowth(udg_cz3Int_up[i],false)
set s=s+"|n生命成长: "+HopeQoL_GradedGrowth(udg_cz4Hp_up[i],true)
set s=s+"|n魔力成长: "+HopeQoL_GradedGrowth(udg_cz5Mp_up[i],false)
set s=s+"|n专注成长: "+HopeQoL_GradedGrowth(udg_cz6Dex_up[i],false)
if udg_hero[i]!=null and abilityId!=0 then
call YDWESetUnitAbilityDataString(udg_hero[i],abilityId,1,218,s)
endif
endfunction

// These transactions are called only from synchronized button events.
// A stale click after confirmation cannot spend points or draw random values.
function HopeGrowth_Roll takes player p,boolean paid returns boolean
local integer i=GetPlayerId(p)+1
if not HopeGrowth_CanAct(p) then
return false
endif
if paid then
if not HopePoints_Spend(p,5) then
return false
endif
else
if udg_CZ_czcs[i]<=0 then
call DisplayTextToPlayer(p,0,0,"免费重置次数已用完；可单独选择5积分重置。")
return false
endif
set udg_CZ_czcs[i]=udg_CZ_czcs[i]-1
endif
call HopeGrowth_Randomize(i)
call HopeGrowth_UpdateTooltip(i)
if paid then
call DisplayTextToPlayer(p,0,0,"成长已重置：消耗5存档积分，剩余 "+I2S(udg_Wj_jf[i])+"。")
else
call DisplayTextToPlayer(p,0,0,"成长已重置：剩余免费次数 "+I2S(udg_CZ_czcs[i])+"。")
endif
return true
endfunction

function HopeGrowth_Accept takes player p returns boolean
local integer owner=GetPlayerId(p)
if not HopeGrowth_CanAct(p) then
return false
endif
set HopeGrowth_Pending[owner]=false
set HopeGrowth_Hero[owner]=null
set HopeChoice_PlayerPending[owner]=IMaxBJ(0,HopeChoice_PlayerPending[owner]-1)
call HopeGrowth_UpdateTooltip(owner+1)
call DisplayTextToPlayer(p,0,0,"初始成长已确认，可以准备出发。")
return true
endfunction

function HopeGrowth_FreeClick takes nothing returns nothing
call HopeGrowth_Roll(DzGetTriggerUIEventPlayer(),false)
endfunction
function HopeGrowth_PaidClick takes nothing returns nothing
call HopeGrowth_Roll(DzGetTriggerUIEventPlayer(),true)
endfunction
function HopeGrowth_AcceptClick takes nothing returns nothing
call HopeGrowth_Accept(DzGetTriggerUIEventPlayer())
endfunction

function HopeGrowth_Fold takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() then
set HopeChoice_Hidden=true
if HopeGrowth_Panel!=0 then
call DzFrameShow(HopeGrowth_Panel,false)
endif
call HopeChoice_ApplyVisibility()
endif
endfunction

function HopeGrowth_Refresh takes nothing returns nothing
local integer owner=GetPlayerId(GetLocalPlayer())
local integer i=owner+1
local boolean show=false
local string status=""
if not HopeGrowth_UIReady or owner<0 or owner>=6 then
return
endif
set show=HopeGrowth_Pending[owner] and not HopeChoice_Hidden
call DzFrameShow(HopeGrowth_Panel,show)
if not show then
return
endif
// Resuming with F6 returns to this choice and closes any intervening panels.
set HopeQoL_Expanded=false
set HopeArchive_Expanded=false
set HopeGift_Expanded=false
set HopeRelic_Expanded=false
set HopeRoute_Details=false
set HopeJob_Expanded=false
call DzFrameSetText(HopeGrowth_Summary,"存档积分  "+I2S(udg_Wj_jf[i])+"    免费重置  "+I2S(udg_CZ_czcs[i])+" 次")
call DzFrameSetText(HopeGrowth_ValueText[0],"力量  +"+HopeQoL_GradedGrowth(udg_cz1Str_up[i],false))
call DzFrameSetText(HopeGrowth_ValueText[1],"敏捷  +"+HopeQoL_GradedGrowth(udg_cz2Agi_up[i],false))
call DzFrameSetText(HopeGrowth_ValueText[2],"智力  +"+HopeQoL_GradedGrowth(udg_cz3Int_up[i],false))
call DzFrameSetText(HopeGrowth_ValueText[3],"生命  +"+HopeQoL_GradedGrowth(udg_cz4Hp_up[i],true))
call DzFrameSetText(HopeGrowth_ValueText[4],"魔力  +"+HopeQoL_GradedGrowth(udg_cz5Mp_up[i],false))
call DzFrameSetText(HopeGrowth_ValueText[5],"专注  +"+HopeQoL_GradedGrowth(udg_cz6Dex_up[i],false))
call DzFrameSetText(HopeGrowth_FreeButton,"免费重置 · 剩余"+I2S(udg_CZ_czcs[i])+"次")
set status="每次重置全部六项成长；免费与积分次数独立。"
if not HopeCloud_CanWrite(GetLocalPlayer()) then
set status="存档积分暂不可用；仍可免费重置或确认成长。"
elseif udg_Wj_jf[i]<5 then
set status="额外重置需要5存档积分，当前积分不足。"
endif
call DzFrameSetText(HopeGrowth_Footer,status+"|n确认后，本局不能再次重置初始成长。")
endfunction

function HopeGrowth_CreateUI takes nothing returns nothing
local integer f=0
local integer index=0
local real x=.014
local real y=-.074
call DestroyTimer(GetExpiredTimer())
set HopeGrowth_Panel=HopeQoL_Surface("HopeGrowthPanel",.229,.535,.342,.323)
if HopeGrowth_Panel==0 then
return
endif
set HopeGrowth_Title=HopeQoL_Label("HopeGrowthTitle",HopeGrowth_Panel,.014,-.010,.210,.021,"|cffffd060初始成长|r")
set f=HopeQoL_Button("HopeGrowthFold",HopeGrowth_Panel,.252,-.006,.076,.026,"收起 F6")
call HopeQoL_Bind(f,function HopeGrowth_Fold,false)
set HopeGrowth_Summary=HopeQoL_Label("HopeGrowthSummary",HopeGrowth_Panel,.014,-.041,.314,.020,"")
set HopeGrowth_UIReady=HopeGrowth_Title!=0 and HopeGrowth_Summary!=0 and f!=0
loop
exitwhen index>=6
if index>=3 then
set x=.178
set y=-.074-I2R(index-3)*.030
else
set x=.014
set y=-.074-I2R(index)*.030
endif
set HopeGrowth_ValueText[index]=HopeQoL_Label("HopeGrowthValue"+I2S(index),HopeGrowth_Panel,x,y,.150,.022,"")
set HopeGrowth_UIReady=HopeGrowth_UIReady and HopeGrowth_ValueText[index]!=0
set index=index+1
endloop
set f=HopeQoL_Label("HopeGrowthExplanation",HopeGrowth_Panel,.014,-.167,.314,.044,"以上为每级成长值；三围小数会累积。|n魔力提升技能伤害，专注提升精确打击伤害。|n积分额外重置不限次数，每次消耗5积分。")
set HopeGrowth_FreeButton=HopeQoL_Button("HopeGrowthFree",HopeGrowth_Panel,.014,-.218,.151,.028,"")
set HopeGrowth_PaidButton=HopeQoL_Button("HopeGrowthPaid",HopeGrowth_Panel,.177,-.218,.151,.028,"积分重置 · 5积分")
set HopeGrowth_AcceptButton=HopeQoL_Button("HopeGrowthAccept",HopeGrowth_Panel,.014,-.253,.314,.028,"以当前成长开始游戏")
call HopeQoL_Bind(HopeGrowth_FreeButton,function HopeGrowth_FreeClick,true)
call HopeQoL_Bind(HopeGrowth_PaidButton,function HopeGrowth_PaidClick,true)
call HopeQoL_Bind(HopeGrowth_AcceptButton,function HopeGrowth_AcceptClick,true)
set HopeGrowth_Footer=HopeQoL_Label("HopeGrowthFooter",HopeGrowth_Panel,.014,-.288,.314,.030,"")
set HopeGrowth_UIReady=HopeGrowth_UIReady and f!=0 and HopeGrowth_FreeButton!=0 and HopeGrowth_PaidButton!=0 and HopeGrowth_AcceptButton!=0 and HopeGrowth_Footer!=0
call DzFrameShow(HopeGrowth_Panel,false)
endfunction

'''


def function(src, name):
    match = re.search(r'^function '+re.escape(name)+r'\b.*?^endfunction\n', src, re.M | re.S)
    assert match, name
    return match.group()


def replace_once(src, old, new):
    assert src.count(old) == 1, (old[:100], src.count(old))
    return src.replace(old, new, 1)


def randomize_from_original(src):
    """Retain every original draw/conditional, including its harmless dead branch."""
    action = function(src, 'Trig_________________________0_042Actions')
    key = 'GetHandleId(GetTriggeringTrigger())*ydl_localvar_step'
    begin = 'call SaveReal(YDLOC,'+key+',$FBEDEC54,I2R(udg_ND_sz)*.1)'
    end = 'set udg_CZ_czcs['
    block = action[action.index(begin):action.index(end)]
    block = block.replace(begin+'\n', '')
    block = block.replace('LoadInteger(YDLOC,'+key+',$877546F4)', 'i')
    block = block.replace('LoadReal(YDLOC,'+key+',$FBEDEC54)', 'penalty')
    block = block.replace('LoadReal(YDLOC,'+key+',$CC612AE3)', 'total')
    block = re.sub(r'call SaveReal\(YDLOC,'+re.escape(key)+r',\$CC612AE3,(.*)\)', r'set total=\1', block)
    assert 'YDLOC' not in block and block.count('GetRandomReal(') == 15
    return ('function HopeGrowth_Randomize takes integer i returns nothing\n'
            'local real penalty=I2R(udg_ND_sz)*.1\nlocal real total=0.\n'
            +block+'endfunction\n\n')


def apply(src):
    assert 'function HopePoints_Spend takes' in src, 'Apply shared points patch first'
    assert 'function HopeGrowth_Begin takes' not in src, 'growth patch already applied'
    randomize = randomize_from_original(src)
    src = replace_once(src, '\nendglobals\n', GLOBALS+'\nendglobals\n')
    old = function(src, 'Trig__________________________041Actions')
    new = ('function Trig__________________________041Actions takes nothing returns nothing\n'
           'call HopeGrowth_Begin(GetTriggerUnit())\nendfunction\n')
    src = replace_once(src, old, EARLY+new)
    old = function(src, 'Trig_________________________0_042Actions')
    new = ('function Trig_________________________0_042Actions takes nothing returns nothing\n'
           '// Initial growth now uses synchronized frame callbacks.\nendfunction\n')
    src = replace_once(src, old, new)
    src = replace_once(src, 'function HopeQoL_Refresh takes nothing returns nothing\n',
                       randomize+LATE+'function HopeQoL_Refresh takes nothing returns nothing\n')
    src = replace_once(src, 'call HopeChoice_Refresh()\n',
                       'call HopeChoice_Refresh()\ncall HopeGrowth_Refresh()\n')
    src = replace_once(src, 'call TimerStart(CreateTimer(),.05,false,function HopeQoL_CreateUI)\n',
                       'call TimerStart(CreateTimer(),.05,false,function HopeQoL_CreateUI)\n'
                       'call TimerStart(CreateTimer(),.08,false,function HopeGrowth_CreateUI)\n')
    # Esc folds without confirming; F6 uses the original shared hidden state.
    old = function(src, 'Trig_Esc_____________026Actions')
    new = old.replace('if GetTriggerPlayer()==GetLocalPlayer() then\n',
                      'if GetTriggerPlayer()==GetLocalPlayer() then\n'
                      'if HopeGrowth_Pending[GetPlayerId(GetLocalPlayer())] then\n'
                      'set HopeChoice_Hidden=true\nendif\n', 1)
    src = replace_once(src, old, new)
    # Opening another panel temporarily folds this choice, retaining all state.
    for name in ('HopeArchive_OpenFor', 'HopeGift_OpenFor', 'HopeRelic_OpenFor', 'HopeJob_Show'):
        old = function(src, name)
        anchor = 'if p==GetLocalPlayer() then\n'
        if name == 'HopeJob_Show':
            anchor = 'if p==GetLocalPlayer() and GetPlayerId(p)<6 then\n'
        assert old.count(anchor) == 1, name
        new = old.replace(anchor, anchor+'if HopeGrowth_Pending[GetPlayerId(p)] then\n'
                          'set HopeChoice_Hidden=true\nendif\n', 1)
        src = replace_once(src, old, new)
    for name, anchor in (('HopeQoL_ToggleStats', 'set HopeQoL_Expanded=not HopeQoL_Expanded\n'),
                         ('HopeRoute_ToggleDetails', 'if HopeRoute_Details then\n')):
        old = function(src, name)
        assert old.count(anchor) == 1, name
        new = old.replace(anchor, anchor+'if HopeGrowth_Pending[GetPlayerId(GetLocalPlayer())] then\n'
                          'set HopeChoice_Hidden=true\nendif\n', 1)
        src = replace_once(src, old, new)
    return src
