"""Classic SStrHash2 byte hashing, used to generate ASCII-only UTF-8 dispatch.

Reference: actboy168/YDWE a69c315, warcraft3/detail/string_hash.cpp.
This is not a replacement engine; the runtime map calls native StringHash.
"""
MASK=0xffffffff

def mix(a,b,c):
    a=((a-b-c)&MASK)^(c>>13)
    b=((b-c-a)&MASK)^((a<<8)&MASK)
    c=((c-a-b)&MASK)^(b>>13)
    a=((a-b-c)&MASK)^(c>>12)
    b=((b-c-a)&MASK)^((a<<16)&MASK)
    c=((c-a-b)&MASK)^(b>>5)
    a=((a-b-c)&MASK)^(c>>3)
    b=((b-c-a)&MASK)^((a<<10)&MASK)
    c=((c-a-b)&MASK)^(b>>15)
    return a,b,c

def string_hash(value):
    data=value.encode('utf-8',errors='surrogateescape') if isinstance(value,str) else value
    data=bytes(x-32 if 97<=x<=122 else 92 if x==47 else x for x in data[:1023])
    a=b=0x9e3779b9;c=0;pos=0
    while len(data)-pos>=12:
        a=(a+int.from_bytes(data[pos:pos+4],'little'))&MASK
        b=(b+int.from_bytes(data[pos+4:pos+8],'little'))&MASK
        c=(c+int.from_bytes(data[pos+8:pos+12],'little'))&MASK
        a,b,c=mix(a,b,c);pos+=12
    tail=data[pos:];c=(c+len(data))&MASK
    a=(a+int.from_bytes(tail[:4],'little'))&MASK
    b=(b+int.from_bytes(tail[4:8],'little'))&MASK
    c=(c+(int.from_bytes(tail[8:],'little')<<8))&MASK
    _,_,c=mix(a,b,c)
    return c if c<0x80000000 else c-0x100000000


def utf8_step_jass():
    s='''function HopeName_Step takes string s,integer at returns integer
local integer h=StringHash(SubString(s,at,at+1))
local integer n=StringLength(s)-at
local integer step=1
// Newer engines normalize incomplete UTF-8 slices; widen only up to one character.
if h==1843378377 then
loop
exitwhen step>=4 or step>=n
set step=step+1
exitwhen StringHash(SubString(s,at,at+step))!=h
endloop
return step
endif
// Classic engine hashes byte slices directly. No non-BMP source literals.
'''
    for size,lo,hi in [(3,0xe0,0xf0),(2,0xc2,0xe0),(4,0xf0,0xf5)]:
        s+='if '+' or '.join('h=='+str(string_hash(bytes([b]))) for b in range(lo,hi))+' then\n'
        s+=f'return IMinBJ({size},n)\nendif\n'
    return s+'return 1\nendfunction\n'
