"""Rebalance only priest holy damage; keep healing, mana recovery and monk intact."""
import re
from hidden_objects import update_section

Q_TEXT = ('发射圣光球攻击敌人。|n基础伤害值：智力×0.8；对亡灵目标伤害提高25%。'
          '|n基础浮动75%~120%，另计敏捷下限、力量上限与精准打击。'
          '|n|c00fffc01行动点消耗:1|r|n该攻击属于法术')
E_TEXT = ('除固定魔法费用外，再消耗最大魔法值的20%打击一名敌人'
          '|n2级额外打击1个目标；3级最多额外打击3个目标'
          '|n基础伤害：(扣固定费用后当前魔法值×20%+智力)×0.8'
          '|n主目标和次目标对亡灵的伤害均提高25%。'
          '|n|c00fffc01行动点消耗:1|r|n每回合限用一次')
Q_OLD = '发射圣光球攻击敌人，对不死族敌人造成双倍伤害|n基础伤害值：智力*1|n浮动数值75%~120%|n|c00fffc01行动点消耗:1|r|n该攻击属于法术'
E_OLD = '除固定魔法费用外，再消耗最大魔法值的20%打击一名敌人|n2级额外打击1个目标；3级最多额外打击3个目标|n基础伤害：扣固定费用后当前魔法值×20%+智力|n主目标亡灵造成300%伤害；次目标亡灵造成200%伤害|n|c00fffc01行动点消耗:1|r|n每回合限用一次'
HELPERS = '''// Priest offense only: restore/support amounts never use these multipliers.
function HopePriest_BaseDamage takes real amount returns real
return amount*.8
endfunction
function HopePriest_TargetDamage takes real amount,unit target returns real
if IsUnitType(target,UNIT_TYPE_UNDEAD) then
return amount*1.25
endif
return amount
endfunction
'''
Q_HANDLER = 'Trig_JN_______005Actions'
E_HANDLER = 'Trig_JN_____________008______________uActions'
E_SPLASH = 'Trig_JN_____________008______________uFunc005Func015Func001Func002A'
CHANGED_FUNCTIONS = {Q_HANDLER, E_HANDLER, E_SPLASH, 'HopeSkill_Original', 'HopeSkill_Preview'}

def replace_function(src, name, transform):
    pattern = r'^function '+re.escape(name)+r' takes .*?^endfunction'
    match = re.search(pattern, src, re.M|re.S)
    assert match, name
    result = transform(match[0])
    assert result != match[0], ('no change', name)
    return src[:match.start()]+result+src[match.end():]

def update_options(options):
    for option in options:
        for field in ('skills', 'passive'):
            option[field] = option[field].replace(Q_OLD, Q_TEXT).replace(E_OLD, E_TEXT)
    # Initial priest and holy branch carry judgment; the first monk promotion
    # explicitly replaces the priest kit and has neither holy attack.
    assert any(E_TEXT in o['skills'] for o in options if o['target']=='N00E')
    assert any(Q_TEXT in o['skills'] and E_TEXT in o['skills'] for o in options if o['target']=='N017' and o['stage']==2)

def apply_script(src):
    anchor = 'function HopeSkill_Original takes'
    assert src.count(anchor)==1 and 'function HopePriest_BaseDamage ' not in src
    src = src.replace(anchor, HELPERS+anchor, 1)
    assert Q_OLD in src and E_OLD in src
    src = src.replace(Q_OLD,Q_TEXT).replace(E_OLD,E_TEXT)
    # Q shares the original missile handler with the mage's fireball. Replace
    # only its exact priest else branch, leaving mage, AP and projectile code.
    old = '''call SaveReal(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$BB4B7313,I2R(GetHeroInt(GetTriggerUnit(),true))*1.)
if IsUnitType(GetSpellTargetUnit(),UNIT_TYPE_UNDEAD)==true then
call SaveReal(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$BB4B7313,I2R(GetHeroInt(GetTriggerUnit(),true))*2.)
else
endif'''
    new = 'call SaveReal(YDLOC,GetHandleId(GetTriggeringTrigger())*ydl_localvar_step,$BB4B7313,HopePriest_TargetDamage(HopePriest_BaseDamage(I2R(GetHeroInt(GetTriggerUnit(),true))),GetSpellTargetUnit()))'
    def patch_q(block):
        assert block.count(old)==1
        return block.replace(old,new)
    src = replace_function(src,Q_HANDLER,patch_q)

    def patch_judgment(block):
        # All original branches remain; replacing only the damage multiplier
        # retains primary/secondary targeting, max targets, and resource logic.
        pattern = r'^(call UnitDamageTargetBJ\(.*?,)(LoadReal\(YDLOC,.*?,\$BB4B7313\))\*[123]\.,(ATTACK_TYPE_MAGIC,DAMAGE_TYPE_COLD\))$'
        damage_count = 0
        def damage(match):
            nonlocal damage_count
            damage_count += 1
            # Base damage is uniformly 80%. Both old undead and normal paths
            # use the exact actual target, so bonuses cannot leak to neighbors.
            prefix = match[1]
            target = 'GetEnumUnit()' if 'GetEnumUnit(),' in prefix else re.search(r',(LoadUnitHandle\(YDLOC,.*?,\$(?:E1001B12|182BDBDA)\)),?$',prefix)[1]
            return prefix+'HopePriest_TargetDamage(HopePriest_BaseDamage('+match[2]+'),'+target+'),'+match[3]
        result = re.sub(pattern,damage,block,flags=re.M)
        assert damage_count==(6 if 'Actions takes' in block else 2), damage_count
        return result
    src=replace_function(src,E_HANDLER,patch_judgment)
    src=replace_function(src,E_SPLASH,patch_judgment)
    old='return "一般目标 "+HopeSkill_Rolled(u,p,i*f,75,120)+"；亡灵 "+HopeSkill_Rolled(u,p,2.*i*f,75,120)'
    new='return "一般目标 "+HopeSkill_Rolled(u,p,HopePriest_BaseDamage(i)*f,75,120)+"；亡灵 "+HopeSkill_Rolled(u,p,HopePriest_BaseDamage(i)*1.25*f,75,120)'
    assert src.count(old)==1
    src=src.replace(old,new)
    old='set b=(.2*RMaxBJ(0.,mana-HopeSkill_ManaCost(id,level))+i)*k*f*z'
    assert src.count(old)==1
    src=src.replace(old,'set b=HopePriest_BaseDamage(.2*RMaxBJ(0.,mana-HopeSkill_ManaCost(id,level))+i)*k*f*z')
    for old,new,count in [('HopeSkill_Number(b*3.)','HopeSkill_Number(b*1.25)',1),('HopeSkill_Number(b*2.)','HopeSkill_Number(b*1.25)',2)]:
        assert src.count(old)==count,(old,src.count(old))
        src=src.replace(old,new)
    return src

def apply_objects(root, output):
    path=output/'Units_campaignabilitystrings.txt'
    text=path.read_text(encoding='utf-8-sig')
    text=update_section(text,'A03J',{'Ubertip':Q_TEXT})
    text=update_section(text,'A04W',{'Ubertip':E_TEXT,'Researchubertip':E_TEXT})
    path.write_text(text,encoding='utf-8')
    print('Priest damage: holy orb/judgment base 80%; all undead bonus 25%; recovery unchanged')
