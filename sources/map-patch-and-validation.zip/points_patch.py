"""Shared, synchronized spending for initial growth and permanent gift purchases."""


def apply(src):
    assert 'function HopePoints_Spend ' not in src
    src = src.replace('endglobals', 'boolean array HopePoints_Busy\nendglobals', 1)
    helper = '''// The original cloud interface submits writes; it is not a commit receipt.
// Call only from synchronized gameplay callbacks, never from local UI refresh.
function HopePoints_Spend takes player p,integer price returns boolean
local integer i=-1
if p==null then
return false
endif
set i=GetPlayerId(p)
if i<0 or i>=6 or price<=0 then
return false
endif
if GetPlayerSlotState(p)!=PLAYER_SLOT_STATE_PLAYING or GetPlayerController(p)!=MAP_CONTROL_USER then
return false
endif
if HopePoints_Busy[i] or HopeArchive_Busy[i] then
return false
endif
if not HopeCloud_CanWrite(p) then
call HopeCloud_Report(p)
return false
endif
if udg_Wj_jf[i+1]<price then
call DisplayTextToPlayer(p,0,0,"存档积分不足：需要 "+I2S(price)+"，当前 "+I2S(udg_Wj_jf[i+1])+"。")
return false
endif
set HopePoints_Busy[i]=true
set udg_Wj_jf[i+1]=udg_Wj_jf[i+1]-price
call DzAPI_Map_StoreInteger(p,"boss_jf",udg_Wj_jf[i+1])
set HopePoints_Busy[i]=false
return true
endfunction

'''
    anchor = 'function YDTriggerSaveLoadSystem___Init takes nothing returns nothing'
    assert src.count(anchor) == 1
    return src.replace(anchor, helper + anchor, 1)
