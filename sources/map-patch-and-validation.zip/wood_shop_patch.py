"""v10: one native ability-shop product; no selection-triggered purchase window."""
import re
from modern_choices_patch import block,replace
from hidden_objects import read_slk,raw_value,clone_section,update_section

RECORD='''function HopeDraw_SaveRecord takes player p,string title,string text,boolean reveal returns nothing
local integer i=GetPlayerId(p)
local integer page=0
set HopeDraw_Count[i]=HopeDraw_Count[i]+1
set page=ModuloInteger(HopeDraw_Count[i],64)*2
call SaveStr(HopeDraw_History,i,page,title)
call SaveStr(HopeDraw_History,i,page+1,text)
if p==GetLocalPlayer() then
set HopeDraw_Page=HopeDraw_Count[i]
if reveal then
set HopeDraw_Open=true
call HopeLayout_Focus(7)
set HopeChoice_Hidden=true
endif
endif
endfunction
function HopeDraw_Record takes player p,string title,string text returns nothing
call HopeDraw_SaveRecord(p,title,text,true)
endfunction'''

SHOP='''function HopeWood_Allowed takes unit shop,unit buyer returns boolean
local player p=GetOwningPlayer(buyer)
local integer i=GetPlayerId(p)
local boolean allowed=false
if buyer!=null and shop==gg_unit_n00Q_0028 and GetUnitTypeId(shop)=='n00Q' and i>=0 and i<6 then
set allowed=GetPlayerSlotState(p)==PLAYER_SLOT_STATE_PLAYING and GetPlayerController(p)==MAP_CONTROL_USER and not udg_ZhandouZhong and not HopeDraw_Busy[i] and udg_hero[i+1]!=null and GetWidgetLife(udg_hero[i+1])>.405
endif
set p=null
return allowed
endfunction
function HopeWood_Sold takes nothing returns nothing
local item sold=GetSoldItem()
local unit shop=GetSellingUnit()
local unit buyer=GetBuyingUnit()
local player p=GetOwningPlayer(buyer)
local integer i=GetPlayerId(p)
local string result="谢谢惠顾（未获得奖励）"
if GetItemTypeId(sold)!='IZWD' then
set sold=null
set shop=null
set buyer=null
set p=null
return
endif
// The native shop already charged the object's 1-wood price. Never debit again.
// Consume the item before rewarding, including on rejected purchases.
call RemoveItem(sold)
if shop==gg_unit_n00Q_0028 then
call AddItemToStock(shop,'IZWD',1,1)
endif
if HopeWood_Allowed(shop,buyer) then
set HopeDraw_Busy[i]=true
if GetRandomInt(1,100)>50 then
set result=HopeDraw_Reward(p)
endif
call HopeDraw_SaveRecord(p,"木材抽取结果 · 消耗1木材",result+"|n|n木材抽取50%谢谢惠顾；未抽空时沿用十连奖池。",false)
call DisplayTimedTextToPlayer(p,0,0,5.,"木材抽奖（1木材）："+result+"。可在抽取记录中回看。")
set HopeDraw_Busy[i]=false
elseif buyer!=null then
// A state change at settlement rejects the draw and returns the native price.
call SetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER,GetPlayerState(p,PLAYER_STATE_RESOURCE_LUMBER)+1)
call DisplayTextToPlayer(p,0,0,"当前不能进行木材抽奖，已退回1木材。请在非战斗时由能力商人购买。")
endif
set sold=null
set shop=null
set buyer=null
set p=null
endfunction
function HopeWood_Init takes nothing returns nothing
local trigger t=CreateTrigger()
call TriggerRegisterAnyUnitEventBJ(t,EVENT_PLAYER_UNIT_SELL_ITEM)
call TriggerAddAction(t,function HopeWood_Sold)
set t=null
endfunction
'''

def apply(src):
    src=replace(src,'HopeDraw_Record',RECORD)
    for name in ['HopeDraw_WoodAllowed','HopeDraw_Wood','HopeDraw_WoodClick','HopeDraw_ReturnWood','HopeDraw_CloseWood','HopeDraw_OnSelect']:
        src=src.replace(block(src,name),'',1)
    f=block(src,'HopeDraw_Create')
    f=f.replace('local integer i=0\n','').replace('local trigger t=CreateTrigger()\n','')
    a=f.index('set f=HopeQoL_Button("HopeDrawReturnWood"');b=f.index('set f=HopeQoL_Button("HopeDrawHistory"',a)
    f=f[:a]+f[b:]
    a=f.index('set HopeDraw_WoodPanel=');f=f[:a]+'call HopeJob_ShowFrame(HopeDraw_Panel,false)\nendfunction'
    f=f.replace('HopeDraw_Panel,.012,-.271,.102,.025','HopeDraw_Panel,.012,-.271,.166,.025')
    f=f.replace('HopeDraw_Panel,.122,-.271,.102,.025','HopeDraw_Panel,.192,-.271,.166,.025')
    src=replace(src,'HopeDraw_Create',f)
    src=src.replace('if view!=8 then\nset HopeDraw_WoodOpen=false\nendif\n','')
    src=src.replace("elseif HopeDraw_WoodOpen and not udg_ZhandouZhong and GetUnitTypeId(udg_Youxi_xzgq)=='n00K' then\nreturn 8\n",'')
    src='\n'.join(line for line in src.split('\n') if not re.search(r'\bHopeDraw_(WoodPanel|WoodStatus|WoodOpen)\b',line))
    src=src.replace('function HopeV8_Init takes',SHOP+'\nfunction HopeV8_Init takes',1)
    src=src.replace('call HopeDraw_Create()','call HopeDraw_Create()\ncall HopeWood_Init()',1)
    assert 'HopeDraw_OnSelect' not in src and 'HopeWoodBuy' not in src
    return src


def apply_objects(root,output):
    # Complete optimized item row, not a custom object inheriting a removed base.
    lines,rows,heads,objects=read_slk(root/'Units_ItemData.slk')
    assert 'IZWD' not in objects
    row=objects['tin2'][1].copy()
    values={'itemID':'IZWD','abilList':'_','goldcost':0,'lumbercost':1,
            'stockMax':1,'stockRegen':0,'stockStart':0,'pickRandom':0,
            'pawnable':0,'droppable':0,'powerup':1,'perishable':1,'usable':1,'uses':1}
    last=max(rows);headers=[]
    for key,value in values.items():
        if key not in heads:
            heads[key]=max(heads.values())+1
            headers.append(f'C;X{heads[key]};Y1;K"{key}"')
        row[heads[key]]=raw_value(value)
    # Explicit coordinates on every added header/cell retain original row state.
    end=next(i for i,line in enumerate(lines) if line.startswith('C;') and re.search(r';Y2(?:;|$)',line))
    lines[end:end]=headers
    lines=[line for line in lines if line!='E']
    lines=[re.sub(r';Y\d+',f';Y{last+1}',re.sub(r';X\d+',f';X{max(heads.values())}',line)) if line.startswith('B;') else line for line in lines]
    lines += [f'C;X{col};Y{last+1};K{value}' for col,value in sorted(row.items())]+['E']
    (output/'Units_ItemData.slk').write_text('\r\n'.join(lines)+'\r\n',encoding='utf-8')
    text=(root/'Units_itemstrings.txt').read_text(encoding='utf-8-sig')
    text=clone_section(text,'tin2','IZWD')
    desc='每次消耗1木材，立即随机获得一次奖励；50%谢谢惠顾。|n25%单项属性+1（力敏智等概率），15%全属性+3。|n8%伤害/暴击奖励（三项等概率），2%圣剑。|n非空结果沿用十连奖池，仅影响本局。|n结果可在左下“抽取记录”查看；三转需要30木材。'
    text=update_section(text,'IZWD',{'Name':'木材抽奖','Tip':'木材抽奖 · 1木材','Description':desc,'Ubertip':desc,'Art':'ReplaceableTextures\\CommandButtons\\BTNReplay-Loop.blp','Buttonpos':'3,0'})
    (output/'Units_itemstrings.txt').write_text(text,encoding='utf-8')
    p=output/'Units_campaignunitstrings.txt';text=p.read_text(encoding='utf-8-sig')
    m=re.search(r'^\[n00Q\]\n(.*?)(?=^\[|\Z)',text,re.M|re.S);assert m
    stock=re.search(r'^Sellitems=(.*)$',m[1],re.M)[1]
    assert 'IZWD' not in stock
    text=update_section(text,'n00Q',{'Sellitems':stock+',IZWD'})
    p.write_text(text,encoding='utf-8')
    print('Wood lottery: one native 1-wood product in n00Q; original item rows preserved.')
