"""Run the shipped optional-name Lua expression, including absent/raising APIs."""
from pathlib import Path
import re,sys
sys.path.insert(0,'/tmp/map-lua-test')
from lupa.lua51 import LuaRuntime


class NameBridge:
    def __init__(self,heroes,on_name):
        self.lua=LuaRuntime(unpack_returned_tuples=True)
        self.heroes={id(u):u for u in heroes if u is not None}
        self.on_name=on_name
        self.api=self.lua.table()
        wrap=self.lua.eval('function(f) return function(u,n) return f(u,n) end end')
        self.api['DzSetUnitName']=wrap(lambda u,n:self.on_name(self.heroes[u],'name',n))
        self.api['DzSetUnitProperName']=wrap(lambda u,n:self.on_name(self.heroes[u],'proper',n))
        self.lua.globals()['available_api']=self.api
        self.lua.execute("function require(n) assert(n=='jass.japi'); return available_api end")
        self.scripts=[]

    def execute(self,script):
        self.scripts.append(script)
        return self.lua.eval(script)


def run():
    # Imported here so the helper can also be used by the general Third fixture.
    from validate_third import Third,INDEX,OPTIONS,DESIGNS,rawcode
    from validate_economy import SCRIPT,body
    count=0
    for case in ['both','missing_module','nil_module','missing_both','missing_name','missing_proper','lookup_throws','call_throws']:
        w=Third('H00E');g=w.g;bridge=w.name_bridge;u=w.u
        old=(u.name,u.proper)
        if case=='missing_module':bridge.lua.execute("function require(n) error('module unavailable') end")
        elif case=='nil_module':bridge.lua.globals()['available_api']=None
        elif case=='missing_both':bridge.api['DzSetUnitName']=None;bridge.api['DzSetUnitProperName']=None
        elif case=='missing_name':bridge.api['DzSetUnitName']=None
        elif case=='missing_proper':bridge.api['DzSetUnitProperName']=None
        elif case=='lookup_throws':bridge.lua.execute("available_api=setmetatable({}, {__index=function() error('unknown native') end})")
        elif case=='call_throws':
            bridge.lua.execute("available_api.DzSetUnitName=function() error('unavailable binding') end; available_api.DzSetUnitProperName=function() error('unavailable binding') end")
        g['HopeJob_Awakened'][1]=False;g['udg_ZhandouZhong']=False
        w.resources[0,'gold']=1000;w.resources[0,'lumber']=30
        g['HopeJob_Commit'](INDEX['H00E'])
        assert g['HopeJob_Awakened'][1] and u.abilities.get(rawcode('AT10'))==1,case
        assert w.resources[0,'gold']==0 and w.resources[0,'lumber']==0,case
        assert g['udg_hero'][2].name=='二转1',case
        expected=OPTIONS[INDEX['H00E']]['name']
        assert u.name==(expected if case in ['both','missing_proper'] else old[0]),case
        assert u.proper==(expected if case in ['both','missing_name'] else old[1]),case
        assert len(bridge.scripts)==1,case
        before=(u.name,u.proper,len(w.names),len(bridge.scripts))
        g['HopeJob_Commit'](INDEX['H00E'])
        assert before==(u.name,u.proper,len(w.names),len(bridge.scripts)),case
        count+=7
    w=Third('N018');g=w.g
    for u,index in [(None,INDEX['N018']),(w.u,-1),(w.u,43)]:g['HopeThird_Rename'](u,index)
    assert not w.name_bridge.scripts;count+=1
    # Unknown index in the static name table is harmless as well.
    g['HopeThird_Rename'](w.u,0)
    assert not w.names;count+=1
    # The bridge appears only in the unlock path, never in main/config/init.
    callers=[m[1] for m in re.finditer(r'^function (\w+) takes.*?^endfunction',SCRIPT,re.M|re.S) if 'call HopeThird_Rename(' in m[0]]
    assert callers==['HopeThird_Unlock'];count+=1
    print(f'PASS: {count} name-compatibility assertions using actual shipped Lua 5.1 expressions.')
    print('Covered absent module, missing/throwing API, partial support and successful per-instance names; no KK native implementation available.')


if __name__=='__main__':run()
