"""Optional per-instance names through the original map's Lua bridge.

Do not declare new platform natives: unknown bindings can prevent map loading.
This expression is evaluated only after awakening, never during initialization.
"""
import json


def jass_quote(s):
    return '"'+s.replace('\\','\\\\').replace('"','\\"')+'"'


def rename_function(opts):
    # Names are build-time map data, never player-provided code.
    names=','.join('['+str(i)+']='+json.dumps(o['name'],ensure_ascii=False)
                   for i,o in enumerate(opts) if o['stage']==3)
    prefix="(function() local ok,j=pcall(require,'jass.japi'); if not ok or type(j)~='table' then return '' end local n=({"+names+"})["
    middle="]; if not n then return '' end local u="
    suffix="; local count=0; for _,k in ipairs({'DzSetUnitName','DzSetUnitProperName'}) do local found,f=pcall(function() return j[k] end); if found and type(f)=='function' then local done=pcall(f,u,n); if done then count=count+1 end end end return tostring(count) end)()"
    assert all(len(s.encode())<1024 for s in (prefix,middle,suffix))
    expression=jass_quote(prefix)+'+I2S(index)+'+jass_quote(middle)+'+I2S(GetHandleId(u))+'+jass_quote(suffix)
    return '''function HopeThird_Rename takes unit u,integer index returns nothing
if u==null or index<0 or index>=HopeJob_Count then
return
endif
// Optional cosmetics. Missing module/API must not block loading or promotion.
call EXExecuteScript('''+expression+''')
endfunction
'''
