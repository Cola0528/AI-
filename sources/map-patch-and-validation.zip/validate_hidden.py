"""Exercise actual hidden-class decisions with deterministic native boundaries."""
from collections import Counter
import json
from pathlib import Path
from validate_economy import World,rawcode,body,SCRIPT

R=Path(__file__).resolve().parent
options=json.loads((R/'patch-options.json').read_text())
w=World();hero=w.hero(0);hero.kind=rawcode('H000')
results=[];calls=[];selection={'roll':1,'ordinary':0}
for i,o in enumerate(options):
 w.g['HopeJob_Item'][i]=rawcode(o['item']) if o['item'] else 0
 w.g['HopeJob_Name'][i]=o['name']
 w.g['HopeJob_Stage'][i]=o['stage']

def random_int(lo,hi):
 calls.append((lo,hi))
 return selection['roll'] if (lo,hi)==(1,100) else selection['ordinary']
def add_item(u,it):
 assert w.g['HopeJob_RandomPromotion']
 results.append(('ordinary',it));return True
w.g.update({'DzGetTriggerUIEventPlayer':lambda:0,'HopeJob_Blocker':lambda index,p:'','GetRandomInt':random_int,'HopeJob_ReplaceHidden':lambda p,kind:results.append(('hidden',kind)), 'CreateItem':lambda kind,x,y:kind,'GetUnitX':lambda u:0.,'GetUnitY':lambda u:0.,'UnitAddItem':add_item,'RemoveItem':lambda it:None,'HopeJob_ShowFrame':lambda *args:None})
w.load('HopeJob_Commit')
for first in range(1,101):
 for second in range(8):
  selection.update(roll=first,ordinary=second);calls.clear()
  w.g['HopeJob_Commit'](24)
  assert calls==([(1,100)] if first<=10 else [(1,100),(0,7)])
  assert not w.g['HopeJob_RandomPromotion']
counts=Counter(kind for kind,item in results)
assert counts=={'hidden':80,'ordinary':720},counts
ordinary=Counter(item for kind,item in results if kind=='ordinary')
assert ordinary=={w.g['HopeJob_Item'][i]:90 for i in range(8)},ordinary
assert {item for kind,item in results if kind=='hidden'}=={rawcode('HZ01')}
w.g['HopeJob_Blocker']=lambda index,p:'not eligible';calls.clear();before=len(results)
w.g['HopeJob_Commit'](24)
assert not calls and len(results)==before
print('PASS: actual random-promotion callback maps exactly 10% hidden and 90% equally to eight ordinary careers; rejected clicks do not draw.')

# Exercise the shipped handlers, not a builder-produced replacement. The only
# doubles below are Warcraft natives and the original shared damage pipeline.
v=World();u=v.hero(0)
u.kind=rawcode('HZ01');u.maximum=200.;u.mana=10.;u.str=u.agi=u.int=20
u.attack=60.
event={'ability':rawcode('AZHR'),'target':None}
damage_inputs=[]
from types import SimpleNamespace
enemy=SimpleNamespace(owner=11,life=200.,active=True)
enemies=[enemy]
def damage(source,target,amount,*args):
 damage_inputs.append(amount)
 # Simulate a final multiplier of 2 in the existing damage callback. The new
 # handler must not pre-apply that multiplier before this boundary.
 target.life=max(0.,target.life-amount*2.)
def state(unit,key):
 return unit.attack if key==20 else getattr(unit,key)
v.g.update({'UNIT_STATE_LIFE':'life','UNIT_STATE_MAX_LIFE':'maximum','UNIT_STATE_MANA':'mana',
            'ATTACK_TYPE_MAGIC':1,'DAMAGE_TYPE_MAGIC':2,'WEAPON_TYPE_WHOKNOWS':3,
            'ATTACK_TYPE_NORMAL':4,'DAMAGE_TYPE_NORMAL':5,
            'GetUnitState':state,'SetUnitState':lambda unit,key,value:setattr(unit,key,value),
            'GetHeroStr':lambda unit,bonus:unit.str,'GetHeroAgi':lambda unit,bonus:unit.agi,'GetHeroInt':lambda unit,bonus:unit.int,
            'IsUnitInGroup':lambda unit,group:unit.active,'IsUnitEnemy':lambda unit,player:unit.owner!=player,
            'IsUnitAlly':lambda unit,player:unit.owner==player,
            'DestroyEffect':lambda effect:None,'AddSpecialEffectTarget':lambda *args:None,
            'UnitDamageTarget':damage,'ConvertUnitState':lambda key:key,
            'GetSpellAbilityId':lambda:event['ability'],'GetTriggerUnit':lambda:u,'GetSpellTargetUnit':lambda:event['target'],
            'CreateGroup':lambda:[],'GroupAddGroup':lambda source,dest:dest.extend(source),
            'FirstOfGroup':lambda group:group[0] if group else None,
            'GroupRemoveUnit':lambda group,unit:group.remove(unit),'DestroyGroup':lambda group:None,
            'udg_Guaiwu_dwz':enemies,'udg_quanshu':0,'udg_boci':0,'udg_huihe_s':0,'udg_ZhandouZhong':True})
v.g['udg_xingdong_dian'][1]=5;v.g['udg_Skill_Dm'][1]=1.2
v.g['udg_Fashang_Dm'][1]=1.5;v.g['udg_Zuizhong_Dm'][1]=2.
v.load('HopeHidden_Stage','HopeHidden_HealAmount','HopeHidden_DrainHealing','HopeHidden_Cast','HopeJob_Cast')
cast=v.g['HopeHidden_Cast'];heal=rawcode('AZHR');drain=rawcode('AZHD')
cast(u,heal,None)
assert (u.life,u.mana,v.g['udg_xingdong_dian'][1])==(145.,8.,4)
cast(u,heal,None)
assert (u.life,u.mana,v.g['udg_xingdong_dian'][1])==(145.,8.,4),'Duplicate heal must not spend or recover again'
v.g['udg_huihe_s']=1;u.life=200.
cast(u,heal,None)
assert (u.life,u.mana,v.g['udg_xingdong_dian'][1])==(200.,8.,4),'Full health must not spend resources'
u.life=190.;cast(u,heal,None)
assert (u.life,u.mana,v.g['udg_xingdong_dian'][1])==(200.,6.,3),'Full health attempt must not consume the turn token'
v.g['udg_huihe_s']=2;u.life=100.;u.mana=1.
cast(u,heal,None)
assert (u.life,u.mana,v.g['udg_xingdong_dian'][1])==(100.,1.,3),'Insufficient mana must not consume action points'
u.mana=10.;v.g['udg_xingdong_dian'][1]=0
cast(u,heal,None);assert u.life==100. and u.mana==10.
v.g['udg_xingdong_dian'][1]=3;v.g['udg_ZhandouZhong']=False
cast(u,heal,None);assert u.life==100. and u.mana==10.
v.g['udg_ZhandouZhong']=True;u.paused=True
cast(u,heal,None);assert u.life==100. and u.mana==10.
u.paused=False;u.life=.4
cast(u,heal,None);assert u.life==.4 and u.mana==10.
u.life=100.;u.str=u.agi=u.int=500
assert v.g['HopeHidden_HealAmount'](u)==60.,'Recovery must stay capped at 30% max health'
u.str=u.agi=u.int=20

cast(u,drain,enemy)
assert (u.life,u.mana,enemy.life)==(100.,10.,200.),'First hidden stage cannot cast second-stage drain'
u.kind=rawcode('HZ02');enemy.active=False
cast(u,drain,enemy)
assert (u.life,u.mana,enemy.life)==(100.,10.,200.),'Out-of-battle target must not consume resources'
enemy.active=True;enemy.owner=0
cast(u,drain,enemy)
assert (u.life,u.mana,enemy.life)==(100.,10.,200.),'Friendly target must not consume resources'
enemy.owner=11
cast(u,drain,None)
assert (u.life,u.mana,enemy.life)==(100.,10.,200.)
cast(u,drain,enemy)
assert abs(damage_inputs[-1]-189.)<.000001,'Drain base: 60 * 1.75 * skill 1.2 * spell 1.5, no repeated final multiplier'
assert (u.life,u.mana,enemy.life,v.g['udg_xingdong_dian'][1])==(130.,7.,0.,1)
enemy.life=200.;cast(u,drain,enemy)
assert len(damage_inputs)==1 and enemy.life==200.,'Same-turn drain must reject even another valid target'
# The two learned spells have independent once-per-turn budgets.
cast(u,heal,None)
assert (u.life,u.mana,v.g['udg_xingdong_dian'][1])==(175.,5.,0)
v.g['udg_huihe_s']=3;v.g['udg_xingdong_dian'][1]=5;u.life=100.;enemy.life=4.
cast(u,drain,enemy)
assert u.life==101.,'Overkill cannot restore more than target old health / 4'
assert v.g['HopeHidden_DrainHealing'](u,100.,100.)==0.
assert v.g['HopeHidden_DrainHealing'](u,100.,200.)==0.
assert v.g['HopeHidden_DrainHealing'](u,20.,-100.)==5.
u.life=198.;assert v.g['HopeHidden_DrainHealing'](u,200.,0.)==2.
v.g['udg_huihe_s']=4;u.life=100.;u.mana=10.;enemy.life=200.
v.g['UnitDamageTarget']=lambda *args:None
cast(u,drain,enemy)
assert u.life==100.,'Damage completely prevented by the original pipeline gives zero drain recovery'
v.g['UnitDamageTarget']=damage
u.kind=rawcode('H001');v.g['udg_xingdong_dian'][1]=5;u.mana=10.
cast(u,drain,enemy);cast(u,heal,None)
assert (u.life,u.mana,enemy.life)==(100.,10.,200.),'Ordinary classes cannot execute hidden skills'

# Verify each real stage-specific Q dispatch and the shared awakening branch.
cast_job=v.g['HopeJob_Cast'];event['target']=enemy
for kind,ability,coefficient,total_coefficient in [('HZ01','AZHA',.6,.45),('HZ02','AZH2',.65,.65),('HZ03','AZH3',.7,.8)]:
 u.kind=rawcode(kind);event['ability']=rawcode(ability);enemy.life=1000.
 v.g['udg_xingdong_dian'][1]=5
 cast_job()
 expected=(60.*coefficient+60.*total_coefficient)*1.2
 assert abs(damage_inputs[-1]-expected)<.000001,(kind,damage_inputs[-1],expected)
 assert v.g['udg_xingdong_dian'][1]==4
for kind,ability,ultimate,expected in [('HZ03','AZ35',5,60.*1.1*1.2*1.5),('H008','AZ31',1,20.*3.*1.2)]:
 u.kind=rawcode(kind);event['ability']=rawcode(ability);event['target']=None
 enemy.life=1000.;u.mana=10.;v.g['udg_xingdong_dian'][1]=5
 v.g['HopeJob_Awakened'][1]=True;v.g['HopeJob_UltimateKind'][1]=ultimate;v.g['HopeJob_LastCast'][1]=-1
 cast_job()
 assert abs(damage_inputs[-1]-expected)<.000001,(kind,damage_inputs[-1],expected)
 assert (u.mana,v.g['udg_xingdong_dian'][1])==(7.,3)

# The fix delegates to the existing damage handler; it does not alter ordinary
# combat critical chance, equipment reactions, resistance or kill statistics.
original=(R/'war3map.j').read_text()
assert body('Trig____________________005Actions')[0]==body('Trig____________________005Actions',original)[0]
print('PASS: shipped hidden spells and Q/awakening dispatch preserve costs, stage/turn/target gates, independent limits, healing caps, actual-damage drain, and one final damage multiplier.')
