"""Battle/run tabs backed by the same original settlement observation."""
import re
from modern_choices_patch import block,replace
GLOBALS='''
real array HopeDamage_Total
integer HopeDamage_Panel=0
integer HopeDamage_Text=0
integer HopeDamage_BattleButton=0
integer HopeDamage_TotalButton=0
boolean HopeDamage_Run=false
integer array HopeDamage_Order
'''
LATE='''function HopeDamage_Battle takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() then
set HopeDamage_Run=false
endif
endfunction
function HopeDamage_RunClick takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() then
set HopeDamage_Run=true
endif
endfunction
function HopeDamage_Value takes integer i returns real
if HopeDamage_Run then
return HopeDamage_Total[i]
endif
return udg_Shuchu_dm_tj[i]
endfunction
function HopeDamage_Number takes real value returns string
local integer exponent=0
if value<10000. then
return R2SW(value,1,0)
elseif value<100000000. then
return R2SW(value/10000.,1,1)+"万"
elseif value<1000000000000. then
return R2SW(value/100000000.,1,1)+"亿"
endif
loop
exitwhen value<1000. or exponent>=36
set value=value/1000.
set exponent=exponent+3
endloop
return R2SW(value,1,1)+"e"+I2S(exponent)
endfunction
function HopeDamage_Refresh takes nothing returns nothing
local integer i=1
local integer j=0
local integer count=0
local integer id=0
local real amount=0.
local real sum=0.
local string text=""
local string name=""
local string line=""
loop
exitwhen i>6
if udg_hero[i]!=null or HopeDamage_Total[i]>0. then
set j=count
loop
exitwhen j<=0
exitwhen HopeDamage_Value(HopeDamage_Order[j])>=HopeDamage_Value(i)
set HopeDamage_Order[j+1]=HopeDamage_Order[j]
set j=j-1
endloop
set HopeDamage_Order[j+1]=i
set count=count+1
set sum=sum+HopeDamage_Value(i)
endif
set i=i+1
endloop
set i=1
loop
exitwhen i>count
set id=HopeDamage_Order[i]
set name=GetPlayerName(Player(id-1))
if StringLength(name)>18 then
set name="玩家 "+I2S(id)
endif
set amount=HopeDamage_Value(id)
set line=I2S(i)+". "+name+"  "+HopeDamage_Number(amount)
if sum>0. then
set line=line+" ("+R2SW(amount/sum*100.,1,1)+"%)"
endif
set text=text+YDWEGetPlayerColorString(Player(id-1),line)+"|n"
set i=i+1
endloop
if count==0 then
set text="等待英雄进入本局。|n"
endif
set text=text+"|cff999999结算伤害含溢出|r"
call HopeJob_SetText(HopeDamage_Text,text)
if HopeDamage_Run then
call HopeJob_SetText(HopeDamage_BattleButton,"本场")
call HopeJob_SetText(HopeDamage_TotalButton,"|cffffd060本局|r")
else
call HopeJob_SetText(HopeDamage_BattleButton,"|cffffd060本场|r")
call HopeJob_SetText(HopeDamage_TotalButton,"本局")
endif
endfunction
function HopeDamage_Create takes nothing returns nothing
local integer f=0
set HopeDamage_Panel=HopeQoL_Surface("HopeDamagePanel",.642,.574,.144,.117)
set f=HopeQoL_Label("HopeDamageTitle",HopeDamage_Panel,.007,-.006,.032,.014,"伤害榜")
set HopeDamage_BattleButton=HopeQoL_Button("HopeDamageBattle",HopeDamage_Panel,.045,-.005,.043,.017,"本场")
call HopeQoL_Bind(HopeDamage_BattleButton,function HopeDamage_Battle,false)
set HopeDamage_TotalButton=HopeQoL_Button("HopeDamageTotal",HopeDamage_Panel,.094,-.005,.043,.017,"本局")
call HopeQoL_Bind(HopeDamage_TotalButton,function HopeDamage_RunClick,false)
set HopeDamage_Text=HopeQoL_Label("HopeDamageText",HopeDamage_Panel,.007,-.029,.130,.081,"")
call DzFrameSetFont(HopeDamage_Text,"Fonts\\\\ZiTi.ttf",.0085,0)
endfunction
'''
def apply(src):
    src=src.replace('endglobals',GLOBALS+'\nendglobals',1)
    f=block(src,'Trig____________________005Actions')
    line=next(l for l in f.splitlines() if l.startswith('set udg_Shuchu_dm_tj['))
    src=src.replace(line,line+'\n'+line.replace('udg_Shuchu_dm_tj','HopeDamage_Total'),1)
    # Remove integer conversion/update calls from the hidden legacy board.
    src=re.sub(r'^call LeaderboardSetPlayerItemValueBJ\(.*?\)\n','',src,flags=re.M)
    src=src.replace('call LeaderboardDisplay(udg_shuchubang,true)','call LeaderboardDisplay(udg_shuchubang,false)')
    src=src.replace('function main takes nothing returns nothing',LATE+'\nfunction main takes nothing returns nothing',1)
    return src
