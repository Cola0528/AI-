"""Battle/run tabs backed by the same original settlement observation."""
import re
from modern_choices_patch import block,replace
GLOBALS='''
real array HopeDamage_Total
integer HopeDamage_Panel=0
integer HopeDamage_Text=0
integer HopeDamage_BattleButton=0
integer HopeDamage_TotalButton=0
boolean HopeDamage_Run=false
integer array HopeDamage_Order
'''
LATE='''function HopeDamage_Battle takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() then
set HopeDamage_Run=false
endif
endfunction
function HopeDamage_RunClick takes nothing returns nothing
if DzGetTriggerUIEventPlayer()==GetLocalPlayer() then
set HopeDamage_Run=true
endif
endfunction
function HopeDamage_Value takes integer i returns real
if HopeDamage_Run then
return HopeDamage_Total[i]
endif
return udg_Shuchu_dm_tj[i]
endfunction
function HopeDamage_Refresh takes nothing returns nothing
local integer i=1
local integer j=0
local integer count=0
local integer id=0
local real amount=0.
local real sum=0.
local string text=""
local string name=""
loop
exitwhen i>6
if udg_hero[i]!=null or HopeDamage_Total[i]>0. then
set j=count
loop
exitwhen j<=0
exitwhen HopeDamage_Value(HopeDamage_Order[j])>=HopeDamage_Value(i)
set HopeDamage_Order[j+1]=HopeDamage_Order[j]
set j=j-1
endloop
set HopeDamage_Order[j+1]=i
set count=count+1
set sum=sum+HopeDamage_Value(i)
endif
set i=i+1
endloop
set i=1
loop
exitwhen i>count
set id=HopeDamage_Order[i]
set name=GetPlayerName(Player(id-1))
if StringLength(name)>18 then
set name="玩家 "+I2S(id)
endif
set amount=HopeDamage_Value(id)
set text=text+I2S(i)+". "+name+"  "+R2SW(amount,1,0)
if sum>0. then
set text=text+" ("+R2SW(amount/sum*100.,1,1)+"%)"
endif
set text=text+"|n"
set i=i+1
endloop
if count==0 then
set text="等待英雄进入本局。|n"
endif
set text=text+"|n结算伤害（含溢出），与原输出榜口径一致。"
call HopeJob_SetText(HopeDamage_Text,text)
if HopeDamage_Run then
call HopeJob_SetText(HopeDamage_BattleButton,"本场战斗")
call HopeJob_SetText(HopeDamage_TotalButton,"|cffffd060本局总计|r")
else
call HopeJob_SetText(HopeDamage_BattleButton,"|cffffd060本场战斗|r")
call HopeJob_SetText(HopeDamage_TotalButton,"本局总计")
endif
endfunction
function HopeDamage_Create takes nothing returns nothing
local integer f=0
set HopeDamage_Panel=HopeQoL_Surface("HopeDamagePanel",.574,.574,.212,.163)
set f=HopeQoL_Label("HopeDamageTitle",HopeDamage_Panel,.010,-.007,.190,.018,"伤害榜")
set HopeDamage_BattleButton=HopeQoL_Button("HopeDamageBattle",HopeDamage_Panel,.010,-.029,.090,.025,"本场战斗")
call HopeQoL_Bind(HopeDamage_BattleButton,function HopeDamage_Battle,false)
set HopeDamage_TotalButton=HopeQoL_Button("HopeDamageTotal",HopeDamage_Panel,.110,-.029,.090,.025,"本局总计")
call HopeQoL_Bind(HopeDamage_TotalButton,function HopeDamage_RunClick,false)
set HopeDamage_Text=HopeQoL_Label("HopeDamageText",HopeDamage_Panel,.010,-.060,.192,.097,"")
endfunction
'''
def apply(src):
    src=src.replace('endglobals',GLOBALS+'\nendglobals',1)
    f=block(src,'Trig____________________005Actions')
    line=next(l for l in f.splitlines() if l.startswith('set udg_Shuchu_dm_tj['))
    src=src.replace(line,line+'\n'+line.replace('udg_Shuchu_dm_tj','HopeDamage_Total'),1)
    # Remove integer conversion/update calls from the hidden legacy board.
    src=re.sub(r'^call LeaderboardSetPlayerItemValueBJ\(.*?\)\n','',src,flags=re.M)
    src=src.replace('call LeaderboardDisplay(udg_shuchubang,true)','call LeaderboardDisplay(udg_shuchubang,false)')
    src=src.replace('function main takes nothing returns nothing',LATE+'\nfunction main takes nothing returns nothing',1)
    return src
